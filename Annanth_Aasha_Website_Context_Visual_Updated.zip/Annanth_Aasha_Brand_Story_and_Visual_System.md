# Annanth Aasha Foundation — Website Page Context & Visual System
## Final Content Architecture Reference

## 1. Brand premise

**Annanth Aasha is a learning and impact ecosystem where opportunity keeps moving.**

The public website must answer five questions in order:

1. Why does this matter?
2. What are we building?
3. How does it work?
4. How can I see and understand the impact?
5. How can I become part of it?

---

## 2. Page-by-page narrative

### Home — “Where learning begins, opportunity can keep moving.”

**Purpose:** Establish the human reason before explaining the technology.

**Hero direction:**
- Every child can have a schoolbook.
- Not every child gets the same chance to reach its meaning.
- Annanth Aasha builds a learning and impact ecosystem around that gap.

**Primary actions:**
- See how learning works
- Follow the journey

**Secondary actions:**
- Build with us
- Support a cohort

**Visual:** child with schoolbook in a real learning environment; avoid pity imagery.

---

### About — “Why Annanth Aasha exists.”

Tell the story:

**What we noticed → What we believe → What we are building → What we are learning → Where we are going**

Do not write a corporate history page.

The organisation should sound honest about being a builder still learning.

---

### Learning — “The book is the beginning, not the boundary.”

Explain:

**Schoolbook → Understanding → Practice → Confidence**

Cover:
- responsive learning layer
- visual explanations
- worked examples
- practice
- immediate feedback
- language bridge
- offline capability

Keep AI secondary.

---

### Language Bridge — “Enter English without leaving home.”

Explain why language can create distance between the child and the concept.

The bridge preserves English learning while making meaning accessible through familiar language.

Avoid positioning Hindi as a replacement for English.

---

### Eco Seva — “Learning that keeps growing.”

The activity is not a planting photograph.

The journey is:

**Plant → Care → Observe → Return → Learn → Grow**

A future/live timeline can show approximately 15-day progress checkpoints where the actual operating model supports them.

---

### Jal Seva — “Learning that flows into responsibility.”

The journey is:

**Understand water → Notice → Act → Care → Observe → Continue**

Show water as a lived responsibility, not merely a campaign.

---

### Aasha Economy — “When effort has value.”

Explain:

**Learn → Act → Earn → Save → Choose**

Clarify:

- rewards are not payment for marks
- XP and Aasha Coins are learning/motivation mechanisms
- saving teaches patience
- choice creates agency

Avoid casino/financial-app aesthetics.

---

### Cohorts — “Proof points, not destinations.”

The first cohort is an opportunity to:

- listen
- observe
- measure
- learn
- improve
- validate

Never manufacture impact.

Use real evidence only.

---

### Impact — “Impact you can follow.”

Core experience:

**Support → Learning → Action → Evidence → Reflection → Progress → Next step**

A visitor should understand:

- what was planned
- what happened
- what children experienced
- what evidence exists
- what was learned
- what happens next

This is the core transparency experience.

---

### Support / Contribute — “What does your contribution build?”

Explain where support goes in terms of capabilities:

- learning infrastructure
- content transformation
- technology
- learning centres
- Seva equipment
- measurement
- delivery
- platform development

Every funding category should answer:

**What capability does this create?**

**Who benefits?**

**How can progress be seen?**

---

### Partner / Cohort Sponsor — “Follow the journey.”

A sponsor is invited to support a cohort and understand its progress over time.

The intended experience:

**Cohort begins → Learning milestone → Seva/action → Evidence → Progress → Reflection → Next milestone**

Do not claim 15-day reporting is live unless it is actually implemented.

---

### Volunteer / Build With Us — “Bring what you know.”

Invite:

- learning design
- teaching
- engineering
- product
- AI and technology
- content
- measurement
- community engagement
- operations
- partnerships
- storytelling

Position people as builders, not free labour.

---

### Sustainability — “From support to self-reliance.”

Show the long-term direction:

**Philanthropic foundation → Proof → Responsible expansion → Institutional adoption → Earned revenue → Wider subsidised access**

Clearly label this as a pathway/ambition unless individual stages are already operational.

---

## 3. Global visual system

### Design personality

**Editorial, warm, grounded, intelligent, Indian, hopeful.**

### Suggested palette

Use the existing brand identity where already established. If a new public-site palette is required, derive it from:

- deep ink/navy for trust and readability
- muted teal/green for learning and nature
- warm cream/paper for background
- restrained gold for hope/choice/reward
- natural earth tones for Seva sections
- semantic red/green only for system states

Do not turn the entire site into a rainbow.

### Typography

Prefer a highly readable humanist sans-serif with strong Devanagari support where bilingual content appears.

Use:
- large editorial headings
- comfortable body line-height
- clear hierarchy
- restrained uppercase labels
- short paragraphs

### Photography

Prioritise authentic, contextual photography.

Subjects:
- children reading
- hands turning pages
- children discussing learning
- teachers facilitating
- planting/caring
- water responsibility
- small group learning
- real community environments

Avoid:
- crying children
- staged “charity” scenes
- exaggerated poverty
- generic corporate volunteers smiling at camera
- fake-looking AI children

---

## 4. Signature interaction patterns

### Journey line

Use for:
- cohort progress
- impact
- Eco Seva growth
- learning journey

### Living timeline

Each milestone may contain:
- date
- what happened
- evidence
- observation
- reflection
- next step

### Evidence drawer

Allow a user to inspect supporting evidence without overwhelming the primary story.

### Before / after understanding

Use for learning content:
- difficult textbook passage
- supported explanation
- child practice
- understanding check

### Growth loop

Use for the Infinite Loop of Hope:

**Understand → Learn → Act → Earn → Save → Grow → Contribute → Enable**

---

## 5. Component rules

Do not turn every section into cards.

Mix:
- editorial sections
- full-width imagery
- timelines
- pull quotes
- diagrams
- evidence blocks
- numbers
- short text
- interactive journeys
- accordions
- subtle motion

Every component must have a reason to exist.

---

## 6. Copy rules

### Good

“Here is what happened.”

“Here is what we learned.”

“Here is what we are building next.”

### Avoid

“We are revolutionising education.”

“Transforming millions of lives.”

“Powered by cutting-edge AI.”

The brand earns trust through specificity, not adjectives.

---

## 7. Accessibility and dignity

All public pages must:
- meet accessible contrast
- support keyboard navigation
- use meaningful alt text
- preserve heading hierarchy
- work on mobile
- respect reduced motion
- avoid flashing effects
- protect children's identifying information
- avoid publishing sensitive child information without appropriate safeguards

---

## 8. Final acceptance test

A visitor should finish the site understanding:

> Annanth Aasha begins with learning, connects learning to responsibility, makes the journey visible, and wants today's support to help create tomorrow's opportunity.

If the visitor instead thinks:

> “This is an AI education startup asking for donations,”

the website has failed the brand test.
