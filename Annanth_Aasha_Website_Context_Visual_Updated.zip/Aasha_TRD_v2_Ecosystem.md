# Annanth Aasha Foundation — Brand & Product Context

## Purpose of this document

This package translates the existing Aasha product/technical documentation into the **Annanth Aasha Foundation learning and impact ecosystem** that the public website should communicate.

The website is not to be positioned primarily as an AI product, an ed-tech startup, or a donation campaign.

### Core positioning

> **We are not building a charity programme. We are building a learning and impact ecosystem where opportunity keeps moving.**

### Learning philosophy

> **Learning should not end at the page. It should become something a child can understand, practise and live.**

### Technology philosophy

> **Technology is the lever. The child is the purpose.**

### Transparency philosophy

> **We don't want your contribution to become a report. We want it to become a journey you can see, understand and continue to be part of.**

### Hope philosophy

> **Hope becomes stronger when it keeps moving.**

---

## The ecosystem

The Annanth Aasha journey connects:

**Schoolbook → Understanding → Practice → Action → Responsibility → Effort → Value → Saving → Growth → Contribution → Next opportunity**

Key ecosystem components:

- **Aasha Learning** — responsive learning around the child's prescribed schoolbook/curriculum
- **Language Bridge / LLE** — support that helps a child enter English learning without losing the language in which they naturally understand the world
- **Eco Seva** — learning connected to caring for nature, including an ongoing care-and-observation journey rather than a one-day planting event
- **Jal Seva** — learning connected to water awareness, care and continued action
- **Aasha Economy** — an educational experience of effort, value, saving, patience and choice; not payment for marks or learning
- **Cohorts** — small groups used to learn, measure, improve and validate the model before responsible expansion
- **Impact Trail** — dated evidence, milestones, reflection and next steps so support can be followed rather than disappearing into a delayed report
- **Self-reliance pathway** — philanthropic support helps establish and validate the model; future earned revenue/licensing can help sustain access and subsidise participation

---

## Present reality vs future vision

The website must never present planned capabilities as already operational.

### Current validated technical foundation

The supplied product documentation records a working prototype validated across NCERT Class 8 Mathematics Chapters 1–3.

### Broader audience

Annanth Aasha's learning vision is for **Classes 1–10**, with age/stage-appropriate presentation. Class 8 Mathematics is the current validated technical proof point, not the limit of the organisation's educational audience.

### Future capabilities

Features such as sponsor-facing continuous impact trails, broader cohort reporting, school licensing, multi-grade expansion, teacher dashboards and cross-device accounts must be labelled according to their actual implementation status.

Use:
- **Today**
- **Being built**
- **What comes next**
when appropriate.

Never fabricate data, outcomes, testimonials, beneficiaries, activity counts, photographs, locations or reporting history.

---

## Brand vocabulary

Prefer:

- child / learner
- participant
- cohort
- contribution
- support
- partner
- learning journey
- impact trail
- evidence
- milestone
- reflection
- responsibility
- capability
- opportunity
- build
- follow
- grow
- enable

Avoid or minimise:

- beneficiary
- underprivileged
- helpless
- charity case
- transforming lives
- revolutionary AI
- disruptive
- cutting-edge
- scalable solution
- leveraging technology
- one-time impact
- annual thank-you report

The organisation should never use poverty or children's vulnerability as the primary emotional conversion mechanism.

---

## Visual direction

The public website should feel:

**Human + Learning + Nature + Hope + Responsibility + Progress**

Prefer:

- warm editorial photography
- children learning with dignity and agency
- books, hands, plants, water and real environments
- subtle Indian context
- tactile/paper/book-inspired details
- natural whitespace
- restrained technology imagery
- visual timelines
- evidence trails
- diagrams that explain relationships
- real progress states
- gentle motion used to communicate growth and continuity

Avoid:

- generic NGO stock photography
- donation-counter aesthetics
- excessive gradients
- neon SaaS styling
- glassmorphism everywhere
- repetitive icon/card grids
- AI-generated corporate-looking children
- dashboards as the primary public experience
- visual effects that compete with the story

---

## Website narrative sequence

The site should feel like one connected story:

1. **Why** — a child can have the book without reaching its meaning
2. **What** — Annanth Aasha builds a responsive learning layer
3. **How** — learning is supported through explanation, language, practice and exploration
4. **Beyond the page** — learning becomes Eco Seva, Jal Seva and responsibility
5. **Aasha Economy** — effort can become value, saving and choice
6. **Cohorts** — start small, observe honestly, learn and improve
7. **Impact** — show the journey, evidence, reflection and next milestone
8. **Sustainability** — move gradually from philanthropic foundation toward earned sustainability
9. **Participation** — contribute money, time, skills, partnership or knowledge

---

## Sponsor/cohort transparency principle

A cohort sponsor should not experience:

**Contribution → photograph → annual report**

The intended experience is:

**Support → cohort begins → learning milestone → Seva/action → evidence → approximately 15-day progress/check-in where operationally appropriate → reflection → next milestone → continued growth**

### Eco Seva example

Do not reduce the activity to:

> “50 trees planted.”

The meaningful journey is:

**Plant → Care → Observe → Return → Learn → Grow**

The same principle applies to Jal Seva and learning.

If a 15-day reporting system is not yet implemented, the website must describe it as the intended model, not as an existing service.


---

# Technical Requirements Document (TRD)
## Aasha — Learning Engine within the Annanth Aasha Learning & Impact Ecosystem
### Technical Architecture, Data Models, Web Experience, and Build Specifications

**Document Version:** 1.0
**Date:** August 2026
**Author:** Engineering Team, Annanth Aasha Foundation
**Status:** Draft for Review
**Companion document:** Aasha PRD v2

---

## 0. Public Website Context Requirements

### 0.1 Product vs ecosystem

The technical learning engine described in this TRD is one layer of Annanth Aasha. The public website must not expose internal implementation details as the primary story.

Technical terms such as:
- AI pipeline
- JSON STEPS
- HTML assembly
- runtime DOM testing
- LLE engine
- Canvas
- localStorage
- build-time patching

belong in technical documentation or an appropriate methodology section, not in the primary emotional narrative.

### 0.2 Impact trail data readiness

The architecture should remain extensible for future cohort and activity records. A future impact record may contain:

```text
cohort
activity
activity_type
date
location/context
participants
evidence
observation
reflection
status
next_milestone
```

Do not fabricate records. Empty states should explain what will eventually be visible.

### 0.3 Current / building / future states

UI components representing planned features must have explicit status treatment. Do not show future sponsor dashboards, 15-day reporting, school licensing or cross-device accounts as if they are already live unless the codebase actually implements them.

### 0.4 Visual system direction

The existing technical design tokens were created primarily for the learning module. The public Foundation website may use a warmer editorial visual system while retaining semantic states for success, warning and error.

The public experience should prioritise:
- human photography
- books and learning
- nature and water
- progress trails
- evidence
- restrained motion
- accessible typography
- natural whitespace

Avoid making the public site look like a generic SaaS dashboard.

## 1. System Architecture

### 1.1 High-Level Architecture

Aasha is a build-time pipeline that transforms NCERT PDFs into self-contained HTML files. There is no runtime backend — the output is a single HTML file that runs entirely in the browser.

```
┌─────────────────────────────────────────────────────────┐
│                    BUILD PIPELINE                        │
│                                                          │
│  NCERT PDF ──→ Chapter Text ──→ STEPS Array (JSON)      │
│       │              │                  │                │
│       │         pdfminer           AI-generated          │
│       │         extraction         step content           │
│       │                                  │               │
│       │     ┌────────────────────────────┘               │
│       │     │                                            │
│       │     ▼                                            │
│       │  Engine Assembly                                 │
│       │     ├── CSS template (mobile-first, 600px)       │
│       │     ├── LLE Engine (CONN dict + rt() + applyLLE)│
│       │     ├── STEPS JSON (chapter-specific)            │
│       │     └── App Engine (renderers + gamification)    │
│       │                  │                               │
│       │                  ▼                               │
│       │           Validation Gates                       │
│       │             ├── node --check (syntax)            │
│       │             └── Runtime DOM test (all steps)    │
│       │                  │                               │
│       └──────────────────┘                               │
│                          │                               │
│                          ▼                               │
│              Single HTML File (offline)                   │
│              (CSS + JS + data embedded)                   │
└─────────────────────────────────────────────────────────┘
```

### 1.2 Runtime Architecture (In-Browser)

The delivered HTML file contains three major JavaScript components:

```
HTML File (single, offline, ~100KB)
│
├── CSS (embedded <style>)
│   ├── Design tokens (--brand, --green, --gold, etc.)
│   ├── Layout (max-width 600px, sticky header, bottom bar)
│   ├── Step type styles (.we-card, .quiz-opt, .feedback, etc.)
│   ├── Animation (slideIn, pop, pulse, tpulse)
│   └── Responsive (mobile-first, touch-action: manipulation)
│
├── LLE Engine (JavaScript)
│   ├── CONN dictionary (modals + connectors + cue verbs/adverbs/adjectives)
│   ├── WM dictionary (full word-meaning dictionary, for tap-to-reveal)
│   ├── rt(text) function — processes text into tappable + auto-annotated HTML
│   ├── applyLLE() function — applies rt() to all content elements on screen
│   └── showWord() function — opens Hindi meaning dialog on tap
│
├── STEPS Array (JSON)
│   ├── Step objects with type (t) and type-specific fields
│   ├── Chapter-specific content (not generic templates)
│   └── Generated by AI from NCERT chapter text
│
└── App Engine (JavaScript)
    ├── State: sIdx, xp, coins, level, streak, weStepIdx, solveStepIdx
    ├── init() — sets up event listeners, renders first step
    ├── render() — dispatches to step-type renderers
    ├── Step renderers: renderIntro, renderTutor, renderFormula, renderWE,
    │   renderQuiz, renderSolve, renderRapidFire, renderMemoryMatch,
    │   renderMilestone, renderComplete, renderShop
    ├── Sim renderers: renderIxBalance, renderIxPolygonBuilder,
    │   renderIxAngleSum, renderIxExteriorAngle, renderIxQuadExplorer, etc.
    ├── Gamification: updateStats(), checkLevelUp(), confetti()
    ├── Navigation: next(), back()
    └── Assessment: checkQuiz(), checkSolve(), endRF()
```

---

## 2. File Organization (Build Sources)

Build sources are stored in `/workspace/notes/` (durable across sandbox restarts):

| File | Purpose | Status |
|------|---------|--------|
| `build_v3.py` | CSS/HTML head template | Original |
| `build_v3_p2.py` | LLE engine (v1 — has old CONN with is/are/was/etc.) | Superseded by v2 |
| `build_v3_p2_v2.py` | LLE engine v2 (CONN = modals+connectors+cue verbs, max 4) | Current |
| `build_v3_p4.py` | App object base code (unpatched) | Original |
| `app_final.py` | Fully patched app_code (all 9 patches applied, all sim renderers) | Current |
| `app_patched_ch3.py` | Earlier patched version (Ch3 specific) | Legacy |

Extracted chapter texts and intermediate files are in `/scratch/work/` (ephemeral — may not persist between sessions).

---

## 3. Data Models

### 3.1 STEPS Array Structure

Each element in the STEPS array is a JSON object with a `t` (type) field and type-specific fields:

```json
[
  {
    "t": "intro",
    "icon": "⚖️",
    "title": "Linear Equations in One Variable",
    "sub": "Class 8 Math — Chapter 2",
    "intro": "Think about it — you go to a shop..."
  },
  {
    "t": "tutor",
    "icon": "💡",
    "title": "What is an Equation?",
    "body": "An equation is a statement that two expressions are equal..."
  },
  {
    "t": "formula",
    "title": "Key Terms You Must Know",
    "formulas": [
      {"label": "Equation", "expr": "LHS = RHS", "note": "Example: 2x-3=7"}
    ]
  },
  {
    "t": "quiz",
    "q": "Quick Check: Which of these is a linear equation?",
    "diff": "easy",
    "opts": [
      {"t": "4x + 7 = 15", "c": true},
      {"t": "x² = 9", "c": false, "m": "Power is 2.", "correctMethod": "Not linear."}
    ]
  },
  {
    "t": "we",
    "q": "Example 1: Solve 2x - 3 = 7",
    "steps": [
      {"text": "Add 3 to both sides..."},
      {"text": "Divide by 2..."},
      {"text": "x = 5. Check: LHS = RHS."}
    ],
    "answer": "x = 5"
  },
  {
    "t": "solve",
    "q": "Ex 2.1 Q1: Solve x - 2 = 7",
    "steps": [
      {"type": "input", "prompt": "Add 2. x = 7 + ?", "answer": "2", "m": "...", "correctMethod": "x = 9"}
    ]
  },
  {
    "t": "ix_balance_sim",
    "instruction": "Drag the slider to find x that balances 3x + 2 = 11."
  },
  {
    "t": "milestone",
    "icon": "🏆",
    "title": "Basic Equations Mastered!",
    "xp": 50,
    "next": "Now: Word problems!"
  },
  {
    "t": "rapid_fire",
    "qs": [
      {"q": "An equation must have...", "opts": ["= sign","x sign"], "ans": 0}
    ]
  },
  {
    "t": "memory_match",
    "pairs": [
      {"en": "Equation", "hi": "समीकरण"}
    ]
  },
  {
    "t": "complete",
    "icon": "⚖️",
    "title": "Chapter 2 Complete!",
    "sub": "Linear Equations — Mastered!"
  }
]
```

### 3.2 Step Types Reference

| Type | `t` value | Fields | Renderer |
|------|-----------|--------|-----------|
| Intro | `intro` | icon, title, sub, intro | renderIntro |
| Tutor | `tutor` | icon, title, body | renderTutor (inline in render) |
| Formula | `formula` | title, formulas[] | renderFormula (inline) |
| Real Example | `real_example` | icon, title, body | renderRealExample (inline) |
| Text | `text` | title, body | renderText (inline) |
| Worked Example | `we` | q, steps[], answer | renderWE |
| Quiz | `quiz` | q, diff, opts[] | renderQuiz + checkQuiz |
| Solve | `solve` | q, steps[] (input type) | renderSolve + checkSolve |
| Simulation | `ix_*` | instruction | renderIx* (per-sim) |
| Milestone | `milestone` | icon, title, xp, next | renderMilestone (inline) |
| Rapid Fire | `rapid_fire` | qs[] | renderRapidFire |
| Memory Match | `memory_match` | pairs[] | renderMemoryMatch |
| Completion | `complete` | icon, title, sub | renderComplete (inline) |

---

## 4. LLE (Language Layer Engine) — Technical Specification

### 4.1 CONN Dictionary Specification

The CONN dictionary contains understanding-cue words that are auto-annotated inline. It is divided into three categories:

**Category A: Modals (20 entries)**
Words that express possibility, necessity, obligation, or ability:

```javascript
"can":"सकता है", "could":"सकता था", "will":"करेगा", "would":"करेगा",
"shall":"करेगा", "should":"करना चाहिए", "must":"ज़रूरी है", "may":"सकता है",
"might":"शायद कर सके", "need":"ज़रूरत है", "need to":"ज़रूरत है करना",
"have to":"करना पड़ता है", "had to":"करना पड़ा", "ought to":"करना चाहिए",
"be able to":"सक्षम है", "used to":"पहले करता था", "dare":"हिम्मत करना",
"had better":"बेहतर होगा", "be going to":"करने वाला है", "be supposed to":"करना अपेक्षित है"
```

**Category B: Connectors (80+ entries)**
Words that connect ideas — cause, contrast, condition, sequence, addition, conclusion:

```javascript
// Coordinating
"and":"और", "but":"लेकिन", "or":"या", "so":"इसलिए", "because":"क्योंकि",
"also":"भी", "too":"भी", "either":"या भी", "neither":"न ही",
// Cause/Effect
"because of":"के कारण", "due to":"के कारण", "since":"क्योंकि",
"therefore":"इसलिए", "thus":"इस प्रकार", "hence":"इसलिए",
"as a result":"परिणामस्वरूप", "so that":"ताकि", "consequently":"परिणामस्वरूप",
// Condition
"if":"अगर", "unless":"जब तक नहीं", "otherwise":"नहीं तो", "then":"तब",
"even if":"भले ही", "only if":"केवल तभी", "provided":"बशर्ते",
// Contrast
"although":"हालांकि", "though":"हालांकि", "however":"हालांकि",
"yet":"फिर भी", "still":"फिर भी", "whereas":"जबकि", "instead":"इसके बजाय",
// Sequence/Time
"before":"पहले", "after":"बाद में", "when":"जब", "while":"जब",
"until":"जब तक", "finally":"अंत में", "next":"अगला", "as soon as":"जैसे ही",
// Addition
"furthermore":"इसके अलावा", "moreover":"इसके अलावा", "besides":"इसके अलावा",
"in addition":"इसके अलावा", "especially":"विशेष रूप से", "particularly":"खासकर",
// Conclusion
"overall":"कुल मिलाकर", "in conclusion":"निष्कर्ष में",
"to sum up":"संक्षेप में", "in short":"संक्षेप में",
// ... (full list in source code)
```

**Category C: Understanding-Cue Verbs, Adverbs, Adjectives**
Words that carry the meaning of the sentence — action verbs, descriptors, and modifiers that, when translated, give the student an instant understanding anchor:

```javascript
"equals":"बराबर है", "means":"मतलब", "gives":"देता है",
"shows":"दिखाता है", "consider":"सोचो", "observe":"देखो",
"notice":"ध्यान दो", "remember":"याद रखो", "always":"हमेशा",
"never":"कभी नहीं", "exactly":"ठीक", "directly":"सीधे",
"important":"ज़रूरी", "equal":"बराबर", "opposite":"विपरीत",
"parallel":"समान्तर", "perpendicular":"लंबवत", "consecutive":"क्रमागत"
// (grows with each chapter — added as needed based on sentence context)
```

**Design rules for CONN entries:**
1. Hindi must be conversational/colloquial, NOT dictionary-formal
   - "because" → "क्योंकि" (not "कारण कि")
   - "should" → "करना चाहिए" (not "कर्तव्य है")
   - "must" → "ज़रूरी है" (not "अनिवार्य है")
2. Hindi must be short — 1-3 words max
3. Hindi must build understanding, not replace English
4. Math domain terms (equation, variable, coefficient, etc.) are NOT in CONN — they are tap-only

### 4.2 rt() Function — Text Processing Algorithm

The `rt(text)` function processes a text string and returns HTML where:
- Understanding-cue words (from CONN) are auto-annotated inline with Hindi (max 4 per sentence)
- All other words are wrapped as tappable elements (`.wd` class)

```
Algorithm:
1. Sort CONN keys by length (longest first) for multi-word matching
2. Initialize connCount = 0
3. Iterate character by character through the text:
   a. On sentence boundary (., !, ?, ,) → reset connCount = 0
   b. On HTML tag (<...>) → pass through unchanged
   c. At word boundary (not preceded by a letter):
      - Try to match each CONN key (longest first)
      - If matched AND connCount < 4:
        → Wrap as .cn (connecting word) with inline Hindi: word (हिंदी)
        → Increment connCount
      - If matched AND connCount >= 4:
        → Wrap as .wd (tappable) with Hindi in data attribute
      - If not matched:
        → Wrap as .wd (tappable) with WM lookup if available
4. Return processed HTML
```

### 4.3 applyLLE() Function

```javascript
function applyLLE() {
  // Selectors for all content-bearing elements
  var sels = ".bt,.we-question,.we-step,.quiz-opt-text,.instruction,.hint,
    .formula-box .f-label,.f-expr,.f-note,.misconception,.correct-method,
    .feedback,.milestone-text,.milestone-next,.discovery-box .d-text,
    .discovery-box .d-title,.intro-title,.intro-sub,.complete-title,
    .complete-sub,.tutor-box,.real-example,.visual-title,.we-tag";
  var els = document.querySelectorAll(sels);
  for (var i = 0; i < els.length; i++) {
    var el = els[i];
    if (el.querySelector(".wd") || el.querySelector(".cn")) continue; // already processed
    if (el.tagName === "BUTTON" || el.tagName === "INPUT") continue;
    var h = el.innerHTML;
    if (!h || h.trim().length < 3) continue;
    try { el.innerHTML = rt(h); } catch(e) {}
  }
}
```

Called after every render to process new content.

### 4.4 Word Dialog (showWord)

When a `.wd` or `.cn` element is tapped:
- Opens `<dialog id="wordDialog">`
- Shows: word (large, purple), Hindi translation (purple), description (gray)
- For `.cn` elements: description = "Connecting word"
- For `.wd` elements: description = brief context or "Hindi meaning not available"

---

## 5. App Engine — Technical Specification

### 5.1 State Variables

```javascript
var App = {
  sIdx: 0,              // current step index
  xp: 0,                // experience points
  coins: 0,              // coins earned
  streak: 0,             // consecutive correct answers
  level: 1,              // current level
  answered: false,       // quiz/solve answered flag
  selOpt: null,          // selected quiz option index
  shuffledOpts: null,    // shuffled quiz options
  solveStepIdx: 0,       // current solve sub-step
  solveAnswered: false,  // solve completed flag
  weStepIdx: undefined,  // current worked-example sub-step
  _prevSIdx: undefined,  // previous step index (for reset logic)
  rfIdx: 0, rfScore: 0,  // rapid fire state
  mmFlipped: [], mmMatched: 0,  // memory match state
  // ... more state
};
```

### 5.2 Engine Patches (Applied at Build Time)

The base App code (`build_v3_p4.py`) is patched at build time. These patches represent accumulated learnings from building Chapters 1–3:

#### Patch 1: renderIntro — Dynamic Intro Text
**Problem:** Original code hardcoded a Hindi intro ("Dekho yaar, rational numbers...").
**Fix:** Uses `step.intro` from STEPS data.
```javascript
var introText = step.intro || "Welcome!";
// ... uses rt(introText) to render
```

#### Patch 2: renderWE — Step-by-Step Reveal
**Problem:** Original showed all steps at once.
**Fix:** Uses `weStepIdx` counter. Shows steps 0..weStepIdx. Button: "Next Step (X of Y)".
```javascript
if (this.weStepIdx === undefined) this.weStepIdx = 0;
var idx = this.weStepIdx;
if (idx >= step.steps.length) {
  cb.textContent = "Continue"; cb.className = "btn btn-green";
  return;
}
// Render steps 0..idx with current step highlighted
```

#### Patch 3: renderQuiz — Fisher-Yates Shuffle
**Problem:** Correct answer was always option A.
**Fix:** Shuffles options, stores in `shuffledOpts`.
```javascript
var shuffled = step.opts.slice();
for (var i = shuffled.length - 1; i > 0; i--) {
  var j = Math.floor(Math.random() * (i + 1));
  var t = shuffled[i]; shuffled[i] = shuffled[j]; shuffled[j] = t;
}
self.shuffledOpts = shuffled;
```

#### Patch 4: checkQuiz — Use Shuffled Options
**Problem:** checkQuiz used original step.opts, not shuffled.
**Fix:** Uses `this.shuffledOpts || step.opts`.

#### Patch 5: init() WE Handler — Navigation Fix (CRITICAL)
**Problem:** When worked example finished, weStepIdx was set to `undefined`, render() reset it to 0 → infinite loop.
**Fix:** Reset to 0 and call `next()` to advance.
```javascript
if (step.t === "we" && self.weStepIdx !== undefined && self.weStepIdx < step.steps.length) {
  self.weStepIdx++;
  if (self.weStepIdx >= step.steps.length) {
    self.weStepIdx = 0;
    self.next();  // ← advances to next step, NOT render()
    return;
  }
  self.render();
  return;
}
```

#### Patch 6: render() Reset Logic
**Problem:** weStepIdx/solveStepIdx reset on every render, even within the same step.
**Fix:** Only reset when step changes (tracked via `_prevSIdx`).
```javascript
if (this._prevSIdx !== this.sIdx) {
  this.solveStepIdx = 0;
  this.solveAnswered = false;
  this.weStepIdx = 0;
  this._prevSIdx = this.sIdx;
}
```

#### Patch 7: English Feedback
**Problem:** Feedback was in Hinglish ("Sahi!", "Galat.").
**Fix:** English ("Correct!", "Not quite.", "Why wrong:", "Correct approach:").

#### Patch 8: Step Type Cases
Adds `case` entries for chapter-specific simulation types (ix_balance_sim, ix_polygon_builder, etc.) in the render() switch statement.

#### Patch 9: Simulation Render Functions
Inserts chapter-specific simulation render functions (renderIxBalance, renderIxPolygonBuilder, etc.) into the App object before renderShop.

---

## 6. Validation Gates

### 6.1 Syntax Check
```bash
node --check output.js
```
Must return exit code 0. Any syntax error fails the build.

### 6.2 Runtime DOM Test

A simulated DOM environment in Node.js that:
1. Creates mock elements for all `getElementById` calls
2. Calls `App.init()`
3. Iterates through all STEPS, calling `App.render()` for each
4. Verifies: all steps render without error, no blank screens
5. Tests WE navigation: simulates clicking through all sub-steps, verifies `sIdx` advances (no infinite loop)
6. Tests quiz shuffle: runs 10 renders, verifies correct answer position varies
7. Checks for duplicate questions across all we/solve/quiz steps

```javascript
// Key test: WE navigation
App.sIdx = weIdx; App.weStepIdx = 0; App.render();
for (var i = 0; i < step.steps.length; i++) {
  App.weStepIdx++;
  if (App.weStepIdx >= step.steps.length) {
    App.weStepIdx = 0;
    var before = App.sIdx;
    App.next();
    assert(App.sIdx !== before, "sIdx must advance — no infinite loop!");
    break;
  }
  App.render();
}
```

### 6.3 Duplicate Question Check

```python
all_questions = [s["q"][:60] for s in steps if s["t"] in ("we", "solve", "quiz")]
dupes = [q for q in all_questions if all_questions.count(q) > 1]
assert len(dupes) == 0, f"Duplicate questions found: {dupes}"
```

---

## 7. Build Process (Per Chapter)

### 7.1 Step-by-Step Build

1. **Extract chapter text** from NCERT PDF using pdfminer
   ```python
   from pdfminer.high_level import extract_text
   text = extract_text(pdf_path, page_numbers=list(range(start, end)))
   ```

2. **Generate STEPS array** — AI creates JSON with chapter-specific content:
   - intro (with `intro` field for chapter-specific text)
   - tutor segments (learning content with real-life analogies)
   - formula boxes (key formulas with labels)
   - worked examples (NCERT "Example N" — unique questions)
   - quiz checkpoints (different questions from examples)
   - solve assessments (NCERT "Exercise X.Y QZ" — unique)
   - simulations (chapter-specific ix_* steps)
   - milestone, rapid_fire, memory_match, complete

3. **Verify no duplicate questions** — all we/solve/quiz questions must be unique

4. **Load patched App code** from `/workspace/notes/app_final.py`

5. **Load LLE v2 engine** from `/workspace/notes/build_v3_p2_v2.py`

6. **Assemble HTML**: CSS template + LLE engine + STEPS JSON + App code

7. **Syntax check**: `node --check`

8. **Runtime test**: Simulated DOM test (all steps render, WE advances, quiz shuffles)

9. **Deliver**: `workspace_emit` + `present_output`

### 7.2 Build Constraints

- STEPS array generated using `json.dumps(steps, ensure_ascii=False)` — prevents encoding issues
- All Hindi text in Devanagari script (UTF-8)
- File size target: < 150KB
- Zero external dependencies (no CDN, no API, no images)
- ASCII-only filenames
- Max-width: 600px

---

## 8. CSS Design System

### 8.1 Design Tokens

```css
:root {
  --brand: #4f46e5;     /* indigo — primary */
  --bl: #6366f1;        /* lighter indigo */
  --surface: #eef2ff;   /* light indigo background */
  --border: #e2e8f0;    /* slate border */
  --text: #1e293b;      /* dark slate text */
  --muted: #64748b;     /* muted gray */
  --green: #10b981;     /* success/correct */
  --red: #ef4444;       /* error/wrong */
  --gold: #f59e0b;      /* rewards/coins */
  --pi: #ec4899;        /* pink accent */
  --purple: #a855f7;    /* Hindi annotations */
}
```

### 8.2 Key Component Classes

| Class | Element | Purpose |
|-------|---------|---------|
| `.cn` | Connecting word span | Auto-annotated with inline Hindi |
| `.ch` | Hindi text inside .cn | Purple, smaller font |
| `.wd` | Tappable word span | All words — tap for Hindi dialog |
| `.we-card` | Worked example container | Light indigo gradient background |
| `.we-step` | Individual WE step | Left border, indigo gradient |
| `.we-step.final` | Answer box | Green gradient, centered |
| `.quiz-opt` | Quiz option | Border, hover, selected/correct/wrong states |
| `.feedback.ok` | Correct feedback | Green gradient |
| `.feedback.no` | Wrong feedback | Red gradient |
| `.misconception` | Why wrong explanation | Amber/yellow gradient |
| `.correct-method` | Correct approach | Green gradient |
| `.discovery-box` | Simulation feedback | Indigo-pink gradient |
| `.formula-box` | Formula display | Indigo gradient |
| `.tutor-box` | Tutor explanation | Gold/amber gradient |
| `.visual-card` | Simulation container | White-indigo gradient |
| `.shape-btn` | Simulation button | Border, active state |
| `.sim-dot` | Progress dots | Color changes: default/done/active |

---

## 9. Gamification Mechanics

### 9.1 XP and Leveling

| Action | XP | Coins |
|--------|-----|-------|
| Correct quiz answer | +5 | +2 |
| Correct solve step | +5 | +2 |
| Memory match pair | +10 | +3 |
| Milestone reached | +50–80 | +10 |
| Rapid fire correct | +3–8 (speed bonus) | +1–3 |

Level-up thresholds: Level N requires N × 100 XP cumulative.

### 9.2 Streak System

- Each consecutive correct answer increments streak
- Any wrong answer resets streak to 0
- Streak displayed in stats bar (planned V1.1)

---

## 10. Known Issues and Technical Debt

| Issue | Status | Impact | Mitigation |
|-------|--------|--------|------------|
| LLE v2 engine not yet deployed to Ch2/Ch3 | Pending | Ch2/Ch3 still have old CONN with is/are/was | Rebuild Ch2/Ch3 with LLE v2 before V1 release |
| Ch4 (Practical Geometry) not built | Pending | Gap in chapter coverage | Build next |
| Ch5 (Data Handling) not built | Pending | Gap in chapter coverage | Build after Ch4 |
| localStorage persistence not implemented | Pending | Progress lost on page refresh | V1.1 |
| Profile/avatar system not implemented | Pending | No personalization | V1.1 |
| WM dictionary incomplete | Ongoing | Some words show "Hindi meaning not available" | Grows with each chapter |
| Confetti animation uses fillRect | Works in browser | Fails in Node.js test mock | Cosmetic only — ignored in tests |

---

## 11. Future Technical Considerations

### 11.1 V2: Backend and Accounts
- Lightweight backend (Firebase or Supabase) for progress sync
- Student accounts with phone-number-based auth
- Teacher dashboard with aggregate analytics
- Content delivery via CDN instead of file distribution

### 11.2 V2: Adaptive Learning
- Track per-step performance data
- Build recommendation model: if student fails checkpoint X, recommend reviewing step Y
- Branching paths within chapters (not just linear)

### 11.3 V3: Multi-Language LLE
- CONN and WM dictionaries per language (Tamil, Telugu, Bengali, Marathi)
- Language selection at module load
- Same engine, different dictionaries

### 11.4 V3: Content Authoring
- Web UI for teachers to create/customize STEPS
- Export to same HTML format
- Template library of simulations

---

*This TRD is a living document. It reflects the technical state as of August 2026, based on building Chapters 1–3 of NCERT Class 8 Maths. It will be updated as the engine evolves and new chapters are built.*
