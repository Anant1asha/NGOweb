# Annanth Aasha — Website Implementation Handoff
## For v0 / Vercel AI Agent

### Objective

Transform the existing website using the supplied PRD, TRD and Brand & Product Context.

This is a **contextual and UX transformation**, not a request to fabricate a new organisation.

### Required workflow

1. Inspect every existing route/page.
2. Inspect all reusable components.
3. Map every page to the final page context reference.
4. Audit current copy for contradictions.
5. Rewrite copy page-by-page.
6. Preserve factual data that is already present.
7. Remove unsupported claims.
8. Separate current, building and future capabilities.
9. Apply the public visual system.
10. Preserve working functionality.
11. Improve responsive behaviour.
12. Verify navigation and CTAs.
13. Verify accessibility.
14. Verify no page remains generic or contextless.

### Critical constraints

- Do not invent impact numbers.
- Do not invent beneficiaries.
- Do not invent testimonials.
- Do not invent sponsor reports.
- Do not claim a 15-day reporting system is live unless implemented.
- Do not claim school licensing is live unless implemented.
- Do not claim earned revenue exists unless the existing data supports it.
- Do not fabricate photographs or locations.
- Do not turn future vision into present-tense fact.

### Current technical proof point

The product documentation records validation for:
- NCERT Class 8 Mathematics
- Chapter 1: Rational Numbers
- Chapter 2: Linear Equations in One Variable
- Chapter 3: Understanding Quadrilaterals

This is a **technical proof point**, not the full educational audience.

### Broader learning audience

The organisational learning vision covers **Classes 1–10**.

The UI/content model should support age/stage differences rather than using one identical experience for every grade.

### Keep the technical engine

Preserve the existing technical requirements where they are still applicable:

- self-contained offline HTML modules
- LLE
- tappable word meanings
- conversational Hindi annotations
- step-by-step worked examples
- NCERT-derived assessment
- misconception feedback
- concept-specific simulations
- learning checkpoints
- XP
- coins
- levels
- streaks
- rapid fire
- memory match
- validation gates
- duplicate-question checks
- mobile-first delivery

But do not make these internal implementation details the primary public brand narrative.

### Public-site hierarchy

The public website should prioritise:

**Child → Learning → Action → Evidence → Opportunity**

not:

**AI → Platform → Features → Donation**

### CTA hierarchy

Primary:
- See how learning works
- Follow the journey
- Build with us

Secondary:
- Support a cohort
- Contribute
- Partner
- Volunteer

“Donate” may remain where necessary for clarity and conversion, but should not define the entire relationship.

### Final design test

Every page must feel:
- complete
- human
- connected
- intentional
- credible
- warm
- transparent

No page should feel like:
- a template
- a SaaS dashboard
- an AI-generated NGO page
- a fundraising poster
- an unfinished collection of cards
