---
name: sarvam-doc-coauthoring
description: Guides the user through co-authoring a document by first asking thorough clarifying questions, then planning the work as todos, then writing it. Use when the user wants to write documentation, a proposal, a technical spec, a decision doc, a PRD, an RFC, or similar structured content. Do not use for casual one-off text or for generating Word/PDF files (use sarvam-docx or sarvam-pdf for those).
---

# Doc Co-Authoring Workflow

Before writing a document, do two things the user usually skips: **understand the goal through clarifying questions**, and **plan it as todos**. Then write it.

## When to use

Use when the user wants to write a document ("write a doc", "draft a proposal", "create a spec") or names a doc type (PRD, design doc, decision doc, RFC), or is clearly starting a substantial writing task.

## Step 1: Ask clarifying questions

Close the gap between what the user knows and what you know **before** writing anything. Ask thorough questions and keep asking until you could explain the document's purpose, audience, and content back to the user without guessing.

Start with the essentials, then go deeper:

1. What type of document is this, and what should it achieve?
2. Who is the audience, and what do they already know?
3. What are the key points, decisions, or arguments it must contain?
4. Is there a template, format, or length to follow?
5. Any constraints, source material, or context (links, threads, existing docs)?

Let the user answer in shorthand and dump context freely. Then ask follow-ups targeting any remaining gaps. Only move on when the picture is clear.

## Step 2: Plan as todos

Propose the document's outline (its sections) and confirm it. Then create a todo for each section, plus any prep tasks (e.g. "pull data from X"), using the `todo` tool. This is the agreement on scope — keep it updated as you work.

## Step 3: Write it

Work through the todos and write the document, checking in with the user as you go.
