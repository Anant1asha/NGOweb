#!/usr/bin/env node
// Bundle a deck into one self-contained offline HTML file.
//   node scripts/bundle.mjs "scripts/My Deck.dc.html" "My Deck.html"
//
// Inlines: <link rel="stylesheet">, <script src>, <img src>, and every
// url(...) / @import inside the CSS (fonts included) as data URIs.
// Inside Omelette, prefer the built-in standalone export — it handles
// resources referenced from JS too. This script is the portable fallback.

import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve, extname } from 'node:path';

const [, , inPath, outPath = 'deck.html'] = process.argv;
if (!inPath) { console.error('usage: node bundle.mjs <input.html> [output.html]'); process.exit(1); }

if (inPath.endsWith('.dc.html')) {
  console.warn(
    `\n  Warning: "${inPath}" is a .dc.html file.\n` +
    `  The .dc.html format depends on support.js (the DC runtime) and React,\n` +
    `  which do not exist in a standalone browser. The bundled output will\n` +
    `  render as raw JavaScript text, not as slides.\n` +
    `  \n  To export a standalone deck, use a plain .html file with a raw\n` +
    `  <deck-stage> element. See SKILL.md "Which format to use" and step 3.\n`
  );
}

const MIME = {
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.otf': 'font/otf',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.svg': 'image/svg+xml', '.webp': 'image/webp', '.avif': 'image/avif', '.ico': 'image/x-icon',
};
const isExternal = (u) => /^(https?:|data:|blob:|#|mailto:)/i.test(u);

async function dataUri(file) {
  const buf = await readFile(file);
  const mime = MIME[extname(file).toLowerCase()] || 'application/octet-stream';
  return `data:${mime};base64,${buf.toString('base64')}`;
}

async function inlineCss(cssPath, seen = new Set()) {
  if (seen.has(cssPath)) return '';
  seen.add(cssPath);
  let css = await readFile(cssPath, 'utf8');
  const base = dirname(cssPath);

  for (const m of [...css.matchAll(/@import\s+(?:url\()?["']([^"')]+)["']\)?\s*;/g)]) {
    const nested = isExternal(m[1]) ? '' : await inlineCss(resolve(base, m[1]), seen);
    css = css.replace(m[0], nested);
  }
  for (const m of [...css.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g)]) {
    if (isExternal(m[1])) continue;
    try { css = css.replace(m[0], `url("${await dataUri(resolve(base, m[1]))}")`); }
    catch { console.warn('  ! missing', m[1]); }
  }
  return css;
}

const base = dirname(resolve(inPath));
let html = await readFile(inPath, 'utf8');

for (const m of [...html.matchAll(/<link\b[^>]*rel=["']stylesheet["'][^>]*>/gi)]) {
  const href = m[0].match(/href=["']([^"']+)["']/)?.[1];
  if (!href || isExternal(href)) continue;
  html = html.replace(m[0], `<style>\n${await inlineCss(resolve(base, href))}\n</style>`);
}
for (const m of [...html.matchAll(/<script\b[^>]*src=["']([^"']+)["'][^>]*><\/script>/gi)]) {
  if (isExternal(m[1])) continue;
  const js = await readFile(resolve(base, m[1]), 'utf8');
  html = html.replace(m[0], `<script>\n${js.replace(/<\/script>/gi, '<\\/script>')}\n</script>`);
}
for (const m of [...html.matchAll(/<img\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi)]) {
  if (isExternal(m[1])) continue;
  try { html = html.replace(m[0], m[0].replace(m[1], await dataUri(resolve(base, m[1])))); }
  catch { console.warn('  ! missing', m[1]); }
}

await writeFile(outPath, html);
console.log(`bundled → ${outPath} (${(Buffer.byteLength(html) / 1e6).toFixed(2)} MB)`);
