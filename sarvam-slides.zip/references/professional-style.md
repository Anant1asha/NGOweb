# Professional style reference

Load this file when building a Professional-style deck. Everything here is Professional-specific; for a research report load `references/consulting-style.md`.

Professional is a **blueprint**: steel-blue ink on a light technical ground, Barlow Condensed over Barlow, a drawn modular grid, and every card, figure and photograph framed as a wireframe object — square-cornered, hairline-bordered, with `+` registration marks at the corners. Nothing is rounded, nothing is filled, nothing floats. The one deliberate exception is the primary action: a solid accent block, still square, still marked.

Use it for any deck where the audience should feel they are reading a drawing rather than a brochure. It is a **projection-first** system (unlike Consulting, which is written to be read alone as a PDF): the pages are spare, the grid does the arguing, and the speaker carries the detail.

The kit's copy is deliberately placeholder — "First change, phrased as the thing that moves", "One line describing what this part does". Every string names the job that string does. Replace all of it.

## Type

| Role | Family | Size |
| --- | --- | --- |
| Cover title | Barlow Condensed 600 | 176px / 0.92, tracking −0.015em |
| Section-divider numeral | Barlow Condensed 600 | 240px / 0.8 |
| Closing question | Barlow Condensed 600 | 124px / 1.0 |
| Statement | Barlow Condensed 600 | 108px / 1.04 |
| Slide title | Barlow Condensed 600 | 88px, line-height 96px (two baselines) |
| Quote | Barlow Condensed 600 | 76px / 1.14 |
| Big figure | Barlow Condensed 600 | 96px, tabular numerals |
| Card / cell heading | Barlow Condensed 600 | 36–44px |
| Lead | Barlow 400 | 40px / 1.35 |
| Body | Barlow 400 | 32px / 1.45 |
| Small, table cell, caption | Barlow 400 | 24–28px |
| Kicker, chip, column header, foot | Barlow Condensed 600 | 22–24px, caps, 0.08em |

Barlow Condensed appears **only** on titles, figures, numerals, kickers and chips; every sentence in the deck is Barlow. Titles are sentence case; uppercase is reserved for kickers, column headers, chips and the foot row.

**Emphasis is colour, never weight change or italics.** On paper use `#416180` (the accent's deep step) for body-size emphasis and `#5980A6` for display-size emphasis; on the steel field use `#94BCE3`. Never bold a run of Barlow to emphasise it — 500 is for table row labels, not for stress.

**Swapping the type.** Both families are single-purpose. Replace the display face with any condensed grotesque that holds a 600 weight (Oswald, Archivo Narrow, Saira Condensed) and the text face with a neutral sans; change the two stacks in `professional-tokens.css`, the Google Fonts link in the deck head, and the literal `font-family` values in the slides.

## Palette

- Grounds: `#F2F2F3` paper (the default), `#E9E9EA` surface (table header, chart track, closing band), `#1D2D3D` steel field (dividers, quote, closing). **Max two grounds in play on a page.**
- Ink: `#1D1F20` primary, `#5D5D60` secondary, `#7A7A7D` captions and sources, `#98989B` disabled. On the field: `#F2F2F3` primary, `#B5D9FD` secondary, `#94BCE3` labels and meta.
- Accent — one steel role, the system is mono: `#5980A6` base, `#416180` for accent-coloured body copy on paper, `#94BCE3` secondary series, `#D6EBFF` tinted chip, `#D4D4D7` the "everyone else" series.
- Rules: `rgba(29,31,32,0.16)` on paper, `rgba(242,242,243,0.24)` on the field. The drawn grid is the same ink at 0.07/0.10. Registration marks are the ink at 55%.
- **No gradients, no shadows, no radii, no second accent.** Separation is a 1px rule, a change of ground, or a registration-marked frame.

## Geometry — the field

Every Professional slide is built against one field. Calculate against it; never eyeball.

| Element | Value | Notes |
|---|---|---|
| Slide canvas | 1920 × 1080 | Fixed |
| Field | 120 → 1800 × 120 → 960 | 120px inset from **all four** stage edges |
| Modules | 4 × 384px, 48px gutters | Pitch 432; every block spans whole modules |
| Baseline | 48px | Titles are two baselines tall (96px) |
| Kicker row | `top:70px` | Above the field's top rule, left + right |
| Title | `top:168px` | One line clears 264; two lines clear 360 |
| Content start | `top:336px` (1-line title) · `top:412px` (2-line) | |
| Bottom budget | 960px | Nothing inside the field crosses it |
| Foot row | `bottom:52px` | Source left, folio right, below the field |

The field itself, its column rules and its four corner marks are drawn as one absolutely-positioned div per slide (`repeating-linear-gradient` for the columns). Keep it on cover, dividers, statement, quote and closing; on dense content slides it is optional — the content's own rules already carry the grid.

## Layout inventory

1. **Cover** — paper, field drawn, kicker row, 176px title over three modules, one lead line, meta row on a rule at the foot of the field.
2. **Foundations** — the tokens reference sheet, with a `#E9E9EA` band down the fourth module. Delete from real decks.
3. **Contents** — numbered rows on rules: accent hanging numeral, title, one supporting line, a right-hand meta column (time, slide range).
4. **Section divider** — full steel field, 240px numeral in `#94BCE3` beside the section title, reversed type, meta row on a rule. Only when the deck genuinely has numbered sections.
5. **Statement** — paper, one 108px condensed sentence with four words in steel, optional qualifier under a rule. Max two per deck.
6. **Text + panel** — the workhorse: four numbered rows across three modules, a registration-marked panel in the fourth carrying the consequence.
7. **Four cells** — one blueprint tile per module: bare Lucide icon at 56px, heading, one line.
8. **Metrics** — four figures on 2px ink rules: 96px numeral, accent caps label, one note.
9. **Comparison** — two blueprint cards on identical rows; the recommended one takes a solid accent header band.
10. **Table** — `#E9E9EA` header row, hairline row rules, no zebra, no vertical rules, 5–6 rows, `High`/`Medium`/`Low` chips, and a closing `#E9E9EA` band for the row that does not fit the columns.
11. **Bar chart** — square horizontal bars on a `#E9E9EA` track, sorted descending, label column left, tabular value right.
12. **Trend** — one solid accent line, one dashed `#D4D4D7` comparison, horizontal grid only, dot and condensed value on the final point, legend beneath.
13. **Share** — donut (r=140, 44px stroke, three segments max) with the headline share in the hole, legend as a row list with values.
14. **Timeline** — four steps on one rule; filled accent square = shipped, hollow square = planned.
15. **Process** — up to four blueprint nodes joined by hairlines with a small triangular arrowhead; the emphasised stage inverts to the steel field. A band underneath carries what the boxes cannot say.
16. **Stacked columns** — composition over time: three fills maximum, no gaps between segments, total in condensed above each column, legend row under a 2px baseline.
17. **Matrix** — 2×2 with hairline axes and mid-lines at the thresholds, quadrant names in 24px caps (only the live quadrant in accent), five plotted dots — larger accent dots for the ones that clear both thresholds — and a panel saying the placement is a judgement.
18. **Layer stack** — a system deeper than four boxes becomes full-width rows: number, layer name, one line, an ownership tag at the right; the layer under discussion inverts to the steel field.
19. **Schedule** — a Gantt on the quarter grid: five streams maximum, label column left, square bars on vertical quarter rules, the critical path in the accent and everything else in the pale step.
20. **Quote** — steel field, 76px condensed, attribution to a role under a rule. Max one per deck.
21. **Closing** — steel field mirroring the cover, the question in 124px, and the deck's one solid accent block as the single ask.

## The blueprint frame

Any card, panel, tile, figure or photograph is: `position:relative; box-sizing:border-box; border:1px solid rgba(29,31,32,0.16);` — no background, no radius, no shadow — plus four corner marks, each one element:

```html
<i style="position:absolute;top:-6px;left:-6px;width:11px;height:11px;
  background:linear-gradient(rgba(29,31,32,0.55),rgba(29,31,32,0.55)) 5px 0/1px 100% no-repeat,
             linear-gradient(rgba(29,31,32,0.55),rgba(29,31,32,0.55)) 0 5px/100% 1px no-repeat;"></i>
```

…repeated at `top/right`, `bottom/left`, `bottom/right`. On the steel field the mark colour becomes `rgba(242,242,243,0.55)`. **Never drop the marks from a framed element**, and never give a framed element a fill — the solid accent button and the inverted process node are the only filled objects in the system.

## Charts

Hand-built from divs and inline `<svg>`, no chart library, values stay editable.

- **Lead series `#5980A6`, secondary `#94BCE3`, "everyone else" `#D4D4D7`.** Never more than three fills in one chart.
- Everything is **square** — bars, columns, chips, legend swatches. The only round mark in the system is a plotted dot.
- Bars 44px on a `#E9E9EA` track, label in a fixed left column, value right-aligned in Barlow Condensed with `font-variant-numeric:tabular-nums`. Indian-locale numbers (`8,40,000`).
- Lines: 5px accent stroke, round caps, dot only on the final or called-out point; the comparison series is a 4px `#D4D4D7` dash. Horizontal grid at `rgba(29,31,32,0.10)` with a 2px baseline — no vertical spines, no axis box.
- Donut: r=140, 44px stroke, three segments max, share in the hole in Barlow Condensed, legend as a row list with values. Never on-arc labels, never an exploded segment.
- Stacked columns: no gaps between segments, total in condensed above the column, legend as a row of 24px squares under the baseline; three fills and no more.
- Matrix: hairline axes with mid-lines at the thresholds, dots only — no bubbles sized by a third variable, no logos. Only items in the quadrant the title is about get the large accent dot, and every dot stays clear of the threshold lines.
- Gantt: square bars on the quarter grid, one accent bar for the critical path, everything else `#94BCE3`; the quarter rules are hairlines, never a filled band.
- Axis and tick labels 26px `#7A7A7D`; series labels 28–30px ink.
- Below five data points a table beats a chart; a single number belongs on the metrics layout.

## Icons

- **Lucide at stroke-width 1.5**, 56px in a cell, 40px inline, `fill:none`, `currentColor` ink. Inline the path data — a deck must survive with no network. Icons sit **bare** on the grid; never in a tinted box, never filled, never accent-coloured.
- **No photography in this system's decks.** Structure, rules and figures carry the page; do not add stock imagery or decorative illustration. If the user supplies a real photograph, frame it like any other module (hairline, four marks, square corners) and duotone it: `filter:grayscale(1) contrast(1.06)` with a `#5980A6` overlay at `mix-blend-mode:color`. Never round it, never run type over it.
- No emoji, no unicode glyph marks.

## Copy

Titles are sentence-case noun phrases or short clauses — "Where the volume actually sits", "How a request moves through the system". No punchline titles, no title case, no exclamation marks. Kickers are two or three words in caps naming the page's job ("Argument", "Conditions", "Trend"). Every slide carrying a number carries a source line in the foot row. Meta reads as ` · `-separated fragments ("Q3 · planned", "Owner · team name").

## Don'ts

Rounded corners. Filled cards. Shadows or gradients. A second accent colour. Registration marks dropped from a frame. Thick icon strokes. Bold Barlow as emphasis. Italics. Stock photography or decorative illustration. A section divider in a deck with one section.
