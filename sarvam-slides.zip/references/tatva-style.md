# Tatva style reference

Load this file when building a Tatva-style deck. Everything here is Tatva-specific; for the other two systems load
`references/professional-style.md` or `references/consulting-style.md` instead.

Tatva is made with Sarvam's design system.

## Deck type scale (1920×1080)

| Role | Family | Size |
| --- | --- | --- |
| Display / title slide | Season Mix 500 | 104px |
| Statement | Season Mix 500 | 82px |
| Section divider heading | Season Mix 500 | 76px |
| Slide title | Season Mix 500 | 64px |
| Big figure | Season Mix 500 | 112px |
| Card heading | Season Mix 500 | 44px |
| Lead paragraph | Matter 400 | 38px |
| Body | Matter 400 | 30–34px |
| Caption / eyebrow / meta | Matter 400 | 26–28px |
| Code, API params, keys | Matter Mono 400 | 30px |

**Emphasis.** Season Mix has a playful italic lowercase — one italicised word inside a display line is the system's own way of stressing a phrase. Use it once in a deck, never bold: Matter's heavier weights are UI affordances, not typographic emphasis.

Line-height: headings 1.1–1.2, body 1.4–1.5. Nothing below 26px. Frame padding **96px top/bottom, 120px left/right** on every slide.

## Palette (deck subset)

- Surfaces: `#FAFAFA` (default), `#FFFFFF` (alternate + cards), `#141414` (dividers, quotes, closing). Max two light surfaces per deck; alternate deliberately, not randomly.
- Text: `#141414` primary, `#666666` secondary, `#999999` tertiary/meta, `#B3B3B3` numerals. On dark: `#FFFFFF` / `#999999` / `#666666`.
- Hairlines: `#F0F0F0` dividers, `#E6E6E6` borders, `#B3B3B3` table header rule.
- Accent tints — chips and state blocks only, never a background wash: indigo `#E8EFFC`/`#3333CC`, orange `#FEEDE6`/`#E6651B`, green `#F2F8EB`, red `#FDE7E2`.
- Card: `background:#FFFFFF; border-radius:20px; box-shadow:0 0 64px 0 rgba(20,20,20,0.08);` no border. Chips and buttons: `border-radius:9999px`.

## Layout inventory

Pick from these; don't invent new ones without reason.

1. **Title** — wordmark + chip top, display title + one lead line centre, meta row at base.
2. **Contents** — two-column numbered rows, hairline dividers, no bullets.
3. **Section divider** — `#141414`, wordmark top-left, 200px Season Mix numeral beside the section name.
4. **Statement** — white, one Season Mix sentence, nothing else. Max two per deck.
5. **Text + panel** — title, then bullets left / white card right. The workhorse.
6. **Metrics** — 3 columns, hairline above each, Season Mix numeral, label below.
7. **Comparison** — two identical cards, chip rows, equal copy length.
8. **Table** — hairline rows, no zebra, no vertical rules, 6 rows max.
9. **Quote** — `#141414`, Season Mix 400, attribution in Matter.
10. **Product shot** — aspect-fit screenshot on white with 1px `#E6E6E6` border, one-line caption.
11. **Timeline** — 4 steps max, filled dot = shipped, hollow = planned.
12. **Pillars** — three columns, 88px tinted icon box + heading + one line. The icon-led layout.
13. **State blocks** — tinted 72px square + label + meta; the AgentStateBlock pattern at slide scale.
14. **Bar chart** — horizontal bars, sorted descending, value at the end of the bar.
15. **Trend** — line chart, hairline grid, one solid series + one dashed comparison.
16. **Share** — donut with centre figure and a legend table.
17. **Process** — four connected step cards, plus a three-row stack diagram.
18. **Code** — Matter Mono on the dark card, six lines max, one line accented.
19. **Product UI** — a product shell rebuilt at ~1.8× so it reads projected.
20. **Rules / reference** — two-column numbered notes (delete from real decks).
21. **Closing** — dark, mirrors the title slide, closes on a pill CTA.

## Charts and diagrams

Tatva ships no chart library, so charts are hand-built from the same tokens as everything else — plain HTML divs for bars, inline `<svg>` for lines and donuts. Slides 14–17 of the kit are the reference implementations; copy them and swap the numbers. Keep them static markup (no JS chart lib) so the values stay directly editable.

**Data-viz palette.** Neutral-first, exactly like the rest of the system.
- Primary series / bars: `#141414`. Secondary or comparison series: `#B3B3B3` (dashed if a line), or `#E6E6E6` for a remainder segment.
- **One** accent per chart, on the single element the slide is about: orange `#E6651B` (default) or indigo `#3333CC`. Semantic only when the meaning is literal: green `#6EA335`, red `#B81514`, ochre `#A27224`.
- Tracks and empty states: `#F5F5F5`. Grid lines: `#F0F0F0`, baseline `#E6E6E6`.
- Never a rainbow series, never a gradient fill, never a drop shadow on a data mark. Area fill under a line is `rgba(20,20,20,0.05)`.

**Type in charts.** Axis and tick labels 26px `#999999`. Series labels 30–34px `#141414`. Numeric values in Matter Mono so columns align — Indian locale (`8,40,000`). Chart titles use the normal 64px slide title; the metric and period go in the 26px eyebrow above it ("Requests by language · last 30 days").

**Form.**
- Bars: 44px tall, `border-radius:9999px`, on a `#F5F5F5` track of the same radius. Label left in a fixed-width column, value right-aligned in a fixed-width column, so rows line up.
- Columns: same fill rules, `border-radius:8px 8px 0 0`, minimum 48px wide with a 32px gap.
- Lines: 5px stroke, round caps and joins, dot only on the final or called-out point. Grid horizontal only, `#F0F0F0` with a 2px `#E6E6E6` baseline — no vertical spines beyond the baseline.
- Donut: 44px stroke on r=140, three segments max, the headline figure in Season Mix in the hole. No pie charts with on-slice labels, no exploded slices, no legends floating over the arc — the legend is a row list with values.
- Tables beat charts below five data points; a single number belongs on a metrics slide, not a chart.

**Product UI on a slide.** Two honest options, no third. Either drop the real screenshot in, aspect-fit on white with a 1px `#E6E6E6` border (slide 10), or rebuild the interface at roughly 1.8× product scale so its type clears the 26px floor (slide 19) — 15px product text shrunk onto a slide is unreadable and shrunk-and-then-enlarged is worse. A rebuilt mock keeps every Tatva idiom: pill sidebar rows, pill composer, tinted state block, `#FAFAFA` shell around a `#FFFFFF` pane. Never annotate a mock with callout arrows and numbered circles — say it out loud instead.

**Diagrams.** Built from the deck's own card: white, radius 20, ambient shadow, 44px padding — connected by 1px `#B3B3B3` rules with a small CSS triangle arrowhead. Four boxes across is the maximum; deeper systems become a stack of full-width rows (radius 12, 1px `#E6E6E6`), with the layer you're emphasising inverted to `#141414`. No hand-drawn SVG illustration, no icons inside diagram nodes unless they come from Hugeicons.

## Icons

Tatva uses **Hugeicons** — 2px stroke, no fill, `currentColor`. Never emoji, never a unicode glyph, never a hand-drawn illustration.

- **Inline the SVG.** A deck must survive with no network, so paste the path data into the slide rather than loading the icon library. Wrapper: `<svg viewBox="0 0 24 24" style="width:40px;height:40px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;">`. Slide 12 is the worked example.
- **Sizes.** 40px inside an 88px box (feature layouts), 28–32px inside a 72px box (state blocks), 24px inline beside 30px text. Product-UI sizes (12–20px) are unreadable projected.
- **Icon box, not bare icon.** The Tatva pattern is an icon centred in a tinted rounded square: neutral `#F5F5F5` with `#141414` glyph, or an accent tint (`#FEEDE6`/`#E6651B`) on the one item you're emphasising. Radius 20 at 88px, 12 at 72px.
- **Names to reach for:** `ai-magic`, `brain`, `microphone`, `send`, `chat-multiple`, `speech-to-text`, `audio-book`, `wallet`, `pie-chart`, `settings`, `history`, `check`, `plus`, `search`, `refresh`, `success`, `warning`, `error`, `loader`. Grab the path data from [hugeicons.com](https://hugeicons.com) or the free package.
- **No icon available?** A neutral `#F5F5F5` rounded square is a better placeholder than an approximated glyph. Never improvise a mark.

## Dark decks

The kit is light with dark punctuation (dividers, quote, closing). A fully dark deck is legitimate for a keynote or an evening room — flip the surfaces and nothing else:

| Light | Dark |
| --- | --- |
| `#FAFAFA` / `#FFFFFF` surfaces | `#141414` / `#1E1E1E` |
| `#141414` / `#666666` / `#999999` text | `#E4E4E4` / `#949494` / `#646464` |
| `#F0F0F0` / `#E6E6E6` hairlines | `#343434` / `#444444` |
| Cards: white + ambient shadow | `#1E1E1E`, 1px `#343434`, no shadow (shadows don't read on dark) |

Keep accent tints out of a dark deck except as text colour — the pale tint fills (`#FEEDE6`) are light-surface only. The wordmark runs in `#FFFFFF` throughout.

## Marks

The kit carries no logo file. The mark slot on the title, divider and closing slides is a
type wordmark — `yourbrand` in Season Mix 500, 34px, `#141414` on light and `#FFFFFF` on dark.
Replace it with the deck owner's wordmark, or delete the slot; never leave `yourbrand` shipping.

## Copy rules

Sentence case everywhere. No emoji, no exclamation marks, no "we" in-product. Nouns for labels, imperatives for actions. Three to five bullets max, phrases not sentences. Indian-locale numbers (`10,00,000`). Metadata as ` · `-separated fragments ("Fetching agents · 1.2s").

**Indian-language text.** These decks often show a bilingual example — an English prompt with a Devanagari or Tamil response. Matter and Season Mix are Latin families; check the glyphs actually render before shipping, and if they don't, set that run in a matching Noto family (`'Noto Sans Devanagari', 'Matter', sans-serif`) at the same size rather than letting the browser pick a fallback. Never transliterate to dodge the problem.

## Don'ts

Gradients. Drop shadows with offset. Rounded-rectangle buttons. Title case. Emoji or unicode glyph icons (use Hugeicons or a neutral placeholder square). Serif body text. Accent-coloured left borders. Text over an un-scrimmed photo. More than two accent colours in one deck.
