# Editing an existing PPTX

Load this file before touching a `.pptx` the user supplied. Editing a deck is an
XML task, not a rebuild — the goal is to change what was asked and leave every
other byte of the original formatting alone.

## Contents

- Prerequisites
- Choosing an approach
- Workflow: unzip → edit → validate → zip
- Gotchas (XML entities, styling mismatch, node cloning, layouts, background,
  line spacing, overflow, zip flags, parser choice)
- Key paths inside a `.pptx`

## Prerequisites

`python-pptx` and `defusedxml`. `markitdown` is optional, for reading a deck's
text quickly. Install what is missing before starting:

```bash
pip install python-pptx defusedxml
```

## Choosing an approach

| Task | Approach | Watch for |
|---|---|---|
| Change text in an existing shape (same box, same styling) | Edit `slideN.xml` directly: unzip → patch → zip | XML entities — gotcha 1 |
| Add a brand-new slide with several shapes | `python-pptx` | Layout index, background, line spacing — gotchas 4, 5, 6 |
| Add an element that must match an existing one's styling | Deep-copy the source XML node with `defusedxml.minidom` | python-pptx textboxes will not match — gotchas 2, 3 |
| Read or inspect slide content | `python -m markitdown deck.pptx`, or iterate `shape.has_text_frame` | — |

**Rule of thumb:** modifying existing content → edit the XML. Adding net-new
content → python-pptx. Matching an existing element's style → clone its node.

## Workflow: unzip → edit → validate → zip

A `.pptx` is a ZIP of XML files. Slides live at `ppt/slides/slide1.xml`,
`slide2.xml`, one file per slide.

**1. Unzip**

```bash
mkdir unzipped && cd unzipped
unzip -o original_deck.pptx
```

**2. Inspect the slide XML**

```python
import xml.dom.minidom as m
with open('ppt/slides/slide1.xml') as f:
    print(m.parseString(f.read()).toprettyxml(indent='  '))
```

Each text-bearing shape is a `<p:sp>` containing `<p:spPr>` (position via
`<a:off x= y=/>`, size via `<a:ext cx= cy=/>`, geometry) and `<p:txBody>` (the
text: `<a:bodyPr>`, paragraphs `<a:p>`, runs `<a:r>` with `<a:rPr>` properties
and `<a:t>` text).

**3. Edit** — targeted string replacement on the raw file, or node manipulation
via `defusedxml.minidom` (see gotcha 9 for why not `ElementTree`).

**4. Validate before re-zipping.** One malformed token corrupts the whole deck.

```python
from defusedxml import minidom
minidom.parse('ppt/slides/slide1.xml')
print('XML well-formed: OK')
```

If this fails, fix the XML and re-run. Do not re-zip until it passes.

**5. Re-zip**

```bash
cd unzipped
zip -r -X output_deck.pptx .
```

**6. Verify the result opens and check for overflow**

```python
from pptx import Presentation
p = Presentation('output_deck.pptx')
print('slides:', len(p.slides._sldIdLst))
for sh in p.slides[0].shapes:
    if sh.has_text_frame:
        print(sh.text_frame.text)
```

## Gotchas

### 1. A raw `&` breaks the XML

The most common failure. An unescaped `&` in text content makes the slide XML
invalid, and PowerPoint refuses to open the file or shows a repair prompt.

```xml
<!-- Wrong — raw ampersand -->
<a:t>Yash Jawajiwar & Harsh Jawajiwar</a:t>

<!-- Right — escaped as an entity -->
<a:t>Yash Jawajiwar &amp; Harsh Jawajiwar</a:t>
```

When doing byte-level replacement in Python, build the entity from parts so the
`&` in your own source can't be mangled by whatever writes the patch:

```python
amp_entity = b'&' + b'amp;'   # the 5 bytes: & a m p ;
broken = b'Yash Jawajiwar & Harsh Jawajiwar'
fixed  = b'Yash Jawajiwar ' + amp_entity + b' Harsh Jawajiwar'
data = data.replace(broken, fixed)
```

The other characters needing entities, written here as literal text:
`<` is `&lt;`, `>` is `&gt;`, `"` is `&quot;`, `'` is `&apos;`.

### 2. python-pptx textboxes do not match the deck's styling

`slide.shapes.add_textbox()` generates minimal XML:

```xml
<a:bodyPr wrap="square" lIns="0" rIns="0" tIns="0" bIns="0">
  <a:spAutoFit/>
</a:bodyPr>
<a:p>
  <a:pPr algn="l"/>
  <a:r>
    <a:rPr sz="1400"><a:latin typeface="Matter"/></a:rPr>
    <a:t>09</a:t>
  </a:r>
</a:p>
```

The deck's own entry carries far more:

```xml
<a:bodyPr wrap="square" rtlCol="0" anchor="ctr"/>
<a:lstStyle/>
<a:p>
  <a:pPr indent="0" marL="0"><a:buNone/></a:pPr>
  <a:r>
    <a:rPr lang="en-US" sz="1400" dirty="0">
      <a:solidFill><a:srgbClr val="B3B3B3"/></a:solidFill>
      <a:latin typeface="Matter" pitchFamily="34" charset="0"/>
      <a:ea typeface="Matter" pitchFamily="34" charset="-122"/>
      <a:cs typeface="Matter" pitchFamily="34" charset="-120"/>
    </a:rPr>
    <a:t>01</a:t>
  </a:r>
  <a:endParaRPr lang="en-US" sz="1400" dirty="0"/>
</a:p>
```

What causes the visible misalignment:

- `anchor="ctr"` — the original centres text vertically; python-pptx defaults to top
- `<a:buNone/>` — removes inherited bullet formatting
- `pitchFamily` / `charset` on `<a:latin>`, `<a:ea>`, `<a:cs>` — font metadata that affects rendering
- `<a:endParaRPr>` — end-of-paragraph run properties
- `spAutoFit` — python-pptx adds it; it auto-sizes the box and can shift position

Fix: clone the node instead of creating one from scratch.

### 3. Clone shapes to match styling exactly

```python
import copy
from defusedxml import minidom

d = minidom.parse('ppt/slides/slide2.xml')

# Find the shape to clone (e.g. the "01" number textbox)
for sp in d.getElementsByTagName('p:sp'):
    texts = sp.getElementsByTagName('a:t')
    if ''.join(t.firstChild.nodeValue for t in texts if t.firstChild).strip() == '01':
        template_sp = sp
        break

clone = copy.deepcopy(template_sp)

cNvPr = clone.getElementsByTagName('p:cNvPr')[0]
cNvPr.setAttribute('id', str(max_id + 1))   # must be unique within the slide
cNvPr.setAttribute('name', 'Text 09num')

clone.getElementsByTagName('a:off')[0].setAttribute('y', '4535424')  # new row offset
clone.getElementsByTagName('a:t')[0].firstChild.replaceWholeText('09')

d.getElementsByTagName('p:spTree')[0].appendChild(clone)
```

This preserves font, size, colour, anchor, paragraph properties, `endParaRPr`
and font metadata, so the new element is visually identical to its siblings.
It is the only method that guarantees exact style inheritance.

### 4. The slide layout index may not be what you expect

A stock PowerPoint template has 10+ layouts (index 6 is often "Blank"), but a
custom deck may have one. `p.slide_layouts[6]` raises `IndexError` there. Check
first:

```python
for i, layout in enumerate(p.slide_layouts):
    print(i, layout.name)
```

Decks with a single "DEFAULT" layout use `p.slide_layouts[0]`.

### 5. Set the background explicitly on new slides

A blank layout may default to white rather than the deck's ground:

```python
slide.background.fill.solid()
slide.background.fill.fore_color.rgb = RGBColor(0xFA, 0xFA, 0xFA)
```

### 6. Line spacing requires manual XML injection

python-pptx does not expose line-spacing percentage. `val` is in thousandths of
a percent, so 140% is `140000`:

```python
from pptx.oxml.ns import qn

pPr = para.get_or_add_pPr()
lnSpc = pPr.makeelement(qn('a:lnSpc'), {})
lnSpc.append(lnSpc.makeelement(qn('a:spcPct'), {'val': str(int(140 * 1000))}))
pPr.append(lnSpc)
```

### 7. Check for overflow after every edit

```python
p = Presentation('output_deck.pptx')
slide_w, slide_h = p.slide_width, p.slide_height
for sh in p.slides[target_idx].shapes:
    right, bottom = sh.left + (sh.width or 0), sh.top + (sh.height or 0)
    if right > slide_w + 100 or bottom > slide_h + 100:
        print(f'OVERFLOW: {sh.name} right={right} bottom={bottom}')
```

The 100 EMU tolerance absorbs rounding in the original geometry; anything
beyond it is a genuine overhang.

### 8. Re-zip with `-X`

`zip -r -X` excludes extra file attributes (permissions, timestamps) that some
PowerPoint versions object to. Without it the file usually still opens, but `-X`
is the clean form.

### 9. Never use `xml.etree.ElementTree` on OOXML

It rewrites the `xmlns:a`, `xmlns:p`, `xmlns:r` namespace prefixes to `ns0`,
`ns1`, `ns2`, which PowerPoint cannot parse. Use `defusedxml.minidom`:

```python
from defusedxml import minidom
d = minidom.parse('ppt/slides/slide1.xml')
# ... manipulate ...
with open(path, 'wb') as f:
    f.write(d.toxml().encode('utf-8'))
```

## Key paths inside a `.pptx`

| Path | Contents |
|---|---|
| `ppt/slides/slideN.xml` | Individual slide XML, one per slide |
| `ppt/slides/_rels/slideN.xml.rels` | Relationships (images, hyperlinks, layout refs) per slide |
| `ppt/presentation.xml` | Presentation-level settings — slide size, slide order |
| `ppt/slideLayouts/` | Slide layout definitions |
| `ppt/slideMasters/` | Slide master definitions |
| `ppt/media/` | Embedded images and media |
| `[Content_Types].xml` | MIME type mappings for all parts |
