# Consulting style reference

Load this file when building a Consulting-style deck. Everything here is Consulting-specific; for a blueprint-grid deck, load `references/professional-style.md` instead.

The kit's copy is deliberately placeholder — "First theme title, phrased as the finding it stands for", "Row label two", "Source: name the dataset and the year". Every string describes the job that string does. Replace all of it; never ship a page with kit copy on it, and never treat the placeholder wording as a content model to imitate literally.

Its logic is the opposite of Professional's: Professional slides are spare and spoken over; consulting slides are **self-contained arguments** — a full-sentence headline, the evidence beneath it, the source line at the foot. Assume every page is read alone, in a PDF, without you in the room.

## Type

| Role | Family | Size |
| --- | --- | --- |
| Cover title | Archivo 800 | 124px / 0.94, tracking −0.03em |
| Closing question | Archivo 800 | 110px / 0.96, tracking −0.03em |
| Slide headline | Archivo 800 | 54px / 1.02, tracking −0.02em (50px at 2 lines) |
| Big figure | Archivo 800 | 76–88px, tracking −0.035em |
| Accent sub-head | Instrument Sans 600 | 30px |
| Lead | Instrument Sans 400 | 32px |
| Body | Instrument Sans 400 | 26px / 1.45 |
| Dense body, table cells, tiles | Instrument Sans 400 | 24px / 1.45 |
| Eyebrow, chip, column header | Instrument Sans 600, caps, 0.1em | 19px |
| Source line, folio | Instrument Sans 400 | 17–20px |

**Headlines are sentence case**, set heavy and tightly tracked so they read as a block of weight rather than a shout. Uppercase is reserved for eyebrows, column headers, chips and the running title. Archivo appears **only** on headlines and figures; every other word in the deck is Instrument Sans. The Google Fonts import is a **network dependency** — a standalone export needs the fonts inlined by hand or by the host's exporter.

**Emphasis is semibold accent, and only that.** `<span style="font-weight:600;color:#2F6BFF;">` on the two or three words that carry the sentence. Never italics, never underline, never a highlight. This is the loudest signature in the system — it lets a reader skim a dense page in five seconds. Put it mid-sentence as often as at the start.

**Swapping the type.** Both families are single-purpose, so a different pairing drops in cleanly: replace the display face with any heavy grotesque that holds up at −0.02em tracking (Archivo Black, Anton and Saira Condensed all work, the condensed ones in uppercase), and the text face with any geometric or neutral sans with a 600 weight. Change the two stacks in `consulting-tokens.css`, the Google Fonts link in the kit's `<helmet>`, and the literal `font-family` values in the slides; nothing else in the system moves.

## Palette

- Content surfaces: `#FFFFFF` paper, `#F2EFE9` warm panel. **Two, no third** — every page between the bookends is one of those.
- **Bookends only:** full-bleed `#2F6BFF` on the cover and the closing, the same accent on both. Never mid-deck, never as a section divider (the framework grid is the divider). On accent, type is white, secondary text is `#D8E4FF` and labels `#C3D6FF`, hairlines are `rgba(255,255,255,0.32)`, and emphasis is plain white — the accent pair has nowhere to go on its own colour.
- Ink: `#0A0E28` (a navy-black, never `#000`), `#474C63` secondary, `#7C808F` captions/sources, `#A6A9B4` folio and "(1/2)" qualifiers.
- Accent: `#2F6BFF` for links, emphasis, chips and the lead data series; `#6FA4FF` for hanging numerals and secondary series; `#DBE7FF` for "medium" chips; `#D8D3CA` for the neutral "everyone else" series.
- Hairline: `#DCD8D0` — the only rule colour, on white and on the panel alike.
- The palette is deliberately shallow: one accent, one soft step of it, one wash, one warm neutral. Re-hue it by moving the accent pair and the panel together; don't add a fifth colour.
- **No shadows, no gradients, no rounded cards, no borders except that hairline.** Separation is a 1px rule or the panel changing colour.

## Page furniture — on every content slide

**No logo, no mark, on any slide.** The vertical running title is what identifies the report; a mark in the corner of 18 pages is noise the reader stops seeing on page two.

1. **Vertical running title** in the 96px left gutter: `writing-mode:vertical-rl; transform:rotate(180deg)`, Instrument Sans 15px caps, 0.1em, report name semibold + subtitle regular, vertically centred.
2. **Folio** bottom-left at `left:56px; bottom:44px`, 17px `#A6A9B4`.
3. **Footer link** bottom-right, Instrument Sans 600 17px, accent, underlined — on roughly half the pages, not all.
4. **Source line** bottom-left of the content column, 20px `#7C808F`, whenever a number appears: `Source: …`.
5. Content spans **128 → 1824**; headline top **56**; headline width 940–1500 depending on the panel.

## Layout geometry reference

These are the fixed numbers every Consulting slide is built against. Calculate against them, never eyeball:

| Element | Position | Notes |
|---|---|---|
| Slide canvas | 1920 × 1080 | Fixed, never change |
| Content left margin | 128px | All content starts here |
| Content right edge (no panel) | 1824px | `right:96px` from slide edge |
| Panel start (split layouts) | 1248px | Right-hand panel begins here |
| Content width (no panel) | 1696px | 1824 − 128 |
| Content width (with panel) | 1120px | 1248 − 128 |
| Max headline width (with panel) | 1060px | Leaves 60px clearance before panel |
| Max headline width (no panel) | 1400px | Full content width |
| Source line position | `bottom:44px` | Bottom-anchored, left-aligned |
| Folio position | `bottom:44px`, `left:56px` | Bottom-anchored |
| Bottom boundary for content | 1036px | 1080 − 44 (source line) |
| Left gutter (running title) | 48px–88px | 40px wide vertical text |

**Bottom boundary rule:** before finalising any slide, calculate the bottom edge of every absolutely-positioned element: `element_bottom = container_top + element_top_offset + element_height`. This must be less than **1036px**. If it is not, the element collides with the source line.

## Layout inventory

1. **Cover** — full-bleed `#2F6BFF`, no panel and no page furniture: a caps eyebrow and the edition on one top row over a white 32%-alpha rule, a 124px Archivo title in white, one lead line in `#D8E4FF`, and a matching rule over the footer row. On accent there is no second colour — emphasis is plain white.
2. **Foundations** — the tokens reference sheet. Delete from real decks.
3. **Contents** — numbered rows with a right-hand figure column; the agenda doubles as a summary.
4. **Theme summary** — the section opener: numbered headline, five lettered rows (`5A`…`5E`) each with an accent code at the right, and a full-height panel carrying driver chips plus two big figures. The most useful page in the system.
5. **Framework grid** — 3 column-headed bands of numbered tiles, one column highlighted in solid accent with an "in scope" flag, one full-width band underneath. **Reuse this as the section divider**, moving the highlight — that is this system's divider idiom, not a dark title card.
6. **Split insight** — argument left, panel right: five hanging-numeral rows on hairlines, and the panel taking a second headline plus 4 bare-icon + text consequences. The headline and the panel heading are one sentence split across the fold (`…` on both halves). The flagship page.
7. **Evidence grid** — four quadrants, each an accent sub-head + a small chart or list, hairline-separated, one source line for all four.
8. **Survey · columns** — a full-width vertical column chart, no panel: five columns, value above each in Archivo 44px, category labels under a 2px baseline, the verbatim question in 20px below. The chart gets the whole page, so the columns read from the back of the room.
9. **Survey · full width** — the same data as horizontal bars, no panel: the headline cut across the top at full width, the two secondary cuts side by side below a hairline. Use when all three cuts deserve equal room. **Columns (08) vs bars (09):** columns when the categories are few, short-labelled and ordinal (years, sizes, ranks); horizontal bars when the labels are long or the list runs past six.
10. **Trend and share** — line chart left (one solid series, one dashed prior-edition comparison, dot and Archivo value on the final point, horizontal grid only), donut right in the panel with the headline share in the hole and a legend *table* of rows and values. One line and one donut per page — never two charts of the same kind.
11. **Waterfall** — a build-up: two solid absolute-level columns (base and total) with floating `#6FA4FF` increments between them, each increment labelled with its driver, over a 2px baseline. The panel says how to read it and names the contested assumption.
12. **Positioning matrix** — 2×2 with hairline axes, the two thresholds as mid-lines, quadrant names in 18px caps (only the live quadrant in accent), and 5 plotted items — larger accent dots for the ones that clear both thresholds. Never more than seven items, and always say the placement is a judgement, not a score.
13. **Conditions table** — row groups: label column, criteria column, and 2–4 rating columns of `High` (solid accent) / `Medium` (`#DBE7FF`) chips. Close with a panel band that carries the continuation.
14. **Myth vs reality** — numbered rows, claim left in `#474C63`, correction right in Instrument Sans 600, and the supporting verbatim in a panel block with a semibold attribution. A row may end without a quote.
15. **Case examples** — numbered rows, description left, one big figure right, panel of "what they share". Describe examples generically unless the user supplies named ones.
16. **Market sizing** — stacked columns with totals above, an axis hairline, a legend row, and a right-hand column of three big figures.
17. **Quote** — full-bleed `#F2EFE9`, 50px Instrument Sans, accent emphasis inside, attribution under a hairline. Max one per deck.
18. **Closing** — the cover's frame reused: full-bleed `#2F6BFF`, top row over a white 32%-alpha rule, a 110px Archivo question, one lead line in `#D8E4FF`, and four contact columns on matching rules along the bottom. Cover and closing are the deck's only coloured surfaces and they are the **same** accent, so the light pages sit between two identical bookends.

## Charts

Same discipline as Professional — hand-built divs, no chart library, values stay editable — but the palette is blue-led rather than neutral-led.

- **Lead series `#2F6BFF`, rest `#6FA4FF`, the "everyone else" bar `#D8D3CA`.** Never more than three fills in one chart.
- Bars and columns are **square** — no radius anywhere in this system. Track on white is `#F2EFE9`; on the panel it is `#FFFFFF`.
- Values live **outside** the bar in Archivo 800 when they are the point (34px), **inside** in Instrument Sans 600 20–23px when the bar is a share of 100%.
- Category labels sit under a hairline, 20–24px `#474C63`. The survey question goes below the chart in 20px `#7C808F`, verbatim, with the n.
- Stacked columns: no gaps between segments, totals in Archivo above the column, legend as a row of 18px squares under the axis.
- Lines: 5px stroke, round caps, no markers except a dot on the final or called-out point; the comparison series is a 4px `#D8D3CA` dash. Horizontal grid at `#EDEAE4` with a 2px `#DCD8D0` baseline — no vertical rules, no axis spine on the left.
- Donut: 44px stroke on r=140, **three segments maximum**, headline share in Archivo in the hole, legend as a row list with values — never labels on the arcs, never a pie with slice callouts, never an exploded segment.
- Waterfall: increments float from the running total; keep absolute-level columns in `#2F6BFF` and increments in `#6FA4FF` so the reader can tell a level from an addition, and say which is which in the panel.
- Matrix: hairline axes with mid-lines at the thresholds, dots only (no bubbles sized by a third variable, no logos), labels under the dot. The emphasis has to agree with the headline — only items inside the quadrant the headline is about get the large accent dot, and keep every dot clear of the threshold lines so which side it falls on is never ambiguous.
- Below five data points a table beats a chart, and a single number belongs on a figure row, not a chart.
- No axis spines beyond the baseline hairline, no gridlines, no data labels on every point, no percentages to one decimal.

## Structure without shapes

**There is no shape vocabulary in this system — no rounded nodes, no chevrons, no boxes-and-arrows.** Nothing has a corner radius except a plotted dot. Where another deck would draw a diagram, this one uses:

- **Hanging numerals** — Archivo 800 at 44px in `#6FA4FF`, in a fixed 104px column beside 25px copy, each row separated by a `#DCD8D0` hairline. This is the workhorse for any set of parallel points (slide 06).
- **Bordered tiles** in a grid, one filled solid accent, for a map of many items at once (slide 05).
- **Flat blocks of accent** — a bar, a column, a chip, a filled table cell — sized to carry the number they represent.

Icons are Hugeicons-style strokes at 56px in `#0A0E28`, 1.5px, sitting **bare** in a 64px grid column beside their text — never inside a tinted box, never filled, never coloured.

## Copy

Headlines are **full clauses that state the finding**, sentence case, and they often run on across pages or across the fold of a split page — `Five design choices make the shift possible…` / `…creating four benefits for incumbents`. That is the opposite of Professional's noun-phrase titles, and it is correct here: the headline is the argument. Continuation qualifiers go in `#A6A9B4` parentheses — `Conditions for success vary by type (1/2)`. Spell out the n on every survey figure, quote survey questions verbatim, and attribute every verbatim to a role rather than a name (`— Role, company type`). Name companies only when the user supplies them; otherwise describe the example generically.

### Tone register

The cover title sets the tone for the entire deck. Draft it with the same care as a slide headline — sentence-case, professional, stating the thesis. Do not import marketing voice or casual language into a Consulting deck.

| Do | Don't |
|---|---|
| "Databricks: the platform beneath enterprise AI" | "Databricks and the data intelligence land grab" |
| "Growth is accelerating, and overtaking Snowflake" | "Databricks is crushing it!" |
| "Only Databricks pairs deep data with production AI" | "Why Databricks is the best" |
| "Three beliefs about Databricks the numbers correct" | "3 myths about Databricks DEBUNKED" |
