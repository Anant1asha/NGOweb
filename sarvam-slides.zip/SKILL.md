---
name: sarvam-slides
description: >-
  Builds 1920×1080 HTML slide decks from three design systems — "Professional
  style" (a blueprint grid, the default), "Tatva style" (clean, typographic
  product and keynote decks) and "Consulting style" (investment-research and
  strategy readouts) — and edits existing PowerPoint decks, from slide text to
  adding and restyling slides. Use when the user wants a presentation deck,
  slide deck, or slides on any topic, or wants to change a .pptx deck they
  already have or have uploaded. If the user does not name a template for a new
  deck, use Professional, then Tatva.
user-invocable: true
---
# Sarvam slides

Build standalone HTML slide decks using one of three design systems. Every deck uses the same `<deck-stage>` web component at 1920×1080, with each slide as an inline-styled `<section>`. The deck is bundled into one offline `.html` file by `bundle.mjs`.

## Editing an existing PPTX

**If the user supplies or uploads a `.pptx` to change, edit that file — do not build a new HTML deck.** Rebuilding discards the original's formatting, which is the one thing the user is asking you to keep. Read `references/editing.md` before the first edit; it carries the unzip → patch → validate → re-zip workflow and the failure modes that corrupt a deck.

Route by edit type:

| Edit | Approach |
| --- | --- |
| Change text in an existing shape | Patch `ppt/slides/slideN.xml` directly |
| Add a net-new slide | `python-pptx` |
| Add an element that must match existing styling | Deep-copy the source XML node with `defusedxml.minidom` |

Everything below applies to building a new deck.

## Which format to use

Use **plain** `.html` — a raw `<deck-stage>` element with `<link>` and `<script src>`. Renders in any browser. **This is the default format for the Panja agent sandbox** — the deliverable is a standalone HTML file opened in a browser.

## Pick a template first

**Professional is the default.** If the user does not name a template, use Professional. **Tatva is the second default** — reach for it when Professional's drawn-grid, technical register is wrong for the room, or when the user asks for something cleaner, warmer or more modern.


| Template                         | Reference kits                                             | Use it for                                                                                                                                                                                                                                                                     |
| -------------------------------- | ---------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Professional style** (default) | `scripts/Professional Slide Kit (plain).html` — 21 layouts | A blueprint design system: a drawn modular grid, hairline frames with "+" registration marks, one steel accent. Barlow Condensed + Barlow, light technical ground, steel-blue field for dividers and the close. Projection-first: spare pages, the speaker carries the detail. |
| **Tatva style** (second default) | `scripts/Tatva Slide Kit (plain).html` — 21 layouts        | Product, roadmap, keynote, all-hands and customer decks. Season Mix over Matter, neutral greys, generous whitespace, pill chips and ambient-shadow cards — light with dark punctuation. Spare and spoken-over, like Professional, but warm and typographic rather than drawn. Made with Sarvam's design system. |
| **Consulting style**             | `scripts/Consulting Slide Kit (plain).html` — 18 layouts   | Research reports, market sizings, strategy readouts, investor theses — dense, evidence-first pages meant to be read as a PDF as much as presented. Archivo + Instrument Sans, navy-black ink, warm panel, one blue.                                                            |


The three systems do not mix. Pick one per deck and stay inside it. If the ask is a report or a numbers-heavy readout for an outside audience, that is Consulting style; if it is a product, launch or keynote deck, or the user wants a cleaner look, that is Tatva; for everything else, use Professional.

Copy slides out of the relevant kit rather than composing from scratch.

**After picking a template, load the matching reference file** for type scales, palette, layout inventory, chart specs, and copy rules:

- Professional style → read `references/professional-style.md`
- Tatva style → read `references/tatva-style.md`
- Consulting style → read `references/consulting-style.md`

Then read `references/writing-guide.md` for narrative structure, heading rules, anti-slop checks, and data integrity — these apply to every deck regardless of template.

## Clarify before building

**Before generating a new deck, check whether anything material is missing from the brief — and ask the user rather than assuming.** Detailed prompts still routinely omit the audience, the outcome the deck must drive, the core takeaway, or the real source data. If any context needed to build confidently is absent or ambiguous, clarify it with the user first — for example, who the audience is, how long the deck should be, what the one takeaway is, or what data to cite. Only skip this for edits to an existing deck or a trivial change.

## Before building

Write the full title sequence first, in the voice of the template you picked. **Professional style:** sentence-case noun phrases or short clauses naming what the page shows ("Where the volume actually sits", "How a request moves through the system"). **Tatva style:** short topic noun-phrases ("Model latency", "Rollout plan"). **Consulting style:** full clauses that state the finding ("Three drivers close the gap to FY30"). Whichever you pick — sentence case, no punchline titles, no "It's not X, it's Y".

## Files in this skill

Self-contained — copy the whole directory into any project.

```
sarvam-slides/
  SKILL.md                     this file
  references/
    professional-style.md      Professional type, palette, the field geometry, the
                               blueprint frame, layouts, charts, imagery, copy rules
    tatva-style.md             Tatva type, palette, layouts, charts, icons, marks, copy rules
    consulting-style.md         Consulting type, palette, layouts, charts, geometry, copy rules
    writing-guide.md           Narrative structure, headings, anti-slop, data integrity,
                               citations — applies to every deck
    editing.md                 Editing an existing .pptx: XML workflow, python-pptx,
                               node cloning, the gotchas that corrupt a deck
  scripts/
    Professional Slide Kit (plain).html   reference deck — Professional style, 21 layouts
    Tatva Slide Kit (plain).html      reference deck — Tatva style, 21 layouts
    Consulting Slide Kit (plain).html reference deck — Consulting style, 18 layouts
    professional-tokens.css    Professional-style tokens + the Google Fonts import
    tatva-tokens.css           Tatva tokens + @font-face (points at ../assets/fonts)
    consulting-tokens.css      Consulting-style tokens + the Google Fonts import
    deck-stage.js              slide stage: scaling, nav, thumbnails, notes, print
                               — locally modified: adds the hide-thumbnails (T)
                               and full-screen (F) buttons. Re-copying a stock
                               deck-stage.js overwrites them.
    bundle.mjs                 node script: deck → one offline HTML file
  assets/
    fonts.css                  @font-face only, when you don't want the Tatva tokens
    fonts/matter/*.woff2       Matter 300–700 + Matter Mono   (Tatva only)
    fonts/season/*.woff2       Season Mix 300–700             (Tatva only)
```

**Everything that renders lives in** `scripts/`**; the Tatva fonts live in** `assets/`**.** Paths below assume the deck sits in `scripts/` next to its siblings — `professional-tokens.css`, `tatva-tokens.css`, `consulting-tokens.css` and `deck-stage.js` are `./`, and the Tatva fonts are `../assets/`.

> The `sandbox_dir` returned by `skill_view` is a real directory on disk. `scripts/` and `assets/` already exist there. Write your deck directly into `scripts/` — do not create a new subfolder. The bundler resolves all relative paths against the deck's location, so the deck must sit alongside its sibling files.



## Build a deck

1. **Start from the kit, don't compose from scratch.** Read the kit for your chosen template — `scripts/Professional Slide Kit (plain).html` or `scripts/Consulting Slide Kit (plain).html`. Copy the slides you need into your deck.
  Write your deck to `<sandbox_dir>/scripts/<name>.html` — directly into the existing `scripts/` directory. Do NOT create a new subfolder. The `scripts/` and `assets/` directories already exist at the `sandbox_dir` path returned by `skill_view`, and the deck must sit alongside `professional-tokens.css`, `tatva-tokens.css`, `consulting-tokens.css`, `deck-stage.js` and `../assets/` so relative paths resolve correctly.
2. **Keep the deck inside** `scripts/`**.** Moving it elsewhere breaks `./deck-stage.js` and, on Tatva, `../assets/`; if you must move it, repoint all paths.
3. **The deck shell.** For a standalone deck (Panja sandbox or local development), use plain `.html`:

   **Professional style:**
   ```html
   <!DOCTYPE html>
   <html>
   <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;700&family=Barlow+Condensed:wght@400;600&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="professional-tokens.css">
   <style>
     body { margin: 0; background: #1D2D3D; }
     a { color: #5980A6; text-decoration: underline; text-underline-offset: 3px; }
     a:hover { color: #416180; }
   </style>
   <script src="deck-stage.js"></script>
   </head>
   <body>
   <deck-stage width="1920" height="1080">
     <section data-label="Title" data-screen-label="01" data-speaker-notes="…" style="…">…</section>
   </deck-stage>
   </body>
   </html>
   ```

   **Consulting style:** identical, but swap the two style lines:
   ```html
   <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700;800&family=Instrument+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="consulting-tokens.css">
   <style>
     body { margin: 0; background: #0A0E28; }
     a { color: #2F6BFF; text-decoration: underline; text-underline-offset: 3px; }
   </style>
   ```

   **Tatva style:** no Google Fonts links at all — `tatva-tokens.css` declares every `@font-face` against `../assets/fonts`, so linking it is enough:
   ```html
   <link rel="stylesheet" href="tatva-tokens.css">
   <style>body { margin: 0; background: #FAFAFA; }</style>
   ```
4. **Inline styles, literal values, on every slide** — no classes, no shared stylesheet, no CSS variables in the slides. The token file is there for fonts and for anything you build outside the deck; slide markup repeats the hex values so each `<section>` stays self-describing and directly editable.
5. **Fonts:** Professional and Consulting load their families from Google Fonts — Barlow Condensed + Barlow, and Archivo + Instrument Sans respectively — which is a **network dependency** at view time. **Tatva self-hosts:** `tatva-tokens.css` declares every `@font-face` against `../assets/fonts`, so a bundled Tatva deck renders with its real type offline. Stacks: `'Season Mix', Georgia, serif` / `'Matter', system-ui, sans-serif` / `'Matter Mono', ui-monospace, monospace`. Use `../assets/fonts.css` if you want the faces without the tokens.
6. **Ship it.** A deck is not done until it is exported — see **Export** below. For a file the user can keep, run the bundler from the sandbox directory:
  ```bash
   cd "<sandbox_dir>" && node scripts/bundle.mjs "scripts/My Deck.html" "/scratch/work/My Deck.html"
  ```
   Run it from `<sandbox_dir>` so relative paths resolve correctly (the paths inside the deck are resolved relative to the deck, not to your shell). Output is one offline HTML file — tokens, fonts and stage inlined. Requires Node 18+, no npm install.
7. **Per slide:** `data-label` (thumbnail rail), `data-screen-label` (slide number), `data-speaker-notes` (the note travels with the slide on reorder). Never set position/inset/width/height on a `<section>` — the stage does that.
8. **Verify before bundling.** After building the deck but before bundling, run this checklist on every slide:
  - No kit placeholder text remains (check: headlines, body, labels, chips, chart annotations, footer links, contact tiles, speaker notes)
  - Headline width does not overflow into a right-hand panel (Consulting: max 1060px on split layouts)
  - Professional: every block spans whole modules, sits inside the 120–960 field, and every framed element still has its four `+` marks
  - No content overflows past the 1080px slide bottom (check: source line, last content element)
  - Source line is concise and width-constrained
  - Charts and legends are aligned in a shared flex container
  - Panels with sparse content use `justify-content:center`, not `margin-top:auto`
  - No quadrant labels, axis labels, or chart annotations are copied from the kit demo
  - Closing slide does not carry redundant tiles or placeholder contact information
  - All numbers in the deck are sourced (source line present on every slide with data)
  - Running title in the left gutter matches the cover title
  - Every numeral on the deck (section markers, step numbers, large display numerals) is verified for logical consistency — does it make sense in context? Is there a matching sequence?
  - Every layout included in the deck is justified by the content's structure, not by the kit's inventory. If a layout does not serve the deck's narrative, remove it.



## Gotchas

These pitfalls were observed in real deck-building sessions. They apply to every template unless noted.

### All templates

1. **The kit is a reference, not a template.** Every string in the kit is placeholder. Every layout value is calibrated for the kit's demo content. Every layout is optional. Copy the structure, not the content. Replace every string. Recalculate every dimension. Include only the layouts the content demands.
2. **Do not use a layout just because the kit offers it.** A typical deck uses 10–15 of the kit's layouts. The remaining are not "missing" — they were not needed. Every layout in the deck should answer: "What does this slide communicate that the adjacent slides don't?" If the answer is "nothing," remove it.
3. **Large display numerals are information, not decoration.** The 200px numeral on a section divider, the 112px figures on a metrics layout, the 88px big figures on case examples — these must be correct relative to the deck's structure. A section divider showing "02" when there is no "01" is a bug, not a design choice.
4. **When fixing one layout issue, change only the property that is broken.** Do not adjust unrelated properties — each additional change is a potential new bug. Fix the specific problem, test the result, then move on.
5. **Empty space is better than broken content.** When filling empty space, prefer enlarging existing elements over adding new ones. A taller chart is always safer than a new content block that might not fit.



### Consulting-specific

1. **Headline width on split layouts.** When a slide has a right-hand panel (starting at `left:1248px`), the headline width must not exceed ~1060px. The kit uses `width:1300px` for full-width layouts — do not copy this value to split layouts.
2. `margin-top:auto` **on sparse panels.** The kit uses `margin-top:auto` to push content to the bottom of flex panels. This creates large gaps when the panel content is sparse. Use `justify-content:center` with fixed gaps instead.
3. **Quadrant labels are demo content.** The positioning matrix's "Act now", "Worth solving for", "Deprioritise", "Ready, but small" labels are specific to the kit's demo scenario. Replace them with labels that describe the deck's actual axes.
4. **Footer links are optional, not structural.** The `<a href="#">yourfirm.com/insights</a>` footer link is placeholder. Remove it entirely if there is no real URL, or replace with a real link. Do not ship a deck with placeholder URLs.
5. **Section-prefix numerals in headlines.** The "Theme summary" layout includes a coloured numeral prefix in the headline (e.g., `<span style="color:#6FA4FF;">05.</span>`). This is a kit convention for section openers. It duplicates the folio number and confuses readers. Remove it unless the deck specifically uses section numbering.
6. **Closing slide contact tiles.** The 4-column contact grid on the closing slide is a layout option, not a requirement. If there is no real contact information or the tiles would only repeat numbers from earlier slides, remove the grid entirely and keep only the closing question and offer.
7. **Source line length.** Source lines should be concise. Do not include full paper titles or long dataset names. Use short forms: "VLDB 2020 Delta Lake paper" not "Delta Lake: High-Performance ACID Table Storage over Cloud Object Stores (VLDB 2020)."
8. **Chart height must fill the canvas.** The kit's default chart heights are calibrated for the kit's content density. When the slide has less content, scale the chart height up to fill the available space. Calculate: `available_height = 1080 − headline_bottom − source_line_top − margins`.
9. **Donut and legend must share alignment.** Place the donut chart and its legend in a shared flex container with `align-items:center` so they align on the same centre axis. Do not position them as independent elements.
10. **Bottom boundary check.** Before finalising any slide, verify that no content extends below `top:1036px` (1080px slide height minus 44px for the source line). Calculate the bottom edge of every absolutely-positioned element and confirm it clears this boundary.



### Tatva-specific

1. **Section dividers are conditional, not mandatory.** The kit's section divider (layout #3) is a dark slide with a 200px numeral. It only makes sense when a deck has several distinct sections needing visual separation. On a single continuous narrative it breaks the flow and orphans a numeral with no sequence. Ask "how many sections does this deck actually have?" — if the answer is one or zero, drop the layout.
2. **The wordmark is a placeholder.** The title, divider and closing slides carry `yourbrand` in Season Mix. Replace it with the deck owner's wordmark or delete the slot — never ship `yourbrand`. The kit ships no logo file by design; if the user supplies a mark, drop it into `assets/` and reference it as `../assets/<file>`.
3. **Slide 19 is a rebuilt product interface, not a template.** Include it only when the deck genuinely shows a UI. If it does, either drop in a real screenshot aspect-fit on white with a 1px `#E6E6E6` border, or rebuild at ~1.8× so type clears the 26px floor — never shrink a product screenshot onto a slide.
4. **Icons are Hugeicons, inlined.** 2px stroke, no fill, `currentColor`, pasted as SVG path data so the deck survives with no network. Never emoji, never a unicode glyph. No icon available? A neutral `#F5F5F5` rounded square beats an approximated mark.
5. **Two light surfaces maximum.** `#FAFAFA` and `#FFFFFF`, alternated deliberately. Dark (`#141414`) is punctuation — dividers, quote, closing — not a third body surface.

### Professional-specific

1. **The field is the layout.** Content lives inside 120 → 1800 × 120 → 960 and spans whole 384px modules with 48px gutters. Blocks that start at 300px or span 2.5 modules break the system faster than a wrong colour would. A one-line title clears 264px, a two-line title clears 360px — start content at 336 or 412 accordingly, and never let it cross the 960 bottom rule.
2. **Never drop the registration marks, never fill a frame.** A card, panel, tile or figure is a 1px rule with four `+` marks and no background. The only filled objects in a deck are the solid accent action block on the closing slide and, at most, one inverted steel node in a process diagram. A framed element with a fill — or a frame with its marks removed — reads as a different design system.
3. **The drawn grid is furniture, not decoration.** Keep the field board on the cover, dividers, statement, quote and closing. On dense content slides drop it — the table rules, bar tracks and row hairlines already carry the grid, and doubling them makes the page noisy.
4. **One steel accent, no second colour.** Professional is a mono system. Chart series go `#5980A6` → `#94BCE3` → `#D4D4D7`, and that is the whole range. Do not introduce a green "good" or a red "bad" — say it in the label.
5. **Emphasis is the accent's deep step, not bold.** `#416180` at body size, `#5980A6` at display size. Barlow 500 is for table row labels only. No italics anywhere.
6. **No photography.** Professional decks carry no images — the drawn grid, the framed cells and the figures are the visual interest. Do not add stock imagery to fill a page; enlarge what is there or leave the field empty.
7. **No logo, no mark.** The kicker row identifies the deck.



### What to strip from the kit

After copying a layout from the kit, perform a systematic text sweep. These elements are commonly copied from the kit but should be evaluated for removal or replacement:

- Section-prefix numerals in headlines (e.g., `<span style="color:#6FA4FF;">05.</span>`)
- Footer link `<a>` elements with placeholder URLs (`yourfirm.com/insights`)
- Quadrant labels on the positioning matrix ("Act now", "Deprioritise", etc.)
- Contact tiles on the closing slide (remove if no real contact info)
- Chart category labels that reference the kit's demo data ("Cat one", "Cat two", etc.)
- Panel body text that describes the kit's demo scenario rather than the deck's topic
- Speaker notes that reference the kit's demo content ("Read the lettered rows; the panel carries the two numbers to remember")
- Professional: the kicker pairs ("Capabilities / Four modules"), the meta rows on the cover, divider and closing ("Owner · team name", "Appendix · slides 19 — 24"), and the demo figures on the metrics slide
- Tatva: the `yourbrand` wordmark on the title, divider and closing slides, the `yourbrand.com` / `docs.yourbrand.com` footers, the "Product name · one-line descriptor" eyebrow on the product-shot slide, and the whole product-UI mock on slide 19 unless the deck genuinely shows an interface



## Motion

Slides don't need transitions, and both templates are restrained: **200–300ms, ease-out in, ease-in out. No bounce, no spring, no parallax, no infinite loops on slide content.**

If you do add a build-in, make the visible state the base style and animate *from* hidden, gated on the active slide, so print and reduced-motion users still see everything:

```css
@media (prefers-reduced-motion: no-preference) {
  [data-deck-active] .build { animation: deck-fade-in 300ms ease-out both; }
}
```



## Export

**Presenting** — the bottom toolbar carries two controls beyond prev/next/reset: **hide thumbnails** (or press `T`) collapses the left rail and refits the slide to the full window, and **full screen** (or `F`) takes over the display. The rail preference persists, so a deck opened for a talk stays clean. Nav is ←/→, ↑/↓, space, Home/End, or number keys.

**Standalone HTML** (one offline file — email it, present from a plane):

1. Your deck must be plain `.html`.
2. Bundle it:
  ```bash
   cd "<sandbox_dir>" && node scripts/bundle.mjs "scripts/My Deck.html" "/scratch/work/My Deck.html"
  ```
   This inlines the stylesheet (with all `@font-face` and `url()` references), `deck-stage.js`, and every `<img src>` as data URIs. Output is one self-contained file (~1–3 MB, mostly fonts). Note: Professional and Consulting styles use Google Fonts via `@import` — the bundler inlines the CSS but the font files themselves are fetched from Google's CDN at view time, so those decks need an internet connection to render with their real type. Tatva decks do not: their faces are inlined from `../assets/fonts` and render offline.
3. Deliver it:
  ```python
   workspace_emit(local_path="/scratch/work/My Deck.html", name="My Deck.html")
   present_output(artifact_ids=["..."], caption="Deck title")
  ```

**PDF** — the deck is `<deck-stage>`, already print-ready: `show_pdf_export_dialog`, one page per slide. No rebuild, no print CSS.

**PPTX** — `gen_pptx` at 1920×1080 with `resetTransformSelector: "deck-stage"` so the capture sees authored-size geometry. Add `data-om-raster` to the chart and diagram slides' root so they export as images rather than mangled shapes. In Consulting style that means slides 10–12 — the line chart, the donut and the matrix; in Professional style slides 12–13 and 16–17 — the trend line, the donut, the stacked columns and the matrix (the registration marks and drawn grid survive as shapes, but check them); in Tatva style slides 14–17 and 19 — the bar chart, the trend, the donut, the process diagram and the product-UI mock. Every other page is text, hairlines and flat blocks, all of which convert to native shapes cleanly, so leave them alone.
