
document.addEventListener('DOMContentLoaded',()=>{
 const menu=document.querySelector('.menu'); const nav=document.querySelector('.navlinks');
 if(menu&&nav){menu.addEventListener('click',()=>{nav.classList.toggle('open');menu.setAttribute('aria-expanded',nav.classList.contains('open'))})}
 document.querySelectorAll('[data-year]').forEach(x=>x.textContent=new Date().getFullYear());
 document.querySelectorAll('form[data-demo]').forEach(form=>form.addEventListener('submit',e=>{
   e.preventDefault(); const note=form.querySelector('[data-form-note]');
   if(!form.checkValidity()){form.reportValidity();return}
   if(note){note.textContent='Thank you. The form is ready for the Foundation’s connected submission endpoint. No information has been sent from this static frontend.';note.hidden=false;}
 }));
});
