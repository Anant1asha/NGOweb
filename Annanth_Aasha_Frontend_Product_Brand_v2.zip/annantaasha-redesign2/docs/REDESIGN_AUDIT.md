# Annanth Aasha — Frontend Product + Brand Redesign Audit

## Decision frozen before implementation

The public website uses the **current live learning catalogue** as production truth. The PRD/TRD are retained only as product/technical understanding and are not used to decide what the public catalogue contains.

### Current live learning catalogue represented in the frontend
1. Number Play — Class 8 Mathematics
2. Squares & Square Roots — Class 8 Mathematics
3. Understanding Quadrilaterals — Class 8 Mathematics
4. Polynomials — Class 10 Mathematics
5. Algebraic Expressions — Class 8 Mathematics
6. Language Skills / Modals & Connectors — Middle school English

The supplied Health, Invisible Living World and Patterns HTML files remain reference material only and are **not** exposed as production website catalogue entries.

## Jal Seva correction
Jal Seva means **providing water to birds** and learning a repeatable habit of noticing, filling, returning and caring. It is not presented as a generic water-conservation programme.

## Public website narrative
The website is structured as a journey:

**Why → Learning → Action → Choice → Evidence → Participation**

Learning is the first step, but no other page is forced to repeat the same learning message. Each page explains its own role and links naturally to the next part of the ecosystem.

## Visual split

### Public Foundation website
Warm, editorial, human, natural, documentary, restrained.

### Learning room
Interactive, focused, playful, precise. Existing live learning experiences are linked rather than visually rewritten.

## Transparency model

**Claim → Record → Evidence → Check → Limitation → Next step**

No invented impact data, beneficiary stories, testimonials, member counts or financial records are used.

## Eco Seva model

**Plant → Return → Notice → Record → Continue**

The emphasis is on care after the photograph, not the planting day itself.

## Jal Seva model

**Fill → Notice → Return → Reflect → Carry it forward**

The object is a bird water point; the learning is continuity of care.

## Aasha Economy model

**Earn → Save → Choose → Wait → Reflect**

Aasha Coins are not described as salary, cryptocurrency or payment for children.

## Forms

The package includes frontend validation and honest static-state feedback. No backend submission endpoint, email address or API has been invented. Connecting the Foundation's real submission endpoint is a backend integration step.
