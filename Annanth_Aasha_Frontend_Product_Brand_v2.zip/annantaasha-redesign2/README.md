# Annanth Aasha Foundation — Frontend Product + Brand Book v2

This package implements the finalized frontend-first product/brand direction. It is intentionally dependency-light: static HTML, CSS and vanilla JavaScript so the surface is stable, inspectable and easy to deploy.

## Production learning catalogue
The public catalogue follows the current live production chapters observed on www.annantaasha.org:
1. Number Play — Class 8 Mathematics
2. Squares & Square Roots — Class 8 Mathematics
3. Understanding Quadrilaterals — Class 8 Mathematics
4. Polynomials — Class 10 Mathematics
5. Algebraic Expressions — Class 8 Mathematics
6. Language Skills / Modals & Connectors — Middle school English

The PRD/TRD are retained as product/technical context only. They are not treated as the website catalogue. Additional supplied HTML modules (Health, Invisible Living World, Patterns) are retained under docs for reference but are not exposed as production catalogue entries.

## Jal Seva
Jal Seva means providing water to birds and learning to notice, refill, return and care over time.

## Design principles
- Learning is the first step, not the entire identity.
- Every page connects to the wider journey without repeating the same message.
- Public website = warm editorial / documentary / human.
- Learning room = interactive / focused / playful.
- Impact = a journey people can follow, not a one-time report.
- Transparency = claim → record → evidence → limitation → next step.
- No fabricated metrics, testimonials, beneficiary stories or payment identifiers.
- AI is a lever, not the hero.
- Illustrative visuals are original inline SVG artwork; no AI-generated person is presented as a real beneficiary.

## Run
`python3 -m http.server 4173` then open `http://localhost:4173/`.

## Important
The frontend is ready for deployment, but actual forms still require the Foundation's connected submission endpoint. The package intentionally does not invent an email address or backend integration.
