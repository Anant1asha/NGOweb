---
name: sarvam-presentation
description: "Create, read, and edit professional .pptx presentations from scratch with PptxGenJS. Ships three ready-made looks — a professional/consulting default, a data-heavy report style, and a bold big-type pitch-deck style — each with a concise component reference and deterministic layout QA. Use whenever the user mentions a deck, slides, a presentation, a pitch, or a .pptx file, or asks to build, edit, or read slides. If a new-deck request lacks audience, length, or style/tone, ask with the clarify tool before generating."
---

# Sarvam Presentation Skill

## When to use

Use this skill any time a .pptx file is involved — creating, reading, editing, or parsing presentations. Trigger whenever the user mentions "deck," "slides," "presentation," "pitch," or references a `.pptx` filename.

This skill is brand-neutral. It produces clean, professional, executive/business decks. If the user asks for a specific brand's look, apply their colors/fonts on top of these patterns.

## Clarify before building (always)

**Always ask clarifying questions before generating a NEW deck — even when the
brief looks detailed.** Detailed prompts still routinely omit the audience, the
one outcome the deck must drive, the core takeaway, or the real source data.
Gathering context beats assuming: use the clarify tool, and keep asking until you
can build confidently. Cover at least:
- **Audience & setting** — who reads it; live-presented vs. sent as a document
- **Goal** — the one decision or action the deck should drive
- **Core message / narrative angle** — the through-line (see [content-guide.md](content-guide.md))
- **Length & depth** — slide count, and how much detail per slide
- **Style/tone** — which ready-made look fits (Templates table below: general/professional/strategy → professional; charts/data/market or research report or dense consulting → consulting-report; "more designer"/high-impact → bold-pitch)
- **Data & sources** — figures to include, and any must-include content or claims to cite

Only skip the questions for edits to an existing deck or a trivial change.

## Templates (ready-made looks)

Three self-contained starter scripts live in `scripts/`. Pick by the requested
look and read only its component reference. **Never open, copy, grep, or patch a
template script.** Write a small `deck-main.js` containing only `main()`, then
let `scripts/compose_deck.py` combine it with the template. Template internals
must stay out of model context.

| Template (`compose_deck.py --template`) | When to use (1-line) | Component reference (read first) |
|---|---|---|
| `professional` *(default)* | **General / professional / strategy decks** — the everyday default: clean deep-navy consulting look for business, executive, and strategy content (covers, card rows, stat rows, two-column compares, charts, quotes). | [reference/professional-components.md](reference/professional-components.md) |
| `consulting-report` | **Complex, data-heavy decks** — charts, graphs, tables, market-research & general research reports, dense consulting deliverables; also clean consulting/strategy narratives. Its fixed tokens, grid, content budgets, and chart rules are mandatory. | [consulting_style_rules.md](consulting_style_rules.md), then [reference/consulting-report-components.md](reference/consulting-report-components.md) |
| `bold-pitch` | **Designed / high-impact look** — when the user wants it "more designer" rather than plain-professional (pitch decks, bold big-type). | [reference/bold-pitch-components.md](reference/bold-pitch-components.md) |

**Each `main()` is a WORKED EXAMPLE, not a fixed sequence.** It shows each
helper's calling convention composed into one deck — it is not the required slide
count/order. Decide the slide set from the user's content and reuse the helpers
in whatever order/count/combination fits. Font default is Calibri (a template
uses Helvetica/Impact where its look requires it). Design rules:
[design-guide.md](design-guide.md).

## Reference

| Task | Guide |
|------|-------|
| Content rules (narrative arc, headings, data units/legends, citations, readability) | Read [content-guide.md](content-guide.md) |
| Design rules (palette, type, layout, action titles, prohibitions) | Read [design-guide.md](design-guide.md) |
| Consulting-report design system (tokens, grid, dense type, content caps, charts) | Read [consulting_style_rules.md](consulting_style_rules.md) — **mandatory for consulting-report decks** |
| Structured narrative/evidence plan | Read [reference/deck-plan.md](reference/deck-plan.md) — **required for new decks** |
| Full PptxGenJS API details | Read [pptxgenjs.md](pptxgenjs.md) |
| Edit / create from an existing template | Read [editing.md](editing.md) |
| Read / analyze a .pptx | `python -m markitdown presentation.pptx` (see [qa.md](qa.md)) |
| QA before delivering any deck (deterministic + content) | Read [qa.md](qa.md) — **required** |

## Creating from scratch

Do the clarifying round first (see "Clarify before building" above) — a wrong
guess on audience, message, or data costs a full regeneration.

1. Install dependencies (see Dependencies below).
2. Research into a **source ledger**. For time-sensitive or quantitative claims,
   open the primary source; search-result snippets and aggregator summaries are
   discovery aids, not evidence. Do not invent a brand/author. A valuation,
   forecast, or scenario requires explicit assumptions and derivation.
3. Write `deck-plan.json` using [reference/deck-plan.md](reference/deck-plan.md).
   It is the narrative, evidence, unit, chart-shape, and source contract.
4. Validate before coding:
   `python scripts/validate_deck_plan.py deck-plan.json`. Fix the plan until it
   passes; do not write slide code from a failing plan.
5. Pick a template. For consulting-report, read
   [consulting_style_rules.md](consulting_style_rules.md) and its component
   reference; otherwise read that template's component reference.
6. Write `deck-main.js` containing exactly one `main()` and only deck-specific
   helper calls. Match each plan slide to the documented helper. Use short 3–6
   word titles, explicit units/legends, and source notes. Never inspect template
   source to discover a signature.
7. Compose without loading template internals:
   `python scripts/compose_deck.py --template consulting-report --main-file deck-main.js --output my_deck.js`
   (substitute the selected template name). Then run `node my_deck.js`.
8. Confirm the generated deck is not the worked example by checking the first
   extracted title against `deck-plan.json`; only then run the QA gate below.
9. If QA fails, patch only the named call in `deck-main.js`, re-compose, rebuild,
   and re-run once. Never patch the composed script or template.

## QA (required)

**No visual QA.** Never render slides to images for QA — no PPTX→PDF→PNG
conversion, no image-description/vision tools, no pixel analysis; the gate
below plus one markitdown read are the complete QA (full rule: [qa.md](qa.md)).

**Never consider a deck done without passing the QA gate** — one command,
one consolidated report:

```bash
python scripts/run_qa.py output.pptx --plan deck-plan.json
```

For new decks, `--plan` is mandatory: it rejects a worked-example deck, wrong
slide count/titles, and leftover placeholders. The validated plan separately
rejects branding that was not supplied by the user.
Exit `0` = read the extracted text once (`python -m markitdown output.pptx`) for
content and the [content-guide.md](content-guide.md) writing rules, then
deliver. Exit `1` = fix `deck-main.js` **from the FAIL messages** (each
names the slide, the shapes with a text snippet to locate the helper call,
and the exact fix — including the `y` that clears an overlap), rebuild,
re-run the gate once. Never read the check script's source, and never re-read
the whole build script — patch the named calls only. Full doctrine,
thresholds, and the required checklist: **[qa.md](qa.md)**.

Also check the JS source by hand for two things no script catches: hex colors
with a `#` prefix (corrupts the file — except inside `iconToPng`, which
legitimately takes CSS-style `#hex`), and reused shadow/option objects
(PptxGenJS mutates them in place — recreate per call).

## Dependencies

Install at session start:
```bash
npm install pptxgenjs                          # create decks (required)
pip install python-pptx                        # deterministic QA, check_deck.py (required)
npm install react react-dom react-icons sharp  # only if adding icons (optional)
pip install "markitdown[pptx]"                 # text extraction for content QA (optional)
```

| Package | Purpose |
|---------|---------|
| `pptxgenjs` | Create presentations from scratch |
| `python-pptx` | Deterministic layout QA (`check_deck.py`) |
| `react`, `react-dom`, `react-icons`, `sharp` | Rasterize icons to PNG (optional) |
| `markitdown[pptx]` | Extract text from .pptx for content QA (optional) |
