# professional-style.js — Component Reference

Concise index of the helpers in `scripts/professional-style.js` (the default
template). Read this before building a professional deck; open the script to copy
its constants block or a helper's body.

**Style:** clean consulting/strategy — deep-navy cover/divider/closing, light
content slides, a single teal accent, action titles. Standard 10×5.625in canvas,
Calibri.

## Contents
- Setup (required constants)
- Slide shells (call one per slide)
- Content blocks (add into a content slide)
- Charts
- Gotchas
- Vertical stacking — `makeStack`

## Setup (required constants)
Copy the top of the script verbatim — helpers depend on these globals: `PALETTE`
(`primary 0D1B2A` navy, `secondary`, `accent 0E7C86` teal, `accentLight`, `white`,
`offWhite`, `lightGray`, `medGray`, `charcoal`, `darkText`); `CHART_COLORS`;
`FONT_HEADER`/`FONT_BODY` (both "Calibri"; try "Georgia"/"Cambria" header for a
serif feel); `MX=0.5`, `PAGE_W=10`, `PAGE_H=5.625`; `makeShadow()`; and `pres`.

## Slide shells (call one per slide)
`addTitleSlide(title, subtitle, tagline)` — navy cover with teal top/bottom bars.
`addDividerSlide({ eyebrow, title })` — navy section divider; centered title + small eyebrow.
`addContentSlide(actionTitle, pageNum)` — light content slide with an action-title header + footer; **returns the slide** to add content into.
`addQuoteSlide({ quote, attribution })` — centered pull-quote on a soft surface.
`addClosingSlide(items, bottomTagline)` — navy closing; `items: [{ title, desc }]` laid out as a numbered 2-column recommendations grid.

```js
const s = addContentSlide("Revenue beat plan but margin slipped on input costs", 4);
addStatRow(s, [ { value: "$42.6M", label: "Revenue, 8% above plan" }, /* ... */ ]);
```

## Content blocks (add into a content slide returned by addContentSlide)
`addBullets(slide, items, { x, y, w, h })` — bulleted list in the body zone.
`addCardRow(slide, cards, { y, h })` — equal-width white cards, each with a left teal accent bar; `cards: [{ kicker, title, body }]` (kicker optional).
`addStatRow(slide, stats, { y })` — big teal numerals + labels; `stats: [{ value, label }]`.
`addTwoColumn(slide, left, right, { y, h })` — two compare panels (navy heading bar + bordered white body); each side `{ heading, items[] }`.
`addCard(slide, x, y, w, h, accentColor)` — a single white card + left accent bar (the primitive `addCardRow` builds on).

## Charts
`addChartSlide(title, chartType, chartData, pageNum, chartOpts)` — full-width chart under an action title. `chartType` is a `pres.charts.*` value; `chartData` is pptxgenjs's `[{ name, labels, values }]`; `chartOpts` overrides the styled defaults (muted axes, hairline value gridlines, bottom legend, `CHART_COLORS`). Example: `{ barDir: "col", showValue: false }`.

## Gotchas
- **`main()` is a worked example, not a fixed sequence.** Decide slide count/order
  from the user's content; reuse the helpers in any combination.
- **Slide titles:** default to a short 3–6 word heading ("Timeline",
  "Unit economics"); use a one-line claim (≤ ~8 words) only where the slide
  argues a point; never enumerate the slide's content in the title (see
  design-guide.md § Slide titles).
- **Never reuse a shadow object** — call `makeShadow()` fresh each time (pptxgenjs
  mutates option objects in place).
- Deterministic QA: run `python scripts/check_deck.py output.pptx` (see [../qa.md](../qa.md)).

## Vertical stacking — `makeStack`

Every template ships `makeStack(startY, defaultGap)` — a cursor that computes
`y` for you when a slide stacks elements vertically. `stack.place(h, gap?)`
returns the y for a block of height `h` and advances past it; `stack.y()` reads
the current cursor (e.g. for a footline).

```js
const stack = makeStack(1.2);
addKicker(slide, "Section", { x: MX, y: stack.place(0.4) });
addBody(slide, "...",       { x: MX, y: stack.place(2.0, 0.3) });
addFootLine(slide, "...",   { x: MX, y: stack.y() });
```

Use it whenever a slide stacks 3+ elements: to fix a text-fit failure you then
change ONE height and everything below re-flows — hand-placed absolute `y`
values are how fixing one box creates the next overlap.
