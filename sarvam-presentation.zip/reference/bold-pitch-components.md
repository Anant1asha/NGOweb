# bold-pitch-style.js — Component Reference

Concise index of every reusable helper in `scripts/bold-pitch-style.js`, so you
can compose a deck without reading the full script. Read this before building a
bold-pitch deck; open the script only to copy the constants block or inspect a
helper's body.

**Style:** bold ultra-condensed display headlines, two-tone maroon/pink slides
that alternate dark/light, giant stats, minimal charts. Native 20×11.25in canvas.

## Contents
- Setup (required constants)
- Slide shell — `newSlide`
- Headlines — `addSectionHeadline`
- Text & content blocks — `addKicker`, `addBody`, `addNumberedItem`, `addRuledItem`, `addColumnKB`
- Stats — `addStatUnit`
- Meta / footer — `addMetaPair`, `addFootLine`
- Charts — `addColumnChart`, `addLineChart`, `addDonutChart`, `addBarChart`
- Gotchas
- Vertical stacking — `makeStack`

## Setup (required constants)
Copy the top of the script verbatim — the helpers depend on these globals:
`PAGE_W=20`, `PAGE_H=11.25`, `MX=1.0`; palette `C` (`maroon 70020F`, `pink FEDEE1`,
`white`, `black`, chart tints); `RAMP_DARK`/`RAMP_LIGHT`; `FONT_DISPLAY="Impact"`,
`FONT_BODY="Arial"`; the `SZ` type-scale object; and `let pres`.

```js
pres = new pptxgen();
pres.defineLayout({ name: "BOLDPITCH", width: PAGE_W, height: PAGE_H });
pres.layout = "BOLDPITCH";
```

## Slide shell
`newSlide(dark = true) → { slide, fg, body, bg, ramp, grid }`
Creates a slide with the two-tone background and returns the resolved colors for
that tone. **Always start a slide with this** and thread `fg`/`body`/`ramp`/`grid`
into the helpers below — that's what keeps a slide internally consistent.
- `dark:true` → maroon bg, pink headline (`fg`), white body. `dark:false` → pink bg, maroon headline, black body.

```js
const { slide, fg, body, ramp, grid } = newSlide(true);
```

## Headlines
`addSectionHeadline(slide, text, { color, x=MX, y=1.17, w=PAGE_W-2MX, h=5.0, size=SZ.section, align="left" })`
Oversized condensed headline. Pass `"LINE1\nLINE2"` to force two lines.

**Sizes are a fixed role scale — do not pass `size` to vary it per slide.**
Content-slide headlines always use the default (`SZ.section`); the cover uses
`size: SZ.cover` and the closing `size: SZ.closing` (with `align:"center"`),
each exactly once per deck. Mixed headline sizes across slides read as a
mistake, and `check_deck.py` flags them. If a long word wraps mid-word
(e.g. "OPPORTUNITY"), widen `w` or force a line break with `\n` — never
shrink the size.

```js
addSectionHeadline(slide, "PROBLEM", { color: fg, h: 2.8 });
addSectionHeadline(slide, "THANK YOU", { color: fg, y: 3.4, size: SZ.closing, align: "center" });
```

## Text & content blocks
`addKicker(slide, text, { x, y, w=5.0, color, size=SZ.kicker, align="left" })` — ALL-CAPS condensed label (auto-uppercased).
`addBody(slide, text, { x, y, w=5.2, h=1.6, color, size=SZ.body })` — justified body paragraph.
`addNumberedItem(slide, { x, y, w, num, kicker, body, fg, bodyColor, bg })` — square bullet + `N.` + kicker + body (problem-grid item).
`addRuledItem(slide, { x, y, w, kicker, body, fg, bodyColor })` — hairline rule on top + kicker + body (stacked list).
`addColumnKB(slide, { x, y, w, kicker, body, fg, bodyColor })` — kicker + body column, no rule.

```js
const xs = [MX, 7.4, 13.7];
items.forEach((it, i) => addRuledItem(slide, { x: xs[i], y: 5.6, w: 5.3, kicker: it.k, body: it.b, fg, bodyColor: body }));
```

## Stats
`addStatUnit(slide, { x, y, w, value, caption, fg, size=115, numH=2.1, boxH=1.0, capSize=18 })`
Giant numeral with its caption in a bordered box **directly beneath** — the number
and its meaning read as one pair. Lay several in an aligned row for a stats slide.
Keep the default `size` on every stat in the deck (one role, one size); if a
long `value` (e.g. "$50M+") wraps, widen `w` — don't resize the numeral.

```js
const xs = [MX, 7.25, 13.5];
stats.forEach((s, i) => addStatUnit(slide, { x: xs[i], y: 5.2, w: 5.5, value: s.value, caption: s.caption, fg, numH: 3.0 }));
```

## Meta / footer
`addMetaPair(slide, { x, y, w=2.4, label, value, fg, valColor, labelSize=SZ.meta, valSize=SZ.contact })` — small caps label + value below (cover "PRESENTED BY", closing "PHONE"). Drop `valSize` to ~13 for long values (emails).
`addFootLine(slide, text, { x=MX, y=PAGE_H-1.05, w=6.0, color, align="left", bold=false, size=SZ.metaVal })` — bottom corner line ("2025", a tagline).

## Charts
All four take the SAME shape and MUST be passed `fg`, `grid`, and `ramp` from
`newSlide` so they match the slide's tone. Bold/minimal: transparent chart area
(shows slide bg), condensed value labels, subtle gridlines, value axis hidden on
bar/column in favor of on-bar labels.

`addColumnChart(slide, { x, y, w, h, labels, values, name, fg, grid, ramp })` — vertical columns w/ value labels (revenue by year).
`addLineChart(slide, { x, y, w, h, labels, values, name, fg, grid, ramp })` — trend line w/ markers (growth over time).
`addDonutChart(slide, { x, y, w, h, labels, values, name, fg, grid, ramp })` — share/breakdown ring w/ legend (uses the full `ramp` for segments).
`addBarChart(slide, { x, y, w, h, labels, values, name, fg, grid, ramp })` — horizontal ranked bars w/ value labels.

```js
addColumnChart(slide, { x: MX, y: 4.2, w: 11, h: 6.2,
  labels: ["2022","2023","2024","2025","2026"], values: [4,9,18,31,52],
  name: "Revenue ($M)", fg, grid, ramp });
```

## Gotchas
- **`main()` is a worked example, not a fixed sequence.** Build the slide set the
  user's content needs; reuse the helpers in any order/count/combination.
- **Impact is much WIDER than the source's Anton.** The `SZ` role scale is
  already calibrated for it — long single words wrap mid-word ("PITC/H") only
  when the box is too narrow; fix by widening `w` or forcing a `\n` break,
  never by changing the role's size.
- **No hollow/outline text.** LibreOffice ignores text `outline` entirely — a
  fill=bg + stroke numeral renders invisible. Stat numerals are solid-filled here.
- **Charts need `fg`/`grid`/`ramp` from `newSlide`.** Omitting them yields
  default (wrong-tone) colors that clash with the slide background.
- **No logos, no ghost/double-headline, no headshot photos** — deliberately
  removed; keep it that way (brand-neutral; the doubled headline read as a defect).
- Deterministic QA: run `python scripts/check_deck.py output.pptx` (see [../qa.md](../qa.md)).

## Vertical stacking — `makeStack`

Every template ships `makeStack(startY, defaultGap)` — a cursor that computes
`y` for you when a slide stacks elements vertically. `stack.place(h, gap?)`
returns the y for a block of height `h` and advances past it; `stack.y()` reads
the current cursor (e.g. for a footline).

```js
const stack = makeStack(1.2);
addKicker(slide, "Section", { x: MX, y: stack.place(0.4) });
addBody(slide, "...",       { x: MX, y: stack.place(2.0, 0.3) });
addFootLine(slide, "...",   { x: MX, y: stack.y() });
```

Use it whenever a slide stacks 3+ elements: to fix a text-fit failure you then
change ONE height and everything below re-flows — hand-placed absolute `y`
values are how fixing one box creates the next overlap.
