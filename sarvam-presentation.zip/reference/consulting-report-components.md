# consulting-report-style.js — Component Reference

Concise index of every reusable helper in `scripts/consulting-report-style.js` (~2200
lines, ~22 helpers), so you can compose a deck without scanning the whole script.
Read [../consulting_style_rules.md](../consulting_style_rules.md) first, then this component
reference. This contract is self-contained: never open, grep, copy, or patch the
template. Write only `deck-main.js`; run `scripts/compose_deck.py` to produce the
executable script.

**Style:** research-report look — bold near-black action-title headlines, blue
accent palette, dense card/chart/table vocabulary. Standard 10×5.625in canvas.

## Contents
- Setup (required constants)
- Slide shells (call one first, per slide)
- Dividers / recap
- Charts & data
- Tables
- Cards / lists
- Diagrams
- Supporting panels
- Content caps (avoid overflow)
- Gotchas
- Vertical stacking — `makeStack`

## Setup (provided by the composer)
`compose_deck.py` supplies `pres`, `C`, `CHART_COLORS`, `FONT_H`, `FONT_B`,
`GRID`, `TYPE`, `SPACE`, `CHART_DEFAULTS`, and every helper below. Do not declare
or copy them into `deck-main.js`. Use the documented names directly.

## Slide shells (call one first, per slide)
`addSimpleCoverSlide({ title, subtitle })` — flat color field, centered title+subtitle.
`addCoverSlide({ eyebrow, title, subtitle, brandName, photoDataUri })` — full-bleed dark cover w/ line/node accent, lime title; pass `photoDataUri` for a photo bg.
`addContentSlide(actionTitle, pageNum, { note })` — white bg, bold black action title, footer. Returns the slide; add content into it.
`addBannerHeaderSlide(actionTitle, pageNum)` — full-width colored banner instead of a plain title.
`addSimpleClosingSlide({ title, subtitle })` — flat field, centered statement.
`addClosingSlide({ line1, line2, brandName, contacts })` — dark two-tone statement + contact row.

```js
const slide = addContentSlide("Mid-market platforms beat point solutions", 6);
addFourPanelGrid(slide, panels, { y: 1.55, h: 3.75 });
```

## Dividers / recap
`addNumberedThemeGrid({ title, titleAccent, leftItems, rightItems, spotlight, banner, pageNum })` — N numbered items across left/spotlight/right columns + a full-width banner row. This is its own full slide (don't wrap in addContentSlide).

## Charts & data
Use the factory whose semantics match `deck-plan.json`; do not use horizontal
bars as a universal fallback.

`addConsultingBarChart(slide, { series, x, y, w, h, unit, maxValue, comparison=false, firstCategoryAtTop=true, showLegend, options })` — ranked/long-label comparisons. Enforces dimensions, visible units, top-first order, and multi-series legends.
`addConsultingColumnChart(slide, { series, x, y, w, h, unit, maxValue, minValue=0, stacked=false, comparison=false, showLegend, options })` — discrete comparisons or short time series; use `stacked:true` only for composition-over-time with 2+ series.
`addConsultingLineChart(slide, { series, x, y, w, h, unit, maxValue, minValue=0, comparison=false, showLegend, options })` — trends with at least 4 ordered points.
`addConsultingAreaChart(slide, { series, x, y, w, h, unit, maxValue, minValue=0, options })` — one cumulative series with at least 4 ordered points; use at most once per deck.
`addConsultingDonutChart(slide, { label, segments, x, y, w, h, showLegend=false, showPercent=true, expectedTotal=100, options })` — part-to-whole only. Segments must total `expectedTotal`±0.5; add an explicit remainder such as “Other”. Use `expectedTotal:null` only for count data.

Every `series` entry is `{ name, labels: [...], values: [...] }` with equal-size
arrays. A single chart must be at least 6.0×2.5in; only a direct A/B pair may
use `comparison:true` at 4.0×2.5in each. Multi-series charts always show a
legend.
`addPercentBarList(slide, { x, y, w, h, heading, items, max=100 })` — hand-drawn horizontal ranked bar + value list.
`addStackedBarRows(slide, { x, y, w, h, groups, legend })` — horizontal 100%-style stacked bar rows + legend (contrast-aware labels).
`addFourPanelGrid(slide, panels, { y=1.55, h=3.75, note })` — dashboard with exactly 2 or 4 panels; each panel is `"bars"` | `"donuts"` | `"iconlist"`. Bar panels use compact horizontal metric bars rather than squeezed mini-columns; donut panels render every segment in their text legend.

## Tables
`addComparisonMatrix(slide, { x, y, w, h, groups, indicatorCols, descColHeading, segColHeading, tacticColHeading })` — grouped left category column + colored-dot indicator columns, hand-drawn (native `addTable()` can't do the grouped rowspans). Explicitly pass headings that fit the subject; never accept the default “Tactic” for a company/vendor matrix. Marks are `"high"`, `"medium"`, or `null`; explain their meaning in the slide note because color alone is not a legend.
`addMythRealityTable(slide, { mythHeading, realityHeading, rows, y=1.35, h=3.85 })` — numbered rows: statement | rebuttal | quote. Give the number badge real left inset.

## Cards / lists
`addIconBulletRow(slide, { x, y, w, h, items, iconColor })` — vertical stack of icon-accent + title + body.
`addIconCardStack(slide, { x, y, w, h, heading, cards })` — 1–3 stacked soft-surface cards w/ left accent bar.
`addNumberedProcessCards(slide, { x, y, w, h, steps, outcome })` — N numbered step-cards flowing into a highlighted outcome box.
`addLetteredCardList(slide, { x, y, w, h, rows })` — full-width rows, lettered badge + inline-bold body.

## Diagrams
`addHubChainDiagram(slide, { x, y, w, h, steps })` — vertical connected-node chain, alternating labels.
`addValueChainFlow(slide, { x, y, w, h, nodes })` — horizontal box/circle chain w/ dashed connectors + optional % badges.
`addCycleDiagram(slide, { cx, cy, labels, petalW=1.0, petalH=0.55, petalColor })` — exactly 4 square "petals" around a center hub.

## Supporting panels (alongside other content, not standalone)
`addSidebarPanel(slide, { x, y, w, h, heading, bullets, quotes })` — beige right-hand column; provide exactly one mode: a heading plus 2–4 concise bullets, or 1–2 attributed quotes. It sizes each bullet row before drawing and throws instead of clipping.
`addFooter(slide, pageNum, note)` — footer page-number + optional note.
`addBrandMark(slide, { x, y, dark, brandName })` — optional PLAIN-TEXT wordmark only (no logo glyph — brand-neutral).

## Content caps (avoid overflow)

Helpers validate their contracts before drawing and throw a message that names
the offending component. Reduce items or split the slide; never bypass a
contract by shrinking text.

| Helper | Safe content budget |
|---|---|
| `addNumberedThemeGrid` | 1–3 items per column; item title ≤ 4 words; body ≤ 18 words |
| `addPercentBarList` | 2–5 items; heading ≤ 8 words; label ≤ 7 words |
| `addFourPanelGrid` | exactly 2 or 4 panels; title ≤ 5 words; bar label ≤ 5 words |
| `addComparisonMatrix` | ≤ 8 rows and ≤ 5 indicator columns |
| `addMythRealityTable` | ≤ 4 rows; myth/reality ≤ 22 words; quote ≤ 30 words |
| `addNumberedProcessCards` | 2–4 steps; title ≤ 4 words; body ≤ 15 words |
| `addIconCardStack` | 1–3 cards; title ≤ 3 words; body ≤ 16 words |
| `addLetteredCardList` | 2–5 rows; sentence ≤ 25 words |
| `addStackedBarRows` | 2–5 groups and 2–5 legend entries |
| `addSidebarPanel` bullets | heading ≤ 6 words; 2–4 bullets; each bullet ≤ 12 words |
| `addSidebarPanel` quotes | 1–2 quotes; quote ≤ 30 words + one-line attribution |

Longer content means fewer items per slide or a different layout — never a
smaller font.

## Gotchas
- **`main()`'s 13-slide sequence is a worked example, not a fixed template.** Build
  the slide set the user needs; reuse helpers in any order/count/combination
  (e.g. `addFourPanelGrid` with 2 or 4 panels, `addIconCardStack` with 3 cards).
- **Never reuse a shadow/option object** — call `softShadow()` fresh each time;
  pptxgenjs mutates option objects in place.
- **Hand-drawn tables need complete grids** — every column a header, grouped cells
  get per-row divider lines, or the table reads as missing cells.
- **Rotated text wraps against the un-rotated box width** — build the box with
  `w`/`h` swapped around the visual center, then apply `rotate`.
- Deterministic QA: run `python scripts/run_qa.py output.pptx` (see [../qa.md](../qa.md)).

## Vertical stacking — `makeStack`

Every template ships `makeStack(startY, defaultGap)` — a cursor that computes
`y` for you when a slide stacks elements vertically. `stack.place(h, gap?)`
returns the y for a block of height `h` and advances past it; `stack.y()` reads
the current cursor (e.g. for a footline).

```js
const stack = makeStack(1.2);
addKicker(slide, "Section", { x: MX, y: stack.place(0.4) });
addBody(slide, "...",       { x: MX, y: stack.place(2.0, 0.3) });
addFootLine(slide, "...",   { x: MX, y: stack.y() });
```

Use it whenever a slide stacks 3+ elements: to fix a text-fit failure you then
change ONE height and everything below re-flows — hand-placed absolute `y`
values are how fixing one box creates the next overlap.
