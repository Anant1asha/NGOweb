# Deck plan contract

Create `deck-plan.json` before slide code. The plan is the source of truth for
narrative, evidence, chart semantics, and units. Run:

```bash
python scripts/validate_deck_plan.py deck-plan.json
```

Exit `0` means code may be written. Exit `1` means fix only the reported plan
fields and rerun. Do not weaken the validator.

## Exact shape

```json
{
  "audience": "Investor / financial analysis",
  "goal": "Decide whether the company merits deeper diligence",
  "narrative": "Scale and margin expansion support the thesis, but valuation limits upside.",
  "brand_name": "",
  "brand_source": "none",
  "sources": [
    {
      "id": "s1",
      "kind": "external",
      "title": "Q1 2026 shareholder letter",
      "publisher": "Example Co.",
      "url": "https://example.com/q1-2026",
      "published": "2026-04-28"
    }
  ],
  "slides": [
    {
      "number": 1,
      "role": "cover",
      "visual": "cover",
      "title": "Example Co.",
      "subtitle": "Investor review · July 2026"
    },
    {
      "number": 2,
      "role": "content",
      "visual": "line",
      "title": "Margins expand with scale",
      "takeaway": "Operating margin rose each quarter as revenue scaled.",
      "supporting_points": [
        "Q1 margin reached 16%",
        "Basis: reported operating income"
      ],
      "source_ids": ["s1"],
      "data_shape": "trend-over-time",
      "data": {
        "unit": "%",
        "basis": "Reported operating margin by fiscal quarter",
        "order": "chronological-asc",
        "part_to_whole": false,
        "categories": ["Q2'25", "Q3'25", "Q4'25", "Q1'26"],
        "series": [
          {"name": "Operating margin", "values": [9.8, 11.6, 14.9, 15.8]}
        ]
      }
    },
    {
      "number": 3,
      "role": "sources",
      "visual": "sources",
      "title": "Sources"
    },
    {
      "number": 4,
      "role": "closing",
      "visual": "closing",
      "title": "Decision and next step"
    }
  ]
}
```

## Rules encoded by the validator

- Slides are numbered consecutively; cover is first, sources is penultimate
  when evidence is used, and closing is last.
- Every content slide has a short title, one takeaway, `supporting_points`, and
  valid `source_ids`. User-provided evidence uses a source with
  `"kind": "internal"` and a descriptive title; do not fabricate a URL.
- `brand_name` is empty unless the user supplied it. If supplied, set
  `"brand_source": "user"`.
- Chart data carries one explicit `unit`, a human-readable `basis`, ordered
  categories, and equal-length series.
- Part-to-whole percentages total 100±0.5. If a percentage comparison omits
  categories, add `"coverage_note"` (for example, `"Selected vendors; Other =
  14.6%"`) and include the remainder in the slide copy.
- Use horizontal bars for ranked/long-label comparisons, columns for discrete
  or short comparisons, lines for 4+ ordered time points, stacked columns for
  composition over time, donuts only for part-to-whole, and area only for a
  cumulative trend.
- Matrix slides include `matrix.headings`, a text `matrix.legend` with `high`,
  `medium`, and `none` labels, plus sourced `matrix.criteria`. Never leave
  generic template headings such as “Tactic” in a company comparison.
- Any slide containing a DCF, intrinsic value, price target, bull/base/bear
  case, forecast, or “fair” multiple includes a non-empty `"methodology"` and
  at least three explicit `"assumptions"`. Otherwise remove the claim.
- Do not mix currencies, periods, percentages, counts, reported growth, and
  constant-currency growth without stating the basis in the title, takeaway,
  data basis, or supporting point.
