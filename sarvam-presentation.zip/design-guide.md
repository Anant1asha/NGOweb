# Design Guide

Brand-neutral rules for clean, professional, executive/business decks built with PptxGenJS. Apply these on top of any template in `scripts/`.

## Contents
- Slide titles (the most important rule)
- Typography (Calibri default)
- Color: choosing a palette
- Palette library (copy one)
- Layout grid (10" × 5.625")
- Cards
- Charts & data
- Varied layouts (avoid monotony)
- Common failure patterns (from hillclimbing real decks)
- Prohibitions

---

## Slide titles

**Default: a short 3–6 word heading** naming the slide's subject; **upgrade to a
one-line claim (≤ ~8 words) only where the slide argues a point.** This is the
single highest-impact choice for clean, executive decks.

- Good default: "Timeline", "Rollout plan", "Unit economics", "The ask"
- Good claim (argument slides): "The EV market grew 5x since 2020"
- Bad — enumerating the body in the title: "Beta in July, release candidate in
  August, GA and full rollout in September" (that's the slide's content; the
  title is "Timeline")
- Bad — a claim stretched into a sentence-summary of the slide: if the claim
  needs more than ~8 words, it's a summary, not a title — cut it back or use
  the short label.

Deciding the title first forces you to know the slide's one point before
designing it; full rules in [content-guide.md](content-guide.md).

---

## Typography

**Default font: Calibri** for both headings and body — professional, ships with Office, renders consistently. Only change if the user asks.

Acceptable pairings (header / body) if a different feel is requested:

| Header | Body | Feel |
|--------|------|------|
| Calibri | Calibri | Clean, modern (default) |
| Georgia | Calibri | Traditional consulting |
| Cambria | Calibri | Editorial, serious |
| Trebuchet MS | Calibri | Friendly, approachable |

Size scale (pt) for LAYOUT_16x9:

| Element | Size |
|---------|------|
| Cover / closing title | 32–40, bold |
| Slide (action) title | 20–24, bold |
| Section header within slide | 14–16, bold |
| Body / bullets | 14–16 |
| Big stat numeral | 36–44, bold |
| Caption / footer / axis | 9–11, muted |

Rules: left-align body and bullets always; center only on cover, dividers, and closing. Use size and weight (not color) for emphasis. Never italic/underline for emphasis.

### Dense consulting-report exception

The 14–16pt body scale applies to narrative slides. The structured helpers in
`consulting-report-style.js` may use 9.5–11pt text inside matrices, dashboards,
legends, and compact cards because those components have explicit content caps,
minimum dimensions, and deterministic text-fit checks. This is a component
contract, not a general license to shrink text. Read
[consulting_style_rules.md](consulting_style_rules.md); if copy does not fit at the helper's
declared size, reduce items or split the slide.

---

## Color: choosing a palette

- **Pick a palette that fits the topic.** If your colors would work equally well on an unrelated deck, they're too generic.
- **Dominance over equality.** One color dominates (60–70% of visual weight), 1–2 supporting tones, one sharp accent. Never give every color equal weight.
- **Dark/light sandwich.** Dark backgrounds for title + closing, light for content. Or commit to dark throughout for a premium feel.
- **One accent.** Use the accent sparingly — large numerals, a single bar, a thin rule. Not on every element.

---

## Palette library

Copy one into a template's `C`/`PALETTE` constant. No `#` prefix (PptxGenJS requirement).

| Theme | Primary (dark) | Secondary | Accent |
|-------|----------------|-----------|--------|
| **Professional Navy** (default — `professional-style.js`) | `0D1B2A` | `1B3A5C` | `0E7C86` (teal) or `7C3AED` (violet) |
| **Executive Navy** | `0F2A43` | `1C3B57` | `2E7DA6` / gold `C9A24B` |
| **Charcoal Minimal** | `2B2B2B` | `F2F2F2` | `C0392B` (signal red) |
| **Deep Teal** | `0B3C49` | `13697B` | `E0A458` (amber) |
| **Forest** | `1E3A2F` | `3E6B53` | `D4A23A` (gold) |
| **Slate & Coral** | `27303B` | `4A5A6A` | `F25C54` (coral) |
| **Ink & Gold** | `1A1A2E` | `2C2C44` | `C9A24B` (gold) |
| **Consulting Report Blue** (from `scripts/consulting-report-style.js`) | `0B1C2C` | `0F1E30` | `2F6FED` (blue) / lime `C9D94A` (cover title only) |
| **Bold Pitch Maroon/Pink** (from `scripts/bold-pitch-style.js`) | `70020F` (maroon) | `FEDEE1` (pink) | two-tone: maroon text on pink slides, pink text on maroon slides |

Neutrals that work with any of the above: text `1A1A1A` (never pure black `000000`), body `5A5A5A`, caption `8C8C8C`, hairline `DCDCDC`, surface `F4F6F8`, paper `FFFFFF`.

---

## Layout grid (10" × 5.625")

| Element | x | y | w | h |
|---------|---|---|---|---|
| Left/right margin | 0.5 | — | 9.0 (content width) | — |
| Action title | 0.5 | 0.35 | 9.0 | 0.8 |
| Content zone | 0.5 | 1.4 | 9.0 | 3.6 |
| Footer (page number) | bottom-right | 5.34 | — | 0.2 |

Keep at least 0.5" margins; use 0.25–0.4" gaps between blocks consistently; leave breathing room.

---

## Cards

- White fill, hairline border (`line: { color: "DCDCDC", width: 0.75 }`).
- Optional soft shadow OR border — not two heavy treatments. Recreate the shadow object per call (PptxGenJS mutates it).
- Structure: optional large numeral/kicker (accent) → bold title → muted body.
- Equal widths in a row; consistent internal padding (~0.2").

---

## Charts & data

- **One chart per slide is the default**, at generous size (`w ≥ 6in` on the
  10in canvas). The only sanctioned two-chart layout is a direct A-vs-B
  **comparison pair**: half/half across the full content width, each chart
  `≥ 4in` wide. Never shrink charts to fit alongside other content blocks —
  a chart squeezed under ~4in wide has unreadable labels at slide size; move
  the other content to its own slide instead.
- Place charts in the content zone below the title (`y ≈ 1.4`, `h ≈ 3.6`).
- **Legend whenever a chart has more than one series** (`showLegend: true`,
  bottom). Single-series charts may drop the legend but must carry data labels
  or a readable value axis so values are readable without one.
- White chart area, no fill tints, no 3D, no shadows.
- Value axis gridlines only at `0.5pt` in the hairline color; hide category gridlines (`catGridLine: { style: "none" }`).
- Axis/legend text in the muted caption color, 9–11pt, in the deck font.
- Accent color = chart series 1; supporting tones for the rest. Reserve the accent for the story, not decoration.
- Pie/doughnut: max ~5 segments, then group "Other".

The chart options used in `scripts/professional-style.js` follow these rules. For
consulting-report decks, always call `addConsultingBarChart()` or
`addConsultingDonutChart()` rather than re-deriving options: the factories enforce
dimensions, explicit units, tuned gap/axis styling, legend policy, and donut
viability.

---

## Varied layouts (avoid monotony)

Monotonous decks are the most common failure mode. Rotate among:
- Two-column (text + chart, or compare A/B)
- Numbered/kicker card rows (2–4 cards)
- Big-stat callout row (large numbers, small labels)
- Quote / single-statement slide
- Section dividers between major topics
- Icon + text rows (icons rasterized to PNG via `sharp`)

Match layout to content type; never repeat the same title+bullets slide.

---

## Common failure patterns (from hillclimbing real decks)

`scripts/consulting-report-style.js` was built and iteratively fixed against a
curated golden set of real decks — see its own header comment and
`ppt_golden_set/template_2/PROGRESS.md` for the round-by-round history. Most
of the real, user-caught defects along the way fell into a small number of
recurring patterns, most of which `check_deck.py`'s bounds/overlap/font-floor
checks (plus its text-fit heuristic, see QA in SKILL.md) **cannot** see on
their own. **Design them out up front, in the build script's coordinates and
sizes** — do not try to catch them by rendering slides to images (see qa.md:
visual QA is not part of this skill's workflow):

- **Text overflowing its own box.** `check_deck.py`'s box-vs-box overlap
  check only catches a text box colliding with a *different* shape — it
  doesn't (fully) catch a box whose own content is simply taller than the
  box itself (e.g. 22pt bold text in a 0.28in-tall row). `check_deck.py` now
  includes a heuristic estimate for this (chars-per-line from box width/font
  size vs. box height), but it's an estimate — when a box holds text whose
  exact length can vary (user-supplied headings, wrapping-dependent labels),
  size the box for the *worst case* it needs to hold, not the one example
  you tested with. And stack slide elements with the template's `makeStack`
  cursor (see the component reference) instead of hand-placed absolute `y`
  values — then growing one box re-flows everything below it instead of
  creating the next overlap.
- **Text/element overlap that isn't two text boxes.** The overlap check only
  compares text-bearing shapes to each other — a decorative shape with no
  text frame (an icon square, a brand mark, a connector line) can still
  visually collide with a *neighboring* text box without either check
  catching it. Leave explicit clearance in the coordinates wherever a
  non-text shape sits near text, especially near a title.
- **Inconsistent sizing across visually-parallel elements.** If several
  elements share the same visual role (numeral badges in a row of cards, a
  set of stat callouts, icons in a repeating list), give them the *same*
  font size / same shape size everywhere they appear — even a small
  variance (e.g. 20pt vs. 16pt vs. 22pt across three groups of otherwise
  identical numeral badges) reads as an obvious inconsistency once multiple
  instances are on screen together, even though no single instance looks
  wrong in isolation.
- **Text sitting flush against its container's edge.** A numeral, badge, or
  label positioned with near-zero left/top inset from its own card/row
  reads as a mistake ("stuck to the edge"), not a deliberate design choice.
  Leave a real inset (~0.12–0.16in minimum) between any text and the edge
  of the shape it sits inside.
- **Chart/legend elements competing for the same scarce space.** Stacking a
  label, a chart, and a separate legend/caption vertically in a short,
  wide panel (e.g. a 2x2 dashboard quadrant) starves the chart itself —
  each additional stacked text row directly shrinks the chart. Prefer
  embedding a key stat inside a donut's hole, or placing a label/legend
  *beside* a chart rather than above/below it, when the container is wider
  than it is tall.
- **Decorative connector shapes that read as broken.** A filled block shape
  (e.g. `CHEVRON`) used as a directional connector between two elements
  tends to render as a clunky, disproportionate arrow rather than a clean
  connector. Prefer a thin `LINE` shape with `line: { endArrowType:
  "triangle" }` for an actual arrowhead, or — often better — no connector
  glyph at all; two clearly-labeled adjacent elements usually don't need an
  arrow between them to read as related.
- **Icon placeholders that look unfinished.** This skill has no icon asset
  library, so a recurring pattern is a plain shape standing in for an icon.
  An **unfilled outline square with nothing inside it** reads as a broken or
  missing icon, not a deliberate minimal design. A **solid filled color
  square** is a safer placeholder; a **thin accent bar** on a card's leading
  edge is often better still (it doesn't pretend to be an icon it isn't).
- **Hand-drawn table/grid completeness.** When building a table from
  shapes/text instead of `addTable()` (needed for merged/grouped-row
  layouts `addTable()` can't express), every column needs a header cell —
  including structural columns like a row-group label — or the header row
  reads as incomplete against the rest of the grid. Likewise, a
  merged/grouped cell spanning multiple rows needs thin internal divider
  lines at each row boundary to match the surrounding per-row grid, or it
  reads as a missing cell.
- **Rotated text wrapping against the wrong dimension.** `rotate: 270/90`
  visually reorients text, but PptxGenJS still wraps the text against the
  box's *un-rotated* `w` — passing the narrow column width there (the
  intuitive thing to do) forces short words into an ugly mid-word wrap
  ("Mid-" / "marke" / "t"). Build the box with `w`/`h` swapped (`w` = the
  long/reading axis after rotation, `h` = the column's actual thickness)
  around the same visual center, then apply `rotate`.
- **Decorative marks that accidentally mimic a real logo.** When a template
  is inspired by a real reference deck, an abstract geometric accent
  (a triangle, a specific icon shape) copied from that reference can
  accidentally reproduce the reference's actual company logo — especially
  if it recurs in the same position on every single slide, which is exactly
  how branding marks are used. Keep decorative accents genuinely
  abstract (thin lines, dots, generic shapes) and never let one shape
  become a recurring per-slide signature that could read as a wordmark or
  logo.

---

## Prohibitions (hard rules)

- **Never pure black** (`000000`) — use `1A1A1A`.
- **Never an accent line directly under the title** — a hallmark of AI-generated slides; use whitespace instead.
- **Never center body text** — left-align paragraphs and lists.
- **Never text-only slides** — add a chart, cards, stats, or other visual structure.
- **Never emoji** — use `•` bullets, `|` pipes, `→` arrows.
- **Never `#` in hex colors**, and never 8-char hex for opacity — use the `opacity` property.
- **Never reuse option/shadow objects** across `addShape`/`addText` calls.
- **Never give all colors equal weight** — commit to one dominant color and one accent.
- **Never use an unfilled outline shape as a stand-in icon** — it reads as a
  broken/missing icon, not a minimal design; use a solid color block instead.
- **Never invent a recurring per-slide decorative mark** copied or adapted
  from a real reference deck — even an abstracted shape can reproduce that
  deck's actual logo. This is a brand-neutral skill; it doesn't source or
  replicate real company logos, full stop.
