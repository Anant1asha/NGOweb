# Consulting Report Design System

Authoritative rules for `scripts/consulting-report-style.js`. Use this system for
dense research, market, strategy, and data-heavy consulting decks. Preserve these
tokens and component contracts unless the user explicitly supplies another brand.

## Design principles

1. One message per slide. Titles are short labels by default and concise claims
   only when the slide argues a point.
2. Geometry follows content. Never shrink text to force oversized content into a
   fixed box; reduce items or split the slide.
3. Reuse the template helpers. Do not rebuild cards, tables, legends, or chart
   chrome ad hoc inside `main()`.
4. Dense does not mean cramped. Every container keeps a visible inset and every
   chart keeps enough room for labels and legends.
5. One visual hierarchy per deck. Parallel elements use the same typography,
   inset, alignment, and spacing.

## Color tokens

Use hex values without a `#` prefix.

| Token | Hex | Usage |
|---|---|---|
| `navy` | `0B1C2C` | Cover and dark surfaces |
| `navySurface` | `0F1E30` | Spotlight panels |
| `blue` | `2F6FED` | Primary accent, first chart series, links |
| `blueLight` | `DCEAFE` | Highlight surfaces and banners |
| `lime` | `C9D94A` | Cover title only; never a general content accent |
| `ink` | `12181F` | Titles and primary text; never pure black |
| `ink2` | `4A4A4A` | Body text |
| `ink3` | `8C8C8C` | Captions, axes, legends, footers |
| `line` | `DCDCDC` | Card borders and light rules |
| `lineDark` | `333333` | Dense hand-drawn table grids |
| `gray` | `BFBFBF` | Secondary bars and low-priority data |
| `paper` | `FFFFFF` | Default background |

Chart series order is `blue`, `ink`, `gray`, `lime`, `navy`. Do not reorder the
palette between slides when series meaning is stable.

## Grid and spacing tokens

Standard canvas: 10 × 5.625 inches.

| Slot | Value |
|---|---|
| Left/right margin | `0.50in` |
| Title | `x=0.50, y=0.30, w=8.00, h=0.90` |
| Content top | `1.35in` |
| Content bottom | `5.15in` |
| Footer | `y=5.34in, h=0.22in` |
| Standard block gap | `0.25in` |
| Dense block gap | `0.12in` |
| Container inset | minimum `0.14in` |
| Text-to-visual clearance | minimum `0.10in` |

Use `makeStack()` whenever a slide contains three or more vertically arranged
blocks. If a block grows, all blocks below it must reflow.

## Typography roles

The consulting template uses Helvetica for predictable cross-platform rendering.

| Role | Size | Rules |
|---|---:|---|
| Cover title | 40pt | Bold, one line preferred |
| Content title | 24pt | Bold, 1–2 lines maximum |
| Section heading | 14pt | Bold |
| Standard narrative body | 14pt | Use on low-density narrative slides |
| Dense card/table body | 9.5–11pt | Only inside structured report components |
| Card title | 11–13pt | Bold |
| Hero statistic | 32pt | One fixed size across parallel statistics |
| Caption/axis/legend | 9–10pt | Never below 9pt |
| Footer | 8pt | Only permitted 8pt role |

Dense typography is an explicit component mode, not permission to shrink arbitrary
text. If content cannot fit at the component's declared size, split the slide.

## Component contracts

Every helper validates its content budget before drawing. A violated contract
must throw an actionable error naming the helper and suggesting fewer items or a
split slide.

| Helper | Contract |
|---|---|
| `addNumberedThemeGrid` | 1–3 columns; 1–3 items per column; title ≤ 10 words; item title ≤ 4 words; body ≤ 18 words |
| `addPercentBarList` | 2–5 items; heading ≤ 6 words; labels ≤ 6 words |
| `addFourPanelGrid` | Exactly 2 or 4 panels; panel heading ≤ 5 words; bar label ≤ 5 words; dashboard bars are horizontal, never compressed mini-columns |
| `addComparisonMatrix` | Maximum 8 data rows and 5 indicator columns |
| `addMythRealityTable` | Maximum 4 rows; each statement/rebuttal ≤ 22 words |
| `addIconCardStack` | 1–3 cards; title ≤ 3 words; body ≤ 16 words |
| `addNumberedProcessCards` | 2–4 steps; title ≤ 3 words; body ≤ 15 words |
| `addLetteredCardList` | 2–5 rows; one sentence ≤ 25 words |
| `addSidebarPanel` | Exactly one content mode; bullet mode = heading ≤ 6 words plus 2–4 bullets of ≤ 12 words each; quote mode = 1–2 quotes of ≤ 30 words |
| `addStackedBarRows` | 2–5 groups and 2–5 legend entries |

## Charts and legends

- Single-chart slide: chart width ≥ `6.0in`, height ≥ `2.8in`.
- Direct A/B comparison: each chart width ≥ `4.0in`, height ≥ `2.5in`.
- A horizontal bar chart renders its first input category at the top. Do not
  manually reverse chronological or ranked data in `main()`.
- Donut: both dimensions ≥ `0.85in`; `holeSize` ≤ `50`.
- Multi-series charts always show a legend. Single-series charts may omit it only
  when the series name is explicit in the title/subtitle.
- Every chart declares its unit (`%`, `$M`, count, index, etc.) in the axis title,
  chart subtitle, or data-label suffix.
- Axis, legend, and data-label text is 9pt or larger.
- Value-axis gridlines only; no 3D and no shadows.
- Donut legends render every segment, not only the first item.
- Reserve vertical space for legends; never overlay a legend on the plot area.
- A chart-plus-sidebar layout keeps the chart at least `6.0in` wide and limits
  the sidebar to the bullet contract above. Split detail onto another slide
  instead of narrowing the chart or adding a fifth bullet.

Use the shared chart factories and `CHART_DEFAULTS`; do not derive chart options
again inside `main()`.

## Bookends and composition

- Use `addCoverSlide()` for a full report and `addSimpleCoverSlide()` only for a
  short internal memo.
- Use `addClosingSlide()` when contacts or a final statement are needed;
  `addSimpleClosingSlide()` is for short internal memos.
- Place a references slide immediately before closing when external facts or data
  sources are used.
- Vary layouts according to content, but never repeat the same dense grid on
  consecutive slides.

## Hard prohibitions

- Never use pure black `000000`.
- Never use a `#` prefix in PptxGenJS color values.
- Never shrink component text below its declared typography role.
- Never center body copy.
- Never place text flush against a container edge.
- Never omit units or a required multi-series legend.
- Never mix ad hoc chart styling with the shared consulting chart defaults.
- Never reuse shadow or mutable option objects across PptxGenJS calls.
- Never add unfilled outline squares as icon placeholders.
- Never add a recurring decorative mark that resembles a real company logo.

## Required QA

Run:

```bash
python scripts/run_qa.py output.pptx
```

The gate checks bounds, overlap, text fit, container insets, chart dimensions,
chart label floors, donut viability, visual collisions, and typography-role
consistency. A failing component contract must be fixed in the build script by
reducing content or changing layout, not by reducing font size.
