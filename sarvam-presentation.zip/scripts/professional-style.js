/**
 * Professional Presentation Template (PptxGenJS) — the default look.
 *
 * A clean consulting/strategy style: deep-navy title + closing slides, light
 * content slides, a single sharp accent, and "action titles" (every content
 * title is a full sentence stating the insight). The everyday default for
 * business/executive/strategy decks. Rich helper set — cover, section divider,
 * action-title content slides, bullet lists, card rows, big-stat rows,
 * two-column compares, charts, quotes, and a numbered-recommendations closing.
 *
 * Default font is Calibri (ships with Office, renders consistently — no font
 * files needed). For a more traditional consulting feel set FONT_HEADER to a
 * serif ("Georgia" or "Cambria") and keep Calibri for body.
 *
 * Concise component reference: reference/professional-components.md
 *
 * HOW TO USE
 *   1. Copy this file next to your project; edit PALETTE / FONT constants for a
 *      different look.
 *   2. Do NOT just replace main() 1:1 — it's a WORKED EXAMPLE of each helper's
 *      calling convention, not a fixed slide sequence/count. Every function
 *      below is independently callable; decide the slide set from the user's
 *      content and reuse the helpers in whatever order/count/combination fits.
 *      See reference/professional-components.md for the full index.
 *   3. Run:  node professional-style.js   ->  output.pptx
 *
 * Requires:  npm install pptxgenjs
 * Optional (icons): npm install react react-dom react-icons sharp
 *
 * Design rules baked in (see design-guide.md):
 *   - Action titles (a full-sentence insight, not a topic label)
 *   - Left-aligned body; centered text only on cover / divider / closing
 *   - No accent line directly under titles (a hallmark of AI-made slides)
 *   - Never pure black (#000000) — use darkText
 *   - Hairline borders + soft shadows on cards; never both heavy
 */

const path = require("path");
const pptxgen = require("pptxgenjs");

// ─── CUSTOMIZE: PALETTE (no "#" prefix) ───
const PALETTE = {
  primary:     "0D1B2A", // deep navy — dominant color (cover/divider/closing bg)
  secondary:   "1B3A5C", // medium navy — cards on dark
  accent:      "0E7C86", // teal accent — bars, big numerals, key highlights (swap for your brand)
  accentLight: "5BB0B8", // light accent — subtitles, eyebrows, secondary highlights
  white:       "FFFFFF",
  offWhite:    "F7F8FA", // content slide background
  lightGray:   "E2E8F0", // borders, dividers
  medGray:     "8C97A3", // captions, citations, axis labels
  charcoal:    "3A4654", // body text
  darkText:    "1A1A1A", // headings on light bg (never pure black)
};

const CHART_COLORS = ["0E7C86", "0D1B2A", "5BB0B8", "8C97A3", "C7D0DA"];

// ─── CUSTOMIZE: FONTS (Calibri default) ───
const FONT_HEADER = "Calibri"; // try "Georgia" or "Cambria" for a serif feel
const FONT_BODY   = "Calibri";

// ─── SETUP ───
const pres = new pptxgen();
pres.layout = "LAYOUT_16x9"; // 10" x 5.625"
pres.author = "Presentation Skill";
pres.title = "Professional Presentation";

const MX = 0.5;      // left/right margin
const PAGE_W = 10;
const PAGE_H = 5.625;

// ─── HELPERS ───

/** Fresh shadow object each call — PptxGenJS mutates option objects. */
const makeShadow = () => ({ type: "outer", color: "000000", blur: 4, offset: 2, angle: 135, opacity: 0.08 });

// ─── Vertical stack cursor ──────────────────────────────────────────────────
// Place slide content top-to-bottom without hand-computing a y for every box:
// each place(h) returns the y for a block of height h and advances the cursor
// by h + gap. Changing one block's height re-flows everything below it — which
// is what prevents the "grew a box to fix text-fit, created a new overlap"
// cascade. Use it whenever a slide stacks 3+ elements vertically.
//   const stack = makeStack(1.2);                         // content top (in)
//   addKicker(slide, "...", { x: MX, y: stack.place(0.4) });
//   addBody(slide, "...",   { x: MX, y: stack.place(2.0, 0.3) }); // h, gap
//   addFootLine(slide, "...", { x: MX, y: stack.y() });   // current cursor
function makeStack(startY, defaultGap = 0.25) {
  let cur = startY;
  return {
    place(h, gap = defaultGap) { const y = cur; cur = y + h + gap; return y; },
    y() { return cur; },
  };
}

function addFooter(slide, pageNum) {
  slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 5.25, w: PAGE_W, h: 0.375, fill: { color: PALETTE.primary }, line: { type: "none" } });
  slide.addText(String(pageNum), {
    x: 9, y: 5.26, w: 0.7, h: 0.35,
    fontSize: 9, color: PALETTE.white, fontFace: FONT_BODY, align: "right", valign: "middle", margin: 0,
  });
}

/** White card with a left accent bar (the consulting visual motif). */
function addCard(slide, x, y, w, h, accentColor) {
  slide.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: PALETTE.white }, line: { type: "none" }, shadow: makeShadow() });
  slide.addShape(pres.shapes.RECTANGLE, { x, y, w: 0.06, h, fill: { color: accentColor || PALETTE.accent }, line: { type: "none" } });
}

/**
 * Render a react-icons component to a base64 PNG data URI.
 * Requires: npm install react react-dom react-icons sharp
 */
async function iconToBase64Png(IconComponent, color = "#1A1A1A", size = 256) {
  const React = require("react");
  const ReactDOMServer = require("react-dom/server");
  const sharp = require("sharp");
  const svg = ReactDOMServer.renderToStaticMarkup(
    React.createElement(IconComponent, { color, size: String(size) })
  );
  const png = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + png.toString("base64");
}

// ─── SLIDE TEMPLATES ───

/** Title / cover slide — dark background, large title, subtitle, tagline. */
function addTitleSlide(title, subtitle, tagline) {
  const s = pres.addSlide();
  s.background = { color: PALETTE.primary };
  s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: PAGE_W, h: 0.15, fill: { color: PALETTE.accent }, line: { type: "none" } });

  s.addText(title, {
    x: 0.8, y: 1.4, w: 8.4, h: 1.8,
    fontSize: 36, fontFace: FONT_HEADER, color: PALETTE.white, bold: true, valign: "top", margin: 0, lineSpacingMultiple: 1.05,
  });
  if (subtitle) {
    s.addText(subtitle, {
      x: 0.8, y: 3.3, w: 8.4, h: 0.5,
      fontSize: 18, fontFace: FONT_BODY, color: PALETTE.accentLight, margin: 0,
    });
  }
  if (tagline) {
    s.addText(tagline, {
      x: 0.8, y: 3.95, w: 8.4, h: 0.4,
      fontSize: 13, fontFace: FONT_BODY, color: PALETTE.medGray, margin: 0,
    });
  }
  s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 5.475, w: PAGE_W, h: 0.15, fill: { color: PALETTE.accent }, line: { type: "none" } });
}

/** Section divider — dark background, centered title with a small eyebrow. */
function addDividerSlide({ eyebrow, title }) {
  const s = pres.addSlide();
  s.background = { color: PALETTE.primary };
  s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: PAGE_W, h: 0.15, fill: { color: PALETTE.accent }, line: { type: "none" } });
  if (eyebrow) {
    s.addText(eyebrow.toUpperCase(), {
      x: 0, y: 2.0, w: PAGE_W, h: 0.3,
      fontSize: 12, fontFace: FONT_BODY, color: PALETTE.accentLight, bold: true, charSpacing: 3, align: "center", margin: 0,
    });
  }
  s.addText(title, {
    x: 0.8, y: eyebrow ? 2.4 : 2.1, w: PAGE_W - 1.6, h: 1.3,
    fontSize: 34, fontFace: FONT_HEADER, color: PALETTE.white, bold: true, align: "center", valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
  });
}

/**
 * Content slide shell — action title at top, returns the slide for content.
 * @param {string} actionTitle  a full sentence stating the insight
 */
function addContentSlide(actionTitle, pageNum) {
  const s = pres.addSlide();
  s.background = { color: PALETTE.offWhite };
  s.addText(actionTitle, {
    x: MX, y: 0.35, w: PAGE_W - MX * 2, h: 0.8,
    fontSize: 22, fontFace: FONT_HEADER, color: PALETTE.darkText, bold: true, valign: "top", margin: 0, lineSpacingMultiple: 1.05,
  });
  if (pageNum != null) addFooter(s, pageNum);
  return s;
}

/** Bullet list inside a content slide's body zone. */
function addBullets(slide, items, { x = MX, y = 1.4, w = PAGE_W - MX * 2, h = 3.6 } = {}) {
  slide.addText(
    items.map((t) => ({ text: t, options: { bullet: { code: "2022", indent: 18 }, breakLine: true, paraSpaceAfter: 10 } })),
    { x, y, w, h, fontSize: 15, fontFace: FONT_BODY, color: PALETTE.charcoal, valign: "top", margin: 0, lineSpacingMultiple: 1.15 }
  );
}

/** Equal-width cards in a row (white card + left accent bar). cards: [{ kicker, title, body }] */
function addCardRow(slide, cards, { y = 1.4, h = 3.4 } = {}) {
  const gap = 0.25;
  const w = (PAGE_W - MX * 2 - gap * (cards.length - 1)) / cards.length;
  cards.forEach((card, i) => {
    const x = MX + i * (w + gap);
    addCard(slide, x, y, w, h);
    if (card.kicker) {
      slide.addText(card.kicker, {
        x: x + 0.28, y: y + 0.22, w: w - 0.5, h: 0.5,
        fontSize: 26, fontFace: FONT_HEADER, color: PALETTE.accent, bold: true, margin: 0,
      });
    }
    slide.addText(card.title, {
      x: x + 0.28, y: y + (card.kicker ? 0.82 : 0.26), w: w - 0.5, h: 0.5,
      fontSize: 15, fontFace: FONT_HEADER, color: PALETTE.darkText, bold: true, margin: 0,
    });
    slide.addText(card.body, {
      x: x + 0.28, y: y + (card.kicker ? 1.32 : 0.8), w: w - 0.5, h: h - (card.kicker ? 1.5 : 1.0),
      fontSize: 11.5, fontFace: FONT_BODY, color: PALETTE.charcoal, margin: 0, valign: "top", lineSpacingMultiple: 1.15,
    });
  });
}

/** Big-number stat row. stats: [{ value, label }] */
function addStatRow(slide, stats, { y = 1.7 } = {}) {
  const colW = (PAGE_W - MX * 2) / stats.length;
  stats.forEach((stat, i) => {
    const x = MX + i * colW;
    slide.addText(stat.value, {
      x, y, w: colW - 0.2, h: 0.9,
      fontSize: 44, fontFace: FONT_HEADER, color: PALETTE.accent, bold: true, margin: 0,
    });
    slide.addText(stat.label, {
      x, y: y + 0.95, w: colW - 0.3, h: 1.0,
      fontSize: 11.5, fontFace: FONT_BODY, color: PALETTE.charcoal, margin: 0, valign: "top", lineSpacingMultiple: 1.15,
    });
  });
}

/** Two-column compare. left/right: { heading, items[] } */
function addTwoColumn(slide, left, right, { y = 1.4, h = 3.5 } = {}) {
  const gap = 0.4;
  const w = (PAGE_W - MX * 2 - gap) / 2;
  [[MX, left], [MX + w + gap, right]].forEach(([x, col]) => {
    slide.addShape(pres.shapes.RECTANGLE, { x, y, w, h: 0.55, fill: { color: PALETTE.primary }, line: { type: "none" } });
    slide.addText(col.heading, {
      x: x + 0.2, y, w: w - 0.4, h: 0.55,
      fontSize: 14, fontFace: FONT_HEADER, color: PALETTE.white, bold: true, valign: "middle", margin: 0,
    });
    slide.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.55, w, h: h - 0.55, fill: { color: PALETTE.white }, line: { color: PALETTE.lightGray, width: 0.75 } });
    slide.addText(
      col.items.map((t) => ({ text: t, options: { bullet: { code: "2022", indent: 16 }, breakLine: true, paraSpaceAfter: 8 } })),
      { x: x + 0.22, y: y + 0.72, w: w - 0.44, h: h - 0.9, fontSize: 12, fontFace: FONT_BODY, color: PALETTE.charcoal, valign: "top", margin: 0, lineSpacingMultiple: 1.1 }
    );
  });
}

/** Chart slide — full-width chart under an action title. */
function addChartSlide(title, chartType, chartData, pageNum, chartOpts = {}) {
  const s = addContentSlide(title, pageNum);
  s.addChart(chartType, chartData, {
    x: MX, y: 1.4, w: PAGE_W - MX * 2, h: 3.6,
    chartColors: CHART_COLORS,
    chartArea: { fill: { color: PALETTE.white } },
    catAxisLabelColor: PALETTE.medGray,
    valAxisLabelColor: PALETTE.medGray,
    catAxisLabelFontFace: FONT_BODY,
    valAxisLabelFontFace: FONT_BODY,
    catAxisLabelFontSize: 10,
    valAxisLabelFontSize: 10,
    catGridLine: { style: "none" },
    valGridLine: { color: PALETTE.lightGray, size: 0.5 },
    showLegend: true, legendPos: "b", legendFontSize: 10, legendColor: PALETTE.charcoal,
    ...chartOpts,
  });
  return s;
}

/** Quote slide — centered statement on a soft surface. */
function addQuoteSlide({ quote, attribution }) {
  const s = pres.addSlide();
  s.background = { color: PALETTE.offWhite };
  s.addText(`“${quote}”`, {
    x: 1.0, y: 1.4, w: PAGE_W - 2.0, h: 2.4,
    fontSize: 26, fontFace: FONT_HEADER, color: PALETTE.darkText, align: "center", valign: "middle", margin: 0, lineSpacingMultiple: 1.15,
  });
  if (attribution) {
    s.addText(attribution, {
      x: 1.0, y: 4.0, w: PAGE_W - 2.0, h: 0.4,
      fontSize: 13, fontFace: FONT_BODY, color: PALETTE.charcoal, align: "center", margin: 0,
    });
  }
}

/** Closing slide — dark background, numbered strategic recommendations (2-col grid). */
function addClosingSlide(items, bottomTagline) {
  const s = pres.addSlide();
  s.background = { color: PALETTE.primary };
  s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: PAGE_W, h: 0.15, fill: { color: PALETTE.accent }, line: { type: "none" } });

  s.addText("Recommendations", {
    x: 0.5, y: 0.4, w: 9, h: 0.6,
    fontSize: 30, fontFace: FONT_HEADER, color: PALETTE.white, bold: true, margin: 0,
  });

  items.forEach((item, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const xPos = 0.5 + col * 4.7;
    const yPos = 1.35 + row * 1.7;

    s.addShape(pres.shapes.RECTANGLE, { x: xPos, y: yPos, w: 4.5, h: 1.5, fill: { color: PALETTE.secondary }, line: { type: "none" }, shadow: makeShadow() });
    s.addShape(pres.shapes.RECTANGLE, { x: xPos, y: yPos, w: 0.06, h: 1.5, fill: { color: PALETTE.accent }, line: { type: "none" } });
    s.addText(String(i + 1).padStart(2, "0"), {
      x: xPos + 0.2, y: yPos + 0.12, w: 0.6, h: 0.4,
      fontSize: 20, fontFace: FONT_HEADER, color: PALETTE.accentLight, bold: true, margin: 0,
    });
    s.addText(item.title, {
      x: xPos + 0.8, y: yPos + 0.12, w: 3.5, h: 0.45,
      fontSize: 12, fontFace: FONT_BODY, color: PALETTE.white, bold: true, valign: "middle", margin: 0,
    });
    s.addText(item.desc, {
      x: xPos + 0.2, y: yPos + 0.62, w: 4.1, h: 0.8,
      fontSize: 9.5, fontFace: FONT_BODY, color: PALETTE.lightGray, margin: 0, valign: "top", lineSpacingMultiple: 1.1,
    });
  });

  if (bottomTagline) {
    s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 5.25, w: PAGE_W, h: 0.375, fill: { color: PALETTE.accent }, line: { type: "none" } });
    s.addText(bottomTagline, {
      x: 0.5, y: 5.26, w: 9, h: 0.35,
      fontSize: 11, fontFace: FONT_BODY, color: PALETTE.white, bold: true, valign: "middle", margin: 0,
    });
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// main() — WORKED EXAMPLE. One composition showing each helper; NOT a fixed
// sequence. Build the slide set the user's content needs. See
// reference/professional-components.md.
// ═══════════════════════════════════════════════════════════════════════════
async function main() {
  addTitleSlide(
    "Q3 Business Review",
    "Performance, priorities, and the path to plan",
    "Executive Committee  ·  Prepared by Strategy & Operations",
  );

  const agenda = addContentSlide("Today we cover three decisions and the data behind them", 2);
  addCardRow(agenda, [
    { kicker: "01", title: "Where we stand", body: "Revenue, margin, and pipeline against the Q3 plan." },
    { kicker: "02", title: "What changed", body: "The two drivers that moved results most this quarter." },
    { kicker: "03", title: "What we decide", body: "Three resourcing choices to close the gap to plan." },
  ]);

  addDividerSlide({ eyebrow: "Section 01", title: "Where we stand today" });

  const stats = addContentSlide("We beat revenue plan but margin slipped on input costs", 4);
  addStatRow(stats, [
    { value: "$42.6M", label: "Quarterly revenue, 8% above plan" },
    { value: "31%", label: "Gross margin, down 3 pts vs. Q2" },
    { value: "1.9x", label: "Pipeline coverage entering Q4" },
    { value: "+12%", label: "Net new logos quarter over quarter" },
  ]);

  addChartSlide(
    "Revenue grew for the fourth straight quarter, led by Enterprise",
    pres.charts.BAR,
    [
      { name: "Enterprise", labels: ["Q4'24", "Q1'25", "Q2'25", "Q3'25"], values: [14, 16, 19, 23] },
      { name: "Mid-market", labels: ["Q4'24", "Q1'25", "Q2'25", "Q3'25"], values: [11, 12, 12, 13] },
      { name: "SMB", labels: ["Q4'24", "Q1'25", "Q2'25", "Q3'25"], values: [6, 6, 7, 7] },
    ],
    5,
    { barDir: "col", showValue: false },
  );

  const cmp = addContentSlide("The margin gap is a cost problem, not a pricing problem", 6);
  addTwoColumn(
    cmp,
    { heading: "What is working", items: ["Net retention held at 114%", "Win rate up 6 pts in Enterprise", "Discounting flat vs. last year"] },
    { heading: "What needs action", items: ["Cloud + inference costs up 22%", "Onboarding cost per logo rising", "Support load concentrated in 3 accounts"] },
  );

  addQuoteSlide({
    quote: "We do not have a growth problem. We have a cost-of-delivery problem we can fix this quarter.",
    attribution: "— Chief Financial Officer",
  });

  addClosingSlide(
    [
      { title: "Re-tier infrastructure", desc: "Move batch workloads to committed-use pricing for ~$1.4M annualized savings." },
      { title: "Automate onboarding", desc: "Templatize the top five integrations to halve setup cost per logo." },
      { title: "Focus support", desc: "Stand up a dedicated pod for the three heaviest accounts to protect retention." },
      { title: "Hold pricing", desc: "No broad discounting; protect the 6-point Enterprise win-rate gain." },
    ],
    "Decision needed by Friday to land the plan in Q4",
  );

  const outPath = path.join(__dirname, "output.pptx");
  await pres.writeFile({ fileName: outPath });
  console.log("Saved: " + outPath);
}

main().catch((err) => {
  console.error("Error:", err);
  process.exit(1);
});
