/**
 * Bold Pitch Deck style (PptxGenJS) — "Red & Pink Bold Condensed" pitch look.
 *
 * A high-impact startup/consulting pitch-deck style: oversized ultra-condensed
 * display headlines, a two-tone maroon/pink palette that alternates dark and
 * light slides for rhythm, giant stat numerals paired with their captions, and
 * bold minimal charts. Style target: ppt_golden_set/template_1/ (extracted spec
 * in that folder's SPEC.md). Hillclimbed per goal_2.md — see
 * ppt_golden_set/template_1/PROGRESS.md.
 *
 * DISTINGUISHING FEATURES vs. the other scripts in this skill
 *   - Native 20 x 11.25 in canvas (16:9 at 2x standard) via a custom layout.
 *   - Ultra-condensed heavy DISPLAY font for ALL headlines/stats/kickers, a
 *     normal sans for body. Source used Anton (embedded, not portable); this
 *     substitutes Impact (ships with Office + macOS + Windows) for portability.
 *   - Two-tone alternation: dark maroon slides (pink headline, white body) and
 *     light pink slides (maroon headline, black body).
 *   - Giant stat numerals, each paired with a bordered caption box as one unit.
 *   - Bold minimal charts (column / line / donut / horizontal bar) in-palette.
 *
 * HOW TO USE
 *   1. Copy this file next to your project.
 *   2. Edit the C palette / FONT constants if you want a different look.
 *   3. Do NOT just replace main() 1:1 — it's a WORKED EXAMPLE of each helper's
 *      calling convention, not a fixed slide sequence to reproduce. Read the
 *      COMPONENT REFERENCE below, decide how many slides the user's content needs
 *      and which helper fits each, then call them in that order — including
 *      combinations/counts/orderings not shown in main().
 *   4. Run:  node bold-pitch-style.js   ->  output.pptx
 *
 * Requires:  npm install pptxgenjs
 *
 * COMPONENT REFERENCE — every function below is an independent, reusable block.
 * Full concise reference (read this instead of scanning this file):
 *   reference/bold-pitch-components.md
 *   Slide shell:
 *     newSlide(dark)        — new slide w/ maroon(dark) or pink(light) bg;
 *                             returns {slide, fg, body, bg, ramp}
 *   Headlines / text:
 *     addSectionHeadline    — oversized condensed headline (left or centered)
 *     addKicker             — ALL-CAPS condensed kicker label
 *     addBody               — justified body paragraph
 *   Content blocks:
 *     addNumberedItem       — square bullet + "N." + kicker + body
 *     addRuledItem          — hairline rule + kicker + body
 *     addColumnKB           — kicker + body column (no rule)
 *     addStatUnit           — giant numeral + caption box directly beneath (one
 *                             obvious pair) — the clear way to show stats
 *     addMetaPair           — small kicker label + value (PRESENTED BY / PHONE)
 *     addFootLine           — bottom corner meta line ("2025" / a tagline)
 *   Charts (bold, minimal, in-palette — pass the slide's `ramp` for colors):
 *     addColumnChart        — vertical columns w/ value labels (e.g. revenue/yr)
 *     addLineChart          — trend line w/ markers (e.g. growth over time)
 *     addDonutChart         — share/breakdown ring w/ legend
 *     addBarChart           — horizontal ranked bars w/ value labels
 */

const pptxgen = require("pptxgenjs");

// ─── CANVAS (native source size; 16:9 at 2x standard 10x5.625) ───
const PAGE_W = 20;
const PAGE_H = 11.25;
const MX = 1.0;

// ─── CUSTOMIZE: PALETTE (no "#" prefix — PptxGenJS requirement) ───
const C = {
  maroon:    "70020F", // deep maroon — dark bg + dark display text on light slides
  pink:      "FEDEE1", // pale pink   — light bg + display fill on dark slides
  white:     "FFFFFF", // body text on dark slides
  black:     "000000", // body text on light slides
  maroonMid: "A83246", // secondary chart series on light slides
  pinkMid:   "E39FAA", // secondary chart series on dark slides
  gridDark:  "8A2E3B", // subtle gridline on dark slides
  gridLight: "E6B9C0", // subtle gridline on light slides
};
// Chart color ramps (primary → lighter) per slide tone.
const RAMP_DARK = ["FEDEE1", "E39FAA", "C56B7B", "9B4A54"];  // on maroon bg
const RAMP_LIGHT = ["70020F", "A83246", "C56B7B", "E39FAA"]; // on pink bg

// ─── CUSTOMIZE: FONTS ───
// DISPLAY = condensed heavy. Source used Anton (not portable); Impact is the
// closest widely-available substitute. Fallbacks: "Arial Narrow Bold",
// "DIN Condensed Bold". BODY stays a NORMAL-width sans.
const FONT_DISPLAY = "Impact";
const FONT_BODY = "Arial";

// ─── Type scale (pt @ native 20x11.25 canvas) ───
// FIXED ROLE SCALE — one size per role, on every slide. Do NOT pass per-call
// `size` overrides to vary a role's size between slides: mixed headline sizes
// across a deck read as a mistake (production feedback), and check_deck.py's
// headline-consistency check flags them. If a long word doesn't fit, widen
// `w` or break the line — never resize the role.
const SZ = {
  cover:   170, // cover headline (one per deck)
  closing: 170, // closing headline (one per deck; same tier as cover)
  section: 125, // EVERY content-slide headline — the one size for the role
  kicker:  23.5,
  meta:    20,  // small kicker labels (PRESENTED BY / PHONE)
  metaVal: 29,  // cover meta value / "2025"
  body:    17,  // body copy
  contact: 15,  // small contact values
};

let pres; // set in main()

// ─── Vertical stack cursor ──────────────────────────────────────────────────
// Place slide content top-to-bottom without hand-computing a y for every box:
// each place(h) returns the y for a block of height h and advances the cursor
// by h + gap. Changing one block's height re-flows everything below it — which
// is what prevents the "grew a box to fix text-fit, created a new overlap"
// cascade. Use it whenever a slide stacks 3+ elements vertically.
//   const stack = makeStack(1.2);                         // content top (in)
//   addKicker(slide, "...", { x: MX, y: stack.place(0.4) });
//   addBody(slide, "...",   { x: MX, y: stack.place(2.0, 0.3) }); // h, gap
//   addFootLine(slide, "...", { x: MX, y: stack.y() });   // current cursor
function makeStack(startY, defaultGap = 0.25) {
  let cur = startY;
  return {
    place(h, gap = defaultGap) { const y = cur; cur = y + h + gap; return y; },
    y() { return cur; },
  };
}

/** New slide with the two-tone background. Returns resolved colors + chart ramp. */
function newSlide(dark = true) {
  const slide = pres.addSlide();
  const bg = dark ? C.maroon : C.pink;
  const fg = dark ? C.pink : C.maroon;   // display/headline color
  const body = dark ? C.white : C.black; // body copy color
  const ramp = dark ? RAMP_DARK : RAMP_LIGHT;
  const grid = dark ? C.gridDark : C.gridLight;
  slide.background = { color: bg };
  return { slide, fg, body, bg, ramp, grid };
}

/** Oversized condensed section headline (left by default; centered for cover/closing). */
function addSectionHeadline(slide, text, { color, x = MX, y = 1.17, w = PAGE_W - MX * 2, h = 5.0, size = SZ.section, align = "left" } = {}) {
  slide.addText(text, {
    x, y, w, h,
    fontFace: FONT_DISPLAY, fontSize: size, color, bold: true,
    align, valign: "top", lineSpacingMultiple: 0.9, charSpacing: -1,
  });
}

/** ALL-CAPS condensed kicker label. */
function addKicker(slide, text, { x, y, w = 5.0, color, size = SZ.kicker, align = "left" } = {}) {
  slide.addText(String(text).toUpperCase(), {
    x, y, w, h: 0.42,
    fontFace: FONT_DISPLAY, fontSize: size, color, bold: true,
    align, valign: "middle",
  });
}

/** Justified body paragraph. */
function addBody(slide, text, { x, y, w = 5.2, h = 1.6, color, size = SZ.body } = {}) {
  slide.addText(text, {
    x, y, w, h,
    fontFace: FONT_BODY, fontSize: size, color,
    align: "justify", valign: "top", lineSpacingMultiple: 1.08,
  });
}

/** Numbered grid item: square bullet + "N." + kicker + body. */
function addNumberedItem(slide, { x, y, w, num, kicker, body, fg, bodyColor, bg }) {
  const sq = 0.34;
  slide.addShape(pres.shapes.RECTANGLE, { x, y, w: sq, h: sq, fill: { color: fg }, line: { type: "none" } });
  slide.addText(`${num}.`, {
    x, y, w: sq, h: sq, fontFace: FONT_DISPLAY, fontSize: 16, color: bg, bold: true,
    align: "center", valign: "middle", margin: 0,
  });
  addKicker(slide, kicker, { x: x + sq + 0.25, y: y - 0.03, w: w - sq - 0.25, color: fg });
  addBody(slide, body, { x, y: y + 0.62, w, h: 2.0, color: bodyColor });
}

/** Stacked list item: hairline rule on top + kicker + body. */
function addRuledItem(slide, { x, y, w, kicker, body, fg, bodyColor }) {
  slide.addShape(pres.shapes.LINE, { x, y, w, h: 0, line: { color: fg, width: 1 } });
  addKicker(slide, kicker, { x, y: y + 0.2, w, color: fg });
  addBody(slide, body, { x, y: y + 0.78, w, h: 1.5, color: bodyColor });
}

/** Kicker + body column (no rule). */
function addColumnKB(slide, { x, y, w, kicker, body, fg, bodyColor }) {
  addKicker(slide, kicker, { x, y, w, color: fg });
  addBody(slide, body, { x, y: y + 0.56, w, h: 1.8, color: bodyColor });
}

/** Clear stat unit: giant numeral with its caption box DIRECTLY beneath, so the
 * number and what it means read as one obvious pair (never scattered). */
function addStatUnit(slide, { x, y, w, value, caption, fg, size = 115, numH = 2.1, boxH = 1.0, capSize = 18 }) {
  slide.addText(String(value), {
    x, y, w, h: numH,
    fontFace: FONT_DISPLAY, fontSize: size, color: fg, bold: true,
    align: "left", valign: "bottom", charSpacing: -1,
  });
  const by = y + numH + 0.18;
  slide.addShape(pres.shapes.RECTANGLE, { x, y: by, w, h: boxH, fill: { type: "none" }, line: { color: fg, width: 1.25 } });
  slide.addText(String(caption).toUpperCase(), {
    x, y: by, w, h: boxH, fontFace: FONT_DISPLAY, fontSize: capSize, color: fg, bold: true,
    align: "center", valign: "middle",
  });
}

/** Small kicker label + value stacked (cover PRESENTED BY / closing PHONE). */
function addMetaPair(slide, { x, y, w = 2.4, label, value, fg, valColor, labelSize = SZ.meta, valSize = SZ.contact }) {
  slide.addText(String(label).toUpperCase(), {
    x, y, w, h: 0.34, fontFace: FONT_DISPLAY, fontSize: labelSize, color: fg, bold: true,
    align: "left", valign: "middle",
  });
  slide.addText(value, {
    x, y: y + 0.36, w, h: 0.5, fontFace: FONT_BODY, fontSize: valSize, color: valColor,
    align: "left", valign: "top",
  });
}

/** Bottom corner meta line ("2025" / a tagline). */
function addFootLine(slide, text, { x = MX, y = PAGE_H - 1.05, w = 6.0, color, align = "left", bold = false, size = SZ.metaVal }) {
  slide.addText(text, { x, y, w, h: 0.5, fontFace: FONT_BODY, fontSize: size, color, bold, align, valign: "middle" });
}

// ─── Charts — bold + minimal, colored from the slide's `ramp` ───
// Shared axis/label styling; no 3D, no shadow, transparent chart area (shows
// the slide's own background), value axis hidden in favor of on-bar labels.
function chartBase(fg, grid) {
  return {
    showLegend: false, showTitle: false,
    catAxisLabelColor: fg, catAxisLabelFontFace: FONT_BODY, catAxisLabelFontSize: 12,
    valAxisLabelColor: fg, valAxisLabelFontFace: FONT_BODY, valAxisLabelFontSize: 12,
    catGridLine: { style: "none" },
    valGridLine: { style: "solid", color: grid, size: 0.5 },
    catAxisLineColor: fg, valAxisLineColor: grid,
    dataLabelColor: fg, dataLabelFontFace: FONT_DISPLAY, dataLabelFontSize: 14, dataLabelFontBold: true,
  };
}

/** Vertical column chart w/ value labels (e.g. revenue by year). */
function addColumnChart(slide, { x, y, w, h, labels, values, name = "Series", fg, grid, ramp }) {
  slide.addChart(pres.charts.BAR, [{ name, labels, values }], {
    x, y, w, h, barDir: "col", chartColors: [ramp[0]], barGapWidthPct: 45,
    showValue: true, dataLabelPosition: "outEnd", valAxisHidden: true,
    ...chartBase(fg, grid),
  });
}

/** Trend line w/ markers (e.g. growth over time). */
function addLineChart(slide, { x, y, w, h, labels, values, name = "Series", fg, grid, ramp }) {
  slide.addChart(pres.charts.LINE, [{ name, labels, values }], {
    x, y, w, h, chartColors: [ramp[0]], lineSize: 3, lineSmooth: true,
    lineDataSymbol: "circle", lineDataSymbolSize: 7,
    showValue: false, ...chartBase(fg, grid),
  });
}

/** Share / breakdown donut w/ legend. */
function addDonutChart(slide, { x, y, w, h, labels, values, name = "Share", fg, grid, ramp }) {
  slide.addChart(pres.charts.DOUGHNUT, [{ name, labels, values }], {
    x, y, w, h, holeSize: 58, chartColors: ramp,
    showLegend: true, legendPos: "r", legendColor: fg, legendFontFace: FONT_BODY, legendFontSize: 13,
    showValue: false, showLabel: false, showTitle: false, dataBorder: { pt: 1, color: fg },
  });
}

/** Horizontal ranked bars w/ value labels. */
function addBarChart(slide, { x, y, w, h, labels, values, name = "Series", fg, grid, ramp }) {
  slide.addChart(pres.charts.BAR, [{ name, labels, values }], {
    x, y, w, h, barDir: "bar", chartColors: [ramp[0]], barGapWidthPct: 45,
    showValue: true, dataLabelPosition: "outEnd", valAxisHidden: true,
    ...chartBase(fg, grid),
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// main() — WORKED EXAMPLE composing the helpers into a pitch deck. ONE example
// composition, NOT a fixed sequence to output verbatim. Build the real deck the
// user asks for: different slide count/order, different helpers per slide. See
// COMPONENT REFERENCE above.
// ═══════════════════════════════════════════════════════════════════════════
function main() {
  pres = new pptxgen();
  pres.defineLayout({ name: "BOLDPITCH", width: PAGE_W, height: PAGE_H });
  pres.layout = "BOLDPITCH";

  // ── 1 — Cover (dark) ──
  {
    const { slide, fg } = newSlide(true);
    addSectionHeadline(slide, "PITCH\nDECK", { color: fg, x: MX, y: 1.5, w: 11, h: 7.2, size: SZ.cover });
    addMetaPair(slide, { x: 12.4, y: 4.8, label: "Presented by :", value: "Aldenaire & Partners", fg, valColor: C.white, w: 3.2 });
    addMetaPair(slide, { x: 12.4, y: 6.0, label: "Presented to :", value: "Arowwai Industries", fg, valColor: C.white, w: 3.2 });
    addFootLine(slide, "2025", { color: C.white, align: "left" });
    addFootLine(slide, "STRATEGIC CONSULTING", { x: PAGE_W - MX - 8, w: 8, color: C.white, align: "right", bold: true });
  }

  // ── 2 — Problem (dark, numbered grid) ──
  {
    const { slide, fg, body, bg } = newSlide(true);
    addSectionHeadline(slide, "PROBLEM", { color: fg, h: 2.8 });
    const colW = 5.3, xs = [MX, 7.4, 13.7], y = 5.6;
    const items = [
      { num: 1, kicker: "Market Saturation", body: "Legacy firms flood the mid-market with look-alike offerings, leaving buyers unable to tell real expertise from noise." },
      { num: 2, kicker: "Digital Complexity", body: "Fragmented tools and half-finished transformations stall teams before they ever reach measurable outcomes." },
      { num: 3, kicker: "Inefficient Operations", body: "Manual handoffs and unclear ownership quietly drain margin across every engagement and every quarter." },
    ];
    items.forEach((it, i) => addNumberedItem(slide, { x: xs[i], y, w: colW, num: it.num, kicker: it.kicker, body: it.body, fg, bodyColor: body, bg }));
  }

  // ── 3 — Our Solution (dark, ruled right column) ──
  {
    const { slide, fg, body } = newSlide(true);
    addSectionHeadline(slide, "OUR\nSOLUTION", { color: fg, w: 12, h: 5.0 });
    const rx = 13.4, rw = 5.5, ys = [2.2, 5.1, 8.0];
    const items = [
      { kicker: "Custom Strategy", body: "Every engagement starts from the client's own constraints, not a recycled playbook — diagnosis before prescription." },
      { kicker: "Project-Based", body: "Scoped, milestone-driven programs with a fixed outcome and a clear owner, so progress is never ambiguous." },
      { kicker: "Hands-On", body: "Senior operators embed with the team through delivery, transferring capability instead of just slides." },
    ];
    items.forEach((it, i) => addRuledItem(slide, { x: rx, y: ys[i], w: rw, kicker: it.kicker, body: it.body, fg, bodyColor: body }));
  }

  // ── 4 — Market Opportunity (dark, hero stat unit + ruled right) ──
  {
    const { slide, fg, body } = newSlide(true);
    addSectionHeadline(slide, "MARKET\nOPPORTUNITY", { color: fg, w: 12.5, h: 5.0 });
    addStatUnit(slide, { x: MX, y: 6.2, w: 8.0, value: "$900B+", caption: "Global consulting market", fg, numH: 2.4, boxH: 1.0 });
    const rx = 13.4, rw = 5.5, ys = [5.7, 8.4];
    const items = [
      { kicker: "High Demand for Boutiques", body: "Buyers are shifting spend from generalist giants to specialist firms that can show domain depth." },
      { kicker: "Digital & Sustainability Tailwinds", body: "Two structural transformation waves keep expanding the addressable market year over year." },
    ];
    items.forEach((it, i) => addRuledItem(slide, { x: rx, y: ys[i], w: rw, kicker: it.kicker, body: it.body, fg, bodyColor: body }));
  }

  // ── 5 — Business Model (light, lettered list) ──
  {
    const { slide, fg, body } = newSlide(false);
    addSectionHeadline(slide, "BUSINESS\nMODEL", { color: fg, h: 5.0 });
    addKicker(slide, "Revenue Streams", { x: MX, y: 6.9, w: 6, color: fg });
    const colW = 5.3, xs = [MX, 7.3, 13.7], y = 7.5;
    const items = [
      { label: "a. Strategic consulting", body: "Retained advisory engagements priced on outcomes, not hours — the durable core of recurring revenue." },
      { label: "b. Execution & implementation", body: "Hands-on delivery squads that ship the roadmap, billed per milestone across multi-quarter programs." },
      { label: "c. Digital transformation packages", body: "Productized platform rollouts with fixed scope and predictable margin, sold into the existing base." },
    ];
    items.forEach((it, i) => {
      slide.addText(it.label, { x: xs[i], y, w: colW, h: 0.3, fontFace: FONT_BODY, fontSize: SZ.body, color: body, bold: true, align: "left" });
      addBody(slide, it.body, { x: xs[i], y: y + 0.46, w: colW, h: 1.6, color: body });
    });
  }

  // ── 6 — Success Stories (light, three clear stat units in a row) ──
  {
    const { slide, fg } = newSlide(false);
    addSectionHeadline(slide, "SUCCESS STORIES", { color: fg, w: PAGE_W - MX * 2, h: 2.6 });
    const uw = 5.5, xs = [MX, 7.25, 13.5], y = 5.2;
    const stats = [
      { value: "30+", caption: "Clients in 5 countries" },
      { value: "2", caption: "Unicorns scaled" },
      { value: "$50M+", caption: "Capital raised" },
    ];
    stats.forEach((s, i) => addStatUnit(slide, { x: xs[i], y, w: uw, value: s.value, caption: s.caption, fg, size: 115, numH: 3.0, boxH: 1.1 }));
  }

  // ── 7 — Market Strategy (light, kicker+body columns) ──
  {
    const { slide, fg, body } = newSlide(false);
    addSectionHeadline(slide, "MARKET\nSTRATEGY", { color: fg, w: 11, h: 5.0 });
    const colW = 5.3, xs = [MX, 7.3, 13.7], y = 7.2;
    const items = [
      { kicker: "Relationship-Driven Leads", body: "Warm introductions and repeat clients compound into a pipeline that doesn't depend on cold outreach." },
      { kicker: "Referrals & Thought Leadership", body: "Webinars, briefings, and published points of view keep the firm visible to the right buyers." },
      { kicker: "B2B Events & Partnerships", body: "Co-marketing with platform partners opens strategic accounts that would be slow to reach alone." },
    ];
    items.forEach((it, i) => addColumnKB(slide, { x: xs[i], y, w: colW, kicker: it.kicker, body: it.body, fg, bodyColor: body }));
  }

  // ── 8 — Financials (dark, COLUMN CHART + ruled highlights) ──
  {
    const { slide, fg, body, grid, ramp } = newSlide(true);
    addSectionHeadline(slide, "FINANCIALS", { color: fg, h: 2.6, w: 12 });
    addColumnChart(slide, {
      x: MX, y: 4.2, w: 11, h: 6.2, labels: ["2022", "2023", "2024", "2025", "2026"],
      values: [4, 9, 18, 31, 52], name: "Revenue ($M)", fg, grid, ramp,
    });
    const rx = 13.0, rw = 5.9, ys = [4.6, 7.6];
    addRuledItem(slide, { x: rx, y: ys[0], w: rw, kicker: "3.4x YoY Growth", body: "Revenue compounding as delivery capacity and repeat business scale together.", fg, bodyColor: body });
    addRuledItem(slide, { x: rx, y: ys[1], w: rw, kicker: "Profitable by 2025", body: "Platform leverage turns each new engagement into margin, not just headcount.", fg, bodyColor: body });
  }

  // ── 9 — Traction (light, LINE CHART) ──
  {
    const { slide, fg, body, grid, ramp } = newSlide(false);
    addSectionHeadline(slide, "TRACTION", { color: fg, h: 2.6, w: 12 });
    addLineChart(slide, {
      x: MX, y: 4.0, w: 12.5, h: 6.4, labels: ["Q1", "Q2", "Q3", "Q4", "Q5", "Q6"],
      values: [12, 19, 28, 44, 63, 88], name: "Active clients", fg, grid, ramp,
    });
    addColumnKB(slide, { x: 14.2, y: 4.6, w: 4.8, kicker: "88 Active Clients", body: "Six straight quarters of accelerating net-new logos, with retention holding above 95%.", fg, bodyColor: body });
  }

  // ── 10 — Market Share (dark, DONUT + horizontal BAR) ──
  {
    const { slide, fg, body, grid, ramp } = newSlide(true);
    addSectionHeadline(slide, "THE MARKET", { color: fg, h: 2.6, w: 12 });
    addKicker(slide, "Share of mid-market spend", { x: MX, y: 3.9, w: 8, color: fg });
    addDonutChart(slide, {
      x: MX, y: 4.4, w: 8.5, h: 6.2, labels: ["Us", "Legacy A", "Legacy B", "Other"],
      values: [34, 26, 22, 18], fg, grid, ramp,
    });
    addKicker(slide, "Fastest-growing segments", { x: 10.6, y: 3.9, w: 8, color: fg });
    addBarChart(slide, {
      x: 10.6, y: 4.4, w: 8.4, h: 6.2, labels: ["Fintech", "Health", "Retail", "Industrial"],
      values: [48, 41, 33, 22], name: "Growth %", fg, grid, ramp,
    });
  }

  // ── 11 — Thank You (dark, centered headline + contacts) ──
  {
    const { slide, fg } = newSlide(true);
    addSectionHeadline(slide, "THANK YOU", { color: fg, x: MX, y: 3.4, w: PAGE_W - MX * 2, h: 3.6, size: SZ.closing, align: "center" });
    addMetaPair(slide, { x: 5.7, y: 9.2, label: "Phone", value: "+123-456-7890", fg, valColor: C.white, w: 2.6 });
    addMetaPair(slide, { x: 8.7, y: 9.2, label: "Email", value: "hello@reallygreatsite.com", fg, valColor: C.white, w: 3.4, valSize: 13 });
    addMetaPair(slide, { x: 12.4, y: 9.2, label: "Address", value: "123 Anywhere St., Any City", fg, valColor: C.white, w: 3.4, valSize: 13 });
    addFootLine(slide, "2025", { color: C.white, align: "left" });
  }

  const out = require("path").join(__dirname, "output.pptx");
  return pres.writeFile({ fileName: out }).then(() => console.log("Saved:", out));
}

main();
