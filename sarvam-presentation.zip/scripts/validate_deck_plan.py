#!/usr/bin/env python3
"""Validate narrative, chart semantics, and visual variety before deck code."""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any


ROLES = {"cover", "content", "sources", "closing", "appendix"}
SOURCE_KINDS = {"external", "internal"}
DATA_ORDERS = {"chronological-asc", "ranked-asc", "ranked-desc", "categorical"}
VISUALS = {
    "cover",
    "closing",
    "dashboard",
    "horizontal-bar",
    "column",
    "stacked-column",
    "line",
    "area",
    "donut",
    "matrix",
    "cards",
    "process",
    "timeline",
    "text",
    "sources",
}
CHART_VISUALS = {
    "horizontal-bar",
    "column",
    "stacked-column",
    "line",
    "area",
    "donut",
}
DATA_SHAPES = {
    "horizontal-bar": {"ranked-comparison", "long-label-comparison"},
    "column": {"discrete-comparison", "short-time-comparison"},
    "stacked-column": {"composition-over-time"},
    "line": {"trend-over-time"},
    "area": {"cumulative-trend"},
    "donut": {"part-to-whole"},
}
VALUATION_RE = re.compile(
    r"\b(dcf|intrinsic value|price target|bull|base|bear|forecast|fair multiple|fair value)\b",
    re.IGNORECASE,
)


def words(value: Any) -> int:
    return len(str(value or "").split())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Validate a deck-plan.json before writing presentation code. "
            "Outputs structured JSON and uses exit 1 for correctable plan errors."
        )
    )
    parser.add_argument("plan", type=Path, help="Path to deck-plan.json.")
    return parser.parse_args()


def slide_label(index: int, slide: dict[str, Any]) -> str:
    return f"slide {slide.get('number', index + 1)}"


def validate(plan: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(plan, dict):
        return ["Plan root must be a JSON object."]

    for field in ("audience", "goal", "narrative"):
        if not str(plan.get(field, "")).strip():
            errors.append(f"Top-level field '{field}' is required and must be non-empty.")

    brand_name = str(plan.get("brand_name", "")).strip()
    brand_source = str(plan.get("brand_source", "none")).strip()
    if brand_name and brand_source != "user":
        errors.append(
            "Top-level 'brand_name' may be non-empty only when 'brand_source' is 'user'."
        )
    if not brand_name and brand_source not in {"none", ""}:
        errors.append("Empty 'brand_name' requires 'brand_source'='none'.")

    raw_sources = plan.get("sources", [])
    if not isinstance(raw_sources, list):
        errors.append("Top-level 'sources' must be an array.")
        raw_sources = []
    sources: dict[str, dict[str, Any]] = {}
    for index, raw_source in enumerate(raw_sources):
        label = f"source {index + 1}"
        if not isinstance(raw_source, dict):
            errors.append(f"{label} must be a JSON object.")
            continue
        source_id = str(raw_source.get("id", "")).strip()
        if not source_id:
            errors.append(f"{label}: non-empty 'id' is required.")
            continue
        if source_id in sources:
            errors.append(f"{label}: duplicate source id {source_id!r}.")
            continue
        sources[source_id] = raw_source
        kind = raw_source.get("kind")
        if kind not in SOURCE_KINDS:
            errors.append(
                f"{label}: 'kind' must be one of {sorted(SOURCE_KINDS)}; got {kind!r}."
            )
        if not str(raw_source.get("title", "")).strip():
            errors.append(f"{label}: non-empty 'title' is required.")
        if kind == "external":
            url = str(raw_source.get("url", "")).strip()
            if not url.startswith(("http://", "https://")):
                errors.append(f"{label}: external sources require an http(s) 'url'.")
            if not str(raw_source.get("publisher", "")).strip():
                errors.append(f"{label}: external sources require 'publisher'.")

    slides = plan.get("slides")
    if not isinstance(slides, list) or len(slides) < 3:
        errors.append("Field 'slides' must contain at least 3 slide objects.")
        return errors

    roles: list[str] = []
    chart_visuals: list[tuple[int, str]] = []
    external_sources_used = False

    for index, raw_slide in enumerate(slides):
        if not isinstance(raw_slide, dict):
            errors.append(f"slide {index + 1} must be a JSON object.")
            continue
        label = slide_label(index, raw_slide)
        number = raw_slide.get("number")
        if number != index + 1:
            errors.append(
                f"{label}: 'number' must be {index + 1} to keep slide order consecutive; "
                f"got {number!r}."
            )
        role = raw_slide.get("role")
        visual = raw_slide.get("visual")
        roles.append(str(role))

        if role not in ROLES:
            errors.append(f"{label}: role must be one of {sorted(ROLES)}; got {role!r}.")
        if visual not in VISUALS:
            errors.append(f"{label}: visual must be one of {sorted(VISUALS)}; got {visual!r}.")

        title = str(raw_slide.get("title", "")).strip()
        if not title:
            errors.append(f"{label}: title is required.")
        elif role == "content" and words(title) > 10:
            errors.append(f"{label}: title has {words(title)} words; maximum is 10.")

        if role == "content":
            takeaway = str(raw_slide.get("takeaway", "")).strip()
            if not takeaway:
                errors.append(f"{label}: content slides require a one-sentence 'takeaway'.")
            supporting_points = raw_slide.get("supporting_points")
            if (
                not isinstance(supporting_points, list)
                or not supporting_points
                or not all(str(point).strip() for point in supporting_points)
            ):
                errors.append(
                    f"{label}: content slides require non-empty 'supporting_points'."
                )
            if visual in {"cover", "closing", "sources"}:
                errors.append(f"{label}: content role cannot use visual {visual!r}.")
            source_ids = raw_slide.get("source_ids")
            if not isinstance(source_ids, list) or not source_ids:
                errors.append(
                    f"{label}: content slides require non-empty 'source_ids'; "
                    "use an internal source for user-provided material."
                )
                source_ids = []
            for source_id in source_ids:
                if not isinstance(source_id, str) or not source_id.strip():
                    errors.append(f"{label}: every source id must be a non-empty string.")
                    continue
                if source_id not in sources:
                    errors.append(f"{label}: unknown source id {source_id!r}.")
                elif sources[source_id].get("kind") == "external":
                    external_sources_used = True

            points_for_evidence = (
                supporting_points if isinstance(supporting_points, list) else []
            )
            evidence_text = " ".join(
                [
                    title,
                    takeaway,
                    *(str(point) for point in points_for_evidence),
                ]
            )
            if VALUATION_RE.search(evidence_text):
                if not str(raw_slide.get("methodology", "")).strip():
                    errors.append(
                        f"{label}: valuation/forecast/scenario claims require 'methodology'."
                    )
                assumptions = raw_slide.get("assumptions")
                if (
                    not isinstance(assumptions, list)
                    or len(assumptions) < 3
                    or not all(str(item).strip() for item in assumptions)
                ):
                    errors.append(
                        f"{label}: valuation/forecast/scenario claims require at least "
                        "3 explicit 'assumptions'."
                    )

        if visual == "matrix":
            matrix = raw_slide.get("matrix")
            if not isinstance(matrix, dict):
                errors.append(f"{label}: matrix slides require a 'matrix' object.")
            else:
                headings = matrix.get("headings")
                if (
                    not isinstance(headings, list)
                    or len(headings) < 3
                    or not all(str(heading).strip() for heading in headings)
                ):
                    errors.append(
                        f"{label}: matrix requires at least 3 explicit non-empty 'headings'."
                    )
                legend = matrix.get("legend")
                if (
                    not isinstance(legend, dict)
                    or not str(legend.get("high", "")).strip()
                    or not str(legend.get("medium", "")).strip()
                    or not str(legend.get("none", "")).strip()
                ):
                    errors.append(
                        f"{label}: matrix requires text legend labels for high, medium, "
                        "and none."
                    )
                if not str(matrix.get("criteria", "")).strip():
                    errors.append(
                        f"{label}: matrix requires sourced scoring 'criteria'."
                    )

        if visual in CHART_VISUALS:
            chart_visuals.append((index, str(visual)))
            data_shape = raw_slide.get("data_shape")
            allowed = DATA_SHAPES[str(visual)]
            if data_shape not in allowed:
                errors.append(
                    f"{label}: {visual!r} requires data_shape in {sorted(allowed)}; "
                    f"got {data_shape!r}."
                )
            data = raw_slide.get("data")
            if not isinstance(data, dict):
                errors.append(f"{label}: chart slides require a 'data' object.")
                continue
            unit = str(data.get("unit", "")).strip()
            basis = str(data.get("basis", "")).strip()
            order = data.get("order")
            categories = data.get("categories")
            series = data.get("series")
            if not unit:
                errors.append(f"{label}: chart data requires non-empty 'unit'.")
            if not basis:
                errors.append(f"{label}: chart data requires non-empty 'basis'.")
            if order not in DATA_ORDERS:
                errors.append(
                    f"{label}: chart data 'order' must be one of {sorted(DATA_ORDERS)}; "
                    f"got {order!r}."
                )
            if not isinstance(categories, list) or not categories:
                errors.append(f"{label}: chart data requires non-empty 'categories'.")
                categories = []
            elif not all(str(category).strip() for category in categories):
                errors.append(f"{label}: chart categories must all be non-empty.")
            if not isinstance(series, list) or not series:
                errors.append(f"{label}: chart data requires non-empty 'series'.")
                series = []

            numeric_series: list[list[float]] = []
            for series_index, entry in enumerate(series):
                if not isinstance(entry, dict):
                    errors.append(
                        f"{label}: series {series_index + 1} must be a JSON object."
                    )
                    continue
                if not str(entry.get("name", "")).strip():
                    errors.append(f"{label}: series {series_index + 1} requires 'name'.")
                values = entry.get("values")
                if not isinstance(values, list) or len(values) != len(categories):
                    errors.append(
                        f"{label}: series {series_index + 1} must have exactly "
                        f"{len(categories)} values."
                    )
                    continue
                if not all(
                    isinstance(value, (int, float))
                    and not isinstance(value, bool)
                    and math.isfinite(float(value))
                    for value in values
                ):
                    errors.append(
                        f"{label}: series {series_index + 1} values must be finite numbers."
                    )
                    continue
                numeric_series.append([float(value) for value in values])

            if visual in {"line", "area"}:
                if len(categories) < 4:
                    errors.append(
                        f"{label}: {visual} charts require at least 4 ordered points."
                    )
                if order != "chronological-asc":
                    errors.append(
                        f"{label}: {visual} charts require order='chronological-asc'."
                    )
            if visual == "stacked-column" and len(series) < 2:
                errors.append(f"{label}: stacked columns require at least 2 series.")

            part_to_whole = data.get("part_to_whole")
            if not isinstance(part_to_whole, bool):
                errors.append(f"{label}: chart data requires boolean 'part_to_whole'.")
            if visual == "donut" and part_to_whole is not True:
                errors.append(f"{label}: donut charts require part_to_whole=true.")
            if part_to_whole is True and numeric_series:
                if len(numeric_series) == 1:
                    totals = [sum(numeric_series[0])]
                else:
                    totals = [sum(values) for values in zip(*numeric_series)]
                for total_index, total in enumerate(totals):
                    if abs(total - 100) > 0.5:
                        errors.append(
                            f"{label}: part-to-whole total {total_index + 1} is "
                            f"{total:.1f}; expected 100±0.5."
                        )
            if (
                unit == "%"
                and "share" in basis.lower()
                and part_to_whole is False
                and numeric_series
                and sum(numeric_series[0]) < 99.5
                and not str(data.get("coverage_note", "")).strip()
            ):
                errors.append(
                    f"{label}: partial percentage-share data requires 'coverage_note' "
                    "that names the omitted remainder."
                )

    if roles and roles[0] != "cover":
        errors.append("The first slide must have role='cover'.")
    if roles and roles[-1] != "closing":
        errors.append("The last slide must have role='closing'.")
    if external_sources_used:
        if len(roles) < 2 or roles[-2] != "sources":
            errors.append(
                "A deck using external evidence must place role='sources' immediately "
                "before closing."
            )

    if len(chart_visuals) >= 4:
        counts = Counter(kind for _, kind in chart_visuals)
        kind, count = counts.most_common(1)[0]
        if count / len(chart_visuals) > 0.5:
            errors.append(
                f"Chart mix is monotonous: {kind!r} is {count}/{len(chart_visuals)} chart slides; "
                "no chart type may exceed 50% when the deck has 4+ charts."
            )
    for (_, first), (_, second), (_, third) in zip(
        chart_visuals, chart_visuals[1:], chart_visuals[2:]
    ):
        if first == second == third:
            errors.append(
                f"Chart mix has 3 consecutive {first!r} slides; use at most 2 consecutively."
            )
            break
    counts = Counter(kind for _, kind in chart_visuals)
    for limited in ("donut", "area"):
        if counts[limited] > 1:
            errors.append(f"Use at most one {limited!r} chart per deck; found {counts[limited]}.")

    return errors


def main() -> int:
    args = parse_args()
    try:
        plan = json.loads(args.plan.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "unreadable", "errors": [str(exc)]}), file=sys.stderr)
        return 2

    errors = validate(plan)
    result = {
        "status": "pass" if not errors else "fail",
        "plan": str(args.plan),
        "slide_count": len(plan.get("slides", [])) if isinstance(plan, dict) else 0,
        "errors": errors,
    }
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
