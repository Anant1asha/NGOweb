#!/usr/bin/env python3
"""The single QA gate for a generated .pptx deck — run this ONCE after building.

Runs the deterministic layout check (`check_deck.py`: bounds, overlaps,
text-fit, container insets, typography roles, chart readability/legends,
centering integrity, native-table column tiling) and prints one consolidated
report.

Writing quality (action titles, anti-slop, data integrity) is governed by
content-guide.md and applied while drafting — it is not machine-checked.
Content QA (read the extracted text for missing content, typos, order,
leftover placeholders, and the content-guide rules) stays a separate one-off
read:
    python -m markitdown output.pptx

Usage:
    python scripts/run_qa.py output.pptx --plan deck-plan.json [--tol 0.05]

Exit 0 = the deck's geometry is verified; run the markitdown content read,
then deliver. Exit 1 = fix the build script from the FAIL messages below
(each names the slide, the shapes with a text snippet, and the exact fix),
rebuild, and re-run this gate once — the messages are self-sufficient, so do
NOT read the check script's source. Exit 2 = the file itself is unreadable.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

from pptx import Presentation


PLACEHOLDER_PATTERNS = (
    re.compile(r"\blorem ipsum\b", re.IGNORECASE),
    re.compile(r"\bconsectetur adipiscing\b", re.IGNORECASE),
)


def normalize(value: str) -> str:
    return " ".join(re.sub(r"[^a-z0-9]+", " ", value.lower()).split())


def check_plan_contract(pptx_path: str, plan_path: str) -> tuple[int, list[str]]:
    """Verify that the built deck is the validated plan, not the worked example."""
    try:
        plan = json.loads(Path(plan_path).read_text(encoding="utf-8"))
        prs = Presentation(pptx_path)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return 2, [f"PLAN QA UNREADABLE: {exc}"]

    planned_slides = plan.get("slides")
    if not isinstance(planned_slides, list):
        return 2, ["PLAN QA UNREADABLE: plan field 'slides' must be an array."]

    errors: list[str] = []
    if len(prs.slides) != len(planned_slides):
        errors.append(
            f"slide count is {len(prs.slides)}, but deck-plan.json specifies "
            f"{len(planned_slides)}."
        )

    for index, (slide, planned) in enumerate(zip(prs.slides, planned_slides), start=1):
        slide_text = "\n".join(
            shape.text
            for shape in slide.shapes
            if getattr(shape, "has_text_frame", False) and shape.text
        )
        planned_title = str(planned.get("title", "")).strip()
        if planned_title and normalize(planned_title) not in normalize(slide_text):
            errors.append(
                f"slide {index}: planned title {planned_title!r} is missing; "
                "the wrong main() may have been composed."
            )
        for pattern in PLACEHOLDER_PATTERNS:
            match = pattern.search(slide_text)
            if match:
                errors.append(
                    f"slide {index}: forbidden worked-example placeholder "
                    f"{match.group(0)!r} remains."
                )

    return (1 if errors else 0), errors


def main() -> int:
    ap = argparse.ArgumentParser(description="Single QA gate for a generated .pptx")
    ap.add_argument("pptx")
    ap.add_argument(
        "--plan",
        help=(
            "Validated deck-plan.json. Required for new decks; verifies slide count, "
            "titles, and absence of worked-example placeholders."
        ),
    )
    ap.add_argument("--tol", type=float, default=None,
                    help="geometry tolerance in inches (passed to check_deck)")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    cmd = [sys.executable, os.path.join(here, "check_deck.py"), args.pptx]
    if args.tol is not None:
        cmd += ["--tol", str(args.tol)]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    if out:
        print(out)
    if err:
        print(err, file=sys.stderr)
    print()

    plan_returncode = 0
    if proc.returncode == 0 and args.plan:
        plan_returncode, plan_errors = check_plan_contract(args.pptx, args.plan)
        if plan_errors:
            print("PLAN QA FAILED:")
            for error in plan_errors:
                print(f"- {error}")
            print()
        else:
            print("PLAN QA PASSED — slide count and planned titles match; no placeholders remain.")
            print()

    returncode = max(proc.returncode, plan_returncode)
    if returncode == 0:
        verified = "layout, chart, and plan" if args.plan else "layout and chart"
        print(f"ALL QA PASSED — {verified} contracts are verified. Read the extracted text "
              "once (python -m markitdown <deck>.pptx) for content and the "
              "content-guide.md writing rules, then deliver.")
    else:
        print("QA GATE FAILED. Fix the build script from the FAIL messages "
              "above — each names the slide, the shapes (with a text snippet "
              "to locate the helper call), and the fix. Do NOT read the check "
              "script's source; the messages are the whole contract. Rebuild, "
              "then re-run run_qa.py once.")
    return returncode


if __name__ == "__main__":
    sys.exit(main())
