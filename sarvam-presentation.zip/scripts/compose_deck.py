#!/usr/bin/env python3
"""Compose a deck script without reading or rewriting template internals.

The input file contains only the deck-specific ``main()`` function. This tool
copies the selected template helpers and replaces its worked-example main.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
TEMPLATES = {
    "professional": SCRIPT_DIR / "professional-style.js",
    "consulting-report": SCRIPT_DIR / "consulting-report-style.js",
    "bold-pitch": SCRIPT_DIR / "bold-pitch-style.js",
}
MAIN_PATTERN = re.compile(r"(?m)^(?:async\s+)?function\s+main\s*\(\s*\)\s*\{")
CONSULTING_MARKER = "// ─── MAIN — replace with your content ───"


def fail(message: str, *, code: int) -> int:
    print(json.dumps({"status": "error", "error": message}), file=sys.stderr)
    return code


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Combine a presentation template with a deck-specific main.js. "
            "The template remains unchanged and does not need to be read."
        )
    )
    parser.add_argument(
        "--template",
        choices=sorted(TEMPLATES),
        required=True,
        help="Template family to compose.",
    )
    parser.add_argument(
        "--main-file",
        type=Path,
        required=True,
        help="JS file containing one function main() (async is allowed).",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Destination build script. Parent directories are created.",
    )
    return parser.parse_args()


def add_invocation(main_source: str) -> str:
    """Append the standard invocation when the caller supplied only a function."""
    function_match = MAIN_PATTERN.search(main_source)
    assert function_match is not None
    trailing = main_source[function_match.end() :]
    if re.search(r"(?m)^\s*main\s*\(\s*\)\s*(?:\.catch|\;)", trailing):
        return main_source.rstrip() + "\n"
    if function_match.group(0).lstrip().startswith("async"):
        invocation = """

main().catch((err) => {
  console.error("Error:", err);
  process.exit(1);
});
"""
    else:
        invocation = "\nmain();\n"
    return main_source.rstrip() + invocation


def main() -> int:
    args = parse_args()
    template_path = TEMPLATES[args.template]

    try:
        template_source = template_path.read_text(encoding="utf-8")
    except OSError as exc:
        return fail(f"Cannot read template {template_path}: {exc}", code=2)
    try:
        deck_main = args.main_file.read_text(encoding="utf-8")
    except OSError as exc:
        return fail(f"Cannot read main file {args.main_file}: {exc}", code=2)

    main_matches = list(MAIN_PATTERN.finditer(deck_main))
    if len(main_matches) != 1:
        return fail(
            f"{args.main_file} must contain exactly one function main(); found {len(main_matches)}.",
            code=1,
        )

    template_main = MAIN_PATTERN.search(template_source)
    if template_main is None:
        return fail(
            f"Template {template_path.name} has no function main() marker.",
            code=2,
        )

    replace_at = template_main.start()
    if args.template == "consulting-report":
        marker_at = template_source.find(CONSULTING_MARKER)
        if marker_at == -1 or marker_at > template_main.start():
            return fail(
                f"Template {template_path.name} is missing its stable main marker.",
                code=2,
            )
        replace_at = marker_at

    composed = template_source[:replace_at].rstrip() + "\n\n" + add_invocation(deck_main)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(composed, encoding="utf-8")

    print(
        json.dumps(
            {
                "status": "ok",
                "template": args.template,
                "main_file": str(args.main_file),
                "output": str(args.output),
                "output_bytes": len(composed.encode("utf-8")),
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
