#!/usr/bin/env python3
"""
Deterministic layout QA for a generated .pptx - the presentation-skill
equivalent of sarvam-pdf's check_layout.py. Run this before delivering: it is
exact and cheap, and catches the geometry-class defects that a glance would
otherwise miss on every slide.

Usage:
    python scripts/check_deck.py output.pptx [--tol 0.05]

Exit codes: 0 pass, 1 FAIL (issues printed to stdout), 2 file unreadable.
"""
import argparse
import sys
from collections import Counter

try:
    from pptx import Presentation
    from pptx.util import Emu
    from pptx.enum.text import MSO_AUTO_SIZE, PP_ALIGN
except ImportError:
    print("check_deck.py requires python-pptx: pip install python-pptx", file=sys.stderr)
    sys.exit(2)

MIN_FONT_PT = 8
OVERLAP_FRACTION_THRESHOLD = 0.2  # flag text-shape pairs overlapping more than this fraction of the smaller box

# Text vs NON-TEXT visuals (charts, pictures, tables, filled decorative
# shapes). These are invisible to the text-text overlap check, and "an element
# rendered on top of another" was a real production defect class. Rules:
#   - A text box FULLY INSIDE a visual = the card/banner pattern (a filled
#     rect drawn first, text laid on top) — intentional, never flagged. This
#     also naturally excuses full-slide background washes.
#   - A PARTIAL overlap (neither contains the other) above the fraction
#     threshold = a collision.
#   - A small visual fully inside a text box's bbox is NOT flagged: text-box
#     bounds routinely exceed the ink (a tall headline box is mostly empty),
#     so containment there proves nothing.
#   - A partial overlap is EXCUSED when another visual both contains the text
#     box and is drawn ABOVE the overlapped visual (higher z-order): the text
#     sits on its card, and the card hides the shape behind it. Real case:
#     addNumberedProcessCards draws a connector band behind the row of cards —
#     the band "overlaps" every card's text but is never visible under it.
#   - Very thin shapes (hairline rules/dividers) are excluded — they sit flush
#     with text by design; their spacing is the clearance check's concern.
# Slack when testing "fully inside". 0.10 (not 0.05) because panel labels
# routinely overshoot their panel edge by up to ~0.08in of EMPTY box padding
# while the glyphs stay inside (real false-positive class: the consulting
# template's 2x2 dashboard labels). Text that genuinely doesn't fit its box
# is the text-fit check's job, not this one's.
CONTAINMENT_TOL_IN = 0.10
VISUAL_MIN_THICKNESS_IN = 0.05  # thinner than this = a decorative rule, skip

# These two checks port sarvam-pdf's check_layout.py / check_tables.py corner
# cases over to pptx. Unlike that PDF checker, we don't need to *infer* a
# centered element's true visual center from rendered glyph positions —
# PowerPoint centers text within its shape's own box width, so the shape's
# bounding-box center IS the true visual center whenever `align: "center"`
# is set. That makes this exact, not a heuristic (same rigor as the
# bounds/overlap checks, unlike the text-fit estimate above).
CENTER_ALIGN_SPREAD_TOL_IN = 0.05  # centered elements on one slide should share ~one x-center
# Small widgets (a lettered badge, a table header cell, a chart value label)
# are routinely center-aligned WITHIN their own tiny box with no expectation
# of sharing a center with anything else on the slide — only a wide,
# content-column-scale box (a title, subtitle, or full-width statement) is
# the "title vs. subtitle" class of element this check is actually for.
# Calibrated against this skill's own example templates: real false
# positives topped out at 3.43in (a stacked-bar value label); real
# title/subtitle-scale boxes in these templates run 6-9in wide.
MIN_CENTERED_SHAPE_WIDTH_IN = 5.0
TABLE_COL_SUM_TOL_IN = 0.05  # native-table column widths should sum to the table frame's width

# Cross-slide role-size consistency. On any one deck, a recurring text box —
# same position, slide after slide — is one ROLE (the title box, a kicker, a
# stat row), and one role uses ONE font size. Decks where the title size
# drifts per slide (real production defect: 125/130/155/175 across one deck)
# read as mistakes. Grouping by POSITION rather than by "largest text on the
# slide" is deliberate: intentional per-slide-type variation (a quote slide's
# 30pt quote, a card slide's 32pt numeral vs a 28pt title) almost always comes
# with different positioning, so it never enters a recurring group — found as
# real false positives of the dominant-size approach against the brand
# template. A same-position box with a different size has no such excuse.
ROLE_POS_BUCKET_IN = 0.15   # boxes whose x AND y agree within this are the same role
ROLE_SIZE_TOL_PT = 1.0      # sizes within 1pt are "the same size" (rounding)
ROLE_MIN_SLIDES = 3         # a position must recur on 3+ slides to define a role

# Consulting design-system checks. Thresholds are intentionally structural and
# conservative so they remain useful for the professional and bold-pitch
# templates that share this gate.
MIN_CONTAINER_HORIZONTAL_INSET_IN = 0.12
MIN_STANDARD_CHART_W_IN = 4.0
MIN_CONSULTING_SINGLE_CHART_W_IN = 6.0
MIN_STANDARD_CHART_H_IN = 2.5
MIN_DONUT_SIZE_IN = 0.85
MAX_DONUT_HOLE_SIZE = 50
MIN_CHART_TEXT_PT = 9
VISUAL_OVERLAP_FRACTION_THRESHOLD = 0.2
WITHIN_ROLE_BUCKET_IN = 0.12
WITHIN_ROLE_SIZE_TOL_PT = 1.0
WITHIN_ROLE_MIN_ITEMS = 3

# Text-fit heuristic (own-box overflow) — deliberately approximate, so it's
# tuned conservative (biased toward NOT flagging) and given generous slack
# before failing. This is the one class of bug the bounds/overlap checks
# above structurally cannot see: a box that doesn't collide with any
# neighbor but is still too short for its OWN text (e.g. a 22pt line crammed
# into a 0.28in-tall box). Real bug class hit repeatedly during this skill's
# own template development — see consulting-report-style.js's PROGRESS.md history.
AVG_CHAR_WIDTH_EM = 0.5   # average glyph width as a fraction of font-size, for proportional sans-serif body text
# Condensed display fonts are far narrower per glyph than a proportional body
# font, so the 0.5 default massively over-estimates their line count (it read
# "PITCH DECK" in a display box as needing ~11in of stacked lines). These
# fonts legitimately run ~0.34-0.40em/char; without this, any template built
# on a condensed headline face (bold-pitch-style.js uses Impact) drowns in
# false overflow flags. Matched case-insensitively as a substring of the run
# font name, so "Impact", "Arial Narrow", "DIN Condensed", "Oswald Bold" etc.
# all resolve.
CONDENSED_CHAR_WIDTH_EM = 0.38
CONDENSED_FONT_HINTS = ("impact", "narrow", "condensed", "anton", "oswald", "bebas", "haettenschweiler")
TEXT_OVERFLOW_TOLERANCE = 0.15  # 15% slack on the height estimate before flagging
DEFAULT_MARGIN_IN = {"left": 0.1, "right": 0.1, "top": 0.05, "bottom": 0.05}  # PowerPoint's built-in inset when unset


def char_width_em_for(font_name):
    """Per-font average glyph width (fraction of font size). Condensed display
    faces are much narrower than a proportional body font."""
    if font_name and any(h in font_name.lower() for h in CONDENSED_FONT_HINTS):
        return CONDENSED_CHAR_WIDTH_EM
    return AVG_CHAR_WIDTH_EM


def emu_to_in(v):
    return Emu(v).inches


def shape_bbox_in(shape):
    return (emu_to_in(shape.left), emu_to_in(shape.top), emu_to_in(shape.width), emu_to_in(shape.height))


def has_text(shape):
    return shape.has_text_frame and shape.text_frame.text.strip() != ""


def overlap_area(a, b):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    ox = max(0.0, min(ax + aw, bx + bw) - max(ax, bx))
    oy = max(0.0, min(ay + ah, by + bh) - max(ay, by))
    return ox * oy


def _margin_in(value, default_in):
    return emu_to_in(value) if value is not None else default_in


def estimate_text_height_in(text_frame, box_width_in):
    """Rough estimate of the vertical space this text frame's content needs,
    for comparison against its actual box height. Returns None when the
    estimate isn't meaningful (auto-fit shapes that PowerPoint will shrink
    itself, or no-wrap boxes that overflow horizontally instead of
    vertically) — callers should skip the check in that case, not treat it
    as zero."""
    if text_frame.auto_size == MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE:
        return None
    if text_frame.word_wrap is False:
        return None

    margin_l = _margin_in(text_frame.margin_left, DEFAULT_MARGIN_IN["left"])
    margin_r = _margin_in(text_frame.margin_right, DEFAULT_MARGIN_IN["right"])
    margin_t = _margin_in(text_frame.margin_top, DEFAULT_MARGIN_IN["top"])
    margin_b = _margin_in(text_frame.margin_bottom, DEFAULT_MARGIN_IN["bottom"])
    usable_w = max(0.2, box_width_in - margin_l - margin_r)

    total_h = 0.0
    for para in text_frame.paragraphs:
        text = "".join(run.text for run in para.runs)
        sizes = [run.font.size.pt for run in para.runs if run.font.size is not None]
        size_pt = max(sizes) if sizes else 12
        em_in = size_pt / 72
        spacing = para.line_spacing
        if isinstance(spacing, float):
            leading_in = em_in * spacing
        elif spacing is not None:  # exact Length leading, not a multiple
            leading_in = emu_to_in(spacing)
        else:
            leading_in = em_in * 1.2  # PowerPoint's implicit default single-spacing leading

        if text == "":
            total_h += em_in
            continue
        # Use the widest run's font to pick the glyph-width factor (condensed
        # display faces are much narrower than proportional body text).
        fonts = [run.font.name for run in para.runs if run.font.name]
        char_em = char_width_em_for(fonts[0]) if fonts else AVG_CHAR_WIDTH_EM
        chars_per_line = max(1, int(usable_w / (em_in * char_em)))
        n_lines = -(-len(text) // chars_per_line)  # ceil division
        # A single line only needs its own glyph height (em_in) to avoid
        # clipping — the extra leading (line_h vs. em_in) only matters as
        # the GAP between stacked lines, so it's added n_lines - 1 times,
        # not once per line. Treating every line as needing full leading
        # overestimates single short labels/numerals in valign:middle boxes
        # that are visually fine in practice (a real false-positive class
        # found while calibrating this check against this skill's own
        # example templates).
        total_h += em_in + max(0, n_lines - 1) * leading_in

    return total_h + margin_t + margin_b


def contains(outer, inner, tol=CONTAINMENT_TOL_IN):
    ox, oy, ow, oh = outer
    ix, iy, iw, ih = inner
    return (ix >= ox - tol and iy >= oy - tol
            and ix + iw <= ox + ow + tol and iy + ih <= oy + oh + tol)


def visual_kind(shape):
    """Classify a non-text shape for the text-vs-visual overlap check.
    Returns a short label, or None when the shape should be skipped."""
    if getattr(shape, "has_chart", False):
        return "chart"
    if getattr(shape, "has_table", False):
        return "table"
    st = str(getattr(shape, "shape_type", "")).lower()
    if "picture" in st:
        return "picture"
    if "line" in st or "connector" in st:
        return None  # decorative lines sit flush with text by design
    if "auto_shape" in st or "rectangle" in st or "freeform" in st or "oval" in st:
        return "shape"
    return None


def has_center_aligned_text(shape):
    if not has_text(shape):
        return False
    return any(para.alignment == PP_ALIGN.CENTER for para in shape.text_frame.paragraphs)


def check_table_column_widths(shape, tol):
    """Mirrors check_tables.py's 'columns tile the table' assertion: for a
    native pptx table, the column widths should sum to the table frame's own
    declared width. A mismatch here is exact — pptxgenjs trusts whatever
    `colW` array it's given, so a bug in that array (fractions that don't sum
    to the intended table width) silently produces a table narrower or wider
    than its own frame, same root cause as sarvam-pdf's most common table
    defect."""
    table = shape.table
    frame_w_in = emu_to_in(shape.width)
    col_sum_in = sum(emu_to_in(col.width) for col in table.columns)
    if abs(col_sum_in - frame_w_in) > tol:
        return frame_w_in, col_sum_in
    return None


def _xml_local_name(element):
    tag = getattr(element, "tag", "")
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def chart_metadata(shape):
    """Return chart kind, series count, legend presence, explicit font sizes,
    and donut hole size from the chart XML without depending on private
    namespace maps."""
    root = shape.chart._chartSpace
    kinds = {
        "barChart": "bar",
        "bar3DChart": "bar",
        "lineChart": "line",
        "line3DChart": "line",
        "pieChart": "pie",
        "pie3DChart": "pie",
        "doughnutChart": "doughnut",
        "areaChart": "area",
        "scatterChart": "scatter",
    }
    kind = "other"
    series_count = 0
    has_legend = False
    font_sizes = []
    hole_size = None
    for element in root.iter():
        local = _xml_local_name(element)
        if local in kinds:
            kind = kinds[local]
        elif local == "ser":
            series_count += 1
        elif local == "legend":
            has_legend = True
        elif local in {"defRPr", "rPr", "endParaRPr"}:
            raw = element.get("sz")
            if raw:
                try:
                    font_sizes.append(int(raw) / 100)
                except ValueError:
                    pass
        elif local == "holeSize":
            raw = element.get("val")
            if raw:
                try:
                    hole_size = int(raw)
                except ValueError:
                    pass
    return {
        "kind": kind,
        "series_count": series_count,
        "has_legend": has_legend,
        "font_sizes": font_sizes,
        "hole_size": hole_size,
    }


def alignment_signature(shape):
    alignments = tuple(
        str(para.alignment) for para in shape.text_frame.paragraphs
        if para.alignment is not None
    )
    return alignments or ("default",)


def check_deck(path, tol):
    try:
        prs = Presentation(path)
    except Exception as e:
        print(f"UNREADABLE: {e}")
        return 2

    slide_w = emu_to_in(prs.slide_width)
    slide_h = emu_to_in(prs.slide_height)
    is_consulting_deck = prs.core_properties.subject == "sarvam-consulting-report"
    issues = []
    # (bucketed x, bucketed y) -> list of (slide_idx, max_pt, snippet): the
    # recurring-role groups for the cross-slide size-consistency check.
    role_groups = {}

    for slide_idx, slide in enumerate(prs.slides, start=1):
        text_boxes = []
        text_records = []  # (name, bbox, snippet, shape, z)
        visuals = []   # (name, bbox, kind) for non-text charts/pictures/tables/shapes
        centered = []  # (name, center_x, y) for shapes with any center-aligned paragraph
        within_slide_roles = []  # (bbox, max_pt, snippet, alignment signature)
        standard_chart_count = sum(
            1
            for candidate in slide.shapes
            if getattr(candidate, "has_chart", False)
            and chart_metadata(candidate)["kind"] != "doughnut"
        )

        for shape_z, shape in enumerate(slide.shapes):
            if shape.left is None or shape.top is None or shape.width is None or shape.height is None:
                continue  # placeholders with no explicit geometry (inherited from layout) - not checkable here
            x, y, w, h = shape_bbox_in(shape)
            name = shape.name or shape.shape_type

            if x < -tol or y < -tol:
                issues.append(f"slide {slide_idx}: '{name}' starts off-slide at ({x:.2f}in, {y:.2f}in)")
            if x + w > slide_w + tol:
                issues.append(f"slide {slide_idx}: '{name}' overflows right edge by {(x + w - slide_w):.2f}in")
            if y + h > slide_h + tol:
                issues.append(f"slide {slide_idx}: '{name}' overflows bottom edge by {(y + h - slide_h):.2f}in")

            if has_text(shape):
                norm_text = "".join(shape.text_frame.text.split()).upper()
                snippet = " ".join(shape.text_frame.text.split())[:32]
                rotated = bool(getattr(shape, "rotation", 0))
                text_boxes.append((name, (x, y, w, h), norm_text, snippet, rotated))
                text_records.append((name, (x, y, w, h), snippet, shape, shape_z))
                box_max_pt = None
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        size = run.font.size
                        if size is not None:
                            if box_max_pt is None or size.pt > box_max_pt:
                                box_max_pt = size.pt
                            if size.pt < MIN_FONT_PT:
                                snippet = run.text.strip()[:30]
                                issues.append(
                                    f"slide {slide_idx}: '{name}' has {size.pt:.1f}pt text "
                                    f"below the {MIN_FONT_PT}pt minimum: \"{snippet}\""
                                )
                if box_max_pt is not None:
                    bucket = (round(x / ROLE_POS_BUCKET_IN), round(y / ROLE_POS_BUCKET_IN))
                    snippet = " ".join(shape.text_frame.text.split())[:32]
                    role_groups.setdefault(bucket, []).append(
                        (slide_idx, box_max_pt, snippet)
                    )
                    within_slide_roles.append(
                        ((x, y, w, h), box_max_pt, snippet, alignment_signature(shape))
                    )

                est_h = estimate_text_height_in(shape.text_frame, w)
                if est_h is not None and est_h > h * (1 + TEXT_OVERFLOW_TOLERANCE):
                    snippet = " ".join(shape.text_frame.text.split())[:32]
                    issues.append(
                        f"slide {slide_idx}: '{name}' (\"{snippet}\") text likely overflows its own box — "
                        f"estimated ~{est_h:.2f}in of text in a {h:.2f}in-tall box. "
                        f"Fix: shrink the font so the text fits, or grow the box to ~{est_h:.2f}in "
                        f"AND move every element below it down by the same amount (or re-stack "
                        f"the slide top-to-bottom) so the growth doesn't create new overlaps"
                    )

                if w >= MIN_CENTERED_SHAPE_WIDTH_IN and has_center_aligned_text(shape):
                    centered.append((name, x + w / 2, x, w))

            if not has_text(shape):
                kind = visual_kind(shape)
                if kind is not None and w >= VISUAL_MIN_THICKNESS_IN and h >= VISUAL_MIN_THICKNESS_IN:
                    visuals.append((name, (x, y, w, h), kind, shape_z))

            if getattr(shape, "has_table", False):
                mismatch = check_table_column_widths(shape, TABLE_COL_SUM_TOL_IN)
                if mismatch is not None:
                    frame_w_in, col_sum_in = mismatch
                    issues.append(
                        f"slide {slide_idx}: '{name}' table column widths sum to {col_sum_in:.2f}in "
                        f"but the table frame is {frame_w_in:.2f}in wide — columns don't tile the frame"
                    )

            if getattr(shape, "has_chart", False):
                meta = chart_metadata(shape)
                if meta["kind"] == "doughnut":
                    if min(w, h) < MIN_DONUT_SIZE_IN:
                        issues.append(
                            f"slide {slide_idx}: '{name}' doughnut chart is {w:.2f}×{h:.2f}in; "
                            f"both dimensions must be at least {MIN_DONUT_SIZE_IN:.2f}in"
                        )
                    if (meta["hole_size"] is not None
                            and meta["hole_size"] > MAX_DONUT_HOLE_SIZE
                            and min(w, h) < 1.5):
                        issues.append(
                            f"slide {slide_idx}: '{name}' doughnut holeSize={meta['hole_size']} "
                            f"exceeds the readable maximum {MAX_DONUT_HOLE_SIZE} "
                            f"for a compact doughnut under 1.50in"
                        )
                else:
                    required_chart_w = (
                        MIN_CONSULTING_SINGLE_CHART_W_IN
                        if is_consulting_deck and standard_chart_count == 1
                        else MIN_STANDARD_CHART_W_IN
                    )
                    if w < required_chart_w or h < MIN_STANDARD_CHART_H_IN:
                        context = (
                            "single consulting"
                            if required_chart_w == MIN_CONSULTING_SINGLE_CHART_W_IN
                            else meta["kind"]
                        )
                        issues.append(
                            f"slide {slide_idx}: '{name}' {context} chart is {w:.2f}×{h:.2f}in; "
                            f"minimum readable size is {required_chart_w:.2f}×{MIN_STANDARD_CHART_H_IN:.2f}in"
                        )
                small_chart_fonts = [pt for pt in meta["font_sizes"] if pt < MIN_CHART_TEXT_PT]
                if small_chart_fonts:
                    issues.append(
                        f"slide {slide_idx}: '{name}' chart contains {min(small_chart_fonts):.1f}pt "
                        f"axis/legend/data-label text below the {MIN_CHART_TEXT_PT}pt minimum"
                    )
                if meta["series_count"] > 1 and not meta["has_legend"]:
                    issues.append(
                        f"slide {slide_idx}: '{name}' has {meta['series_count']} data series but no legend"
                    )

        # Centered elements (title/subtitle/eyebrow on a cover, a divider and
        # the block it decorates, etc.) should share one x-center — mirrors
        # check_layout.py's title-vs-subtitle / divider-vs-block checks. This
        # is exact, not a heuristic: PowerPoint centers text within its own
        # shape box, so the box center IS the rendered visual center whenever
        # `align: "center"` is set.
        #
        # Compared PAIRWISE, and only for pairs whose x-ranges OVERLAP. A title
        # and its subtitle are stacked and both span the content column, so
        # their x-ranges overlap — a real "should share a center" pair. But a
        # ROW of centered elements (stat captions, cards, a legend of columns)
        # sit side by side with disjoint x-ranges and deliberately different
        # centers — comparing those is a false positive. Requiring x-overlap
        # cleanly separates the two.
        for a in range(len(centered)):
            for b in range(a + 1, len(centered)):
                na, ca, xa, wa = centered[a]
                nb, cb, xb, wb = centered[b]
                x_overlap = min(xa + wa, xb + wb) - max(xa, xb)
                if x_overlap <= 0:
                    continue  # side-by-side columns, not a stacked title/subtitle
                spread = abs(ca - cb)
                if spread > CENTER_ALIGN_SPREAD_TOL_IN:
                    issues.append(
                        f"slide {slide_idx}: centered elements don't share a center — "
                        f"'{na}' at x-center={ca:.2f}in vs '{nb}' at x-center={cb:.2f}in "
                        f"(off by {spread:.2f}in). Fix: give both boxes the same x and w "
                        f"(center-aligned text centers within its own box, so equal boxes "
                        f"share a visual center)"
                    )

        # Text inside a filled container needs real breathing room. Include
        # the text frame's own margins in the effective inset; skip centered
        # labels/numerals, which intentionally use their whole box.
        for t_name, t_box, t_snip, t_shape, t_z in text_records:
            if has_center_aligned_text(t_shape):
                continue
            tx, ty, tw, th = t_box
            tf = t_shape.text_frame
            margin_l = _margin_in(tf.margin_left, DEFAULT_MARGIN_IN["left"])
            margin_r = _margin_in(tf.margin_right, DEFAULT_MARGIN_IN["right"])
            for v_name, v_box, v_kind, v_z in visuals:
                if v_kind != "shape" or v_z >= t_z:
                    continue
                vx, vy, vw, vh = v_box
                if vw >= slide_w - tol and vh >= slide_h - tol:
                    continue  # slide background
                if vh < 0.35:
                    continue  # bar/value-label pattern, not a text container
                if not contains(v_box, t_box, tol=0.02):
                    continue
                horizontal = min(
                    tx - vx + margin_l,
                    vx + vw - (tx + tw) + margin_r,
                )
                if horizontal < MIN_CONTAINER_HORIZONTAL_INSET_IN - tol / 2:
                    issues.append(
                        f"slide {slide_idx}: text '{t_name}' (\"{t_snip}\") sits only "
                        f"{horizontal:.2f}in from container '{v_name}' horizontally; "
                        f"minimum inset is {MIN_CONTAINER_HORIZONTAL_INSET_IN:.2f}in"
                    )
                break  # nearest z-order container is enough

        # Parallel elements on one slide (same y/width/height/alignment role)
        # should not drift in font size.
        within_groups = {}
        for box, pt, snippet, alignment in within_slide_roles:
            _x, y, w, h = box
            key = (
                round(y / WITHIN_ROLE_BUCKET_IN),
                round(w / WITHIN_ROLE_BUCKET_IN),
                round(h / WITHIN_ROLE_BUCKET_IN),
                alignment,
            )
            within_groups.setdefault(key, []).append((pt, snippet))
        for members in within_groups.values():
            if len(members) < WITHIN_ROLE_MIN_ITEMS:
                continue
            rounded = Counter(round(pt) for pt, _ in members)
            mode_pt, mode_count = rounded.most_common(1)[0]
            if mode_count < 2:
                continue
            for pt, snippet in members:
                if abs(pt - mode_pt) > WITHIN_ROLE_SIZE_TOL_PT:
                    issues.append(
                        f"slide {slide_idx}: parallel element \"{snippet}\" is {pt:.0f}pt "
                        f"while {mode_count} matching elements use {mode_pt}pt; "
                        f"use one font size for the role"
                    )

        # Visual-to-visual collisions involving charts, tables, or pictures.
        # Containment is the normal chart-on-panel / image-on-background
        # pattern and is intentionally allowed.
        for a in range(len(visuals)):
            for b in range(a + 1, len(visuals)):
                na, ba, ka, _za = visuals[a]
                nb, bb, kb, _zb = visuals[b]
                if not ({ka, kb} & {"chart", "table", "picture"}):
                    continue
                if contains(ba, bb) or contains(bb, ba):
                    continue
                inter = overlap_area(ba, bb)
                if inter <= 0:
                    continue
                smaller_area = min(ba[2] * ba[3], bb[2] * bb[3])
                if smaller_area > 0 and inter / smaller_area > VISUAL_OVERLAP_FRACTION_THRESHOLD:
                    issues.append(
                        f"slide {slide_idx}: {ka} '{na}' and {kb} '{nb}' overlap "
                        f"({inter / smaller_area:.0%} of the smaller visual); "
                        f"move or resize one visual"
                    )

        for i in range(len(text_boxes)):
            for j in range(i + 1, len(text_boxes)):
                name_a, box_a, text_a, snip_a, _rot_a = text_boxes[i]
                name_b, box_b, text_b, snip_b, _rot_b = text_boxes[j]
                # Two boxes carrying identical text are a deliberate layered
                # headline — a ghost/shadow/outline echo (see bold-pitch-style.js's
                # cover & closing). This is never an accidental collision, so
                # skip it. Only exact-match (whitespace/case-normalized), so real
                # different-content overlaps are still caught.
                if text_a and text_a == text_b:
                    continue
                inter = overlap_area(box_a, box_b)
                if inter <= 0:
                    continue
                smaller_area = min(box_a[2] * box_a[3], box_b[2] * box_b[3])
                if smaller_area > 0 and inter / smaller_area > OVERLAP_FRACTION_THRESHOLD:
                    # Name the upper and lower box and the exact y that clears
                    # them, so the fix is a one-line coordinate change — no
                    # geometry archaeology needed.
                    (ux, uy, uw, uh), (lx, ly, lw, lh) = (
                        (box_a, box_b) if box_a[1] <= box_b[1] else (box_b, box_a)
                    )
                    lower_name = name_b if box_a[1] <= box_b[1] else name_a
                    issues.append(
                        f"slide {slide_idx}: '{name_a}' (\"{snip_a}\") and "
                        f"'{name_b}' (\"{snip_b}\") overlap "
                        f"({inter / smaller_area:.0%} of the smaller box). "
                        f"Fix: move '{lower_name}' down to y={uy + uh + 0.1:.2f}in "
                        f"(the upper box ends at y={uy + uh:.2f}in), or shrink the "
                        f"upper box — then re-check the slide's bottom edge"
                    )

        # Text vs non-text visuals: the card pattern (text fully inside a
        # filled shape) is intentional; a PARTIAL overlap is a collision the
        # text-text check structurally cannot see (charts/pictures/decorative
        # rects carry no text frame).
        for t_name, t_box, _t_norm, t_snip, t_rot in text_boxes:
            if t_rot:
                # A rotated label's bbox is PRE-rotation (w/h deliberately
                # swapped per the rotate-wrapping gotcha), so containment in
                # un-rotated coordinates is meaningless — real false-positive
                # class: rotated row-group labels on their band.
                continue
            for v_name, v_box, v_kind, v_z in visuals:
                if contains(v_box, t_box):
                    continue  # card/banner/background pattern
                if contains(t_box, v_box):
                    continue  # small visual inside a sparse text bbox — unprovable
                inter = overlap_area(t_box, v_box)
                if inter <= 0:
                    continue
                # Covering-card excuse: another visual contains this text box
                # AND is drawn above the overlapped visual — the card hides it.
                if any(contains(c_box, t_box) and c_z > v_z
                       for _, c_box, _, c_z in visuals):
                    continue
                smaller_area = min(t_box[2] * t_box[3], v_box[2] * v_box[3])
                if smaller_area > 0 and inter / smaller_area > OVERLAP_FRACTION_THRESHOLD:
                    vx, vy, vw, vh = v_box
                    issues.append(
                        f"slide {slide_idx}: text '{t_name}' (\"{t_snip}\") "
                        f"partially overlaps the {v_kind} '{v_name}' "
                        f"({inter / smaller_area:.0%} of the smaller box). "
                        f"Fix: move one so they don't intersect (the {v_kind} "
                        f"spans x={vx:.2f}-{vx + vw:.2f}, y={vy:.2f}-{vy + vh:.2f}in), "
                        f"or — if the {v_kind} is a card behind this text — "
                        f"grow it to fully contain the text box"
                    )

    # Cross-slide role-size consistency (see constants above): a text box
    # recurring at one position across ROLE_MIN_SLIDES+ slides is one role,
    # and its size must not drift between slides. The modal size is the role's
    # size; the outliers are the drifted slides.
    for members in role_groups.values():
        slides_covered = {s for s, _, _ in members}
        if len(slides_covered) < ROLE_MIN_SLIDES:
            continue
        rounded = Counter(round(pt) for _, pt, _ in members)
        mode_pt, mode_count = rounded.most_common(1)[0]
        if mode_count < ROLE_MIN_SLIDES:
            continue
        for slide_idx, pt, snippet in members:
            if abs(pt - mode_pt) > ROLE_SIZE_TOL_PT:
                issues.append(
                    f"slide {slide_idx}: \"{snippet}\" is {pt:.0f}pt, but the "
                    f"same box position uses {mode_pt}pt on {mode_count} other "
                    f"slides — one size per role: set it to {mode_pt}pt "
                    f"(don't resize a recurring element per slide; if text "
                    f"doesn't fit, widen the box or break the line)"
                )

    if issues:
        for issue in issues:
            print(issue)
        print(f"DECK QA FAILED ({len(issues)} issue(s)) at tol={tol}in")
        return 1

    print(f"DECK QA PASSED ({len(prs.slides)} slides, tol={tol}in)")
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("pptx_path")
    parser.add_argument("--tol", type=float, default=0.05, help="tolerance in inches (default 0.05)")
    args = parser.parse_args()
    sys.exit(check_deck(args.pptx_path, args.tol))


if __name__ == "__main__":
    main()
