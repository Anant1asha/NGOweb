/**
 * Consulting Report — "Bold Headline / Research Report" style (PptxGenJS)
 *
 * A second consulting/strategy look, distinct from scripts/professional-style.js
 * (deep navy + accent bars): bold near-black display headlines, a blue
 * accent palette, and a denser card/chart/table vocabulary aimed at
 * research-report-style decks.
 * (a bold-headline / blue-palette research-report design family).
 *
 * Distinguishing features vs. the base professional-style.js:
 *   - Cover: full-bleed dark background (photo in the original; here a dark
 *     navy field with a few thin angled line accents standing in for it —
 *     see addCoverSlide's `photoDataUri` option if a real image is supplied),
 *     bold display title in a lime accent color, small-caps eyebrow line.
 *   - Bold, heavy, near-black titles on white content slides (not navy).
 *   - A signature "numbered theme grid" divider — a dense recap of N
 *     numbered points grouped into columns, with one group visually
 *     "spotlighted" in a dark callout box. See addNumberedThemeGrid().
 *   - Two chart idioms side by side: a native horizontal bar chart AND a
 *     hand-drawn horizontal percent-bar list (full label + inline value),
 *     used for compact ranked comparisons. See addPercentBarList().
 *   - A hand-drawn comparison matrix table with a merged/grouped left
 *     category column and colored dot indicators, since PptxGenJS's native
 *     addTable() has weak rowspan support for this kind of grouping. See
 *     addComparisonMatrix().
 *
 * HOW TO USE
 *   1. Copy this file next to your project.
 *   2. Edit the PALETTE and FONT constants if you want a different look.
 *   3. Do NOT just replace the slides in main() 1:1 — main() is a WORKED
 *      EXAMPLE showing each helper's calling convention, not a fixed slide
 *      sequence/count to reproduce. Read the COMPONENT REFERENCE below,
 *      decide how many slides the user's actual content needs and which
 *      helper fits each one, then call them in that order — including
 *      combinations, slide counts, and orderings not shown in main() at all.
 *   4. Run:  node consulting-report-style.js   ->  output.pptx
 *
 * Requires:  npm install pptxgenjs
 *
 * Full concise reference (read this instead of scanning this ~2200-line file):
 *   reference/consulting-report-components.md
 *
 * COMPONENT REFERENCE — every function below is an independent, reusable
 * building block (not tied to the specific slides main() happens to
 * assemble). Mix and match them into layouts NOT shown in main() — e.g.
 * addSidebarPanel + addHubChainDiagram + a native chart on one slide, or
 * addIconCardStack stacked three-high instead of two. Each has its own
 * JSDoc with parameter shapes; this is just an index so a new pattern can be
 * assembled without reading the whole file top to bottom.
 *
 * IMPORTANT — main()'s 13-slide sequence is ONE example composition, built
 * for this file's own development/QA, not a template to output verbatim for
 * every request. A real request rarely needs exactly these 13 slides in
 * this exact order with this exact content shape. Build the deck the user
 * actually asked for: fewer or more slides, a different order, different
 * helpers per slide, or a helper used in a way main() never shows (e.g.
 * addFourPanelGrid with 2 panels instead of 4, addIconCardStack with 3
 * cards instead of 2). Reusing a component means reusing its *function*,
 * not its exact position in this example.
 *
 *   Slide shells (call one per slide, first):
 *     addSimpleCoverSlide    — flat color field, centered title + subtitle only,
 *                               no decoration (used for slide 1 below)
 *     addCoverSlide          — full-bleed dark cover w/ line/node accent, eyebrow,
 *                               lime title (not used below — fuller alternative;
 *                               pass a real photoDataUri for a photo background)
 *     addContentSlide        — white bg, bold black action title, footer
 *     addBannerHeaderSlide   — full-width colored banner in place of a plain title
 *     addSimpleClosingSlide  — flat color field, centered statement, no
 *                               decoration (used for the last slide below)
 *     addClosingSlide        — dark two-tone statement + contact row (not used
 *                               below — fuller alternative)
 *
 *   Dividers / recap layouts:
 *     addNumberedThemeGrid   — N numbered items across left/spotlight/right
 *                               columns + a full-width banner row
 *
 *   Charts (native pptxgenjs chart calls are used directly in main() too —
 *   see the Slide 2/10 chart options for a documented, tuned config: explicit
 *   barGapWidthPct + a shared value-axis scale so bar widths render evenly):
 *     addPercentBarList      — hand-drawn horizontal ranked bar+value list
 *     addStackedBarRows      — horizontal 100%-style stacked bar rows + legend
 *     addFourPanelGrid       — 2x2 dashboard; each panel is "bars" | "donuts" |
 *                               "iconlist" (pass any mix of the three)
 *
 *   Tables:
 *     addComparisonMatrix    — grouped left category column + colored dot
 *                               indicator columns (hand-drawn, not addTable())
 *     addMythRealityTable    — numbered rows: statement | rebuttal | quote
 *
 *   Cards / lists:
 *     addIconBulletRow       — vertical stack of icon-accent + title + body
 *     addIconCardStack       — 1-2 stacked soft-surface cards w/ left accent bar
 *     addNumberedProcessCards— N step-cards flowing into a highlighted outcome box
 *     addLetteredCardList    — full-width rows, lettered badge + inline-bold body
 *
 *   Diagrams:
 *     addHubChainDiagram     — vertical connected-node chain, alternating labels
 *     addValueChainFlow      — horizontal box/circle chain w/ dashed connectors
 *                               and optional % badges (not used in main() below)
 *     addCycleDiagram        — N square "petals" around a small center hub
 *
 *   Supporting panels (used alongside the above, not standalone slides):
 *     addSidebarPanel        — beige right-hand column; heading+bullets OR
 *                               one-or-more attributed quotes
 *     addFooter, addBrandMark— footer page-number/note; optional plain-text
 *                               wordmark (no logo glyph — see addBrandMark's
 *                               own doc comment for why)
 *
 * Design rules baked in (see ../../design-guide.md):
 *   - Action titles (a full-sentence insight, not a topic label)
 *   - Left-aligned body; centered text only on cover / divider / closing
 *   - No accent line directly under titles
 *   - Never pure black (#000000) — use INK
 *   - Never reuse shadow/option objects — always call softShadow() fresh
 */

const path = require("path");
const pptxgen = require("pptxgenjs");

// ─── CUSTOMIZE: PALETTE (no "#" prefix — PptxGenJS requirement) ───
const C = {
  navy:      "0B1C2C", // cover / dark surfaces
  navySurface: "0F1E30", // "spotlight" callout box on dividers
  blue:      "2F6FED", // primary accent — bars, links, highlighted words
  blueLight: "DCEAFE", // light-blue card/banner fill
  lime:      "C9D94A", // cover title accent (used sparingly — cover only)
  ink:       "12181F", // headline text (near-black, never pure black)
  ink2:      "4A4A4A", // body text
  ink3:      "8C8C8C", // captions, footer, axis labels
  line:      "DCDCDC", // hairline borders
  lineDark:  "333333", // table grid lines (this family uses crisper, darker hairlines)
  gray:      "BFBFBF", // secondary/lower-priority bar fill
  paper:     "FFFFFF",
};

// ─── CUSTOMIZE: FONTS ───
// The golden reference uses a heavy condensed display face for headlines.
// That font isn't guaranteed to be installed wherever this renders, so we
// use a safe substitute that ships broadly — the same policy as the rest of
// this skill. Swap FONT_H/FONT_B if a display face is safe to assume in
// your environment.
const FONT_H = "Helvetica";
const FONT_B = "Helvetica";

// ─── SETUP ───
const pres = new pptxgen();
pres.layout = "LAYOUT_16x9"; // 10" x 5.625"
pres.author = "Presentation Skill";
pres.title = "Template 2 Presentation";
pres.subject = "sarvam-consulting-report";

// ─── CONSULTING DESIGN SYSTEM ───
// Keep these semantic roles stable even when a user supplies replacement
// colors/fonts. Helpers consume the roles rather than inventing geometry.
const GRID = Object.freeze({
  pageW: 10,
  pageH: 5.625,
  marginX: 0.5,
  titleY: 0.30,
  titleH: 0.90,
  contentTop: 1.35,
  contentBottom: 5.15,
  footerY: 5.34,
  footerH: 0.22,
});

const TYPE = Object.freeze({
  coverTitle: 40,
  contentTitle: 24,
  section: 14,
  narrativeBody: 14,
  denseBody: 10,
  denseBodyLarge: 11,
  cardTitle: 12,
  denseNumeral: 18,
  heroStat: 32,
  caption: 9,
  footer: 8,
});

const SPACE = Object.freeze({
  blockGap: 0.25,
  denseGap: 0.12,
  inset: 0.14,
  textVisualClearance: 0.10,
});

const CHART_DEFAULTS = Object.freeze({
  barGapWidthPct: 35,
  axisFontSize: 10,
  dataLabelFontSize: 10,
  legendFontSize: 9,
  minSingleW: 6.0,
  minCompareW: 4.0,
  minChartH: 2.5,
  minDonutSize: 0.85,
  donutHoleSize: 44,
});

// Chart palette — accent first, then supporting tones.
const CHART_COLORS = Object.freeze([C.blue, C.ink, C.gray, C.lime, C.navy]);

// Backward-compatible aliases used by the existing helper signatures.
const MX = GRID.marginX;
const PAGE_W = GRID.pageW;
const PAGE_H = GRID.pageH;

// ─── HELPERS ───

function wordCount(value) {
  return String(value || "").trim().split(/\s+/).filter(Boolean).length;
}

function assertItems(component, items, min, max, label = "items") {
  if (!Array.isArray(items) || items.length < min || items.length > max) {
    throw new Error(`${component}: ${label} must contain ${min}-${max} entries; got ${items?.length ?? 0}. Reduce items or split the slide.`);
  }
}

function assertWordCap(component, label, value, maxWords) {
  const count = wordCount(value);
  if (count > maxWords) {
    throw new Error(`${component}: ${label} has ${count} words; maximum is ${maxWords}. Shorten it or split the slide.`);
  }
}

function estimateTextHeight(text, widthIn, fontSize = TYPE.denseBody, lineSpacing = 1.1) {
  const usableW = Math.max(0.2, widthIn - SPACE.inset * 2);
  const emIn = fontSize / 72;
  const charsPerLine = Math.max(1, Math.floor(usableW / (emIn * 0.5)));
  const lines = Math.max(1, Math.ceil(String(text || "").length / charsPerLine));
  return emIn + Math.max(0, lines - 1) * emIn * lineSpacing + 0.10;
}

function allocateHeights(component, requiredHeights, availableH, gap = SPACE.denseGap) {
  const required = requiredHeights.reduce((sum, h) => sum + h, 0) + gap * Math.max(0, requiredHeights.length - 1);
  if (required > availableH + 0.001) {
    throw new Error(`${component}: content needs ~${required.toFixed(2)}in but only ${availableH.toFixed(2)}in is available. Reduce items or split the slide; do not shrink the font.`);
  }
  const extra = (availableH - required) / Math.max(1, requiredHeights.length);
  return requiredHeights.map((h) => h + extra);
}

function assertTextFits(component, label, text, { w, h, fontSize = TYPE.denseBody, lineSpacing = 1.1 }) {
  const required = estimateTextHeight(text, w, fontSize, lineSpacing);
  if (required > h + 0.001) {
    throw new Error(`${component}: ${label} needs ~${required.toFixed(2)}in but its box is ${h.toFixed(2)}in tall. Shorten the copy, grow/reflow the box, or split the slide.`);
  }
}

function freshChartChrome() {
  return {
    chartArea: { fill: { color: C.paper } },
    catAxisLabelColor: C.ink2,
    valAxisLabelColor: C.ink3,
    catAxisLabelFontFace: FONT_B,
    valAxisLabelFontFace: FONT_B,
    catAxisLabelFontSize: CHART_DEFAULTS.axisFontSize,
    valAxisLabelFontSize: CHART_DEFAULTS.axisFontSize,
    legendFontFace: FONT_B,
    legendFontSize: CHART_DEFAULTS.legendFontSize,
    legendColor: C.ink2,
    catGridLine: { style: "none" },
    valGridLine: { color: C.line, size: 0.5 },
  };
}

function addConsultingBarChart(slide, {
  series,
  x,
  y,
  w,
  h,
  unit,
  maxValue = 100,
  comparison = false,
  firstCategoryAtTop = true,
  showLegend,
  options = {},
}) {
  if (!unit) throw new Error("addConsultingBarChart: unit is required (for example %, $M, count, or index).");
  assertItems("addConsultingBarChart", series, 1, 5, "series");
  series.forEach((entry, index) => {
    if (!Array.isArray(entry.labels) || !Array.isArray(entry.values) || entry.labels.length !== entry.values.length) {
      throw new Error(`addConsultingBarChart: series ${index + 1} must have equally sized labels and values arrays.`);
    }
  });
  const minW = comparison ? CHART_DEFAULTS.minCompareW : CHART_DEFAULTS.minSingleW;
  if (w < minW || h < CHART_DEFAULTS.minChartH) {
    throw new Error(`addConsultingBarChart: chart is ${w.toFixed(2)}×${h.toFixed(2)}in; minimum is ${minW.toFixed(2)}×${CHART_DEFAULTS.minChartH.toFixed(2)}in.`);
  }
  const legend = showLegend ?? series.length > 1;
  if (series.length > 1 && !legend) {
    throw new Error("addConsultingBarChart: multi-series charts must show a legend.");
  }
  // Native horizontal bars place the first category at the bottom. Consulting
  // charts read top-to-bottom, so reverse the chart payload (without mutating
  // caller data) unless the caller explicitly requests native ordering.
  const chartSeries = series.map((entry) => ({
    ...entry,
    labels: firstCategoryAtTop ? [...entry.labels].reverse() : [...entry.labels],
    values: firstCategoryAtTop ? [...entry.values].reverse() : [...entry.values],
  }));
  slide.addChart(pres.charts.BAR, chartSeries, {
    x, y, w, h,
    barDir: "bar",
    chartColors: [...CHART_COLORS],
    chartColorsOpacity: 100,
    ...freshChartChrome(),
    barGapWidthPct: CHART_DEFAULTS.barGapWidthPct,
    valAxisMinVal: 0,
    valAxisMaxVal: maxValue,
    showTitle: true,
    title: unit,
    titleAlign: "right",
    titleColor: C.ink3,
    titleFontFace: FONT_B,
    titleFontSize: TYPE.caption,
    showValue: true,
    dataLabelColor: C.ink,
    dataLabelFontFace: FONT_B,
    dataLabelFontSize: CHART_DEFAULTS.dataLabelFontSize,
    dataLabelPosition: "outEnd",
    showLegend: legend,
    legendPos: "b",
    ...options,
  });
}

function addConsultingColumnChart(slide, {
  series,
  x,
  y,
  w,
  h,
  unit,
  maxValue,
  minValue = 0,
  stacked = false,
  comparison = false,
  showLegend,
  options = {},
}) {
  if (!unit) throw new Error("addConsultingColumnChart: unit is required (for example %, $M, count, or index).");
  assertItems("addConsultingColumnChart", series, 1, 5, "series");
  series.forEach((entry, index) => {
    if (!Array.isArray(entry.labels) || !Array.isArray(entry.values) || entry.labels.length !== entry.values.length) {
      throw new Error(`addConsultingColumnChart: series ${index + 1} must have equally sized labels and values arrays.`);
    }
  });
  if (stacked && series.length < 2) {
    throw new Error("addConsultingColumnChart: stacked columns require at least 2 series.");
  }
  const minW = comparison ? CHART_DEFAULTS.minCompareW : CHART_DEFAULTS.minSingleW;
  if (w < minW || h < CHART_DEFAULTS.minChartH) {
    throw new Error(`addConsultingColumnChart: chart is ${w.toFixed(2)}×${h.toFixed(2)}in; minimum is ${minW.toFixed(2)}×${CHART_DEFAULTS.minChartH.toFixed(2)}in.`);
  }
  const legend = showLegend ?? series.length > 1;
  if (series.length > 1 && !legend) {
    throw new Error("addConsultingColumnChart: multi-series charts must show a legend.");
  }
  slide.addChart(pres.charts.BAR, series, {
    x, y, w, h,
    barDir: "col",
    barGrouping: stacked ? "stacked" : "clustered",
    chartColors: [...CHART_COLORS],
    ...freshChartChrome(),
    barGapWidthPct: CHART_DEFAULTS.barGapWidthPct,
    valAxisMinVal: minValue,
    valAxisMaxVal: maxValue,
    showTitle: true,
    title: unit,
    titleAlign: "right",
    titleColor: C.ink3,
    titleFontFace: FONT_B,
    titleFontSize: TYPE.caption,
    showValue: true,
    dataLabelColor: C.ink,
    dataLabelFontFace: FONT_B,
    dataLabelFontSize: CHART_DEFAULTS.dataLabelFontSize,
    dataLabelPosition: stacked ? "ctr" : "outEnd",
    showLegend: legend,
    legendPos: "b",
    ...options,
  });
}

function addConsultingLineChart(slide, {
  series,
  x,
  y,
  w,
  h,
  unit,
  maxValue,
  minValue = 0,
  comparison = false,
  showLegend,
  options = {},
}) {
  if (!unit) throw new Error("addConsultingLineChart: unit is required (for example %, $M, count, or index).");
  assertItems("addConsultingLineChart", series, 1, 5, "series");
  series.forEach((entry, index) => {
    if (!Array.isArray(entry.labels) || !Array.isArray(entry.values) || entry.labels.length !== entry.values.length) {
      throw new Error(`addConsultingLineChart: series ${index + 1} must have equally sized labels and values arrays.`);
    }
    if (entry.labels.length < 4) {
      throw new Error(`addConsultingLineChart: series ${index + 1} has ${entry.labels.length} points; trends require at least 4. Use addConsultingColumnChart for shorter comparisons.`);
    }
  });
  const minW = comparison ? CHART_DEFAULTS.minCompareW : CHART_DEFAULTS.minSingleW;
  if (w < minW || h < CHART_DEFAULTS.minChartH) {
    throw new Error(`addConsultingLineChart: chart is ${w.toFixed(2)}×${h.toFixed(2)}in; minimum is ${minW.toFixed(2)}×${CHART_DEFAULTS.minChartH.toFixed(2)}in.`);
  }
  const legend = showLegend ?? series.length > 1;
  if (series.length > 1 && !legend) {
    throw new Error("addConsultingLineChart: multi-series charts must show a legend.");
  }
  slide.addChart(pres.charts.LINE, series, {
    x, y, w, h,
    chartColors: [...CHART_COLORS],
    ...freshChartChrome(),
    valAxisMinVal: minValue,
    valAxisMaxVal: maxValue,
    showTitle: true,
    title: unit,
    titleAlign: "right",
    titleColor: C.ink3,
    titleFontFace: FONT_B,
    titleFontSize: TYPE.caption,
    showValue: true,
    dataLabelColor: C.ink,
    dataLabelFontFace: FONT_B,
    dataLabelFontSize: CHART_DEFAULTS.dataLabelFontSize,
    dataLabelPosition: "t",
    lineSize: 2,
    lineDataSymbol: "circle",
    lineDataSymbolSize: 6,
    lineSmooth: false,
    showLegend: legend,
    legendPos: "b",
    ...options,
  });
}

function addConsultingAreaChart(slide, {
  series,
  x,
  y,
  w,
  h,
  unit,
  maxValue,
  minValue = 0,
  options = {},
}) {
  if (!unit) throw new Error("addConsultingAreaChart: unit is required (for example %, $M, count, or index).");
  assertItems("addConsultingAreaChart", series, 1, 1, "series");
  const entry = series[0];
  if (!Array.isArray(entry.labels) || !Array.isArray(entry.values) || entry.labels.length !== entry.values.length) {
    throw new Error("addConsultingAreaChart: the series must have equally sized labels and values arrays.");
  }
  if (entry.labels.length < 4) {
    throw new Error(`addConsultingAreaChart: the series has ${entry.labels.length} points; cumulative trends require at least 4.`);
  }
  if (w < CHART_DEFAULTS.minSingleW || h < CHART_DEFAULTS.minChartH) {
    throw new Error(`addConsultingAreaChart: chart is ${w.toFixed(2)}×${h.toFixed(2)}in; minimum is ${CHART_DEFAULTS.minSingleW.toFixed(2)}×${CHART_DEFAULTS.minChartH.toFixed(2)}in.`);
  }
  slide.addChart(pres.charts.AREA, series, {
    x, y, w, h,
    chartColors: [C.blue],
    ...freshChartChrome(),
    valAxisMinVal: minValue,
    valAxisMaxVal: maxValue,
    showTitle: true,
    title: unit,
    titleAlign: "right",
    titleColor: C.ink3,
    titleFontFace: FONT_B,
    titleFontSize: TYPE.caption,
    showValue: true,
    dataLabelColor: C.ink,
    dataLabelFontFace: FONT_B,
    dataLabelFontSize: CHART_DEFAULTS.dataLabelFontSize,
    dataLabelPosition: "t",
    showLegend: false,
    areaOpacity: 28,
    ...options,
  });
}

function addConsultingDonutChart(slide, {
  label,
  segments,
  x,
  y,
  w,
  h,
  showLegend = false,
  showPercent = true,
  expectedTotal = 100,
  options = {},
}) {
  assertItems("addConsultingDonutChart", segments, 2, 5, "segments");
  const total = segments.reduce((sum, segment) => sum + Number(segment.value), 0);
  if (segments.some((segment) => !Number.isFinite(Number(segment.value)) || Number(segment.value) < 0)) {
    throw new Error("addConsultingDonutChart: every segment value must be a finite non-negative number.");
  }
  if (expectedTotal !== null && Math.abs(total - expectedTotal) > 0.5) {
    throw new Error(`addConsultingDonutChart: segment values sum to ${total.toFixed(1)}, expected ${expectedTotal}±0.5. Add the missing remainder or pass expectedTotal: null for count data.`);
  }
  if (Math.min(w, h) < CHART_DEFAULTS.minDonutSize) {
    throw new Error(`addConsultingDonutChart: donut is ${w.toFixed(2)}×${h.toFixed(2)}in; both dimensions must be at least ${CHART_DEFAULTS.minDonutSize.toFixed(2)}in.`);
  }
  slide.addChart(
    pres.charts.DOUGHNUT,
    [{ name: label, labels: segments.map((segment) => segment.name), values: segments.map((segment) => segment.value) }],
    {
      x, y, w, h,
      chartColors: segments.map((segment) => segment.color || C.blue),
      showLegend,
      legendPos: "r",
      legendFontFace: FONT_B,
      legendFontSize: CHART_DEFAULTS.legendFontSize,
      showValue: false,
      showPercent,
      holeSize: CHART_DEFAULTS.donutHoleSize,
      dataBorder: { pt: 0.75, color: "FFFFFF" },
      ...options,
    }
  );
}

/** Fresh shadow object — never reuse (PptxGenJS mutates option objects). */
const softShadow = () => ({
  type: "outer", color: "000000", opacity: 0.12, blur: 8, offset: 2, angle: 90,
});

/**
 * Optional plain wordmark — brand-neutral (no logo glyph of any kind: a
 * literal triangle mark was here through round 11 of the hillclimb and it
 * turned out to directly mimic the source deck's real company logo shape,
 * which violates this skill's standing "no third-party logos / no
 * brand-specific marks" rule (ppt_golden_set/SELECTION_NOTES.md). Text-only,
 * and only rendered when a name is actually supplied.
 */
// ─── Vertical stack cursor ──────────────────────────────────────────────────
// Place slide content top-to-bottom without hand-computing a y for every box:
// each place(h) returns the y for a block of height h and advances the cursor
// by h + gap. Changing one block's height re-flows everything below it — which
// is what prevents the "grew a box to fix text-fit, created a new overlap"
// cascade. Use it whenever a slide stacks 3+ elements vertically.
//   const stack = makeStack(1.2);                         // content top (in)
//   addKicker(slide, "...", { x: MX, y: stack.place(0.4) });
//   addBody(slide, "...",   { x: MX, y: stack.place(2.0, 0.3) }); // h, gap
//   addFootLine(slide, "...", { x: MX, y: stack.y() });   // current cursor
function makeStack(startY, defaultGap = 0.25) {
  let cur = startY;
  return {
    place(h, gap = defaultGap) { const y = cur; cur = y + h + gap; return y; },
    y() { return cur; },
  };
}

function addBrandMark(slide, { x, y, dark = false, brandName = "" } = {}) {
  if (!brandName) return;
  const color = dark ? C.ink : "FFFFFF";
  slide.addText(brandName.toUpperCase(), {
    x, y: y - 0.03, w: 2.4, h: 0.32,
    fontSize: 13, fontFace: FONT_H, color, bold: true, charSpacing: 1, margin: 0, valign: "middle",
  });
}

/**
 * Footer — optional source/question note bottom-left, page number
 * bottom-right (this family always numbers pages, unlike the base style
 * where it's a plain page count).
 */
function addFooter(slide, pageNum, note) {
  if (note) {
    slide.addText(note, {
      x: MX, y: GRID.footerY, w: PAGE_W - MX * 2 - 1, h: GRID.footerH,
      fontSize: TYPE.footer, fontFace: FONT_B, color: C.ink3, margin: 0,
    });
  }
  slide.addText(String(pageNum), {
    x: PAGE_W - MX - 0.4, y: GRID.footerY, w: 0.4, h: GRID.footerH,
    fontSize: TYPE.footer, fontFace: FONT_B, color: C.ink3, align: "right", margin: 0,
  });
}

/** Cover — full-bleed dark background, bold lime display title. */
function addCoverSlide({ eyebrow, title, subtitle, brandName = "", photoDataUri = null }) {
  const s = pres.addSlide();
  if (photoDataUri) {
    s.background = { data: photoDataUri };
    // Dark scrim so text stays legible over a photo — draw a semi-transparent
    // dark rectangle across the lower two-thirds of the slide.
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: PAGE_H * 0.35, w: PAGE_W, h: PAGE_H * 0.65,
      fill: { color: "000000", transparency: 35 }, line: { type: "none" },
    });
  } else {
    s.background = { color: C.navy };
    // No real photo asset available (brand-neutral skill, no stock photo
    // access) — the golden reference fills the whole frame with a
    // photographic collage, and a flat solid field here reads as visibly
    // empty/sparse by comparison (round-1 finding). Stand in with a subtle
    // abstract "network" accent (thin diagonal lines + a few nodes) fanning
    // from the upper-right, echoing the golden cover's imagery without
    // needing a photo. Kept low-contrast so it doesn't compete with the
    // title text below it.
    // Kept fully within slide bounds (0,0)-(PAGE_W,PAGE_H): check_deck.py's
    // bounds gate is non-negotiable, so no "bleed past the edge" tricks here.
    const lineColor = "1C3B57";
    const nodeColor = "2E4A63";
    for (let i = 0; i < 5; i++) {
      const x0 = PAGE_W - 3.6 + i * 0.5;
      s.addShape(pres.shapes.LINE, {
        x: x0, y: 0, w: 1.5 - i * 0.1, h: 2.2 + i * 0.1,
        line: { color: lineColor, width: 0.75 },
      });
    }
    [[PAGE_W - 1.6, 0.5], [PAGE_W - 2.4, 1.3], [PAGE_W - 1.1, 1.9], [PAGE_W - 3.0, 2.4]].forEach(([nx, ny]) => {
      s.addShape(pres.shapes.OVAL, {
        x: nx, y: ny, w: 0.09, h: 0.09, fill: { color: nodeColor }, line: { type: "none" },
      });
    });
  }

  addBrandMark(s, { x: MX, y: 0.35, dark: false, brandName });

  if (eyebrow) {
    s.addText(eyebrow.toUpperCase(), {
      x: MX, y: 3.55, w: PAGE_W - MX * 2, h: 0.3,
      fontSize: 12, fontFace: FONT_B, color: "FFFFFF", bold: false, charSpacing: 3, margin: 0,
    });
  }
  // Title box height is sized for ONE line at 40pt bold (~0.75in incl. line
  // gap) — if a title is long enough to wrap to 2 lines, either shorten it
  // or grow this box (and push the subtitle down to match) rather than
  // letting the fixed 0.75in box silently clip/overlap the subtitle below.
  s.addText(title, {
    x: MX, y: 3.85, w: PAGE_W - MX * 2, h: 0.75,
    fontSize: TYPE.coverTitle, fontFace: FONT_H, color: C.lime, bold: true, margin: 0, lineSpacingMultiple: 1.0,
  });
  if (subtitle) {
    s.addText(subtitle, {
      x: MX, y: 4.65, w: PAGE_W - MX * 2, h: 0.5,
      fontSize: 16, fontFace: FONT_B, color: "FFFFFF", bold: true, margin: 0,
    });
  }
}

/**
 * Content slide shell — bold near-black action title top-left, small brand
 * mark top-right, footer. Returns the slide for content.
 */
function addContentSlide(actionTitle, pageNum, { note } = {}) {
  assertWordCap("addContentSlide", "actionTitle", actionTitle, 12);
  const s = pres.addSlide();
  s.background = { color: C.paper };
  // Title width leaves room for the brand mark (which has no text frame, so
  // check_deck.py's text-box overlap check can't catch a collision with it —
  // this gap must stay wide enough that a full-width-wrapping title's last
  // word never reaches the mark's x-position; matches the clearance already
  // used in addNumberedThemeGrid).
  s.addText(actionTitle, {
    x: MX, y: GRID.titleY, w: PAGE_W - MX * 2 - 1.0, h: GRID.titleH,
    fontSize: TYPE.contentTitle, fontFace: FONT_H, color: C.ink, bold: true,
    valign: "top", margin: 0, lineSpacingMultiple: 1.02,
  });
  addBrandMark(s, { x: PAGE_W - MX - 0.9, y: 0.4, dark: true });
  addFooter(s, pageNum, note);
  return s;
}

/**
 * Signature "numbered theme grid" divider — a dense recap of N numbered
 * items in a left column of blue cards, a "spotlight" group in a dark
 * callout box, more cards to the right, and a full-width banner row for a
 * closing/catch-all item. Matches ppt_golden_set/template_2/selected/
 * p3_section-divider.png.
 *
 * @param {object} opts
 * @param {string} opts.title       full-sentence recap headline (2-tone: pass
 *                                  `titleAccent` for the leading clause)
 * @param {string} [opts.titleAccent] leading clause rendered in accent blue
 * @param {Array}  opts.leftItems   [{ num, title, body }] — left column, blue cards
 * @param {object} [opts.spotlight] { label, items: [{ num, title, body }] } — dark callout box
 * @param {Array}  [opts.rightItems] [{ num, title, body }] — right column, light-blue cards
 * @param {object} [opts.banner]    { num, title } — full-width closing banner row
 * @param {number} opts.pageNum
 */
function addNumberedThemeGrid({ title, titleAccent, leftItems = [], spotlight, rightItems = [], banner, pageNum }) {
  assertWordCap("addNumberedThemeGrid", "title", `${titleAccent || ""} ${title || ""}`, 10);
  assertItems("addNumberedThemeGrid", leftItems, 1, 3, "leftItems");
  if (rightItems.length) assertItems("addNumberedThemeGrid", rightItems, 1, 3, "rightItems");
  if (spotlight) assertItems("addNumberedThemeGrid", spotlight.items, 1, 3, "spotlight.items");
  [...leftItems, ...rightItems, ...(spotlight?.items || [])].forEach((item, index) => {
    assertWordCap("addNumberedThemeGrid", `item ${index + 1} title`, item.title, 4);
    assertWordCap("addNumberedThemeGrid", `item ${index + 1} body`, item.body, 18);
  });
  const s = pres.addSlide();
  s.background = { color: C.paper };
  addBrandMark(s, { x: PAGE_W - MX - 0.9, y: 0.35, dark: true });

  const titleRuns = [];
  if (titleAccent) titleRuns.push({ text: titleAccent + " ", options: { color: C.blue } });
  titleRuns.push({ text: title, options: { color: C.ink } });
  s.addText(titleRuns, {
    x: MX, y: GRID.titleY, w: PAGE_W - MX * 2 - 1.0, h: GRID.titleH,
    // 24pt = the one content-slide title size across this template (same as
    // addContentSlide/addBannerHeaderSlide) — check_deck.py flags drift.
    fontSize: TYPE.contentTitle, fontFace: FONT_H, bold: true, valign: "top", margin: 0, lineSpacingMultiple: 1.05,
  });

  const gridTop = 1.35;
  // Banner row needs a taller box than the naive 4.75-4.87 gap gave it (round-11
  // finding: at 22pt bold, the banner's own text is taller than a 0.28in-high
  // box, reading as cramped/clipped) — pull gridBottom in further so the
  // banner gets ~0.4in instead.
  const gridBottom = banner ? 4.6 : 5.15;
  const gridH = gridBottom - gridTop;
  const gap = 0.12;

  // Column layout: left cards | spotlight (if any) | right cards
  const nCols = 1 + (spotlight ? 1 : 0) + (rightItems.length ? 1 : 0);
  const colW = (PAGE_W - MX * 2 - gap * (nCols - 1)) / nCols;

  function drawCardCol(x, items, { fill, textColor, kickerColor }) {
    const textW = colW - 0.74;
    const rowHeights = allocateHeights(
      "addNumberedThemeGrid",
      items.map((item) => Math.max(
        0.58,
        estimateTextHeight(`${item.title}\n${item.body || ""}`, textW, TYPE.denseBodyLarge, 1.1) + 0.16
      )),
      gridH,
      gap
    );
    let cursorY = gridTop;
    items.forEach((item, i) => {
      const rowH = rowHeights[i];
      const y = cursorY;
      s.addShape(pres.shapes.RECTANGLE, { x, y, w: colW, h: rowH, fill: { color: fill }, line: { type: "none" } });
      s.addText(String(item.num), {
        x: x + 0.14, y: y + 0.08, w: 0.5, h: rowH - 0.16,
        fontSize: TYPE.denseNumeral, fontFace: FONT_H, color: kickerColor, bold: true, valign: "middle", margin: 0,
      });
      s.addText(
        [
          { text: item.title, options: { bold: true, breakLine: true } },
          { text: item.body || "", options: {} },
        ],
        {
          x: x + 0.6, y: y + 0.08, w: colW - 0.74, h: rowH - 0.16,
          fontSize: TYPE.denseBodyLarge, fontFace: FONT_B, color: textColor, valign: "middle", margin: 0, lineSpacingMultiple: 1.1,
        }
      );
      cursorY += rowH + gap;
    });
  }

  let colX = MX;
  drawCardCol(colX, leftItems, { fill: C.blue, textColor: "FFFFFF", kickerColor: "FFFFFF" });
  colX += colW + gap;

  if (spotlight) {
    s.addShape(pres.shapes.RECTANGLE, { x: colX, y: gridTop, w: colW, h: gridH, fill: { color: C.navySurface }, line: { type: "none" } });
    s.addText(spotlight.label, {
      x: colX + 0.14, y: gridTop + 0.1, w: colW - 0.28, h: 0.3,
      fontSize: 10, fontFace: FONT_B, color: "FFFFFF", bold: true, margin: 0,
    });
    const innerTop = gridTop + 0.45;
    const innerH = gridH - 0.55;
    const textW = colW - 0.8;
    const rowHeights = allocateHeights(
      "addNumberedThemeGrid spotlight",
      spotlight.items.map((item) => Math.max(
        0.58,
        estimateTextHeight(`${item.title}\n${item.body || ""}`, textW, TYPE.denseBodyLarge, 1.1) + 0.12
      )),
      innerH,
      gap
    );
    let cursorY = innerTop;
    spotlight.items.forEach((item, i) => {
      const rowH = rowHeights[i];
      const y = cursorY;
      s.addShape(pres.shapes.RECTANGLE, { x: colX + 0.1, y, w: colW - 0.2, h: rowH, fill: { color: C.blue }, line: { type: "none" } });
      s.addText(String(item.num), {
        x: colX + 0.22, y: y + 0.06, w: 0.4, h: rowH - 0.12,
        fontSize: TYPE.denseNumeral, fontFace: FONT_H, color: "FFFFFF", bold: true, valign: "middle", margin: 0,
      });
      s.addText(
        [
          { text: item.title, options: { bold: true, breakLine: true } },
          { text: item.body || "", options: {} },
        ],
        {
          x: colX + 0.6, y: y + 0.06, w: colW - 0.8, h: rowH - 0.12,
          fontSize: TYPE.denseBodyLarge, fontFace: FONT_B, color: "FFFFFF", valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
        }
      );
      cursorY += rowH + gap;
    });
    colX += colW + gap;
  }

  if (rightItems.length) {
    drawCardCol(colX, rightItems, { fill: C.blueLight, textColor: C.ink2, kickerColor: C.blue });
  }

  if (banner) {
    const y = gridBottom + gap;
    const h = 5.15 - y;
    s.addShape(pres.shapes.RECTANGLE, { x: MX, y, w: PAGE_W - MX * 2, h, fill: { color: C.blueLight }, line: { type: "none" } });
    s.addText(String(banner.num), {
      x: MX + 0.18, y, w: 0.5, h, fontSize: TYPE.denseNumeral, fontFace: FONT_H, color: C.blue, bold: true, valign: "middle", margin: 0,
    });
    s.addText(banner.title, {
      x: MX + 0.7, y, w: PAGE_W - MX * 2 - 0.9, h,
      fontSize: TYPE.section, fontFace: FONT_B, color: C.ink, bold: true, valign: "middle", margin: 0,
    });
  }

  addFooter(s, pageNum);
  return s;
}

/**
 * Hand-drawn horizontal percent-bar list — a compact ranked-comparison
 * idiom used alongside (or instead of) a native chart. Each item gets a
 * label above/beside a filled bar sized to its value; the value label sits
 * inside the bar (white) if the fill is wide enough, else just outside
 * (dark) — matches ppt_golden_set/template_2/selected/p9_bar-chart-comparison.png.
 *
 * @param {object} opts
 * @param {Array}  opts.items  [{ label, value, max, color }] value/max in [0,100]
 * @param {number} [opts.max]  shared max if items don't each specify one (default 100)
 */
function addPercentBarList(slide, { x, y, w, h, heading, items, max = 100 }) {
  assertItems("addPercentBarList", items, 2, 5);
  if (heading) assertWordCap("addPercentBarList", "heading", heading, 8);
  items.forEach((item, index) => {
    assertWordCap("addPercentBarList", `item ${index + 1} label`, item.label, 7);
  });
  let cursorY = y;
  if (heading) {
    slide.addText(heading, {
      x, y: cursorY, w, h: 0.4, fontSize: 12, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
    });
    cursorY += 0.45;
  }
  const rowH = (h - (heading ? 0.45 : 0)) / items.length;
  if (rowH < 0.34) {
    throw new Error(`addPercentBarList: each row would be ${rowH.toFixed(2)}in tall. Increase h, reduce items, or split the slide.`);
  }
  items.forEach((item, i) => {
    const rowY = cursorY + i * rowH;
    const labelH = rowH * 0.4;
    slide.addText(item.label, {
      x, y: rowY, w, h: labelH, fontSize: 11, fontFace: FONT_B, color: C.ink2, valign: "bottom", margin: 0,
    });
    const barY = rowY + labelH + 0.04;
    const barH = rowH - labelH - 0.1;
    const fillW = Math.max(0.15, (w - 0.5) * (item.value / max));
    const fillColor = item.color || C.blue;
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y: barY, w: fillW, h: barH, fill: { color: fillColor }, line: { type: "none" },
    });
    const insideLabel = fillW > 1.0;
    slide.addText(`${item.value}%`, {
      x: insideLabel ? x + fillW - 0.55 : x + fillW + 0.06,
      y: barY, w: 0.5, h: barH,
      fontSize: 10.5, fontFace: FONT_B, color: insideLabel ? "FFFFFF" : C.ink2,
      bold: insideLabel, valign: "middle", align: insideLabel ? "right" : "left", margin: 0,
    });
  });
}

/**
 * Hand-drawn comparison matrix — a grouped left category column (values
 * spanning multiple rows are only printed once, vertically centered across
 * their row span) + a wide "description" column + N indicator columns using
 * colored dots (e.g. High/Medium/blank). Built from shapes/text rather than
 * addTable(), since PptxGenJS's native table has weak multi-row-merge
 * support for this pattern. Matches
 * ppt_golden_set/template_2/selected/p10_comparison-matrix.png.
 *
 * @param {object} opts
 * @param {Array}  opts.groups   [{ label, rows: [{ subLabel, desc, marks: ["high","medium",null,...] }] }]
 * @param {Array}  opts.indicatorCols  column headers for the indicator section, e.g. ["Metric A","Metric B","Metric C"]
 * @param {string} [opts.descColHeading]
 */
function addComparisonMatrix(slide, { x = MX, y = 1.4, w = PAGE_W - MX * 2, h = 3.7, groups, indicatorCols, descColHeading = "Detail", segColHeading = "Segment", tacticColHeading = "Tactic" }) {
  assertItems("addComparisonMatrix", groups, 1, 4, "groups");
  assertItems("addComparisonMatrix", indicatorCols, 1, 5, "indicatorCols");
  const flatRows = groups.flatMap((group) => group.rows || []);
  assertItems("addComparisonMatrix", flatRows, 1, 8, "data rows");
  flatRows.forEach((row, index) => {
    if (!Array.isArray(row.marks) || row.marks.length !== indicatorCols.length) {
      throw new Error(`addComparisonMatrix: row ${index + 1} has ${row.marks?.length ?? 0} marks for ${indicatorCols.length} indicator columns.`);
    }
  });
  const groupColW = 0.4;
  const subColW = 1.5;
  const indicatorTotalW = 2.7;
  const descColW = w - groupColW - subColW - indicatorTotalW;
  const indicatorColW = indicatorTotalW / indicatorCols.length;

  const headerH = 0.5;
  const rowHeights = allocateHeights(
    "addComparisonMatrix",
    flatRows.map((row) => Math.max(
      0.38,
      estimateTextHeight(row.subLabel, subColW - 0.16, 10.5, 1.0) + 0.08,
      estimateTextHeight(row.desc, descColW - 0.2, 9.5, 1.0) + 0.08
    )),
    h - headerH,
    0
  );

  // Header row — the group-label and sub-label columns previously had no
  // header cell at all (only the desc + indicator columns did), leaving a
  // blank gap at the top-left that broke the header row's grid discipline
  // against the rest of the table (round-12 finding: circled by the user as
  // a missing/incomplete cell). Give them a real (if minimal) header too.
  slide.addShape(pres.shapes.RECTANGLE, {
    x, y, w: groupColW + subColW, h: headerH, fill: { color: C.navy }, line: { color: C.lineDark, width: 0.5 },
  });
  slide.addText(tacticColHeading, {
    x: x + groupColW + 0.12, y, w: subColW - 0.24, h: headerH,
    fontSize: 9.5, fontFace: FONT_H, color: "FFFFFF", bold: true, valign: "middle", margin: 0,
  });
  slide.addShape(pres.shapes.RECTANGLE, {
    x: x + groupColW + subColW, y, w: descColW, h: headerH, fill: { color: C.blue }, line: { color: C.lineDark, width: 0.5 },
  });
  slide.addText(descColHeading, {
    x: x + groupColW + subColW + 0.1, y, w: descColW - 0.2, h: headerH,
    fontSize: 12, fontFace: FONT_H, color: "FFFFFF", bold: true, valign: "middle", margin: 0,
  });
  indicatorCols.forEach((label, i) => {
    const ix = x + groupColW + subColW + descColW + i * indicatorColW;
    slide.addShape(pres.shapes.RECTANGLE, {
      x: ix, y, w: indicatorColW, h: headerH, fill: { color: C.blue }, line: { color: C.lineDark, width: 0.5 },
    });
    slide.addText(label, {
      x: ix + 0.05, y, w: indicatorColW - 0.1, h: headerH,
      fontSize: 9.5, fontFace: FONT_H, color: "FFFFFF", bold: true, align: "center", valign: "middle", margin: 0,
    });
  });

  let rowCursor = y + headerH;
  let rowIndex = 0;
  groups.forEach((group) => {
    const groupRowHeights = rowHeights.slice(rowIndex, rowIndex + group.rows.length);
    const groupH = groupRowHeights.reduce((sum, rowH) => sum + rowH, 0);
    const groupY = rowCursor;
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y: groupY, w: groupColW, h: groupH, fill: { color: C.paper }, line: { color: C.lineDark, width: 0.5 },
    });
    // Internal row dividers within this merged group-label cell — without
    // these, every OTHER column shows a bordered cell per row but this one
    // shows a single undivided block, which reads as a missing/incomplete
    // cell against the rest of the table's grid (round-11 finding).
    let dividerY = groupY;
    for (let ri = 1; ri < group.rows.length; ri++) {
      dividerY += groupRowHeights[ri - 1];
      slide.addShape(pres.shapes.LINE, {
        x, y: dividerY, w: groupColW, h: 0,
        line: { color: C.line, width: 0.5 },
      });
    }
    // Rotated text: PptxGenJS wraps on the box's un-rotated `w`, so passing
    // the narrow column width there (as earlier rounds did) forces a label
    // like "Mid-market" into an ugly 3-line hyphenated wrap. The fix is to
    // build the box pre-rotation with `w`/`h` swapped (w = the long/vertical
    // run, h = the column's actual thickness) around the same visual center,
    // then let `rotate: 270` reorient it — so the label gets its full
    // available length to wrap against, not the column's narrow width.
    const glThickness = groupColW - 0.06;
    const glRun = groupH - 0.12;
    const gcx = x + groupColW / 2;
    const gcy = groupY + groupH / 2;
    slide.addText(group.label, {
      x: gcx - glRun / 2, y: gcy - glThickness / 2, w: glRun, h: glThickness,
      fontSize: 9, fontFace: FONT_H, color: C.ink, bold: true, valign: "middle", align: "center",
      rotate: 270, margin: 0,
    });

    group.rows.forEach((row) => {
      const rowH = rowHeights[rowIndex];
      const ry = rowCursor;
      slide.addShape(pres.shapes.RECTANGLE, {
        x: x + groupColW, y: ry, w: subColW, h: rowH, fill: { color: C.paper }, line: { color: C.lineDark, width: 0.5 },
      });
      slide.addText(row.subLabel, {
        x: x + groupColW + 0.12, y: ry, w: subColW - 0.24, h: rowH,
        fontSize: 10.5, fontFace: FONT_H, color: C.ink, bold: true, valign: "middle", margin: 0,
      });

      slide.addShape(pres.shapes.RECTANGLE, {
        x: x + groupColW + subColW, y: ry, w: descColW, h: rowH, fill: { color: C.paper }, line: { color: C.lineDark, width: 0.5 },
      });
      slide.addText(row.desc, {
        x: x + groupColW + subColW + 0.1, y: ry, w: descColW - 0.2, h: rowH,
        fontSize: 9.5, fontFace: FONT_B, color: C.ink2, valign: "middle", margin: 0, lineSpacingMultiple: 1.0,
      });

      row.marks.forEach((mark, i) => {
        const ix = x + groupColW + subColW + descColW + i * indicatorColW;
        slide.addShape(pres.shapes.RECTANGLE, {
          x: ix, y: ry, w: indicatorColW, h: rowH, fill: { color: C.paper }, line: { color: C.lineDark, width: 0.5 },
        });
        if (mark) {
          const dotColor = mark === "high" ? C.blue : C.blueLight;
          const dotSize = 0.16;
          slide.addShape(pres.shapes.OVAL, {
            x: ix + indicatorColW / 2 - dotSize / 2, y: ry + rowH / 2 - dotSize / 2,
            w: dotSize, h: dotSize, fill: { color: dotColor }, line: { type: "none" },
          });
        }
      });

      rowCursor += rowH;
      rowIndex += 1;
    });
  });
}

/**
 * Closing — dramatic dark statement slide. Two-tone bold headline (first
 * line white, second line accent blue), optional wordmark, optional row of
 * contact/social lines. No real image asset available (brand-neutral skill),
 * so a subtle abstract line+node accent stands in for the golden reference's
 * lit-glass/geometric photo treatment — same device as addCoverSlide, kept
 * deliberately non-representational (earlier rounds used a large triangle
 * accent here that, on user review, read as directly mimicking the source
 * deck's actual company-logo shape; replaced entirely, see addBrandMark).
 * Matches ppt_golden_set/template_2/selected/p34_closing.png.
 */
function addClosingSlide({ line1, line2, brandName = "", contacts = [] }) {
  const s = pres.addSlide();
  s.background = { color: C.navy };

  const lineColor = "1C3B57";
  const nodeColor = "2E4A63";
  for (let i = 0; i < 5; i++) {
    const x0 = PAGE_W - 3.2 + i * 0.45;
    s.addShape(pres.shapes.LINE, {
      x: x0, y: 0, w: 1.3 - i * 0.1, h: 2.0 + i * 0.1,
      line: { color: lineColor, width: 0.75 },
    });
  }
  [[PAGE_W - 1.5, 0.45], [PAGE_W - 2.2, 1.15], [PAGE_W - 1.0, 1.7]].forEach(([nx, ny]) => {
    s.addShape(pres.shapes.OVAL, {
      x: nx, y: ny, w: 0.09, h: 0.09, fill: { color: nodeColor }, line: { type: "none" },
    });
  });

  addBrandMark(s, { x: 1.7, y: 1.55, dark: false, brandName });

  s.addText(
    [
      { text: line1, options: { color: "F3F1EC", breakLine: true } },
      { text: line2, options: { color: C.blue } },
    ],
    {
      x: 1.7, y: 2.0, w: 6.5, h: 1.9,
      fontSize: 38, fontFace: FONT_H, bold: true, margin: 0, lineSpacingMultiple: 1.0,
    }
  );

  if (contacts.length) {
    const colW = 2.0;
    contacts.forEach((c, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 1.7 + col * colW;
      const y = 3.95 + row * 0.42;
      s.addText(c, {
        x, y, w: colW - 0.1, h: 0.32,
        fontSize: 11, fontFace: FONT_B, color: "FFFFFF", valign: "middle", margin: 0,
      });
    });
  }
}

/**
 * Simple cover — a flat color field with just a centered bold title and
 * optional subtitle. No decorative shapes, no photo/scrim, no eyebrow line
 * — for when a plain, quiet opener is wanted instead of addCoverSlide's
 * fuller treatment (line/node accent, eyebrow, lime accent title).
 */
function addSimpleCoverSlide({ title, subtitle }) {
  const s = pres.addSlide();
  s.background = { color: C.navy };
  s.addText(title, {
    x: MX, y: 2.3, w: PAGE_W - MX * 2, h: 1.0,
    fontSize: 36, fontFace: FONT_H, color: "FFFFFF", bold: true, align: "center", valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
  });
  if (subtitle) {
    s.addText(subtitle, {
      x: MX, y: 3.3, w: PAGE_W - MX * 2, h: 0.5,
      fontSize: 14, fontFace: FONT_B, color: "AAB8C9", align: "center", margin: 0,
    });
  }
  return s;
}

/**
 * Simple closing — a flat color field with just a centered bold statement
 * and optional subtitle. No contact/social row, no decorative shapes — for
 * when a plain, quiet closer is wanted instead of addClosingSlide's fuller
 * treatment.
 */
function addSimpleClosingSlide({ title, subtitle }) {
  const s = pres.addSlide();
  s.background = { color: C.navy };
  s.addText(title, {
    x: MX, y: 2.3, w: PAGE_W - MX * 2, h: 1.0,
    fontSize: 36, fontFace: FONT_H, color: "FFFFFF", bold: true, align: "center", valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
  });
  if (subtitle) {
    s.addText(subtitle, {
      x: MX, y: 3.3, w: PAGE_W - MX * 2, h: 0.5,
      fontSize: 14, fontFace: FONT_B, color: "AAB8C9", align: "center", margin: 0,
    });
  }
  return s;
}

/**
 * Four-panel card grid — a dense "dashboard" content slide: 4 equal
 * quadrants, each with a colored header bar (small icon glyph + title) over
 * a soft-surface body. Each panel's body is one of three content shapes:
 *   - { type: "bars", items: [{ label, value, displayValue }] }   compact horizontal metric bars
 *   - { type: "donuts", items: [{ label, segments: [{value,color?}] }] }  paired mini donuts
 *   - { type: "iconlist", items: [{ label, body }], closing }      icon-led text rows + closing line
 * Matches ppt_golden_set/template_2/selected/p7_fourpanel-stat-donut-cards.png.
 *
 * NOTE if passing `note` (a small kicker caption above the grid, e.g. "India
 * Google Play Store Data" in the golden reference): it renders at `y - 0.36`,
 * which must land AFTER the action title's box bottom (title box in
 * addContentSlide ends at y=1.2) — pass `y >= 1.7` when using `note`, or it
 * will overlap the title (round-3 hillclimb finding).
 */
function addFourPanelGrid(slide, panels, { y = 1.55, h = 3.75, note } = {}) {
  if (!Array.isArray(panels) || ![2, 4].includes(panels.length)) {
    throw new Error(`addFourPanelGrid: expected exactly 2 or 4 panels; got ${panels?.length ?? 0}. Split larger dashboards across slides.`);
  }
  if (note && y < 1.7) {
    throw new Error("addFourPanelGrid: y must be at least 1.70in when note is present so the note clears the title.");
  }
  panels.forEach((panel, index) => {
    assertWordCap("addFourPanelGrid", `panel ${index + 1} title`, panel.title, 5);
    if (!["bars", "donuts", "iconlist"].includes(panel.type)) {
      throw new Error(`addFourPanelGrid: panel ${index + 1} has unsupported type "${panel.type}".`);
    }
  });
  const gap = 0.18;
  const colW = (PAGE_W - MX * 2 - gap) / 2;
  const rowCount = panels.length === 2 ? 1 : 2;
  const rowH = (h - gap * (rowCount - 1)) / rowCount;
  const headerH = 0.42;

  panels.forEach((panel, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = MX + col * (colW + gap);
    const py = y + row * (rowH + gap);

    slide.addShape(pres.shapes.RECTANGLE, { x, y: py, w: colW, h: headerH, fill: { color: C.blue }, line: { type: "none" } });
    slide.addText(panel.title, {
      x: x + 0.14, y: py, w: colW - 0.28, h: headerH,
      fontSize: 13, fontFace: FONT_H, color: "FFFFFF", bold: true, valign: "middle", margin: 0,
    });
    const bodyY = py + headerH;
    const bodyH = rowH - headerH;
    slide.addShape(pres.shapes.RECTANGLE, { x, y: bodyY, w: colW, h: bodyH, fill: { color: "F4F1EA" }, line: { type: "none" } });

    if (panel.caption) {
      slide.addText(panel.caption, {
        x: x + 0.16, y: bodyY + 0.08, w: colW - 0.32, h: 0.3,
        fontSize: 10, fontFace: FONT_B, color: C.ink2, margin: 0,
      });
    }
    const contentY = bodyY + (panel.caption ? 0.42 : 0.14);
    const contentH = bodyH - (panel.caption ? 0.5 : 0.22);

    if (panel.type === "bars") {
      assertItems("addFourPanelGrid bars", panel.items, 2, 4);
      const n = panel.items.length;
      const maxVal = Math.max(...panel.items.map((it) => it.value));
      if (!Number.isFinite(maxVal) || maxVal <= 0) {
        throw new Error("addFourPanelGrid bars: values must contain at least one positive number.");
      }
      const rowH = contentH / n;
      const contentX = x + 0.16;
      const contentW = colW - 0.32;
      panel.items.forEach((it, j) => {
        assertWordCap("addFourPanelGrid bars", `item ${j + 1} label`, it.label, 5);
        const rowY = contentY + j * rowH;
        const labelH = Math.min(0.2, rowH * 0.5);
        const trackH = Math.min(0.09, Math.max(0.06, rowH * 0.2));
        const trackY = rowY + labelH + Math.max(0.02, (rowH - labelH - trackH) / 2);
        const ratio = Math.max(0, Math.min(1, Number(it.value) / maxVal));
        slide.addText(it.label, {
          x: contentX, y: rowY, w: contentW * 0.68, h: labelH,
          fontSize: TYPE.caption, fontFace: FONT_B, color: C.ink2, margin: 0, valign: "middle",
        });
        slide.addText(it.displayValue || String(it.value), {
          x: contentX + contentW * 0.68, y: rowY, w: contentW * 0.32, h: labelH,
          fontSize: TYPE.denseBodyLarge, fontFace: FONT_H, color: C.ink, bold: true,
          align: "right", margin: 0, valign: "middle",
        });
        slide.addShape(pres.shapes.RECTANGLE, {
          x: contentX, y: trackY, w: contentW, h: trackH,
          fill: { color: C.blueLight }, line: { type: "none" },
        });
        slide.addShape(pres.shapes.RECTANGLE, {
          x: contentX, y: trackY, w: Math.max(0.08, contentW * ratio), h: trackH,
          fill: { color: it.highlight || j === 0 ? C.blue : C.ink }, line: { type: "none" },
        });
      });
    } else if (panel.type === "donuts") {
      // Sized from contentH (not fixed magic numbers) so this never overflows
      // regardless of grid density/row count — a hardcoded chart size here
      // previously overflowed the slide bottom by design once contentH got
      // smaller than the fixed layout assumed (round-3 finding).
      //
      // Round-12 finding: stacking label text above/inside the donut kept
      // capping its size around ~0.85in, and cramming label+stat text INTO
      // the hole (tried briefly this round) actually overflowed the ring —
      // the real rendered hole is smaller than its nominal `holeSize`
      // fraction suggests. Fix: stop competing for the panel's scarce
      // VERTICAL space entirely. This panel is wide and short, so put the
      // donut and its label/stat side-by-side instead of stacked — the
      // donut can then claim the full contentH, and the text sits in the
      // remaining width where there's plenty of room.
      assertItems("addFourPanelGrid donuts", panel.items, 1, 2);
      const n = panel.items.length;
      const itemW = (colW - 0.32) / n;
      const textW = 0.95;
      const donutSize = Math.min(contentH, itemW - textW - 0.14);
      panel.items.forEach((it, j) => {
        const ix = x + 0.16 + j * itemW;
        const chartX = ix;
        const chartY = contentY + (contentH - donutSize) / 2;
        addConsultingDonutChart(slide, {
          label: it.label,
          segments: it.segments,
          x: chartX,
          y: chartY,
          w: donutSize,
          h: donutSize,
          showPercent: false,
        });
        const textRuns = [{ text: it.label, options: { fontSize: 9, color: C.ink2, breakLine: true } }];
        const legendLines = Array.isArray(it.legend) && it.legend.length === it.segments.length
          ? it.legend
          : it.segments.map((segment) => `${segment.name}: ${segment.value}%`);
        legendLines.forEach((legendLine, legendIndex) => {
          textRuns.push({
            text: legendLine,
            options: {
              fontSize: 9.5,
              bold: legendIndex === 0,
              color: legendIndex === 0 ? C.ink : C.ink2,
              breakLine: legendIndex < legendLines.length - 1,
            },
          });
        });
        slide.addText(textRuns, {
          x: chartX + donutSize + 0.14, y: contentY, w: textW, h: contentH,
          fontFace: FONT_H, valign: "middle", margin: 0, lineSpacingMultiple: 1.1,
        });
      });
    } else if (panel.type === "iconlist") {
      // Single line per item (bold label + inline body, not stacked) — a
      // stacked label-then-2-line-body layout needed ~3 line-heights per
      // item, which didn't fit this panel's content height even at
      // check_deck.py's 8pt floor and silently overlapped adjacent rows
      // (round-3 finding). Keep `label`/`body` short enough to read as one
      // line at this column width (~1.9in) — this is a hard content
      // constraint of this panel type, not just a style preference.
      assertItems("addFourPanelGrid iconlist", panel.items, 2, 4);
      const n = panel.items.length;
      const nRows = Math.ceil(n / 2);
      const closingH = panel.closing ? 0.3 : 0;
      const availableForRows = contentH - closingH;
      const iconFontSize = 9;
      const rowHIcon = availableForRows / nRows;
      const halfW = (colW - 0.32) / 2;
      panel.items.forEach((it, j) => {
        const col2 = j % 2, row2 = Math.floor(j / 2);
        const ix = x + 0.16 + col2 * halfW;
        const iy = contentY + row2 * rowHIcon;
        slide.addText(
          [
            { text: it.label + ": ", options: { bold: true, color: C.ink } },
            { text: it.body, options: { color: C.ink2 } },
          ],
          { x: ix, y: iy, w: halfW - 0.1, h: rowHIcon - 0.04, fontSize: iconFontSize, fontFace: FONT_B, valign: "middle", margin: 0, lineSpacingMultiple: 1.05 }
        );
      });
      if (panel.closing) {
        slide.addText(panel.closing, {
          x: x + 0.16, y: bodyY + bodyH - 0.32, w: colW - 0.32, h: 0.28,
          fontSize: 9, fontFace: FONT_B, color: C.ink2, bold: true, align: "center", margin: 0,
        });
      }
    }
  });

  if (note) {
    slide.addText(note, {
      x: MX, y: y - 0.36, w: PAGE_W - MX * 2, h: 0.28,
      fontSize: 10, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
    });
  }
}

/**
 * Myth-vs-reality table — numbered rows, each with a bold "myth" statement,
 * a "nuanced reality" statement, and a supporting quote in its own column.
 * Matches ppt_golden_set/template_2/selected/p12_two-col-myth-reality.png.
 *
 * @param {Array} rows [{ num, myth, reality, quote, attribution }]
 */
function addMythRealityTable(slide, { mythHeading = "Myth…", realityHeading = "…nuanced reality", rows, y = 1.35, h = 3.85 }) {
  assertItems("addMythRealityTable", rows, 1, 4, "rows");
  rows.forEach((row, index) => {
    assertWordCap("addMythRealityTable", `row ${index + 1} myth`, row.myth, 22);
    assertWordCap("addMythRealityTable", `row ${index + 1} reality`, row.reality, 22);
    assertWordCap("addMythRealityTable", `row ${index + 1} quote`, row.quote, 30);
  });
  const numColW = 0.46;
  const mythColW = 2.7;
  const quoteColW = 3.6;
  const realityColW = PAGE_W - MX * 2 - numColW - mythColW - quoteColW;

  slide.addText(mythHeading, {
    x: MX + numColW, y, w: mythColW, h: 0.3, fontSize: 12, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
  });
  slide.addText(realityHeading, {
    x: MX + numColW + mythColW, y, w: realityColW, h: 0.3, fontSize: 12, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
  });

  const tableTop = y + 0.4;
  const tableH = h - 0.4;
  const rowGap = 0.06;
  const rowHeights = allocateHeights(
    "addMythRealityTable",
    rows.map((row) => Math.max(
      0.55,
      estimateTextHeight(row.myth, mythColW - 0.2, 10.5, 1.05) + 0.12,
      estimateTextHeight(row.reality, realityColW - 0.2, 10.5, 1.05) + 0.12,
      estimateTextHeight(`${row.quote} — ${row.attribution || ""}`, quoteColW - 0.44, 9.5, 1.05) + 0.12
    )),
    tableH,
    rowGap
  );

  let rowCursor = tableTop;
  rows.forEach((row, i) => {
    const rowH = rowHeights[i];
    const ry = rowCursor;
    slide.addShape(pres.shapes.RECTANGLE, {
      x: MX, y: ry, w: PAGE_W - MX * 2, h: rowH, fill: { color: "F4F1EA" }, line: { type: "none" },
    });
    slide.addText(String(row.num), {
      x: MX + 0.16, y: ry, w: numColW - 0.22, h: rowH,
      fontSize: 18, fontFace: FONT_H, color: C.blue, bold: true, valign: "middle", align: "center", margin: 0,
    });
    slide.addText(row.myth, {
      x: MX + numColW + 0.1, y: ry + 0.06, w: mythColW - 0.2, h: rowH - 0.12,
      fontSize: 10.5, fontFace: FONT_H, color: C.ink, bold: true, valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
    });
    slide.addText(row.reality, {
      x: MX + numColW + mythColW + 0.1, y: ry + 0.06, w: realityColW - 0.2, h: rowH - 0.12,
      fontSize: 10.5, fontFace: FONT_B, color: C.ink2, valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
    });
    const qx = MX + numColW + mythColW + realityColW;
    slide.addText(
      [
        { text: row.quote + "  ", options: { color: C.ink2 } },
        { text: row.attribution ? `— ${row.attribution}` : "", options: { color: C.ink, bold: true } },
      ],
      {
        x: qx + 0.34, y: ry + 0.06, w: quoteColW - 0.44, h: rowH - 0.12,
        fontSize: 9.5, fontFace: FONT_B, valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
      }
    );
    rowCursor += rowH + rowGap;
  });
}

/**
 * Icon + bold-lead-in + description, stacked vertically — a recurring
 * "characteristics/benefits list" idiom (icon is a simple outline square
 * placeholder; no icon asset library is available to this brand-neutral
 * skill). Matches the right column of
 * ppt_golden_set/template_2/selected/p18_network-diagram.png and the left
 * column of p19_icon-twocol-comparison.png.
 *
 * @param {Array} items [{ title, body }] — title is the bold lead-in phrase
 */
function addIconBulletRow(slide, { x, y, w, h, items, iconColor = C.blue }) {
  const rowH = h / items.length;
  items.forEach((item, i) => {
    const iy = y + i * rowH;
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y: iy + 0.03, w: 0.3, h: 0.3, fill: { color: iconColor }, line: { type: "none" },
    });
    slide.addText(
      [
        { text: item.title, options: { bold: true, color: C.blue, breakLine: true } },
        { text: item.body, options: { color: C.ink } },
      ],
      {
        x: x + 0.44, y: iy, w: w - 0.44, h: rowH - 0.08,
        fontSize: 11, fontFace: FONT_B, valign: "top", margin: 0, lineSpacingMultiple: 1.1,
      }
    );
  });
}

/**
 * Soft-surface sidebar panel — the recurring beige right-hand column used
 * for either a heading + bullet list, OR a "voice of the industry"-style
 * quote block (pass one or the other, not both). Matches the right column
 * of ppt_golden_set/template_2/selected/{p18_network-diagram,
 * p19_icon-twocol-comparison, p20_multipanel-icon-data}.png — those three
 * golden slides show this is a reusable zone, not a one-off.
 *
 * @param {object} opts
 * @param {string} [opts.heading]
 * @param {Array}  [opts.bullets]   plain bullet strings (heading+bullets mode)
 * @param {Array}  [opts.quotes]    [{ heading, quote, attribution }] (quote mode — can be 1+)
 */
function addSidebarPanel(slide, { x, y, w, h, heading, bullets, quotes }) {
  const hasBullets = Array.isArray(bullets);
  const hasQuotes = Array.isArray(quotes);
  if (hasBullets === hasQuotes) {
    throw new Error("addSidebarPanel: provide exactly one of bullets or quotes.");
  }
  const pad = 0.22;
  const textW = w - pad * 2;
  if (hasBullets) {
    if (!heading) throw new Error("addSidebarPanel: heading is required when bullets are used.");
    assertWordCap("addSidebarPanel", "heading", heading, 6);
    assertItems("addSidebarPanel", bullets, 2, 4, "bullets");
    bullets.forEach((bullet, index) => {
      assertWordCap("addSidebarPanel", `bullet ${index + 1}`, bullet, 12);
    });
    const headingH = Math.max(0.42, estimateTextHeight(heading, textW, TYPE.cardTitle, 1.05) + 0.06);
    const bulletsY = y + 0.2 + headingH + 0.08;
    const bulletsH = h - (bulletsY - y) - 0.2;
    const rowHeights = allocateHeights(
      "addSidebarPanel",
      bullets.map((bullet) => Math.max(
        0.38,
        estimateTextHeight(bullet, textW - 0.18, TYPE.denseBodyLarge, 1.12) + 0.08
      )),
      bulletsH,
      0.04
    );
    slide.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: "F4F1EA" }, line: { type: "none" } });
    slide.addText(heading, {
      x: x + pad, y: y + 0.2, w: textW, h: headingH,
      fontSize: TYPE.cardTitle, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
      lineSpacingMultiple: 1.05, valign: "middle",
    });
    const stack = makeStack(bulletsY, 0.04);
    bullets.forEach((bullet, index) => {
      slide.addText(
        [{ text: bullet, options: { bullet: { code: "2022", indent: 14 } } }],
        {
          x: x + pad, y: stack.place(rowHeights[index]), w: textW, h: rowHeights[index],
          fontSize: TYPE.denseBodyLarge, fontFace: FONT_B, color: C.ink2,
          valign: "middle", margin: 0, lineSpacingMultiple: 1.12,
        }
      );
    });
  } else if (hasQuotes) {
    assertItems("addSidebarPanel", quotes, 1, 2, "quotes");
    quotes.forEach((quote, index) => {
      if (quote.heading) assertWordCap("addSidebarPanel", `quote ${index + 1} heading`, quote.heading, 6);
      assertWordCap("addSidebarPanel", `quote ${index + 1}`, quote.quote, 30);
      if (quote.attribution) assertWordCap("addSidebarPanel", `quote ${index + 1} attribution`, quote.attribution, 8);
    });
    slide.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: "F4F1EA" }, line: { type: "none" } });
    // Round-12 finding: a short quote inside a tall panel (top-anchored via
    // valign:"top") left a large, obviously uneven dead-space gap at the
    // bottom — circled by the user on a slide where this panel ran much
    // taller than its content needed. Centering the quote block vertically
    // within its slot distributes any leftover space evenly instead of
    // dumping it all below.
    const blockH = (h - 0.4) / quotes.length;
    quotes.forEach((q, i) => {
      const qy = y + 0.2 + i * blockH;
      if (q.heading) {
        // h:0.3 (1 line's worth at 12pt) wasn't enough once a narrower
        // sidebar column forced a heading like "Voice of lorem ipsum" to
        // wrap to 2 lines — caught by check_deck.py's text-fit heuristic,
        // not by eye (the render didn't look obviously broken, just tight).
        // 0.5in tolerates 2 lines at this font size with margin to spare.
        slide.addText(q.heading, {
          x: x + pad, y: qy, w: w - pad * 2, h: 0.5,
          fontSize: 12, fontFace: FONT_H, color: C.ink, bold: true, margin: 0, lineSpacingMultiple: 1.05,
        });
      }
      slide.addText(
        [
          { text: q.quote + "  ", options: { color: C.ink2, breakLine: true } },
          { text: q.attribution ? `— ${q.attribution}` : "", options: { color: C.ink, bold: true, align: "right" } },
        ],
        {
          x: x + pad, y: qy + (q.heading ? 0.52 : 0), w: w - pad * 2, h: blockH - (q.heading ? 0.52 : 0) - 0.1,
          fontSize: 10.5, fontFace: FONT_B, valign: "middle", margin: 0, lineSpacingMultiple: 1.15,
        }
      );
    });
  }
}

/**
 * Hub chain diagram — a vertical chain of rounded-square icon nodes
 * connected by a thin line, each with a label to one side (alternating
 * left/right, matching the golden reference's staggered layout). Matches
 * the left column of ppt_golden_set/template_2/selected/p18_network-diagram.png.
 *
 * @param {Array} steps [{ title, body, labelSide: "left"|"right" }]
 */
function addHubChainDiagram(slide, { x, y, w, h, steps }) {
  const nodeSize = 0.62;
  const nodeX = x + w * 0.34;
  const stepH = h / steps.length;

  // Connecting line through node centers.
  const firstCy = y + stepH / 2;
  const lastCy = y + h - stepH / 2;
  slide.addShape(pres.shapes.LINE, {
    x: nodeX + nodeSize / 2, y: firstCy, w: 0, h: lastCy - firstCy,
    line: { color: C.blueLight, width: 3 },
  });

  steps.forEach((step, i) => {
    const cy = y + i * stepH + stepH / 2;
    slide.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: nodeX, y: cy - nodeSize / 2, w: nodeSize, h: nodeSize,
      fill: { color: C.blue }, line: { type: "none" }, rectRadius: 0.08,
    });
    const labelW = nodeX - 0.15 - x;
    if (step.labelSide === "left") {
      slide.addText(
        [
          { text: step.title, options: { bold: true, breakLine: true } },
          { text: step.body, options: {} },
        ],
        {
          x, y: cy - stepH / 2 + 0.05, w: labelW, h: stepH - 0.1,
          fontSize: 11, fontFace: FONT_B, color: C.ink, align: "right", valign: "middle", margin: 0, lineSpacingMultiple: 1.1,
        }
      );
    } else {
      slide.addText(
        [
          { text: step.title, options: { bold: true, breakLine: true } },
          { text: step.body, options: {} },
        ],
        {
          x: nodeX + nodeSize + 0.15, y: cy - stepH / 2 + 0.05, w: w - (nodeX + nodeSize + 0.15 - x), h: stepH - 0.1,
          fontSize: 11, fontFace: FONT_B, color: C.ink, valign: "middle", margin: 0, lineSpacingMultiple: 1.1,
        }
      );
    }
  });
}

/**
 * Segmented horizontal stacked-bar rows — used for "% opinion split" style
 * comparisons across several groups (e.g. maturity/participation views by
 * category). Each row is one fully-stacked 100%-width bar divided into
 * colored segments with inline value labels (label omitted where the
 * segment is too narrow to hold it legibly). Matches the left/main content
 * of ppt_golden_set/template_2/selected/p20_multipanel-icon-data.png.
 *
 * @param {Array} groups [{ label, segments: [{ value, color? }] }] values
 *   within a group's segments should sum to ~100.
 * @param {Array} [legend] [{ label, color }]
 */
function addStackedBarRows(slide, { x, y, w, h, groups, legend }) {
  assertItems("addStackedBarRows", groups, 2, 5, "groups");
  if (legend) assertItems("addStackedBarRows", legend, 2, 5, "legend");
  groups.forEach((group, index) => {
    assertItems("addStackedBarRows", group.segments, 2, 5, `group ${index + 1} segments`);
    const total = group.segments.reduce((sum, segment) => sum + segment.value, 0);
    if (Math.abs(total - 100) > 0.5) {
      throw new Error(`addStackedBarRows: group ${index + 1} totals ${total}; expected 100.`);
    }
  });
  const labelW = 1.1;
  const barX = x + labelW;
  const barW = w - labelW;
  const legendH = legend ? 0.3 : 0;
  const rowGap = 0.35;
  const rowH = (h - legendH - rowGap * (groups.length - 1)) / groups.length;

  groups.forEach((group, gi) => {
    const gy = y + gi * (rowH + rowGap);
    slide.addText(group.label, {
      x, y: gy, w: labelW - 0.1, h: rowH, fontSize: 11, fontFace: FONT_H, color: C.ink, bold: true, valign: "middle", margin: 0,
    });
    const total = group.segments.reduce((sum, sg) => sum + sg.value, 0);
    let cursorX = barX;
    group.segments.forEach((sg) => {
      const segW = Math.max(0.02, (barW * sg.value) / total);
      slide.addShape(pres.shapes.RECTANGLE, {
        x: cursorX, y: gy, w: segW, h: rowH, fill: { color: sg.color || C.blue }, line: { color: "FFFFFF", width: 1 },
      });
      if (segW > 0.35) {
        // Contrast-aware label color — white reads fine on the dark
        // segments (navy/blue) but was nearly illegible on the light
        // "blueLight" fill (round-6 finding); use dark ink there instead.
        const isLightFill = (sg.color || C.blue) === C.blueLight;
        slide.addText(String(sg.value), {
          x: cursorX, y: gy, w: segW, h: rowH,
          fontSize: 10, fontFace: FONT_B, color: isLightFill ? C.ink : "FFFFFF",
          align: "center", valign: "middle", margin: 0,
        });
      }
      cursorX += segW;
    });
  });

  if (legend) {
    const ly = y + h - legendH;
    const itemW = barW / legend.length;
    legend.forEach((item, i) => {
      const lx = barX + i * itemW;
      slide.addShape(pres.shapes.RECTANGLE, { x: lx, y: ly + 0.04, w: 0.14, h: 0.14, fill: { color: item.color }, line: { type: "none" } });
      slide.addText(item.label, {
        x: lx + 0.2, y: ly, w: itemW - 0.24, h: 0.22, fontSize: 9, fontFace: FONT_B, color: C.ink2, valign: "middle", margin: 0,
      });
    });
  }
}

/**
 * Numbered process cards flowing to a highlighted outcome box — N bordered
 * cards in a row (numbered circle badge + title + body), connected by a
 * light-blue flow bar that runs directly into a dark "outcome" callout box.
 * Matches ppt_golden_set/template_2/selected/p27_numbered-process-cards.png.
 *
 * @param {Array} steps [{ num, title, body }]
 * @param {string} outcome closing callout text
 */
function addNumberedProcessCards(slide, { x = MX, y = 1.6, w = PAGE_W - MX * 2, h = 2.3, steps, outcome }) {
  assertItems("addNumberedProcessCards", steps, 2, 4, "steps");
  steps.forEach((step, index) => {
    assertWordCap("addNumberedProcessCards", `step ${index + 1} title`, step.title, 4);
    assertWordCap("addNumberedProcessCards", `step ${index + 1} body`, step.body, 15);
  });
  assertWordCap("addNumberedProcessCards", "outcome", outcome, 12);
  // Round-11/12/13 findings, all fixed here: (1) a small circle badge with a
  // +/- glyph floated above each card — decorative clutter, removed
  // entirely, plain numeral only; (2) a CHEVRON shape, then a line+arrowhead
  // connector into the outcome box, were both tried and both rejected on
  // review — per explicit round-13 feedback, no arrow glyph of any kind here
  // now; the flow bar just runs straight into the outcome box, which reads
  // as "leads to" without needing an arrowhead; (3) cards were fixed at
  // h=3.3 while their content only needed ~1.6in, leaving a large dead gap
  // at the bottom — default height dropped to fit the actual content.
  const outcomeW = 1.7;
  const gap = 0.18;
  const cardW = (w - outcomeW - gap * steps.length) / steps.length;
  const flowBarY = y + 0.42;
  const flowBarH = 0.3;

  slide.addShape(pres.shapes.RECTANGLE, {
    x, y: flowBarY, w: w - outcomeW, h: flowBarH, fill: { color: C.blueLight }, line: { type: "none" },
  });

  steps.forEach((step, i) => {
    const cx = x + i * (cardW + gap);
    assertTextFits("addNumberedProcessCards", `step ${i + 1} title`, step.title, {
      w: cardW - 0.32, h: 0.5, fontSize: TYPE.cardTitle, lineSpacing: 1.05,
    });
    assertTextFits("addNumberedProcessCards", `step ${i + 1} body`, step.body, {
      w: cardW - 0.32, h: h - 1.14, fontSize: TYPE.denseBody, lineSpacing: 1.1,
    });
    slide.addShape(pres.shapes.RECTANGLE, {
      x: cx, y, w: cardW, h, fill: { color: C.paper }, line: { color: C.line, width: 1 },
    });
    slide.addText(String(i + 1), {
      x: cx + 0.16, y: y + 0.12, w: cardW - 0.32, h: 0.36,
      fontSize: TYPE.denseNumeral, fontFace: FONT_H, color: C.blue, bold: true, margin: 0,
    });
    slide.addText(step.title, {
      x: cx + 0.16, y: y + 0.5, w: cardW - 0.32, h: 0.5,
      fontSize: TYPE.cardTitle, fontFace: FONT_H, color: C.ink, bold: true, margin: 0, lineSpacingMultiple: 1.05,
    });
    slide.addText(step.body, {
      x: cx + 0.16, y: y + 1.02, w: cardW - 0.32, h: h - 1.14,
      fontSize: TYPE.denseBody, fontFace: FONT_B, color: C.ink2, valign: "top", margin: 0, lineSpacingMultiple: 1.1,
    });
  });

  const outcomeX = x + w - outcomeW;
  slide.addShape(pres.shapes.RECTANGLE, {
    x: outcomeX, y, w: outcomeW, h, fill: { color: C.navy }, line: { type: "none" },
  });
  slide.addText(outcome, {
    x: outcomeX + 0.14, y, w: outcomeW - 0.28, h,
    fontSize: 12, fontFace: FONT_H, color: "FFFFFF", bold: true, align: "center", valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
  });
}

/**
 * Stacked soft-surface icon cards — a small column of 1-2 cards, each with
 * an icon-square placeholder, bold title, and description. Matches the
 * "Emerging products" column of
 * ppt_golden_set/template_2/selected/p31_barchart-icon-quote.png.
 *
 * @param {Array} cards [{ title, body }]
 */
function addIconCardStack(slide, { x, y, w, h, heading, cards }) {
  assertItems("addIconCardStack", cards, 1, 3, "cards");
  cards.forEach((card, index) => {
    assertWordCap("addIconCardStack", `card ${index + 1} title`, card.title, 3);
    assertWordCap("addIconCardStack", `card ${index + 1} body`, card.body, 16);
  });
  if (heading) {
    slide.addText(heading, {
      x, y, w, h: 0.3, fontSize: 12, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
    });
  }
  const top = y + (heading ? 0.4 : 0);
  const gap = 0.16;
  const availableH = h - (heading ? 0.4 : 0);
  const cardHeights = allocateHeights(
    "addIconCardStack",
    cards.map((card) => Math.max(
      0.58,
      estimateTextHeight(`${card.title}\n${card.body}`, w - 0.36, TYPE.denseBody, 1.1) + 0.16
    )),
    availableH,
    gap
  );
  let cursorY = top;
  cards.forEach((card, i) => {
    const cardH = cardHeights[i];
    const cy = cursorY;
    slide.addShape(pres.shapes.RECTANGLE, { x, y: cy, w, h: cardH, fill: { color: "F4F1EA" }, line: { type: "none" } });
    // Round-12 finding: a bare filled color square with no glyph inside it
    // stopped looking "broken" (round-11's fix) but still read as decorative
    // clutter with no purpose. A thin accent bar on the card's leading edge
    // is a standard, unambiguously-intentional card treatment instead of a
    // shape pretending to be an icon it isn't.
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y: cy, w: 0.06, h: cardH, fill: { color: C.blue }, line: { type: "none" },
    });
    slide.addText(
      [
        { text: card.title, options: { bold: true, color: C.ink, breakLine: true } },
        { text: card.body, options: { color: C.ink2 } },
      ],
      {
        x: x + 0.2, y: cy, w: w - 0.36, h: cardH,
        fontSize: TYPE.denseBody, fontFace: FONT_B, valign: "middle", margin: 0, lineSpacingMultiple: 1.1,
      }
    );
    cursorY += cardH + gap;
  });
}

/**
 * Value-chain flow — a horizontal sequence of nodes (boxes, optionally split
 * into labeled sub-rows, or a single circular "hub" node) connected by
 * dashed arrows carrying an optional oval percentage badge. Matches the
 * left/main content of
 * ppt_golden_set/template_2/selected/p24_valuechain-flow-quote.png.
 *
 * @param {Array} nodes [{ shape: "box"|"circle", title, sub?: string[], badge?: string }]
 *   `badge`, if present, labels the connector INTO this node (ignored for
 *   the first node, which has no incoming connector). With the usual 5-node
 *   chain, each box is only ~0.6in wide — keep `title` to one short word
 *   (~7 characters or fewer); a single long word (e.g. "Onboarding") has no
 *   space to wrap at and will hyphenate mid-word rather than fit, even at
 *   small font sizes (round-9 finding — fixed by shortening the word, not
 *   by shrinking the font further toward check_deck.py's 8pt floor).
 */
function addValueChainFlow(slide, { x, y, w, h, nodes }) {
  const gap = 0.55;
  const n = nodes.length;
  const nodeW = (w - gap * (n - 1)) / n;
  const midY = y + h / 2;

  nodes.forEach((node, i) => {
    const nx = x + i * (nodeW + gap);

    if (i > 0) {
      const prevRight = nx - gap;
      slide.addShape(pres.shapes.LINE, {
        x: prevRight, y: midY, w: gap, h: 0,
        line: { color: C.ink3, width: 1, dashType: "dash" },
      });
      if (node.badge) {
        const badgeW = 0.55;
        slide.addShape(pres.shapes.OVAL, {
          x: prevRight + gap / 2 - badgeW / 2, y: midY - 0.16, w: badgeW, h: 0.32,
          fill: { color: C.blue }, line: { type: "none" },
        });
        slide.addText(node.badge, {
          x: prevRight + gap / 2 - badgeW / 2, y: midY - 0.16, w: badgeW, h: 0.32,
          fontSize: 8.5, fontFace: FONT_B, color: "FFFFFF", bold: true, align: "center", valign: "middle", margin: 0,
        });
      }
    }

    if (node.shape === "circle") {
      const size = Math.min(nodeW, h * 0.55);
      slide.addShape(pres.shapes.OVAL, {
        x: nx + (nodeW - size) / 2, y: midY - size / 2, w: size, h: size,
        fill: { color: C.navy }, line: { type: "none" },
      });
      slide.addText(node.title, {
        x: nx + (nodeW - size) / 2, y: midY - size / 2, w: size, h: size,
        fontSize: 11, fontFace: FONT_H, color: "FFFFFF", bold: true, align: "center", valign: "middle", margin: 0, lineSpacingMultiple: 1.0,
      });
    } else {
      const headH = node.sub ? h * 0.26 : h;
      slide.addShape(pres.shapes.RECTANGLE, {
        x: nx, y, w: nodeW, h: headH, fill: { color: node.sub ? "F4F1EA" : C.paper }, line: { color: C.line, width: 1 },
      });
      // Font size is deliberately smaller than most title text in this file
      // (9pt vs. the usual 11-13pt) — with 5 nodes sharing the available
      // width, node boxes are narrow enough that 11pt caused single words
      // like "Onboarding" to hyphenate mid-word rather than wrap cleanly
      // (round-9 finding). Still above check_deck.py's 8pt floor.
      slide.addText(node.title, {
        x: nx + 0.08, y, w: nodeW - 0.16, h: headH,
        fontSize: 9, fontFace: FONT_H, color: C.ink, bold: true, align: "center", valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
      });
      if (node.sub) {
        const subGap = 0.06;
        const subH = (h - headH - subGap * node.sub.length) / node.sub.length;
        node.sub.forEach((label, j) => {
          const sy = y + headH + subGap + j * (subH + subGap);
          slide.addShape(pres.shapes.RECTANGLE, {
            x: nx, y: sy, w: nodeW, h: subH, fill: { color: "F4F1EA" }, line: { color: C.line, width: 0.75, dashType: "dash" },
          });
          slide.addText(label, {
            x: nx + 0.08, y: sy, w: nodeW - 0.16, h: subH,
            fontSize: 9.5, fontFace: FONT_B, color: C.ink2, align: "center", valign: "middle", margin: 0, lineSpacingMultiple: 1.05,
          });
        });
      }
    }
  });
}

/**
 * Full-width blue banner header — an alternative content-slide shell to
 * addContentSlide, for slides that want a bold colored header band instead
 * of a plain white background + black title. Returns the slide for content
 * (content zone starts below the banner, at y=1.55). Matches
 * ppt_golden_set/template_2/selected/p23_numbered-cards-stat-hexicon.png.
 */
function addBannerHeaderSlide(actionTitle, pageNum) {
  assertWordCap("addBannerHeaderSlide", "actionTitle", actionTitle, 12);
  const s = pres.addSlide();
  s.background = { color: C.paper };
  const bannerH = 1.35;
  s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: PAGE_W, h: bannerH, fill: { color: C.blue }, line: { type: "none" } });
  addBrandMark(s, { x: MX, y: 0.3, dark: false });
  s.addText(actionTitle, {
    x: MX + 0.45, y: 0.25, w: PAGE_W - MX * 2 - 0.45, h: bannerH - 0.4,
    // 24pt = the one content-slide title size across this template — see
    // addContentSlide; check_deck.py flags per-slide drift.
    fontSize: TYPE.contentTitle, fontFace: FONT_H, color: "FFFFFF", bold: true, valign: "middle", margin: 0, lineSpacingMultiple: 1.02,
  });
  addFooter(s, pageNum);
  return s;
}

/**
 * Lettered card list — a vertical stack of full-width bordered rows, each
 * with a lettered badge (in a small bordered square, not a filled circle —
 * distinct from addNumberedProcessCards' style) and body text with inline
 * bold phrases. Matches the left column of
 * ppt_golden_set/template_2/selected/p23_numbered-cards-stat-hexicon.png.
 *
 * @param {Array} rows [{ letter, runs: [{text, bold?}] }] — `runs` lets the
 *   caller bold specific phrases inline, matching the golden reference's
 *   style of bolding the key phrase within each sentence.
 */
function addLetteredCardList(slide, { x = MX, y = 1.55, w = PAGE_W - MX * 2, h = 3.4, rows }) {
  assertItems("addLetteredCardList", rows, 2, 5, "rows");
  const rowTexts = rows.map((row) => (row.runs || []).map((run) => run.text).join(""));
  rowTexts.forEach((text, index) => {
    assertWordCap("addLetteredCardList", `row ${index + 1}`, text, 25);
  });
  const gap = 0.1;
  const rowHeights = allocateHeights(
    "addLetteredCardList",
    rowTexts.map((text) => Math.max(
      0.50,
      estimateTextHeight(text, w - 0.6, TYPE.denseBodyLarge, 1.1) + 0.12
    )),
    h,
    gap
  );
  let cursorY = y;
  rows.forEach((row, i) => {
    const rowH = rowHeights[i];
    const ry = cursorY;
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y: ry + rowH / 2 - 0.22, w: 0.44, h: 0.44, fill: { type: "none" }, line: { color: C.blue, width: 1.25 },
    });
    slide.addText(row.letter, {
      x, y: ry + rowH / 2 - 0.22, w: 0.44, h: 0.44,
      fontSize: 13, fontFace: FONT_H, color: C.blue, bold: true, align: "center", valign: "middle", margin: 0,
    });
    slide.addText(
      row.runs.map((r) => ({ text: r.text, options: { bold: !!r.bold, color: r.bold ? C.blue : C.ink } })),
      {
        x: x + 0.6, y: ry, w: w - 0.6, h: rowH,
        fontSize: TYPE.denseBodyLarge, fontFace: FONT_B, color: C.ink, valign: "middle", margin: 0, lineSpacingMultiple: 1.1,
      }
    );
    if (i < rows.length - 1) {
      slide.addShape(pres.shapes.LINE, {
        x, y: ry + rowH + gap / 2, w, h: 0, line: { color: C.line, width: 0.5 },
      });
    }
    cursorY += rowH + gap;
  });
}

/**
 * Simplified N-part cycle diagram — square "petals" arranged in a 2xN/2
 * grid around a small hollow center hub, standing in for the golden
 * reference's hexagon-wedge diagram (no true hexagon shape is needed to
 * convey "N forces around a shared center"). Originally inlined directly in
 * main() for the banner-header slide; extracted into its own function so
 * it's a real reusable component like everything else in this file, not
 * one-off code a caller would have to copy-paste.
 *
 * @param {Array} labels petal labels — 4 is the tested/expected count (2x2
 *   grid); other counts will need the caller to adjust `petalW`/spacing.
 */
function addCycleDiagram(slide, { cx, cy, labels, petalW = 1.0, petalH = 0.55, petalColor = C.blue }) {
  if (!Array.isArray(labels) || labels.length !== 4) {
    throw new Error(`addCycleDiagram: this 2×2 component requires exactly 4 labels; got ${labels?.length ?? 0}.`);
  }
  // Column dx values must differ by more than petalW (else adjacent petals'
  // text boxes overlap — first attempt used a 0.8in column gap against a
  // 1.15in petal width, a 0.35in overlap check_deck.py correctly caught).
  const dx0 = -(petalW + 0.05), dx1 = 0.1;
  const dy0 = -(petalH + 0.05), dy1 = 0.05;
  const positions = [
    { dx: dx0, dy: dy0 }, { dx: dx1, dy: dy0 },
    { dx: dx0, dy: dy1 }, { dx: dx1, dy: dy1 },
  ];
  labels.forEach((label, i) => {
    const p = positions[i % positions.length];
    slide.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: cx + p.dx, y: cy + p.dy, w: petalW, h: petalH,
      fill: { color: petalColor }, line: { color: "FFFFFF", width: 1.5 }, rectRadius: 0.06,
    });
    slide.addText(label, {
      x: cx + p.dx, y: cy + p.dy, w: petalW, h: petalH,
      fontSize: 10, fontFace: FONT_H, color: "FFFFFF", bold: true, align: "center", valign: "middle", margin: 0,
    });
  });
  const hubSize = 0.4;
  slide.addShape(pres.shapes.OVAL, {
    x: cx - hubSize / 2, y: cy - hubSize / 2, w: hubSize, h: hubSize, fill: { color: "FFFFFF" }, line: { color: petalColor, width: 1.5 },
  });
}

// ─── MAIN — replace with your content ───
async function main() {
  // The value-chain-flow slide is intentionally NOT part of this demo run
  // (round-13: dropped per request) — addValueChainFlow still exists above
  // and is fully reusable; this main() just chooses not to exercise it
  // here. Cover/closing use the simple variants below, not the fuller
  // addCoverSlide/addClosingSlide (also still reusable). All content below
  // is placeholder Lorem Ipsum text — this file is a structural/component
  // reference, not a specific report.

  // Slide 1 — Simple cover
  addSimpleCoverSlide({
    title: "Lorem Ipsum Dolor Sit Amet",
    subtitle: "Consectetur adipiscing elit sed do eiusmod tempor incididunt",
  });

  // Slide 2 — Numbered theme grid divider
  addNumberedThemeGrid({
    titleAccent: "Lorem ipsum introduces 8 elements",
    title: "shaping dolor sit amet consectetur",
    pageNum: 2,
    leftItems: [
      { num: 1, title: "Lorem ipsum dolor", body: "sit amet consectetur adipiscing elit" },
      { num: 2, title: "Consectetur adipiscing", body: "elit sed do eiusmod tempor incididunt" },
      { num: 3, title: "Tempor incididunt", body: "ut labore et dolore magna aliqua" },
    ],
    spotlight: {
      label: "Focus of this section",
      items: [
        { num: 4, title: "Ut enim ad minim", body: "veniam quis nostrud exercitation" },
        { num: 5, title: "Exercitation ullamco", body: "laboris nisi ut aliquip ex ea" },
      ],
    },
    rightItems: [
      { num: 6, title: "Commodo consequat", body: "duis aute irure dolor in reprehenderit" },
      { num: 7, title: "Voluptate velit esse", body: "cillum dolore eu fugiat nulla pariatur" },
    ],
    banner: { num: 8, title: "Excepteur sint occaecat cupidatat non proident" },
  });

  // Slide 3 — Readable single chart + concise insight sidebar
  const chartSlide = addContentSlide(
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit",
    3,
    { note: "Q — Lorem ipsum dolor sit amet? (Select top 3)  ·  Source: Lorem Ipsum Survey 2026, n=48" }
  );
  addConsultingBarChart(chartSlide, {
    series: [{
      name: "% selecting",
      labels: ["Lorem ipsum", "Dolor sit amet", "Consectetur", "Adipiscing elit", "Sed do eiusmod"],
      values: [72, 58, 41, 33, 33],
    }],
    x: MX,
    y: 1.5,
    w: 6.0,
    h: 3.4,
    unit: "%",
    maxValue: 100,
    showLegend: false,
    options: {
      chartColors: [C.blue],
      catAxisLabelFontSize: TYPE.denseBodyLarge,
      dataLabelFontSize: TYPE.denseBodyLarge,
    },
  });
  addSidebarPanel(chartSlide, {
    x: 6.8, y: 1.5, w: 2.7, h: 3.4,
    heading: "What the chart means",
    bullets: [
      "The top two responses account for most stated demand.",
      "Lower-ranked needs remain meaningful but are not primary purchase triggers.",
      "Prioritize the first two themes in the next planning cycle.",
    ],
  });

  // Slide 4 — Comparison matrix
  const matrixSlide = addContentSlide("Lorem ipsum tactics work differently across dolor segments", 4);
  addComparisonMatrix(matrixSlide, {
    indicatorCols: ["Lorem Revenue", "Retention", "NPS"],
    descColHeading: "When does it work for the segment?",
    groups: [
      {
        label: "Segment A",
        rows: [
          {
            subLabel: "Lorem ipsum add-ons",
            desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit.",
            marks: ["high", "medium", "high"],
          },
          {
            subLabel: "Dolor sit commits",
            desc: "Consectetur adipiscing elit sed do eiusmod tempor incididunt.",
            marks: ["medium", "high", "medium"],
          },
        ],
      },
      {
        label: "Segment B",
        rows: [
          {
            subLabel: "Consectetur upsell",
            desc: "Ut labore et dolore magna aliqua ut enim ad minim veniam.",
            marks: ["high", "medium", null],
          },
          {
            subLabel: "Adipiscing renewal",
            desc: "Quis nostrud exercitation ullamco laboris nisi ut aliquip.",
            marks: [null, "high", "medium"],
          },
        ],
      },
    ],
  });

  // Slide 5 — Myth vs. reality table
  const mythSlide = addContentSlide("Lorem ipsum vs. dolor sit amet, as shared by consectetur", 5);
  addMythRealityTable(mythSlide, {
    rows: [
      {
        num: 1,
        myth: "Lorem ipsum always grows dolor faster than sit amet.",
        reality: "Only if lorem correlates with value — otherwise dolor gets choppier, not bigger.",
        quote: "We moved to lorem ipsum and our dolor got harder before it got better.",
        attribution: "Lorem, Ipsum Co.",
      },
      {
        num: 2,
        myth: "Customers prefer lorem ipsum dolor.",
        reality: "Buyers want predictability first — hybrid consectetur-plus-adipiscing models win more deals.",
        quote: "Procurement will not sign a contract they cannot forecast against.",
        attribution: "VP Dolor, Sit Amet Inc.",
      },
      {
        num: 3,
        myth: "You need new lorem infrastructure to switch models.",
        reality: "Most teams can pilot on a subset of accounts using their existing stack.",
        quote: "We ran the pilot on 40 accounts before touching the lorem system.",
        attribution: "Head of Ipsum",
      },
      {
        num: 4,
        myth: "Net dolor retention always improves under lorem pricing.",
        reality: "It improves only where expansion is easy to trigger in-product.",
        quote: "Expansion has to be one click, or lorem ipsum just adds friction.",
        attribution: "Co-founder, Dolor Sit",
      },
    ],
  });

  // Slide 6 — Four-panel dashboard
  const dashSlide = addContentSlide(
    "Dolor sit amet platforms have compelling advantages over lorem",
    6,
    { note: "Source: lorem ipsum analytics, 2026" }
  );
  addFourPanelGrid(dashSlide, [
    {
      title: "Faster lorem to value",
      type: "bars",
      items: [
        { label: "Lorem solution", value: 46, displayValue: "46d" },
        { label: "Ipsum platform", value: 12, displayValue: "12d", highlight: true },
      ],
    },
    {
      title: "Higher dolor rate",
      type: "bars",
      items: [
        { label: "Add-on A", value: 61, displayValue: "61%" },
        { label: "Add-on B", value: 44, displayValue: "44%" },
        { label: "Add-on C", value: 22, displayValue: "22%" },
      ],
    },
    {
      title: "Growing trust in lorem data",
      type: "donuts",
      items: [
        {
          label: "Team A",
          segments: [{ name: "Trust", value: 38, color: C.navy }, { name: "Neutral", value: 29, color: C.blueLight }, { name: "Distrust", value: 33, color: C.blue }],
          legend: ["38% trust", "33% distrust"],
        },
        {
          label: "Team B",
          segments: [{ name: "Trust", value: 52, color: C.navy }, { name: "Neutral", value: 26, color: C.blueLight }, { name: "Distrust", value: 22, color: C.blue }],
          legend: ["52% trust", "22% distrust"],
        },
      ],
    },
    {
      title: "Contextual signals lorem captures",
      type: "iconlist",
      items: [
        { label: "Lorem depth", body: "Dolor adoption per seat" },
        { label: "Expansion signals", body: "Teams hitting lorem limits" },
        { label: "Support load", body: "Tickets per lorem account" },
        { label: "Integration count", body: "Tools connected per lorem" },
      ],
      closing: "Further enriched by first-party lorem data",
    },
  ], { y: 1.7, h: 3.6, note: "Lorem ipsum data, 2026" });

  // Slide 7 — Icon two-col comparison + sidebar (3 zones total): "erode"
  // column | gap | "created" column | sidebar. Matches
  // ppt_golden_set/template_2/selected/p19_icon-twocol-comparison.png. No
  // connector glyph between the two columns (round-13: user asked to remove
  // arrows entirely — a blocky CHEVRON, then a thin line+arrowhead were both
  // tried and rejected). The two column headings already state the
  // relationship in words; the gap between columns is plain whitespace.
  const sidebarSlide = addContentSlide("As lorem motions scale, today's dolor will erode", 7);
  const colW = 3.0;
  const leftX = MX;
  const chevronX = leftX + colW;
  const midX = chevronX + 0.35;
  const sidebarX = midX + colW + 0.15;

  sidebarSlide.addText("Dolor that will erode", {
    x: leftX, y: 1.35, w: colW, h: 0.3, fontSize: TYPE.section, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
  });
  addIconBulletRow(sidebarSlide, {
    x: leftX, y: 1.75, w: colW - 0.1, h: 3.0,
    items: [
      { title: "Lorem ipsum dolor", body: "Sit amet consectetur adipiscing elit sed do eiusmod." },
      { title: "Tempor incididunt seats", body: "A lorem won on one product can be served across many." },
      { title: "Speed of lorem ipsum", body: "Integration time keeps shrinking toward zero across the category." },
    ],
  });

  sidebarSlide.addText("New dolor that will be created", {
    x: midX, y: 1.35, w: colW, h: 0.3, fontSize: TYPE.section, fontFace: FONT_H, color: C.blue, bold: true, margin: 0,
  });
  addIconBulletRow(sidebarSlide, {
    x: midX, y: 1.75, w: colW - 0.1, h: 3.0,
    items: [
      { title: "Underlying lorem depth", body: "How well a vendor turns raw dolor into a recommended next action." },
      { title: "Consectetur experience", body: "How well n=1 personalization is delivered at the moment of use." },
      { title: "Value proposition clarity", body: "Economics and packaging become the differentiator, not access." },
    ],
  });

  addSidebarPanel(sidebarSlide, {
    x: sidebarX, y: 1.35, w: PAGE_W - MX - sidebarX, h: 3.4,
    heading: "However, some lorem unknowns remain",
    bullets: [
      "How will dolor be verified across multi-product bundles?",
      "Which vendor owns the lorem relationship at renewal?",
      "What happens to pricing power as switching costs fall?",
    ],
  });

  // Slide 8 — Hub chain diagram + icon bullet row
  const hubSlide = addContentSlide("These lorem integrations are designed to compound value", 8);
  hubSlide.addText("Characteristics of lorem infrastructure:", {
    x: MX, y: 1.15, w: PAGE_W - MX * 2, h: 0.3,
    fontSize: TYPE.section, fontFace: FONT_H, color: C.blue, bold: true, margin: 0,
  });
  addHubChainDiagram(hubSlide, {
    x: MX, y: 1.6, w: 6.4, h: 3.3,
    steps: [
      { title: "Lorem-first design", body: "allowing for rapid integration", labelSide: "left" },
      { title: "Dolor modules", body: "that snap into existing workflows", labelSide: "right" },
      { title: "Ipsum-based billing", body: "that scales cost with adoption", labelSide: "left" },
      { title: "Open sit contracts", body: "for consent-based data sharing", labelSide: "right" },
    ],
  });
  addIconBulletRow(hubSlide, {
    x: MX + 6.6, y: 1.6, w: PAGE_W - MX * 2 - 6.6, h: 3.3,
    items: [
      { title: "Faster onboarding", body: "New accounts activate without a services engagement." },
      { title: "Lower total cost", body: "Fewer point solutions to license and maintain." },
      { title: "Compounding lorem value", body: "Each integration enriches the shared dolor graph." },
    ],
  });

  // Slide 9 — Stacked bar rows + quote sidebar
  const stackSlide = addContentSlide("It's still early — confidence in lorem motions varies by segment", 9);
  const stackMainW = 6.3;
  addStackedBarRows(stackSlide, {
    x: MX, y: 1.6, w: stackMainW - 0.3, h: 3.2,
    groups: [
      { label: "Segment A", segments: [{ value: 30, color: C.navy }, { value: 45, color: C.blue }, { value: 25, color: C.blueLight }] },
      { label: "Segment B", segments: [{ value: 55, color: C.navy }, { value: 30, color: C.blue }, { value: 15, color: C.blueLight }] },
      { label: "Segment C", segments: [{ value: 70, color: C.navy }, { value: 20, color: C.blue }, { value: 10, color: C.blueLight }] },
    ],
    legend: [
      { label: "Confident", color: C.navy },
      { label: "Cautious", color: C.blue },
      { label: "Not ready", color: C.blueLight },
    ],
  });
  addSidebarPanel(stackSlide, {
    x: MX + stackMainW, y: 1.4, w: PAGE_W - MX * 2 - stackMainW, h: 3.2,
    quotes: [
      {
        heading: "Voice of lorem ipsum",
        quote: "Lorem buyers want the option, not the mandate — dolor pricing has to coexist with committed spend for a while yet.",
        attribution: "VP Sales, Dolor Sit Co.",
      },
    ],
  });

  // Slide 10 — Numbered process cards flowing to an outcome
  const processSlide = addContentSlide("...and unlocking better lorem economics along the way", 10);
  addNumberedProcessCards(processSlide, {
    y: 2.1, h: 2.3,
    steps: [
      { title: "Higher lorem revenue", body: "Consectetur add-ons and cross-sell across the account base." },
      { title: "Lower cost of ipsum", body: "Dolor-led growth loops reduce reliance on outbound." },
      { title: "Lower cost of sit", body: "Self-serve setup flows cut implementation time." },
      { title: "Lower support costs", body: "Better in-product guidance reduces ticket volume." },
    ],
    outcome: "Creating a durable path to profitable lorem growth",
  });

  // Slide 11 — Side-by-side comparison charts (the ONLY sanctioned two-chart
  // layout: a direct A-vs-B comparison, half/half, each chart ≥4in wide).
  // The earlier 4-zone version (chart | chart | icon stack | sidebar) crammed
  // both charts to 2.6in — unreadable at slide size (production feedback);
  // one chart per slide is the default, and a comparison pair gets the FULL
  // content width. See design-guide.md § Charts & data.
  const dualBarSlide = addContentSlide("Several lorem opportunities exist to unlock in dolor expansion", 11);
  dualBarSlide.addText("Top 5 lorem levers¹", {
    x: MX, y: 1.3, w: 4.2, h: 0.25, fontSize: 11, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
  });
  addConsultingBarChart(dualBarSlide, {
    series: [{ name: "% selecting", labels: ["Lorem add-ons", "Dolor commit", "Ipsum referral", "Sit bundle", "Amet expansion"], values: [48, 44, 41, 33, 22] }],
    x: MX,
    y: 1.6,
    w: 4.2,
    h: 3.3,
    unit: "%",
    maxValue: 60,
    comparison: true,
    showLegend: false,
    options: { chartColors: [C.blue], valAxisHidden: true, valGridLine: { style: "none" } },
  });
  dualBarSlide.addText("Top 5 lorem blockers²", {
    x: 5.3, y: 1.3, w: 4.2, h: 0.25, fontSize: 11, fontFace: FONT_H, color: C.ink, bold: true, margin: 0,
  });
  addConsultingBarChart(dualBarSlide, {
    series: [{ name: "% selecting", labels: ["Contract lorem", "Champion turnover", "Budget cycles", "Data ipsum", "Legal review"], values: [52, 37, 26, 19, 15] }],
    x: 5.3,
    y: 1.6,
    w: 4.2,
    h: 3.3,
    unit: "%",
    maxValue: 60,
    comparison: true,
    showLegend: false,
    options: { chartColors: [C.blue], valAxisHidden: true, valGridLine: { style: "none" } },
  });

  // Slide 12 — Banner header + lettered card list + stat/cycle sidebar
  const bannerSlide = addBannerHeaderSlide("Mining the hidden value in lorem expansion motions", 12);
  const letterMainW = 6.3;
  addLetteredCardList(bannerSlide, {
    x: MX, y: 1.6, w: letterMainW - 0.3, h: 3.3,
    rows: [
      { letter: "A", runs: [
        { text: "Lorem accounts are under-monetized relative to dolor — " },
        { text: "most contracts still price on sit alone", bold: true },
        { text: "." },
      ] },
      { letter: "B", runs: [
        { text: "However, lorem telemetry is " },
        { text: "rapidly improving", bold: true },
        { text: ", giving dolor teams a reliable basis for ipsum add-ons." },
      ] },
      { letter: "C", runs: [
        { text: "This unlock creates room to " },
        { text: "price and package by outcome", bold: true },
        { text: ", not just by seat count." },
      ] },
      { letter: "D", runs: [
        { text: "Accounts fall into " },
        { text: "3 archetypes", bold: true },
        { text: " of lorem readiness: proven ROI, emerging usage, and dormant seats." },
      ] },
      { letter: "E", runs: [
        { text: "Fully priced, this unlock is worth an estimated " },
        { text: "$8-10M in incremental value", bold: true },
        { text: " by FY28." },
      ] },
    ],
  });
  const statX = MX + letterMainW;
  const statW = PAGE_W - MX * 2 - letterMainW;
  const statStack = makeStack(1.55, 0.20);
  bannerSlide.addText("$8-10M", {
    // 32pt: a hero stat is its own role, clearly ABOVE the 24pt title tier
    // (26pt read as a drifted title, not a stat — weak hierarchy).
    x: statX, y: statStack.place(0.6, 0), w: statW, h: 0.6,
    fontSize: TYPE.heroStat, fontFace: FONT_H, color: C.ink, bold: true, align: "center", margin: 0,
  });
  bannerSlide.addText("Incremental value by FY28", {
    x: statX, y: statStack.place(0.3), w: statW, h: 0.3,
    fontSize: 10.5, fontFace: FONT_B, color: C.ink2, align: "center", margin: 0,
  });
  bannerSlide.addText("Key lorem drivers", {
    x: statX, y: statStack.place(0.3), w: statW, h: 0.3,
    fontSize: TYPE.cardTitle, fontFace: FONT_H, color: C.ink, bold: true, align: "center", margin: 0,
  });
  const cycleTop = statStack.y() + 0.15;
  addCycleDiagram(bannerSlide, {
    cx: statX + statW / 2,
    cy: cycleTop + 0.85,
    labels: ["Lorem", "Ipsum", "Dolor", "Sit"],
  });

  // Slide 13 — Simple closing
  addSimpleClosingSlide({
    title: "Thank You",
    subtitle: "Lorem ipsum dolor sit amet consectetur adipiscing elit",
  });

  const outPath = path.join(__dirname, "output.pptx");
  await pres.writeFile({ fileName: outPath });
  console.log("Saved: " + outPath);
}

main().catch((err) => {
  console.error("Error:", err);
  process.exit(1);
});
