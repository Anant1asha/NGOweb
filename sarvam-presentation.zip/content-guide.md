# Content Guide

Rules for *what a deck says and how it's sequenced* — the message, the story, and
the integrity of the data. For how it *looks* (palette, type, layout), see
[design-guide.md](design-guide.md). Apply both to every deck.

## Contents
- Build one narrative, not N independent slides
- No information overload
- Message-first, concise headings
- Anti-slop rules (kill the AI tells)
- Data integrity: units, legends, labels, sources
- Citations and references (placement)
- Write for humans
- Deck-type nuances

## Build one narrative, not N independent slides
A deck is a single argument delivered in sequence, not a pile of standalone
slides. Before building, choose a spine and make every slide advance it:
- **Pitch:** Problem → Why now → Solution → Proof/traction → Market → Model → Team → Ask.
- **Consulting (SCR):** Situation → Complication → Resolution.
- **Recommendation:** Context → Insight → Recommendation → Plan.

Then:
- **Write the outline first, before any code**: the full list of slide titles,
  in order. Check it opens by setting the stakes (context/problem — why anyone
  should care) and closes with the so-what (recommendation, ask, or next
  steps) — a deck that starts on content and stops after the last data slide
  has no narrative, only slides.
- **Outline test:** read the title list top to bottom — it should read as a
  coherent table of contents for one argument, with claim titles at the points
  where the argument turns. If the titles read as disconnected topics with no
  progression, reorder or cut slides until they connect.
- Each slide has **one takeaway**, and its takeaway should set up the next slide.
- **Lead with the point** (BLUF) — put the conclusion first, support after.
- Group related slides into sections; use a divider slide to open each section and
  end it on the "so what" that motivates the next.
- Never fill a template's `main()` slide-for-slide without deciding this spine
  first — the sequence and the dependencies between slides are the deck.

## No information overload

A slide is the argument's unit, not a storage format. Select for the argument —
never narrate everything the research produced:
- **One idea per slide**, expressed in at most ~2 content blocks plus 1 visual
  (a chart, a card row, a table). If a slide wants more, split it into two
  slides or move the detail to an appendix slide after the close.
- If a bullet list runs past ~5 items, the slide is doing a section's job —
  promote it to a section with a divider, or cut.
- Detail that supports but doesn't advance the argument (methodology, full
  data tables, edge cases) goes to appendix slides, referenced from the main
  flow, not crammed into it.

## Message-first, concise headings
- **Default: a short 3–6 word heading naming the slide's subject** — "Timeline",
  "Rollout plan", "Unit economics", "The ask". Short headings keep slides clean
  and scannable.
- **Use a one-line claim only when the slide argues a point** ("The EV market
  grew 5x since 2020" for a market-growth argument; "Onboarding is the churn
  lever" for a recommendation). A claim title is a deliberate upgrade for the
  slides where the argument turns — not the default for every slide.
- **A title never enumerates the slide's content.** "Beta in July, release
  candidate in August, GA in September" is the slide body compressed into the
  title — the title is "Timeline" and the dates live in the body. If a title
  repeats items, dates, or numbers that also appear on the slide, replace it
  with the short label.
- **One line, hard cap ~8 words.** Trim by deleting qualifiers, not by
  shrinking the font.
- **One message per slide.** If a slide needs two titles, it's two slides.
- The title must not restate the first bullet — if it does, one of them is
  redundant; keep the stronger and replace the other.

## Anti-slop rules (kill the AI tells)

AI-drafted copy fails review for predictable reasons. These are hard rules,
checked at content QA:

- **Banned words** — empty intensifiers that carry no information. Cut them
  or replace with the specific fact they gesture at: *leverage, delve,
  robust, seamless, holistic, cutting-edge, state-of-the-art, world-class,
  best-in-class, next-generation, transformative, game-changing, unlock,
  empower, elevate, supercharge, streamline, revolutionize, innovative
  solutions, synergy*.
- **Banned constructions**:
  - Throat-clearing openers: "In today's fast-paced / rapidly-evolving X…",
    "Now more than ever…", "As we move into…".
  - The contrast crutch: "It's not just X, it's Y" / "X isn't just about Y".
  - Rhetorical questions as titles ("What does this mean for us?").
  - Bold-fragment triads: "**Fast** — … **Reliable** — … **Secure** — …".
- **The competitor test**: if a sentence still works with your subject swapped
  for a competitor's ("We deliver innovative solutions at scale"), it says
  nothing — replace it with a claim only this deck could make.
- **No symmetric filler bullets.** Three bullets of identical grammatical
  shape that each say nothing ("Enhanced performance / Improved reliability /
  Increased efficiency") is the most recognizable slop tell. Parallel
  structure is good; parallel *emptiness* is not — each bullet must carry a
  distinct, concrete fact.
- **Concrete or cut**: every claim carries a number, a name, or a date.
  "Significant growth" → "+38% YoY". "Multiple enterprise customers" →
  "11 enterprise customers, incl. HDFC and Airtel". A slide with zero
  numbers or named entities is usually a slide with no content.

## Data integrity: units, legends, labels, sources
Any chart, graph, table, or standalone number must be self-explanatory:
- **Charts/graphs:** a title that states the takeaway; **axes labeled with units**
  (`$M`, `%`, `users`, `days`); a **legend whenever there's more than one series
  or category**; data labels or a legible axis scale so values are readable at
  slide size; consistent number formatting across the chart.
- **Numbers (in charts or text):** always carry a **unit and scale** (`%`, `$`,
  `k`/`M`/`B`); state the **basis/timeframe** (`+32% YoY`, `as of Q2 2026`); round
  sensibly and keep precision consistent across the whole deck.
- **Source every non-obvious figure** — a short, muted source line on the slide
  (`Source: internal analytics, 2026`) and/or a citation marker to the References
  slide (below).
- Open the primary source for quantitative/current claims. A search-result
  snippet or aggregator is not evidence. Keep the exact URL in
  `deck-plan.json`; do not turn an unverified snippet into a fact.
- A part-to-whole chart must total 100% (within rounding). If ranked market-share
  data omits vendors, show the explicit remainder (`Other: 14.6%`) or label the
  basis as “selected vendors”; never imply the displayed rows are the full
  market.
- Do not mix currencies, fiscal/calendar periods, reported/constant-currency
  growth, users/subscribers, or run-rate/recognized revenue without an explicit
  bridge or basis label.
- Scores, colored dots, and high/medium/low matrices require a text legend and
  sourced criteria; color alone is not an explanation.
- Never manufacture a DCF, “fair” multiple, price target, or bull/base/bear
  range. Include methodology plus explicit assumptions, or omit the claim.
- Do not invent a studio, analyst, author, or wordmark. Branding appears only
  when supplied by the user.
- Don't chart what a sentence says better; don't show an axis or legend too small
  to read at slide size.

## Citations and references (placement)
- Put all full citations on a dedicated **"References" / "Sources" slide placed
  SECOND-TO-LAST — immediately before the closing/thank-you slide.**
- **Never put references on the closing slide.** The closing is CTA / thanks /
  contact only; a reference dump there buries them and weakens the close.
- On content slides, mark cited claims with compact markers (`¹`, `²`, or `[1]`)
  and list the full sources in matching order on the References slide.

## Write for humans
- Plain language, short sentences, **active voice**, one idea per bullet.
- **Expand acronyms on first use**; drop jargon the audience won't share.
- **Parallel structure** in a list (all fragments, or all full sentences).
- Bullets are fragments, not paragraphs — if a bullet runs 3+ lines, split it or
  move detail to speaker notes.
- Cut filler ("in order to" → "to"); prefer concrete nouns and verbs.
- Target: a reader gets each slide's point in ~3 seconds from the title plus one
  glance at the visual.

## Deck-type nuances

Apply on top of everything above, by deck type:

- **Board / exec review** — the decision needed appears on slide 2 at the
  latest, stated as a question with a recommended answer. Every later slide
  either supports that recommendation or gets cut. End with the explicit ask
  (amount, approval, date).
- **Pitch** — traction before mechanism: what happened (revenue, users,
  logos, growth) earns the right to explain how it works. Claims about the
  future are labeled as projections with their basis.
- **Consulting / strategy** — every slide title passes the "so what" test:
  it states an implication, not an observation ("Churn concentrates in month
  2, so onboarding is the lever" — not "Churn analysis"). Frameworks (2x2s,
  funnels) appear only when the data actually fits them.
- **Finance review** — neutral register: no hype adjectives within a sentence
  of a number ("strong growth of 12%" → "12% growth, vs. 9% plan"). Every
  variance vs. plan/prior period gets one line of explanation. Rounding and
  precision are uniform across all slides (don't mix "₹4.2 Cr" and
  "₹41,800,000").
