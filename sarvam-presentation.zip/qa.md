# Layout QA for generated .pptx decks

Every generated deck passes **deterministic geometry QA** (`check_deck.py`) plus
a **content check** before delivery. The geometry check is the source of truth:
measure, don't eyeball. Across this skill's own template development, a quick
visual pass repeatedly waved through real, measurable defects — uneven font
sizes across visually-parallel elements, a numbered badge flush against its
row's edge, native-table columns that don't tile their frame — because it
pattern-matches "looks roughly right" instead of measuring. Coordinates do not
forgive.

## No visual QA — do not render slides to images

Do **NOT** render the deck to images for QA: no PPTX→PDF→PNG conversion, no
image-description / vision tools, no PIL/pixel analysis, no "quick visual
check". This is a hard rule, not a missing step. In production this path
breaks (artifact-store mismatches), burns many tool rounds on conversion
plumbing, and vision models **hallucinate slide content** that then has to be
refuted. `check_deck.py` reads exact coordinates from the file itself and
`markitdown` extracts the actual text — together they are the *complete* QA.
When both pass, the deck is done; deliver it.

## Contents

- The gate: `run_qa.py` (one invocation)
- Deterministic checks (`check_deck.py`)
- Content QA
- Required workflow (one build → one gate → ship)
- Known false-positive classes and how they were calibrated out

## The gate: `run_qa.py` (one invocation)

```bash
python scripts/run_qa.py output.pptx --plan deck-plan.json
```

One command runs the geometry check (`check_deck.py`) plus the plan-contract
check and prints one consolidated report. `--plan` is mandatory for new decks:
it catches wrong slide counts/titles, accidental worked-example output,
and leftover placeholders. The validated plan separately rejects branding that
was not supplied by the user. Exit `0` = read the extracted text once (content
QA below), then deliver; `1` = fix and re-run once; `2` = unreadable file.

Writing quality is **not** machine-checked: apply
[content-guide.md](content-guide.md) while planning and drafting (action
titles ≤ ~10 words, anti-slop rules, data integrity), and judge the extracted
text against it during the content QA read.

**The FAIL messages are self-sufficient**: each names the slide, the shapes
(with a text snippet so you can find the helper call that created them), and
the exact fix — including the new `y` that clears an overlap. Fix from the
message. Do **not** open the check scripts' source to interpret a failure —
the message is the whole contract.

## Deterministic checks (`check_deck.py`)

```bash
python scripts/check_deck.py output.pptx [--tol 0.05]
```

Parses the deck directly via `python-pptx` (no render needed) and asserts,
per slide:

- **Bounds** — every element stays within the slide's edges.
- **Overlap** — no two text boxes overlap by more than 20% of the smaller
  box's area.
- **Font floor** — no text run below 8pt.
- **Text-fit (heuristic)** — no text box's own content is taller than the box
  itself. Estimates wrapped line count from box width/font size and compares
  to box height, with 15% slack. This is the one class of bug the overlap
  check structurally cannot see: a box that doesn't collide with any
  neighbor but is still too short for its OWN text (e.g. 22pt bold text
  crammed into a 0.28in row). Approximate by nature — see the false-positive
  section below before assuming a flag is wrong.
- **Centering integrity (exact)** — mirrors sarvam-pdf's `check_layout.py`
  title/subtitle and divider/block checks. Any two or more *wide*
  (≥5in) shapes on the same slide with `align: "center"` should share one
  x-center — a title and subtitle stacked with `align: "center"` but
  different `x`/`w` will drift apart, exactly like the 37pt pull-quote bug
  that motivated the PDF version of this check. Unlike the PDF case this is
  **exact, not an estimate**: PowerPoint centers text within its own shape's
  box width, so the shape's bounding-box center *is* the rendered visual
  center whenever center-align is set — no glyph-metric approximation
  needed. Narrow, small widgets (a lettered badge, a table header cell, a
  chart value label) are deliberately excluded — see false-positive section.
- **Native-table column integrity (exact)** — mirrors sarvam-pdf's
  `check_tables.py` "columns tile the table" assertion. For any slide using
  `addTable()` (not this skill's more common hand-drawn tables), the column
  widths must sum to the table frame's own declared width, within tolerance.
  A mismatch means the `colW` array doesn't actually match the table's `w` —
  the same root cause as sarvam-pdf's most common table defect, just ported
  to pptx's very different table model.
- **Container inset** — left-aligned text inside a filled card/panel keeps at
  least 0.12in effective horizontal padding (box offset plus text-frame
  margin). Centered badges and thin value bars are excluded.
- **Chart readability** — consulting decks mark themselves in presentation
  metadata so the gate can require a lone chart to be at least 6.0×2.5in;
  direct two-chart comparisons may use 4.0×2.5in per chart. Compact doughnuts
  are at least 0.85in in both dimensions, with conservative hole sizing.
  Explicit chart-axis/legend/data-label typography stays at 9pt or above.
- **Legend completeness** — native charts with multiple data series must
  contain a legend.
- **Visual-to-visual overlap** — charts, tables, and pictures cannot partially
  collide with another visual. Full containment remains allowed for
  chart-on-panel and image-on-background patterns.
- **Within-slide role consistency** — three or more parallel boxes with the
  same y/width/height/alignment contract use one font size.

Exits `0` (pass), `1` (FAIL, with the exact slide/shape/offset — e.g. `slide
3: 'Text 2' overflows right edge by 0.40in`), or `2` (unreadable file). Fix
and re-run until it exits `0`.

## Content QA

After the gate passes, extract the deck text ONCE and read it for missing
content, typos, wrong order, leftover placeholders — and the
[content-guide.md](content-guide.md) writing rules (titles are one short
claim, no slop phrasing, numbers carry units and basis):

```bash
python -m markitdown output.pptx
```

## Required workflow (one build → one gate → ship)

Get the build right the first time — the component helpers, design-guide, and
content-guide exist so the gate passes on the first run. QA is a safety net,
not an iterative design tool.

```
Deliver-a-deck checklist:
- [ ] 1. Plan: write and validate deck-plan.json (narrative, evidence, units, chart semantics)
- [ ] 2. Build: write only deck-main.js; compose with scripts/compose_deck.py; never inspect template source
- [ ] 3. Gate: python scripts/run_qa.py output.pptx --plan deck-plan.json  (exit 0 required)
- [ ] 4. If it fails: fix deck-main.js FROM THE FAIL MESSAGES (never read the
        check scripts' source; locate helper calls by the text snippets in the
        messages — don't re-read the whole file), re-compose, rebuild, re-run once
- [ ] 5. Content QA: python -m markitdown output.pptx — one read for content + content-guide.md writing rules
- [ ] 6. present_output(artifact_id)
```

If the gate still fails after two fix rounds, the slide layout approach is
wrong — re-stack the failing slide top-to-bottom with explicit gaps instead of
iterating point-fixes (moving one box at a time creates the next overlap).

## Known false-positive classes and how they were calibrated out

Both the text-fit and centering checks were tuned by running them against all
example templates until they passed clean, then confirmed against a synthetic
deck with deliberately-broken geometry to prove they still catch real defects.
Documented here so a future change to these thresholds can be made with the same
rigor, not by guessing:

- **Text-fit**: an early version charged every wrapped line the full
  paragraph-leading multiple (`font-size × 1.2`), which over-counted short
  single-line labels/numerals in `valign: "middle"` boxes — visually fine in
  practice, since a lone line only needs its own glyph height, not the extra
  leading that exists to space stacked lines apart. Fixed by charging leading
  only *between* lines (`n_lines - 1` times), not per line.
- **Centering integrity**: without a width filter, this flagged every
  independently center-aligned small widget on a slide against every other
  one (a lettered badge vs. a chart's value label vs. a table header cell) —
  none of which were ever meant to share a center. `MIN_CENTERED_SHAPE_WIDTH_IN
  = 5.0` (calibrated against real false positives topping out at 3.43in, and
  real title/subtitle-scale boxes in these templates running 6-9in) restricts
  the check to content-column-scale elements — the actual "title vs.
  subtitle" class of bug this check exists for. It also only compares
  centered elements whose x-ranges overlap, so a row of centered captions
  isn't mistaken for a drifting title/subtitle.

- **Text-vs-visual overlap** (three excusable classes, all found against this
  skill's own templates): (1) a connector band drawn BEHIND a row of cards
  "overlaps" every card's text — excused when another visual contains the text
  and is drawn above the overlapped shape (z-order covering-card rule); (2)
  panel labels overshoot their panel edge by ≤ ~0.08in of empty box padding
  while the glyphs stay inside — containment tolerance is 0.10in for this
  reason; (3) rotated row-group labels report a PRE-rotation bbox (w/h
  deliberately swapped), so rotated text is excluded from this check entirely.
- **Role-size consistency**: the first design compared each slide's *largest*
  text against the deck-wide mode, which false-positived on intentional
  per-slide-type variation (the brand template's 30pt quote and 32pt card
  numerals vs its 28pt titles). Recalibrated to group by **position**: only a
  box recurring at the same (x, y) on 3+ slides defines a role, and only
  same-position size drift is flagged — intentional variation almost always
  comes with different positioning, while the production defect (title sizes
  drifting 125→155 in one deck) keeps the title box in one place.
- **Container inset**: centered labels and thin bar-value overlays legitimately
  consume their full shape, so inset checks apply only to left-aligned text in
  container-scale shapes. Effective inset includes PowerPoint text-frame
  margins.
- **Doughnut viability**: a large bold-pitch doughnut can use a wider hole
  safely; the 50% hole cap applies only to compact doughnuts under 1.5in.

If any check ever flags something you're confident is fine, confirm it's a
real false positive, then recalibrate the threshold and record why here, the
same way these were.
