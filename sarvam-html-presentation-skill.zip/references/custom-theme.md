# Synthesizing a custom theme

Use this recipe when the user asks for a look the catalog does not have: a
named aesthetic ("neo-brutalist", "riso zine", "quiet luxury"), a brand
system, a reference deck, site, or screenshot, or a free-text answer to the
template clarification. A bespoke theme is a first-class citizen: it rides
the same substrate, uses the same components, and passes the same validator
as a maintained template.

## What never changes

The core (`assets/deck-core.css` + `deck-core.js`) is embedded verbatim as
always. The skeleton, the component vocabulary in `components.md`, the chart
engine, the sizing model (`--fs`/`--sp`/`--pad` in `cqw`), and
`scripts/validate-deck.py` all apply unchanged. A custom theme is **only**
what a maintained theme is: a token block, a small `t-` component layer, and
a grammar. If you find yourself rewriting core behavior, stop — you are
building slop, not a theme.

## Step 1 — Extract the design decisions

From the user's reference, settle these before writing CSS:

- **Canvas**: paper-light, canvas-dark, or mixed with dark bookends?
- **Type character**: serif or grotesk display? High-contrast editorial or
  uniform utilitarian? Any monospace role?
- **One accent**: the single color that carries focus. Everything else is
  neutrals plus the categorical ramp.
- **Shape**: sharp (0), soft (6–10px), or pill? Border weight: hairline,
  none, or chunky (neo-brutalist)?
- **Decoration vocabulary**: what repeats — rules, frames, offset shadows,
  stamps, grain, geometric marks? Pick at most two devices and use them
  consistently; decoration that appears once looks like an accident.

For a **brand**: brand color becomes `--accent` (or, if too light for text
contrast, `--accent` derives a darker usable variant and the brand hue moves
to `--cat-1`). Never spread the brand color across all series. For a
**screenshot/site**: sample the background, text, and one accent; identify
the display face or its closest Google Fonts equivalent.

## Step 2 — Fill the token contract

Every token below must be defined (the validator fails the deck otherwise):

| tokens | rules |
|---|---|
| `--ink --ink-2 --ink-3` | text hierarchy; `--ink` on `--paper` ≥ 7:1 contrast, `--ink-3` still ≥ 3:1 |
| `--paper --paper-2 --paper-3` | surface, tinted panel, faint panel — same temperature family |
| `--rule --rule-2` | hairline and stronger rule, derived from ink at low opacity or a neutral |
| `--accent --accent-ink --accent-soft` | one focal color; `--accent-ink` is the text color on accent fills; `--accent-soft` a tint usable as a panel background |
| `--signal --ok --warn` | semantic only — negative, positive, caution; may reuse accent hues if honest |
| `--cat-1 … --cat-6` | categorical chart ramp, in usage order: accent-family first, ink second, then distinguishable neutrals/secondaries; no red unless it means negative |
| `--app-bg` | viewer backdrop behind the slides, a shade near the paper family |
| `--font-display --font-body --font-mono` | see Step 3 |
| `--radius` | one value; corners are a system, not a per-component choice |

## Step 3 — Fonts

Two Google Fonts families at most: one display, one body (they may be the
same family at different weights). Mono can stay the system stack
(`ui-monospace,SFMono-Regular,Menlo,monospace`) unless mono *is* the look.
Load 2–4 weights only, via one `<link>` — the deck's single allowed external
request. Always include real fallbacks
(`"Family",Georgia,serif` / `"Family","Helvetica Neue",Arial,sans-serif`).

## Step 4 — The `t-` component layer

Restyle at most **three to six** theme components, sized exclusively with
`calc(var(--fs)*n)` / `calc(var(--sp)*n)` — never `px` type sizes, never
viewport units. If the theme re-declares the base tokens themselves, keep the
autofit multiplier: `--fs:calc(1.3cqw*var(--fit,1))`, never a bare
`--fs:1.3cqw` — a bare override disables the runtime's overflow autofit. The usual set:

1. Title treatment (letter-spacing, weight, an underline or mark device).
2. A dark/inverted slide class for covers and dividers that **re-maps the
   tokens** (see any catalog theme's `t-deep`/`t-navy` block for the pattern).
3. One evidence banner or callout (the theme's voice for "so what").
4. One card (scenario, recommendation, or KPI framing).
5. Optionally: a cover ornament (edge band, frame, masthead) and a footnote
   or tracker device.

Keep the layer under ~100 lines. If the deck needs more than that, you are
fighting the reference — simplify the extraction, not the core.

## Step 5 — Borrow a grammar

Do not invent slide rhythm from scratch. Pick the catalog theme whose
*content shape* is nearest (argument-led → strategy-consulting; chart-led →
consulting-report or insight-deepdive; teaching → education-teaching; metric
update → startup-investor), reuse its slide grammar and deck arc, and re-voice
it in the new skin. Composition discipline (action titles, one idea per
slide, canvas budget, chart-by-question) is identical for every theme,
custom or not.

## Step 6 — Validate and deliver

Run `scripts/validate-deck.py` as always — token completeness, CSS
discipline, and all content lints apply to bespoke themes unchanged. Tell
the user the theme is bespoke and name its reference. If it came out well,
offer to save it as `references/themes/<slug>.md` (frontmatter + token block
+ grammar + two example slides), add an entry to `template-index.json` with
honest `mood`/`tone`/`occasion` tags, and run `scripts/validate-themes.py`
to register it as a maintained template.

## Pitfalls

- Substituting a "close enough" font — typography is most of the look.
- Spreading the accent across every series; the ramp exists so accent can
  mean focus.
- Decorating content slides with the cover's devices; content slides stay
  quiet in every good system.
- Introducing per-slide hex values; if a color is real, it earns a token.
- Building a second component system in deck-specific CSS. The 40-line
  deck-CSS budget still applies.
