# Component and chart vocabulary

Everything below already exists in the embedded core. Compose slides from
these classes; do not invent parallel components. Theme references add a
small `t-`/`e-`/`d-` vocabulary on top — those are defined in the theme CSS
you copy, never improvised.

## Sizing model

Slides are CSS containers. `--fs` (base type size), `--sp` (base spacing),
and `--pad` (slide margin) are set once per slide in `cqw`, so everything
scales with the slide — in the review scroll, in fullscreen present mode,
and in print. Components size themselves with `calc(var(--fs)*n)`. When you
need a size in deck-specific CSS, use the same calc form. Never hardcode
`px` type sizes or use viewport units inside a sheet.

## Text

`.c-eyebrow` (`--rule` `--muted`) kicker line above a title ·
`.c-title` with `--xl` (content slides) `--xxl` (cover) `--sm` ·
`.c-subtitle` · `.c-lede` · `.c-prose` · `.c-section` (+`.c-section__n`) ·
`.c-mark` highlight · `.c-kbd`

## Quotes

`.c-pullquote` (`--accent` `--plain`) with `<p>` + `<cite>` · `.c-blockquote`

## Named boxes

`.c-callout` with `__label` and variants `--insight` `--action` `--caution`
`--method` `--quietbox` `--solid` · `.c-takeaway` (label + one decisive
sentence, use at most once per slide) · `.c-panel` (`--outline` `--card`)
with `.c-panel__label`

## Lists

`.c-list` (`--dot` `--tick` `--cross` `--num` `--rule`) · `.c-checklist`
(+`__meta`) · `.c-deflist` · `.c-chips`/`.c-chip` (`--accent` `--ok` `--warn`)

## Data

- `.c-statrow` (`--bare`, `--cols:n`) of `.c-stat` cells: `__label`,
  `__value` (add `data-count` to animate), `__note`, `.c-delta--up/--down`
- `.c-bignum` one huge number with `<small>` caption — the one-number slide
- `.c-table` (`--booktabs` `--zebra` `--compact` `--matrix` `--lead`
  `--sortable`) with `<caption>`; `th[data-sort]` enables sorting
- `.c-harvey` with `data-v="0..4"` Harvey balls inside matrix tables
- `.c-track` labelled progress bars (`--w` width, `--at` target mark)
- `.c-heatgrid` (`--rows:n`) calendar-style heat grid, cells take `data-tip`
- `.c-waffle` 10×n waffle · `.c-timeline` (`--done`) · `.c-gantt__head/__row`
  (`__bar --muted --risk`) · `.c-matrix2` 2×2 · `.c-metagrid` (`--cols:n`)
- `.c-figure` + `.c-figure__caption` + `.c-source`

## Media

`.c-media` (cover crop) with `--contain` and `--frame` for images inside
columns and panels · `.sheet__bleed` full-bleed image layer with automatic
scrim, covers/dividers only (see `references/image-handling.md`)

## Layout

`.l-cols` grid with `.l-2` `.l-2a` (wide left) `.l-2b` (wide right) `.l-3`
`.l-4` · `.l-stack` vertical rhythm · `.l-fill` consume remaining height ·
`.l-end` push to bottom · `.l-rule` (`--strong` `--accent`) · `.l-flowroot`

## Charts — declarative, no JS to write

```html
<div class="c-chart" data-chart="bars" data-height="260" data-unit="₹ cr"
     data-labels="Q1,Q2,Q3,Q4"
     data-series='[{"name":"Revenue","values":[18.2,21.4,26.0,31.7]}]'
     data-alt="Quarterly revenue rising from 18.2 to 31.7 crore"></div>
```

Types: `bars` `hbars` `stack` `line` `area` `donut` `dot` `scatter` `spark`.

Choose by question, not variety: ranking or long labels → `hbars`; trend
(≥4 points) → `line`/`area`; period or segment comparison (≤6 categories)
→ `bars`; composition of a whole (2–5 segments) → `donut` or `stack` with
`data-pct="true"`; distribution/relationship → `scatter`; estimate with
uncertainty → `dot` with `err:[…]`; tiny inline trend → `spark`.

Attributes: `data-max` `data-ymax` `data-pct="true"` `data-target`
`data-baseline` `data-xlabel` `data-unit` `data-xunit`
`data-value-labels="false"` and **always** `data-alt` (one sentence stating
what the chart shows, with numbers).

`data-height` is in units where 1000 = the slide width, so a chart renders
at the same physical size whether full-bleed or in a third of a column.
230–300 suits a half-width chart; 180–240 suits a wide short one.

Series options: `color` (use `var(--cat-n)` / `var(--accent)`, never hex),
`dash:true` for plan/target lines, `err:[…]` error bars on `dot`,
`square:true`, `colors:[…]` per-bar colours on `hbars`/`donut`,
`points:[[x,y,r,label],…]` on `scatter`.

Interactive add-ons, wired by chart id:

```html
<span class="c-switch" data-switch-for="ex4"></span>   <!-- metric switcher -->
<div  class="c-legend" data-legend-for="ex4"></div>    <!-- toggle series -->
<p class="c-figure__caption" data-caption-for="ex4">…</p>
```

The switcher reads `data-sets` on the chart:

```html
data-sets='{"Gap to plan":{"unit":"£m","series":[…],"caption":"…"},
            "Repricing lag":{"unit":"months","series":[…],"caption":"…"}}'
```

Multi-series charts always get a `c-legend`. Every chart slide names its
unit (in `data-unit`, the caption, or the panel label) and carries a real
source line in the footer.

## Animation

`data-anim` on any element: default rise, or `fade` `rise` `slide` `scale`
`wipe`. Delays stagger automatically in document order; override with
`data-d="300"`. Elements re-reveal per slide in present mode. Numbers with
`data-count="6.4"` (+ `data-prefix` `data-suffix` `data-dec`) count up.

Give every slide 3–6 `data-anim` marks on its major blocks — eyebrow, title,
rule, then each composition region. Do not animate every list item.

Background texture, at most one per sheet and only where the theme uses it:

```html
<div class="k-bgfx k-bgfx--grid" style="color:#fff"></div>
```

`--grid` `--dots` `--orbit` `--glow` `--scan` `--wave` `--rings`. Reserve
these for covers, dividers, and closing slides; content slides stay clean.
