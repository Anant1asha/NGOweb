# Image Handling

Read this file only when the deck uses supplied images.

## Workflow

1. Inspect each image and decide what information it contributes.
2. Map useful images into the slide outline before writing HTML.
3. Keep originals unchanged. Write transformed copies with a `_processed`
   suffix beside the deck file.
4. Use relative paths and descriptive `alt` text.
5. Verify that the image's focal point remains visible in its assigned region.

## Placement

- Logo: an `<img class="c-media c-media--contain">` sized by its container;
  keep it small enough to preserve title hierarchy.
- Screenshot or diagram: put the image in one column of `l-cols l-2a`/`l-2b`
  with `c-media--contain c-media--frame`; caption it with `c-figure__caption`.
- Photography: `c-media` (cover crop) inside a column or panel, only when
  cropping is intentional.
- Full bleed: `<div class="sheet__bleed"><img …></div>` as the first child of
  the sheet — it sits under `sheet__pad` and gets a legibility scrim
  automatically (tune with `--bleed-scrim`). Use on covers and dividers only.

Do not embed large images as base64. Do not repeat the same image on multiple
slides except a consistent logo.

## Processing

Process only when the source is oversized, has the wrong crop, or needs
transparency. Use Pillow when available:

```bash
python3 -m pip install Pillow==12.2.0
```

- Large raster image: resize proportionally to a maximum dimension near
  1600px; do not upscale.
- Wrong aspect ratio: crop deliberately around the subject, not from the
  center by default.
- Circular mark: create an alpha mask and export PNG.
- Screenshot: preserve text sharpness; avoid lossy recompression.

Always save to a new file and reference that new relative path from the deck.
