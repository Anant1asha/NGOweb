# Deck file template

Every deck is ONE self-contained `.html` file assembled in this exact order.
The core CSS and JS are embedded **verbatim, including their sentinel
comments** (`/* ==DECK-CORE-CSS v2== */` … `/* ==END-DECK-CORE-CSS== */` and
`/* ==DECK-CORE-JS v2== */` … `/* ==END-DECK-CORE-JS== */`). The validator
hash-checks both blocks against `assets/`; any edit inside them fails the
deck. Everything you author lives in the theme block and the slide markup.

## Skeleton

```html
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{Deck title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="{Google Fonts URL from the selected theme}" rel="stylesheet">
<style>
{assets/deck-core.css — entire file, verbatim, sentinels included}

/* ---- THEME ---- */
{theme CSS from the selected theme reference, verbatim}

/* ---- DECK-SPECIFIC (optional, keep small) ---- */
{only if this deck needs a component no theme/core class covers}
</style>
</head>
<body>

<div class="k-bar">
  <div class="k-bar__name">{Deck title} <span>{subtitle or client}</span></div>
  <div class="k-seg" role="group" aria-label="Presentation controls">
    <button data-mode-btn="present" aria-pressed="false">Present</button>
  </div>
</div>

<main class="k-stage">
  {slides}
</main>

<div class="k-present-hud" aria-hidden="true">
  <button data-hud="prev" aria-label="Previous slide">←</button>
  <span class="k-pos">1 / 1</span>
  <button data-hud="next" aria-label="Next slide">→</button>
  <button data-hud="exit" aria-label="Exit present mode">Esc</button>
</div>

<style>@page{size:1280px 720px;margin:0}</style>
<script>
{assets/deck-core.js — entire file, verbatim, sentinels included}
</script>
<script>
Doc.init({
  brand:    'Sarvam Co-Work',
  org:      '{presenting organisation}',
  client:   '{audience organisation, if any}',
  docTitle: '{deck title}',
  author:   '{author}',
  date:     '{date}',
  source:   '{real source line for the data}',
  slideFooter: { left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
</script>
</body>
</html>
```

## Slide anatomy

One `<section>` per slide. Nothing else at the top level of `.k-stage`.

```html
<section class="sheet sheet--slide">              <!-- or sheet--invert / sheet--accent -->
  <div class="k-bgfx k-bgfx--grid" style="color:#fff"></div>   <!-- optional, covers/dividers only -->
  <div class="sheet__pad">                        <!-- or sheet__pad--center / --end -->
    <div class="c-eyebrow" data-anim="fade">Section label · context</div>
    <h2 class="c-title c-title--xl" data-anim>Title that states the finding</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    {one composition: l-cols / table / chart / stat row …}
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>
```

- `sheet__pad` is the only content container; `sheet__foot` is the only
  footer. Never position content with fixed pixels or absolute offsets —
  the `--fs`/`--sp`/`--pad` tokens and `l-*` helpers own all geometry.
- Every visible measurement inside a slide derives from `calc(var(--fs)*n)`,
  `calc(var(--sp)*n)`, or `cqw`. Never write `px` font sizes or `vw/vh`
  units inside a sheet.
- `data-foot` renders the configured footer. Override one slide inline:
  `data-l="Exhibit 3" data-c="" data-r=""`. Covers usually blank the right
  slot: `data-r=""`.
- `sheet__pad--center` for covers, dividers, quotes, and one-number slides;
  default (top-aligned) for content slides; use `l-fill` on the main
  composition so it consumes the height between title and footer.
- Use headings in order: the cover carries the only `h1`; content slides
  use `h2`; panel titles inside a slide use `h3` or `b`.

## Behavior you get for free

Do not re-implement any of this: chart rendering and axes, legends
(`data-legend-for`), metric switchers (`data-switch-for` + `data-sets`),
captions that follow the switch (`data-caption-for`), tooltips (`data-tip`),
count-up numbers (`data-count`), sortable tables (`c-table--sortable`),
entrance animation with automatic stagger (`data-anim`), present mode with
keyboard/click/swipe and fullscreen, reduced-motion support, and print
(File → Print gives a 1280×720 landscape PDF).

The runtime also guards the canvas: any slide whose content exceeds the
16:9 stage gets a red "Overflow — split this slide" badge in review mode
(hidden in present and print) and a console warning. Fix an overflowing
slide by splitting it, never by shrinking type or padding.
