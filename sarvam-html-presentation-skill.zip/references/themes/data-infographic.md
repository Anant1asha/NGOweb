---
name: Data Infographic
slug: data-infographic
scheme: mixed
fonts: https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@75..100,400;75..100,500;75..100,600;75..100,700&display=swap
---

# Data Infographic

A broadsheet data section as a deck: Archivo throughout, blue data ink with a strict categorical ramp, masthead instead of hero titles, KPI bands, small multiples, annotated charts, method notes, and sortable ranked tables. Dense but never unlabelled.

**Use for:** Indexes, benchmarks, rankings, operational dashboards, survey summaries, dense quantitative stories needing several coordinated views.
**Avoid for:** Sparse talks, emotional storytelling, evidence too thin to fill coordinated panels.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#101418; --ink-2:#3B444C; --ink-3:#78838C;
  --paper:#FFFFFF; --paper-2:#EFF2F4; --paper-3:#F7F9FA;
  --rule:#DBE0E4; --rule-2:#BFC7CD;
  --accent:#1B6CA8; --accent-ink:#FFFFFF; --accent-soft:#E8F1F8;
  --signal:#D64545; --ok:#1E8A6E; --warn:#D99000;
  --cat-1:#1B6CA8; --cat-2:#1E8A6E; --cat-3:#D99000; --cat-4:#D64545; --cat-5:#7A5AA8; --cat-6:#5C6B75;
  --app-bg:#DDE2E6;
  --font-display:"Archivo","Helvetica Neue",Arial,sans-serif;
  --font-body:"Archivo","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:"Archivo",Arial,sans-serif;
  --radius:5px;
}
.sheet--slide{--fs:calc(1.3cqw*var(--fit,1));--pad:4.2cqw;--sp:calc(1.25cqw*var(--fit,1))}
body{font-variant-numeric:tabular-nums}
.c-title{letter-spacing:-.028em;font-weight:700}
.c-eyebrow{letter-spacing:.16em}
/* masthead */
.d-mast{display:flex;align-items:baseline;gap:calc(var(--sp)*.8);border-bottom:2.5px solid var(--ink);
  padding-bottom:calc(var(--sp)*.6)}
.d-mast b{font-family:var(--font-display);font-weight:700;font-size:calc(var(--fs)*1.2);letter-spacing:-.02em}
.d-mast span{font-size:calc(var(--fs)*.8);color:var(--ink-3)}
.d-mast .r{margin-left:auto;font-size:calc(var(--fs)*.8);color:var(--ink-3);letter-spacing:.06em;text-transform:uppercase}
/* KPI band — the strip that says "fill me with the six numbers that matter" */
.d-band{display:grid;grid-template-columns:repeat(var(--cols,6),1fr);border:1px solid var(--rule);
  border-radius:var(--radius);overflow:hidden;background:var(--paper-3)}
.d-kpi{padding:calc(var(--sp)*.75) calc(var(--sp)*.8);border-right:1px solid var(--rule);min-width:0}
.d-kpi:last-child{border-right:0}
.d-kpi dt{font-weight:600;font-size:calc(var(--fs)*.68);letter-spacing:.09em;text-transform:uppercase;
  color:var(--ink-3);line-height:1.25}
.d-kpi dd{margin:calc(var(--sp)*.35) 0 0;font-weight:700;font-size:calc(var(--fs)*1.62);line-height:1;
  letter-spacing:-.03em}
.d-kpi small{display:block;font-size:calc(var(--fs)*.7);margin-top:calc(var(--sp)*.3);color:var(--ink-3);font-weight:500}
.d-kpi .up{color:var(--ok)}.d-kpi .down{color:var(--signal)}
.d-kpi .c-chart{margin-top:calc(var(--sp)*.35)}
/* hero figure */
.d-hero{display:flex;align-items:flex-end;gap:calc(var(--sp)*1.4)}
.d-hero .n{font-weight:700;font-size:calc(var(--fs)*5.6);line-height:.82;letter-spacing:-.05em;color:var(--accent)}
.d-hero .n sup{font-size:.34em;vertical-align:.9em;letter-spacing:0}
.d-hero p{margin:0;font-size:calc(var(--fs)*.98);line-height:1.45;color:var(--ink-2);max-width:34ch}
/* small multiples */
.d-sm{display:grid;grid-template-columns:repeat(var(--cols,4),1fr);gap:calc(var(--sp)*.9)}
.d-sm > div{border:1px solid var(--rule);border-radius:var(--radius);padding:calc(var(--sp)*.65) calc(var(--sp)*.7)}
.d-sm b{display:block;font-size:calc(var(--fs)*.8);font-weight:600}
.d-sm span{display:block;font-size:calc(var(--fs)*.68);color:var(--ink-3);margin-bottom:calc(var(--sp)*.3)}
.d-sm em{font-style:normal;font-weight:700;font-size:calc(var(--fs)*.95)}
.d-sm .up{color:var(--ok)}.d-sm .down{color:var(--signal)}
/* annotation tag */
.d-annot{border-left:3px solid var(--accent);padding-left:calc(var(--sp)*.8);font-size:calc(var(--fs)*.84);
  line-height:1.45;color:var(--ink-2)}
.d-annot b{display:block;color:var(--accent);font-weight:700;font-size:calc(var(--fs)*.72);
  letter-spacing:.11em;text-transform:uppercase;margin-bottom:.25em}
/* method / caveat */
.d-method{background:var(--paper-2);border-radius:var(--radius);padding:calc(var(--sp)*.85) calc(var(--sp)*1);
  font-size:calc(var(--fs)*.78);line-height:1.5;color:var(--ink-2)}
.d-method b{display:block;font-weight:700;font-size:calc(var(--fs)*.7);letter-spacing:.12em;text-transform:uppercase;
  color:var(--ink-3);margin-bottom:calc(var(--sp)*.4)}
.d-method dl{display:grid;grid-template-columns:auto 1fr;gap:.2em calc(var(--sp)*.7);margin:0}
.d-method dt{font-weight:600;color:var(--ink)}
.d-method dd{margin:0}
/* filter chips */
.d-filter{display:flex;gap:calc(var(--sp)*.4);flex-wrap:wrap}
.d-filter button{appearance:none;cursor:pointer;font:600 calc(var(--fs)*.72)/1 var(--font-body);letter-spacing:.06em;
  border:1px solid var(--rule);background:var(--paper);color:var(--ink-3);border-radius:99px;
  padding:calc(var(--fs)*.36) calc(var(--fs)*.72);transition:all .15s}
.d-filter button:hover{border-color:var(--accent);color:var(--accent)}
.d-filter button[aria-pressed="true"]{background:var(--accent);border-color:var(--accent);color:#fff}
/* dense table */
.d-table{width:100%;border-collapse:collapse;font-size:calc(var(--fs)*.8)}
.d-table th{font-weight:600;font-size:calc(var(--fs)*.68);letter-spacing:.09em;text-transform:uppercase;
  color:var(--ink-3);text-align:right;padding:0 calc(var(--sp)*.5) calc(var(--sp)*.45) 0;
  border-bottom:1.5px solid var(--ink);cursor:pointer;user-select:none;white-space:nowrap}
.d-table th:first-child{text-align:left}
.d-table th[aria-sort="ascending"]::after{content:" ↑";color:var(--accent)}
.d-table th[aria-sort="descending"]::after{content:" ↓";color:var(--accent)}
.d-table td{text-align:right;padding:calc(var(--sp)*.38) calc(var(--sp)*.5);border-bottom:1px solid var(--rule);
  color:var(--ink-2)}
.d-table td:first-child{text-align:left;color:var(--ink);font-weight:600}
.d-table tbody tr:hover{background:var(--accent-soft)}
.d-table .bar{position:relative;display:block;height:calc(var(--fs)*.85);background:var(--paper-2);border-radius:2px}
.d-table .bar i{position:absolute;inset:0 auto 0 0;background:var(--cat-1);border-radius:2px;
  transform-origin:left;transform:scaleX(0);transition:transform .7s cubic-bezier(.22,1,.36,1)}
.is-in .d-table .bar i{transform:scaleX(1)}
.d-pill{font-weight:600;font-size:calc(var(--fs)*.7);padding:.18em .5em;border-radius:99px;white-space:nowrap}
.d-pill--a{background:#E4F3EE;color:var(--ok)}.d-pill--b{background:#FDF0DC;color:var(--warn)}
.d-pill--c{background:#FBE7E7;color:var(--signal)}
/* scale key */
.d-key{display:flex;align-items:center;gap:calc(var(--sp)*.7);font-size:calc(var(--fs)*.72);color:var(--ink-3);
  flex-wrap:wrap}
.d-key span{display:inline-flex;align-items:center;gap:.4em}
.d-key i{width:calc(var(--fs)*.7);height:calc(var(--fs)*.7);border-radius:2px;display:inline-block}
/* waffle tints */
.c-waffle--wide{grid-template-columns:repeat(20,1fr)}
.c-waffle i.on{background:var(--cat-1)}
.c-waffle i.on2{background:var(--cat-2)}
.c-waffle i.on3{background:var(--cat-3)}
.sheet--slide.d-dark{background:#101418;color:#E6EBEF;--ink:#E6EBEF;--ink-2:#AFBAC2;--ink-3:#7E8B95;
  --rule:rgba(255,255,255,.16);--paper:#101418;--paper-2:rgba(255,255,255,.07);--paper-3:rgba(255,255,255,.05);
  --accent:#4FA3DC;--accent-soft:rgba(79,163,220,.15)}
.d-dark .d-band,.d-dark .d-sm>div{border-color:rgba(255,255,255,.15);background:rgba(255,255,255,.04)}
.d-dark .d-kpi{border-right-color:rgba(255,255,255,.13)}
```

## Slide grammar

- Slides open with the `d-mast` masthead (title · subtitle · edition right) instead of an oversized display title. The finding lives in the panels below it.
- The KPI band `d-band`/`d-kpi` carries up to six numbers with `up`/`down` deltas and inline `spark` charts. It appears once, early — not on every slide.
- Hero finding: `d-hero` giant number beside a 34ch explanation. Comparisons: `d-sm` small multiples, one metric each, same scale, with `d-annot` calling out the interesting cell.
- The ranked table is `d-table` with `data-sort` headers, in-cell `bar` fills, and `d-pill--a/b/c` grade chips; `d-filter` chips slice it (the theme's deck script wires filtering — adapt data, keep wiring).
- Every chart panel is labelled: metric, unit, period. `d-method` states source, N, and definitions once per deck. `d-key` explains any colour scale it sits beside.
- The categorical ramp is fixed (blue, green, amber, red, purple, slate) and semantic red never means anything but negative. A `d-dark` closing slide may hold the single headline stat.

## Deck script (includes this template’s widget wiring)

Adapt the values; keep the structure. This template ships widget script beyond `Doc.init` — include it after the core script and adapt its data, not its wiring.

```js
Doc.init({
  org:'Urban Mobility Index',
  docTitle:'Urban Mobility Index 2026',
  docRef:'UMI-2026 · 24 cities',
  date:'July 2026',
  source:'Sample data — illustrative only. Replace via Doc.init({source}).',
  footer:{ left:'{docTitle}', center:'{madeWith}', right:'{page} / {pages}' },
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});

window.addEventListener('DOMContentLoaded', function(){
  /* heat calendar — 26 weeks of daily ridership */
  var cal=document.getElementById('cal');
  if(cal){
    var s=7654321, out=[], start=new Date(2026,0,5);
    for(var i=0;i<182;i++){
      s=(s*1103515245+12345)%2147483648;
      var dow=i%7, base=(dow>=5)?1:3, v=Math.max(0,Math.min(4, base+((s>>16)%3)-1));
      if(i>=91&&i<98) v=Math.min(v,1);            /* network works week */
      var d=new Date(start.getTime()+i*864e5);
      out.push('<i data-v="'+v+'" style="background:'+['#E4EAEF','#BCD3E5','#7FAFD4','#3F86BC','#1B6CA8'][v]+
        '" data-tip="<em>'+d.toLocaleDateString('en-GB',{day:'numeric',month:'short'})+
        '</em><b>'+['Very low','Low','Typical','High','Peak'][v]+'</b>"></i>');
    }
    cal.innerHTML=out.join('');
  }

  /* waffle — 100 squares, cost breakdown */
  var mix=[['var(--cat-1)','Staff',46],['var(--cat-2)','Energy',19],['var(--cat-3)','Maintenance',17],
           ['var(--cat-5)','Capital charge',11],['var(--cat-6)','Other',7]];
  var cells=[];
  mix.forEach(function(m){ for(var i=0;i<m[2];i++)
    cells.push('<i style="background:'+m[0]+'" data-tip="<em>'+m[1]+'</em><b>'+m[2]+' cents in the euro</b>"></i>'); });
  ['waffle','waffle2'].forEach(function(id){
    var w=document.getElementById(id); if(w) w.innerHTML=cells.join('');
  });

  /* table filters */
  document.querySelectorAll('.d-filter').forEach(function(bar){
    var table=bar.parentNode.querySelector('.d-table')||bar.closest('.sheet__pad').querySelector('.d-table');
    bar.addEventListener('click', function(e){
      var b=e.target.closest('button[data-f]'); if(!b||!table) return;
      [].forEach.call(bar.children, function(c){ c.setAttribute('aria-pressed', String(c===b)); });
      var f=b.dataset.f, shown=0;
      [].forEach.call(table.tBodies[0].rows, function(r){
        var on=(f==='all'||r.dataset.t===f);
        r.style.display=on?'':'none'; if(on) shown++;
      });
      var all=bar.querySelector('[data-f="all"]');
      if(all) all.textContent = (f==='all') ? ('All '+shown+' shown') : 'All';
    });
  });

  /* make the dense tables sortable too */
  document.querySelectorAll('.d-table').forEach(function(tb){
    tb.querySelectorAll('th[data-sort]').forEach(function(th){
      th.addEventListener('click', function(){
        var idx=[].indexOf.call(th.parentNode.children,th);
        var dir=th.getAttribute('aria-sort')==='ascending'?'descending':'ascending';
        tb.querySelectorAll('th[data-sort]').forEach(function(o){ o.removeAttribute('aria-sort'); });
        th.setAttribute('aria-sort',dir);
        var body=tb.tBodies[0], rows=[].slice.call(body.rows);
        rows.sort(function(a,b){
          var x=a.cells[idx].textContent.trim(), y=b.cells[idx].textContent.trim();
          var nx=parseFloat(x.replace(/[^0-9.\-]/g,'')), ny=parseFloat(y.replace(/[^0-9.\-]/g,''));
          var r=(!isNaN(nx)&&!isNaN(ny))? nx-ny : x.localeCompare(y);
          return dir==='ascending'? r : -r;
        });
        rows.forEach(function(r){ body.appendChild(r); });
      });
    });
  });
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide d-dark">
  <div class="k-bgfx k-bgfx--dots" style="color:#4FA3DC"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Urban Mobility Index · Edition 2026</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:66%">Ridership recovered.<br>The cost of a trip did not.</h1>
    <p class="c-subtitle" data-anim style="max-width:48%">Twenty-four cities, eight years, one uncomfortable pattern in the subsidy line.</p>
    <dl class="d-band" style="--cols:4;margin-top:calc(var(--sp)*2)" data-anim>
      <div class="d-kpi"><dt>Journeys per capita</dt><dd data-count="284" data-dec="0">284</dd><small class="up">+6.1% YoY</small></div>
      <div class="d-kpi"><dt>vs 2019</dt><dd data-count="101.4" data-suffix="%">101.4%</dd><small class="up">first year above</small></div>
      <div class="d-kpi"><dt>Subsidy / journey</dt><dd>€1.38</dd><small class="down">+41% vs 2019</small></div>
      <div class="d-kpi"><dt>Cities improving</dt><dd>17 / 24</dd><small>on the composite</small></div>
    </dl>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">The index at a glance</div>
    <h2 class="c-title c-title--xl" data-anim>Four views of the same eight years</h2>
    <div class="l-cols l-4 l-fill" data-anim style="margin-top:calc(var(--sp)*1)">
      <div>
        <div class="c-panel__label"><span>Ridership index</span></div>
        <div class="c-chart" data-chart="line" data-height="200" data-unit=""
             data-alt="The ridership index collapsed to 48 in 2020 and recovered past its 2019 level to 101.4 by 2026."
             data-labels="19,20,21,22,23,24,25,26"
             data-series='[{"name":"All","values":[100,48,63,81,90,95,98.2,101.4],"color":"var(--cat-1)"}]'></div>
      </div>
      <div>
        <div class="c-panel__label"><span>Subsidy € / journey</span></div>
        <div class="c-chart" data-chart="bars" data-height="200" data-unit="€"
             data-alt="Subsidy per trip rose from €0.98 in 2019 to €1.38 in 2026, peaking at €1.44 in 2021."
             data-labels="19,21,23,25,26"
             data-series='[{"name":"Subsidy","values":[0.98,1.44,1.31,1.34,1.38],"color":"var(--cat-4)"}]'></div>
      </div>
      <div>
        <div class="c-panel__label"><span>Farebox recovery</span></div>
        <div class="c-chart" data-chart="donut" data-height="200" data-unit=" cities"
             data-alt="Six of 24 cities recovered above 70% of pre-2020 ridership; seven remain below half."
             data-labels="&gt;70%,50–70%,&lt;50%"
             data-series='[{"name":"Cities","values":[6,11,7],"colors":["var(--cat-2)","var(--cat-3)","var(--cat-4)"]}]'></div>
      </div>
      <div>
        <div class="c-panel__label"><span>Modal split</span></div>
        <div class="c-chart" data-chart="stack" data-height="200" data-pct="true" data-unit="%"
             data-alt="Rail-led cities carry 46% of trips on metro while bus-led cities carry 61% on buses."
             data-labels="Rail,Mix,Bus"
             data-series='[{"name":"Metro","values":[46,28,9]},{"name":"Bus","values":[24,37,61]},{"name":"Tram","values":[16,19,12]},{"name":"Active","values":[14,16,18]}]'></div>
      </div>
    </div>
    <div class="l-cols l-3" data-anim style="margin-top:calc(var(--sp)*.6)">
      <div class="d-annot"><b>Read 1</b>Recovery is real but uneven — rail-led cities are eight points above baseline, bus-led nine below.</div>
      <div class="d-annot" style="border-left-color:var(--cat-4)"><b>Read 2</b>Subsidy per journey spiked in 2021 and never came back down.</div>
      <div class="d-annot" style="border-left-color:var(--cat-3)"><b>Read 3</b>Seven cities now recover under half their operating cost from fares.</div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide d-dark">
  <div class="k-bgfx k-bgfx--scan" style="color:#4FA3DC"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="l-cols l-2" style="align-items:center">
      <div data-anim="scale">
        <div class="d-hero"><div class="n" style="font-size:calc(var(--fs)*7.6);color:#4FA3DC">41<sup>%</sup></div></div>
        <p class="c-subtitle" style="margin-top:calc(var(--sp)*1.2);color:#AFBAC2;max-width:22ch">higher subsidy per journey than in 2019, in constant euros</p>
      </div>
      <div data-anim>
        <div class="c-panel__label"><span>Where a euro of operating cost goes</span></div>
        <div class="c-waffle c-waffle--wide" id="waffle2" style="margin-top:calc(var(--sp)*.6)"></div>
        <div class="d-key" style="margin-top:calc(var(--sp)*.8)">
          <span><i style="background:var(--cat-1)"></i>Staff 46</span>
          <span><i style="background:var(--cat-2)"></i>Energy 19</span>
          <span><i style="background:var(--cat-3)"></i>Maintenance 17</span>
          <span><i style="background:var(--cat-5)"></i>Capital 11</span>
          <span><i style="background:var(--cat-6)"></i>Other 7</span>
        </div>
        <div class="d-annot" style="margin-top:calc(var(--sp)*1)"><b>The pressure point</b>Staff and energy are two thirds of the euro, and both repriced faster than fares between 2021 and 2024.</div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Full ranking · sort or filter</div>
    <h2 class="c-title c-title--xl" data-anim>Frequency, not fare level, separates the top from the bottom</h2>
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*.9)">
      <div>
        <div class="d-filter" style="margin-bottom:calc(var(--sp)*.6)">
          <button data-f="all" aria-pressed="true">All</button>
          <button data-f="Rail-led" aria-pressed="false">Rail-led</button>
          <button data-f="Mixed" aria-pressed="false">Mixed</button>
          <button data-f="Bus-led" aria-pressed="false">Bus-led</button>
        </div>
        <table class="d-table" id="rank2">
          <thead><tr><th data-sort>City</th><th data-sort>Type</th><th data-sort>Index</th><th data-sort>Farebox</th><th data-sort>Subsidy €</th><th style="width:18%">Composite</th></tr></thead>
          <tbody>
            <tr data-t="Rail-led"><td>Vantersund</td><td>Rail-led</td><td>114</td><td>74%</td><td>0.96</td><td><span class="bar"><i style="width:94%"></i></span></td></tr>
            <tr data-t="Rail-led"><td>Meridia</td><td>Rail-led</td><td>113</td><td>71%</td><td>1.04</td><td><span class="bar"><i style="width:91%"></i></span></td></tr>
            <tr data-t="Rail-led"><td>Nordhavn</td><td>Rail-led</td><td>111</td><td>69%</td><td>1.11</td><td><span class="bar"><i style="width:89%"></i></span></td></tr>
            <tr data-t="Mixed"><td>Kerreston</td><td>Mixed</td><td>102</td><td>58%</td><td>1.34</td><td><span class="bar"><i style="width:71%"></i></span></td></tr>
            <tr data-t="Mixed"><td>Aldbury</td><td>Mixed</td><td>99</td><td>54%</td><td>1.42</td><td><span class="bar"><i style="width:66%"></i></span></td></tr>
            <tr data-t="Bus-led"><td>Saltmoor</td><td>Bus-led</td><td>93</td><td>48%</td><td>1.61</td><td><span class="bar"><i style="width:52%"></i></span></td></tr>
            <tr data-t="Bus-led"><td>Cavallo</td><td>Bus-led</td><td>90</td><td>44%</td><td>1.74</td><td><span class="bar"><i style="width:45%"></i></span></td></tr>
            <tr data-t="Bus-led"><td>Undercliff</td><td>Bus-led</td><td>89</td><td>41%</td><td>1.88</td><td><span class="bar"><i style="width:41%"></i></span></td></tr>
          </tbody>
        </table>
      </div>
      <div class="l-stack">
        <div class="c-panel__label"><span>Frequency against recovery</span><span>each dot a city</span></div>
        <div class="c-chart" data-chart="scatter" data-height="215" data-xunit=" per hr" data-max="24" data-ymax="120"
             data-alt="Cities with more peak departures per hour recovered more ridership: rail-led cities cluster at 110–114 index points, bus-led cities near 90."
             data-xlabel="Peak departures per hour"
             data-series='[{"name":"Rail-led","color":"var(--cat-2)","points":[[18,114,5,"Vantersund"],[16,109,5,"Porto Lenta"],[17,111,5,"Nordhavn"],[21,113,6,"Meridia"],[19,112,5,"Sundby"]]},{"name":"Mixed","color":"var(--cat-1)","points":[[12,102,4,"Kerreston"],[10,99,4,"Aldbury"],[11,98,4,"Ravensholt"],[13,101,5,"Thornbeck"]]},{"name":"Bus-led","color":"var(--cat-3)","points":[[7,93,4,"Saltmoor"],[6,90,4,"Cavallo"],[5,89,4,"Undercliff"],[8,92,4,"Estal Vega"]]}]'></div>
        <div class="d-annot"><b>r² = 0.71</b>Nothing else in the index explains as much — not fare level, not fleet age, not city size.</div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>
```
