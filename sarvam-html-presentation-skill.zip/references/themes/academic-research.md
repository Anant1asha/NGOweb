---
name: Academic Research
slug: academic-research
scheme: light
fonts: https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700&family=Spectral:ital,wght@0,300;0,400;0,600;1,300;1,400&display=swap
---

# Academic Research

A working paper standing up to present: Spectral serif for argument, Archivo for apparatus, oxblood for emphasis, booktabs tables, and figures with error bars. Claims carry citations; uncertainty is shown, not hidden.

**Use for:** Research seminars, working papers, methods briefings, scientific findings, literature synthesis, evidence-led decks needing citations and uncertainty.
**Avoid for:** Sales pitches, brand launches, or any deck where scholarly restraint reads as coldness.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#1A1A17; --ink-2:#4A4A44; --ink-3:#84847B;
  --paper:#FCFCFA; --paper-2:#F1F0EA; --paper-3:#F7F7F3;
  --rule:#D2D0C6; --rule-2:#B6B3A6;
  --accent:#7A2E33; --accent-ink:#FFFFFF; --accent-soft:#F6EDED;
  --signal:#7A2E33; --ok:#3F6B4A; --warn:#9A6B1E;
  --cat-1:#7A2E33; --cat-2:#2F4858; --cat-3:#9A6B1E; --cat-4:#3F6B4A; --cat-5:#8A8577; --cat-6:#C7BFAE;
  --app-bg:#DEDCD3;
  --font-display:"Spectral","Iowan Old Style",Georgia,serif;
  --font-body:"Spectral","Iowan Old Style",Georgia,serif;
  --font-mono:"Archivo","Helvetica Neue",Arial,sans-serif;
  --radius:0px;
}
.sheet--slide{--fs:calc(1.36cqw*var(--fit,1))}
/* utility face for labels, captions, data */
.c-eyebrow,.c-stat__label,.c-panel__label,.c-callout__label,.c-metagrid dt,
.c-table th,.c-figure__caption,.c-source,.c-pullquote cite,.c-chip,.c-legend,.c-switch button,
.k-foot-l,.k-foot-c,.k-foot-r,.c-timeline li em{font-family:var(--font-mono)}
.c-title{font-weight:600;letter-spacing:-.008em}
.c-section{font-weight:600}
.c-section__n{font-family:var(--font-mono)}
/* the margin apparatus — signature of this template */
.t-row{display:grid;grid-template-columns:23% 1fr;gap:calc(var(--sp)*1.5);align-items:start}
.t-row+.t-row{margin-top:calc(var(--sp)*1.1)}
.t-note{font-family:var(--font-mono);font-size:calc(var(--fs)*.72);line-height:1.45;color:var(--ink-3);
  border-top:1px solid var(--rule);padding-top:calc(var(--sp)*.45)}
.t-note b{display:block;color:var(--accent);font-weight:600;margin-bottom:.35em;letter-spacing:.04em}
.t-note--fig{border-top-color:var(--accent)}
.t-glance{border-top:2px solid var(--ink);border-bottom:2px solid var(--ink);padding:calc(var(--sp)*1) 0;
  margin:calc(var(--sp)*1.2) 0}
.t-glance dt{font-family:var(--font-mono);font-size:calc(var(--fs)*.68);letter-spacing:.14em;text-transform:uppercase;
  color:var(--accent);margin-bottom:.4em}
.t-glance dd{margin:0;font-size:calc(var(--fs)*.94);line-height:1.45}
.t-runhead{display:flex;align-items:baseline;font-family:var(--font-mono);font-size:calc(var(--fs)*.7);
  letter-spacing:.16em;text-transform:uppercase;color:var(--ink-3);border-bottom:1px solid var(--ink);
  padding-bottom:calc(var(--sp)*.6)}
.t-runhead b{color:var(--ink);font-weight:700}
.t-runhead span:last-child{margin-left:auto;letter-spacing:.06em}
.t-authors{font-size:calc(var(--fs)*1.02);line-height:1.55;margin:calc(var(--sp)*1) 0 0}
.t-authors sup{color:var(--accent);font-size:.68em}
.t-affil{font-family:var(--font-mono);font-size:calc(var(--fs)*.72);line-height:1.5;color:var(--ink-3);margin:.5em 0 0}
.t-eq{font-style:italic;text-align:center;font-size:calc(var(--fs)*1.02);margin:calc(var(--sp)*1) 0;
  display:flex;align-items:baseline}
.t-eq span:first-child{flex:1}
.t-eq span:last-child{font-family:var(--font-mono);font-style:normal;color:var(--ink-3);font-size:calc(var(--fs)*.78)}
.t-eq sub{font-style:normal;font-size:.66em}
.c-table--booktabs thead th{border-top:1.4px solid var(--ink)}
.t-refs{counter-reset:r;margin:0;padding:0;list-style:none}
.t-refs li{counter-increment:r;position:relative;padding-left:calc(var(--fs)*2);font-size:calc(var(--fs)*.8);
  line-height:1.42;margin-bottom:.5em;color:var(--ink-2)}
.t-refs li::before{content:"[" counter(r) "]";position:absolute;left:0;font-family:var(--font-mono);
  font-size:calc(var(--fs)*.7);color:var(--ink-3)}
.sheet--slide .c-title{font-weight:600}
.t-seminar .c-title--xl{max-width:22ch}
```

## Slide grammar

- Cover: `t-runhead` (venue · date), a weight-600 serif title, `t-authors` with superscript affiliations and `t-affil`, then a `t-glance` strip: Question / Method / Finding in three columns.
- Content slides use the margin apparatus: `t-row` (23% notes column, body column). The narrow column holds `t-note` blocks — data sources, N, robustness pointers; the wide column holds the figure or table.
- Figures: `dot` charts with `err:[…]` error bars; captions in `c-figure__caption` state the finding ("Figure 2: the effect survives all four specifications"), with `c-source` naming data and standard errors.
- Tables are `c-table--booktabs` — no vertical rules, no zebra. Estimates get parenthesised standard errors in the cell.
- Equations in `t-eq` with the equation number right-aligned. References as `t-refs` numbered list, only for works actually cited on the slides.
- Oxblood is apparatus and emphasis only — never fills. One claim per slide; the title is the claim, the body is its evidence.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Reef Ecophysiology Group · Institute of Marine Science',
  docTitle:'Developmental acclimation in reef fish larvae',
  docRef:'WP-2026-14',
  author:'A. Ruiz-Delgado',
  date:'July 2026',
  source:'Data and code: doi.example/10.5281/zenodo.9910442',
  footer:{ left:'Ruiz-Delgado et al. · {docRef}', center:'{madeWith}', right:'{page} / {pages}' },
  slideFooter:{ left:'{docTitle}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide t-seminar">
  <div class="k-bgfx k-bgfx--rings" style="color:var(--accent)"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Seminar · Reef Ecophysiology Group</div>
    <h1 class="c-title c-title--xl" data-anim>Developmental acclimation raises thermal tolerance — and hides the cost</h1>
    <p class="c-subtitle" data-anim style="max-width:56%">Two reef fish larvae, five rearing temperatures, and a survivorship problem in the middle of the result.</p>
    <p class="t-authors" data-anim style="font-size:calc(var(--fs)*1.05)">A. Ruiz-Delgado, K. Mwangi, T. Halvorsen, J. Okabe</p>
  </div>
  <footer class="sheet__foot" data-foot data-l="Working paper WP-2026-14 · preprint"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Result 1 of 2</div>
    <h2 class="c-title c-title--xl" data-anim>Tolerance tracks rearing temperature, and one species stops responding above 32&nbsp;°C</h2>
    <hr class="l-rule" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-chart" data-chart="dot" data-height="290" data-unit="°C" data-baseline="34.6" data-max="39"
             data-alt="Thermal tolerance rises with acclimation temperature in both species, from 36.2 to 38.4 °C in A. polyacanthus and 35.4 to 36.9 °C in P. amboinensis."
             data-xlabel="Acclimation temperature (°C)"
             data-labels="26,28,30,32,34"
             data-series='[{"name":"A. polyacanthus","values":[36.2,36.8,37.3,37.9,38.4],"err":[0.35,0.33,0.36,0.34,0.38],"color":"var(--cat-1)"},{"name":"P. amboinensis","values":[35.4,35.9,36.2,36.6,36.9],"err":[0.32,0.30,0.34,0.31,0.35],"color":"var(--cat-2)","square":true,"dash":true}]'></div>
      </div>
      <div>
        <ul class="c-list">
          <li><b>0.28 °C per degree</b> in <em>A. polyacanthus</em> (95% CI 0.24–0.32), linear across the gradient.</li>
          <li><b>0.19 °C per degree</b> in <em>P. amboinensis</em>, saturating above 32&nbsp;°C.</li>
          <li><b>Clutch explains little</b> — SD of the random intercept is 0.12&nbsp;°C.</li>
        </ul>
        <div class="c-takeaway"><span class="c-takeaway__label">Reading</span>
          <p>Within one generation, plasticity closes about a third of the warming projected for this region by 2100.</p></div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Figure 1 · mean ± 1 SE, n = 24 per point"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Result 2 of 2 · the catch</div>
    <h2 class="c-title c-title--xl" data-anim>Survival moves the other way, and the assay cannot see it</h2>
    <hr class="l-rule" data-anim="wipe">
    <div class="l-cols l-2 l-fill" data-anim>
      <div>
        <div class="c-chart" id="surv" data-chart="bars" data-height="240" data-unit="%"
             data-alt="Survival falls with acclimation temperature in both species, from roughly 80% at 26 °C to about a third at 34 °C."
             data-labels="26 °C,28 °C,30 °C,32 °C,34 °C"
             data-series='[{"name":"A. polyacanthus","values":[81,84,76,58,37]},{"name":"P. amboinensis","values":[77,79,70,52,31]}]'></div>
        <div class="c-legend" data-legend-for="surv"></div>
        <p class="c-source">Survival to 21 days post-hatch. Binomial GLM, clutch as random effect.</p>
      </div>
      <div>
        <div class="c-pullquote c-pullquote--accent" style="margin-top:0">
          <p>The individuals that survived 34&nbsp;°C were the ones that could.</p>
          <cite>Part of the measured plasticity is selection</cite>
        </div>
        <div class="c-prose"><p>The model is fitted only to animals that reached day 21 — 37% and 31% of each cohort at the warmest treatment. β<sub>1</sub> therefore absorbs both acclimation and selection.</p></div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Table 2 · survival by treatment"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Where this goes</div>
    <h2 class="c-title c-title--xl" data-anim>Three commitments for the 2027 season</h2>
    <hr class="l-rule" data-anim="wipe">
    <ul class="c-timeline l-fill" data-anim>
      <li><em>Nov 2026</em><b>Mark individuals at hatching</b>Separates within-individual acclimation from selection; pre-registration drafted.</li>
      <li><em>Feb 2027</em><b>Add a fluctuating-temperature arm</b>Lagoon regimes are not constant; constant-temperature estimates may be biased upward.</li>
      <li><em>Jun 2027</em><b>Report survival and tolerance jointly</b>Proposed as a reporting standard for the working group.</li>
    </ul>
    <div class="c-callout c-callout--insight" data-anim><span class="c-callout__label">Ask of this room</span>
      <p>If your group holds marked-cohort data for any pomacentrid, we would like to pool it. The identification problem is easier with four populations than with one.</p></div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Contact: a.ruiz-delgado@ims.example.edu"></footer>
</section>
```
