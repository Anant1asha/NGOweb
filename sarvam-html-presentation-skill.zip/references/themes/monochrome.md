---
name: Monochrome
slug: monochrome
scheme: light
fonts: https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Jost:wght@300;400;500&display=swap
---

# Monochrome

Ivory ledger paper and all-black type, no color at all (adapted from the
MIT-licensed "Monochrome" system): Lora serif headlines over light Jost
body, black hairlines, grayscale charts. Emphasis comes from size, weight,
and space — never from color. The most restrained deck in the catalog.

**Use for:** Essays and position papers presented aloud, design and
typography reviews, principles and values decks, memos to senior audiences,
any deck whose confidence is quietness.
**Avoid for:** Multi-series data stories that need color separation
(consulting-report, data-infographic), sales energy, or teaching decks.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#1A1A16; --ink-2:#5E5E54; --ink-3:#8A8A80;
  --paper:#FAFADF; --paper-2:#F2F2D2; --paper-3:#F5F0E4;
  --rule:#1A1A16; --rule-2:#1A1A16;
  --accent:#1A1A16; --accent-ink:#FAFADF; --accent-soft:#EDEDCB;
  --signal:#1A1A16; --ok:#1A1A16; --warn:#5E5E54;
  --cat-1:#1A1A16; --cat-2:#5E5E54; --cat-3:#8A8A80; --cat-4:#B4B4A8; --cat-5:#3A3A32; --cat-6:#D2D2C2;
  --app-bg:#ECECD2;
  --font-display:"Lora",Georgia,serif;
  --font-body:"Jost","Helvetica Neue",Arial,sans-serif;
  --font-mono:ui-monospace,SFMono-Regular,Menlo,monospace;
  --radius:0px;
}
.c-title{font-weight:500;letter-spacing:-.005em}
.c-eyebrow{letter-spacing:.26em;color:var(--ink-2)}
body{font-weight:300}
/* black interlude — one per deck, for the single statement */
.sheet--slide.t-black{background:#1A1A16;color:#FAFADF;--ink:#FAFADF;--ink-2:#C8C8B4;--ink-3:#8A8A80;
  --paper-2:rgba(250,250,223,.07);--paper-3:rgba(250,250,223,.04);
  --rule:rgba(250,250,223,.3);--rule-2:rgba(250,250,223,.6);
  --accent:#FAFADF;--accent-ink:#1A1A16;--accent-soft:rgba(250,250,223,.12)}
/* ruled box — the only container device */
.t-rulebox{border:1px solid var(--ink);padding:calc(var(--sp)*1) calc(var(--sp)*1.2)}
.t-rulebox b{display:block;font:500 calc(var(--fs)*.68)/1 var(--font-body);letter-spacing:.24em;
  text-transform:uppercase;color:var(--ink-2);margin-bottom:calc(var(--sp)*.5)}
.t-rulebox p{margin:0;font-family:var(--font-display);font-size:calc(var(--fs)*1);
  line-height:1.55;color:var(--ink)}
/* serif italic emphasis */
.t-em{font-family:var(--font-display);font-style:italic}
```

## Slide grammar

- Cover: ivory, a letterspaced eyebrow, a light Lora xxl title, nothing
  else. The restraint *is* the cover.
- Content slides: eyebrow, Lora xl action title, `l-rule` (black hairline),
  one composition surrounded by generous space. Fill honestly but never
  densely — this theme takes fewer elements per slide than any other.
- Charts are grayscale by design: ink for the focal series, graphite and
  silver for context (`--cat-1…6` are a value ramp). Prefer one- or
  two-series charts; label directly, lean on `data-alt` and captions.
- Deltas carry a minus sign and weight, never color. `data-count` on the
  one number that matters.
- The `t-rulebox` holds the implication — one per slide at most.
- One `t-black` interlude per deck for the single sentence everything
  builds to. No textures anywhere.
- Closing: the decision in Lora, owners and dates in a definition list.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Ledger & Line',
  docTitle:'On fewer, better clients',
  date:'July 2026',
  source:'Source: Ledger & Line engagement records, 2023–2026.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide">
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Ledger &amp; Line · a working position</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:70%">On fewer, better clients</h1>
    <p class="c-subtitle" data-anim style="max-width:50%">What three years of engagement records say about where our best work comes from.</p>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Engagement records · 2023–2026</div>
    <h2 class="c-title c-title--xl" data-anim>Our five longest client relationships produced 71% of referred work</h2>
    <hr class="l-rule" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-chart" id="ref" data-chart="hbars" data-height="230" data-unit="% of referrals"
             data-labels="5 longest relationships,Next 10,Next 20,All others"
             data-series='[{"name":"Share of referred work","values":[71,17,9,3],"color":"var(--cat-1)"}]'
             data-alt="The five longest client relationships produced 71 percent of referred work while all clients beyond the top 35 produced 3 percent."></div>
      </div>
      <div class="t-rulebox" data-anim>
        <b>The point</b>
        <p>Referrals follow depth, not reach. Every hour moved from prospecting to existing clients has paid back <span class="t-em">roughly four to one</span>.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: engagement records, 2023–2026"></footer>
</section>
```
