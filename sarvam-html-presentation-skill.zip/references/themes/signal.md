---
name: Signal
slug: signal
scheme: dark
fonts: https://fonts.googleapis.com/css2?family=Source+Serif+4:ital,opsz,wght@0,8..60,400;0,8..60,600;0,8..60,700;1,8..60,400;1,8..60,600&family=DM+Sans:opsz,wght@9..40,400;9..40,500&family=IBM+Plex+Mono:wght@400;500&display=swap
---

# Signal

Institutional weight without stiffness (adapted from the MIT-licensed
"Signal" system): deep navy canvas, warm off-white serif type, one antique
gold accent, IBM Plex Mono timestamps. Roman-and-italic Source Serif
headlines give it the voice of a serious desk; DM Sans body keeps the data
legible. Occasional cream slides act as bright interludes.

**Use for:** Leadership briefings, strategy memos presented aloud, research
desks, market or policy commentary, decks that should feel like an
institution speaking calmly.
**Avoid for:** Playful workshops, brand launches, or dense dashboards
(data-infographic).

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#E2DCD0; --ink-2:#8A96A8; --ink-3:#6B7890;
  --paper:#1C2644; --paper-2:#232F55; --paper-3:#202B4C;
  --rule:#2E3D5C; --rule-2:#3E4F76;
  --accent:#C8A870; --accent-ink:#1C2644; --accent-soft:rgba(200,168,112,.14);
  --signal:#C87070; --ok:#7FA882; --warn:#C8A870;
  --cat-1:#C8A870; --cat-2:#E2DCD0; --cat-3:#8A96A8; --cat-4:#7189B0; --cat-5:#A88B5C; --cat-6:#4E5A6E;
  --app-bg:#141C33;
  --font-display:"Source Serif 4",Georgia,serif;
  --font-body:"DM Sans","Helvetica Neue",Arial,sans-serif;
  --font-mono:"IBM Plex Mono",ui-monospace,Menlo,monospace;
  --radius:0px;
}
.c-title{font-weight:600;letter-spacing:-.008em}
.c-eyebrow{font-family:var(--font-mono);letter-spacing:.2em;color:var(--accent)}
/* italic gold emphasis — the Signal signature, one phrase per slide */
.t-em{font-style:italic;color:var(--accent)}
/* cream interlude slide — bright pause for the key statement or table */
.sheet--slide.t-light{background:#F0ECE3;color:#1A2030;--ink:#1A2030;--ink-2:#5A6270;--ink-3:#9AA0A8;
  --paper:#F0ECE3;--paper-2:#E6E0D4;--paper-3:#EBE6DA;
  --rule:#CAC4B4;--rule-2:#A89F8C;
  --accent:#8A6F3C;--accent-soft:rgba(138,111,60,.14);--accent-ink:#F0ECE3}
.t-light .c-eyebrow{color:#8A6F3C}
/* mono timestamp/desk line */
.t-stamp{font:400 calc(var(--fs)*.68)/1.5 var(--font-mono);letter-spacing:.14em;
  text-transform:uppercase;color:var(--ink-3)}
/* reading note — one implication, serif voice */
.t-note-panel{border-left:3px solid var(--accent);padding:calc(var(--sp)*.8) calc(var(--sp)*1.1);
  background:var(--paper-2)}
.t-note-panel b{display:block;font:500 calc(var(--fs)*.66)/1 var(--font-mono);letter-spacing:.2em;
  text-transform:uppercase;color:var(--accent);margin-bottom:calc(var(--sp)*.5)}
.t-note-panel p{margin:0;font-family:var(--font-display);font-size:calc(var(--fs)*1);
  line-height:1.5;color:var(--ink)}
```

## Slide grammar

- Cover: navy, a `t-stamp` desk-and-date line, serif xxl title mixing roman
  and one italic gold phrase (`t-em`), one-line subtitle. No textures.
- Content slides stay navy: mono eyebrow, serif xl action title, `l-rule`,
  one composition. Gold (`--cat-1`) is the focal series; cream and blue-grey
  carry the rest. Never more than one gold element besides the chart.
- Use one or two `t-light` cream interludes per deck for the governing
  statement, the decisive table, or the recommendation — the brightness
  change is the emphasis.
- Evidence pairs with a `t-note-panel` (serif implication) or a short
  bolded-lead `c-list`, not both.
- Numbers in stat rows take `data-count`; deltas use `--ok`/`--signal`
  muted tones, never saturated red/green.
- Closing on navy: the position in one serif sentence, then owners and
  dates in a `c-statrow--bare` or definition list.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Calder Institute',
  docTitle:'Rates desk briefing',
  date:'July 2026',
  source:'Source: Calder Institute rates desk; central bank releases to 24 Jul 2026.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide">
  <div class="sheet__pad sheet__pad--center" style="padding-left:8cqw">
    <div class="t-stamp" data-anim="fade">Calder Institute · Rates desk · 24 July 2026</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:76%;margin-top:calc(var(--sp)*.8)">The easing cycle is priced; <span class="t-em">the pause is not</span></h1>
    <p class="c-subtitle" data-anim style="max-width:56%">Why the desk expects two cuts, a long hold, and a steeper curve than consensus.</p>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Exhibit · policy rate path, %</div>
    <h2 class="c-title c-title--xl" data-anim>Markets price 90 bps of cuts; our path stops at 50</h2>
    <hr class="l-rule" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-chart" id="path" data-chart="line" data-height="240" data-unit="%"
             data-labels="Now,Q4 26,Q1 27,Q2 27,Q3 27,Q4 27"
             data-series='[{"name":"Desk view","values":[6.5,6.25,6.0,6.0,6.0,6.0],"color":"var(--cat-1)"},{"name":"Market-implied","values":[6.5,6.15,5.9,5.75,5.65,5.6],"dash":true,"color":"var(--cat-3)"}]'
             data-alt="The desk expects the policy rate to stop at 6 percent by Q1 2027 while market pricing implies a fall to 5.6 percent by end 2027."></div>
        <div class="c-legend" data-legend-for="path"></div>
      </div>
      <div class="t-note-panel" data-anim>
        <b>Desk view</b>
        <p>The last 40 bps the market prices require a growth stumble we do not forecast — <span class="t-em">fade the front end</span>.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: desk model v6; market pricing 24 Jul 2026"></footer>
</section>
```
