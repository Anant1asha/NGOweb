---
name: Personal Review
slug: personal-review
scheme: mixed
fonts: https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Newsreader:ital,opsz,wght@0,6..72,300;0,6..72,400;0,6..72,500;1,6..72,300;1,6..72,400&display=swap
---

# Personal Review

A half-year review that feels like a well-designed journal: Newsreader light serif with italic emphasis, Figtree for data, plum and mint, rounded panels, a 182-day heat grid. Warm, honest, first-person — data in service of reflection.

**Use for:** Year or half-year reviews, personal retrospectives, portfolio reflections, habit and wellbeing tracking, founder letters, team reflections.
**Avoid for:** Formal reporting, sales, anything requiring institutional neutrality.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#22222B; --ink-2:#4E4E5C; --ink-3:#7A7A88;
  --paper:#F7F6FA; --paper-2:#EDEBF3; --paper-3:#FFFFFF;
  --rule:#DEDCE6; --rule-2:#C6C2D4;
  --accent:#5B3E6B; --accent-ink:#FFFFFF; --accent-soft:#F0EBF4;
  --signal:#C97B5A; --ok:#4F9B7A; --warn:#D9A441;
  --cat-1:#5B3E6B; --cat-2:#79C6A8; --cat-3:#D9A441; --cat-4:#8E6BA0; --cat-5:#C97B5A; --cat-6:#C7BFD6;
  --app-bg:#DAD7E2;
  --font-display:"Newsreader","Iowan Old Style",Georgia,serif;
  --font-body:"Figtree","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:"Figtree",Arial,sans-serif;
  --radius:12px;
}
.c-title{font-family:var(--font-display);font-weight:300;letter-spacing:-.022em;line-height:1.12}
.c-title--xl{font-weight:300}
.c-title--xxl{font-weight:300;line-height:1.02}
.c-title em{font-style:italic;color:var(--accent)}
.c-eyebrow{color:var(--cat-4)}
.c-subtitle{font-family:var(--font-display);font-style:italic;font-weight:300;font-size:calc(var(--fs)*1.35);
  line-height:1.42;color:var(--ink-2)}
.c-statrow{border-radius:var(--radius)}
.c-stat__value{font-family:var(--font-display);font-weight:400;letter-spacing:-.02em}
.c-panel{background:var(--paper-3);border:1px solid var(--rule)}
.c-pullquote{border:0;border-left:2px solid var(--cat-2);padding:0 0 0 calc(var(--sp)*1.2)}
.c-pullquote p{font-family:var(--font-display);font-style:italic;font-weight:300;font-size:calc(var(--fs)*1.42);
  line-height:1.4;color:var(--accent)}
.c-callout{border-radius:var(--radius)}
/* heat grid tints */
.c-heatgrid i[data-v="0"]{background:#E7E4EE}
.c-heatgrid i[data-v="1"]{background:#D6CFE2}
.c-heatgrid i[data-v="2"]{background:#B29EC4}
.c-heatgrid i[data-v="3"]{background:#8E6BA0}
.c-heatgrid i[data-v="4"]{background:#5B3E6B}
.t-months{display:flex;font-size:calc(var(--fs)*.72);color:var(--ink-3);margin-bottom:calc(var(--sp)*.5)}
.t-months span{flex:1}
.t-key{display:flex;align-items:center;gap:.4cqw;font-size:calc(var(--fs)*.72);color:var(--ink-3);
  margin-top:calc(var(--sp)*.8)}
.t-key i{width:1cqw;height:1cqw;border-radius:.22cqw;display:inline-block}
.t-avatar{width:calc(var(--fs)*3.6);height:calc(var(--fs)*3.6);border-radius:50%;
  background:linear-gradient(150deg,var(--cat-1),var(--cat-2));display:grid;place-items:center;color:#fff;
  font-family:var(--font-display);font-size:calc(var(--fs)*1.5);line-height:1;flex:0 0 auto}
.t-who{display:flex;align-items:center;gap:calc(var(--sp)*1)}
.t-who b{display:block;font-weight:600;font-size:calc(var(--fs)*1)}
.t-who span{color:var(--ink-3);font-size:calc(var(--fs)*.85)}
.t-list li{display:flex;gap:calc(var(--sp)*.8);align-items:baseline;padding:calc(var(--sp)*.5) 0;
  border-bottom:1px solid var(--rule);font-size:calc(var(--fs)*.92);color:var(--ink-2);list-style:none}
.t-list li:last-child{border-bottom:0}
.t-list li em{font-family:var(--font-display);font-style:italic;color:var(--ink-3);margin-left:auto;white-space:nowrap}
.t-list .dot{width:.55em;height:.55em;border-radius:50%;background:var(--cat-2);flex:0 0 auto}
.t-list .dot.p{background:var(--cat-4)}.t-list .dot.s{background:var(--cat-3)}
.sheet--slide.t-grad{background:linear-gradient(155deg,#5B3E6B 0%,#3E3050 55%,#2A2438 100%);color:#F3F0F7;
  --ink:#F3F0F7;--ink-2:#D3C7DD;--ink-3:#B4A0C2;--rule:rgba(255,255,255,.2);--accent:#79C6A8}
```

## Slide grammar

- Cover: `t-grad` plum gradient, serif title with an italic `<em>` phrase, `t-who` identity row with the gradient `t-avatar`.
- The signature evidence is the `c-heatgrid` day grid with `t-months` axis and `t-key` legend — cells carry `data-tip` with the date and note. The theme's deck script builds it from data; adapt the data, keep the builder.
- Numbers appear in rounded `c-statrow` cells with honest `c-stat__note`s ("11 of 26 weeks", not "42% success"). Deltas may point down; say so plainly.
- Reflections are `c-pullquote`s in italic serif plum — first person, specific ("I said yes to too much in March"). `t-list` rows with coloured dots log events with italic dates.
- Structure the deck as: cover → the period in numbers → the heat grid story → what worked / what didn't (`c-list--tick` / `--cross`) → intentions next.
- Keep it humane: no corporate verbs, no KPI language, nothing uppercase except eyebrows.

## Deck script (includes this template’s widget wiring)

Adapt the values; keep the structure. This template ships widget script beyond `Doc.init` — include it after the core script and adapt its data, not its wiring.

```js
Doc.init({
  author:'Sofia Almeida',
  docTitle:'The first half of 2026',
  date:'1 July 2026',
  source:'Personal log, 1 January – 30 June 2026',
  footer:{ left:'{author} · {docTitle}', center:'{madeWith}', right:'{page} / {pages}' },
  slideFooter:{ left:'{docTitle}', center:'{madeWith}', right:'{page} / {pages}' }
});

/* the daily grid — replace `days` with your own array of 0–4 values */
(function(){
  var days=(function(){ var s=20260101,out=[];
    for(var i=0;i<182;i++){ s=(s*1103515245+12345)%2147483648;
      var v=(s>>16)%100, b=v<18?0:v<38?1:v<62?2:v<85?3:4;
      if(i>31&&i<66) b=Math.max(b,3);
      if(i>=130&&i<=136) b=Math.min(b,1);
      out.push(b); }
    return out; })();
  var names=['Quiet day','Something small','A normal day','A full day','Everything at once'];
  var start=new Date(2026,0,1);
  var html=days.map(function(v,i){
    var d=new Date(start.getTime()+i*864e5);
    var lbl=d.toLocaleDateString('en-GB',{day:'numeric',month:'short'});
    return '<i data-v="'+v+'" data-tip="<em>'+lbl+'</em><b>'+names[v]+'</b>"></i>';
  }).join('');
  window.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('.c-heatgrid').forEach(function(el){ el.innerHTML=html; });
  });
})();
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide t-grad">
  <div class="k-bgfx k-bgfx--glow" style="color:#79C6A8"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Half-year review · January to June</div>
    <h1 class="c-title c-title--xxl" data-anim>The first half of <em style="color:#79C6A8">2026</em></h1>
    <p class="c-subtitle" data-anim style="max-width:54%;color:#D3C7DD">I stopped trying to do everything before breakfast, and it turns out most of it still got done.</p>
  </div>
  <footer class="sheet__foot" data-foot data-l="Sofia Almeida"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">182 days, no gaps</div>
    <h2 class="c-title c-title--xl" data-anim>The grid is the only honest part of this <em>review</em></h2>
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*1.1)">
      <div class="c-panel">
        <div class="t-months"><span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span><span>Jun</span></div>
        <div class="c-heatgrid" id="hm-slide" style="--rows:7"></div>
        <div class="t-key"><span>Quieter</span><i style="background:#E7E4EE"></i><i style="background:#D6CFE2"></i>
          <i style="background:#B29EC4"></i><i style="background:#8E6BA0"></i><i style="background:#5B3E6B"></i><span>Fuller</span></div>
      </div>
      <div class="l-stack">
        <div class="c-statrow" style="--cols:2">
          <div class="c-stat"><span class="c-stat__label">Run</span><b class="c-stat__value" data-count="612" data-dec="0">612</b><span class="c-stat__note">km, +18%</span></div>
          <div class="c-stat"><span class="c-stat__label">Sleep</span><b class="c-stat__value">7.1</b><span class="c-stat__note">median hours</span></div>
          <div class="c-stat"><span class="c-stat__label">Books</span><b class="c-stat__value">14</b><span class="c-stat__note">four abandoned</span></div>
          <div class="c-stat"><span class="c-stat__label">Streak</span><b class="c-stat__value">34</b><span class="c-stat__note">2 Feb – 7 Mar</span></div>
        </div>
        <div class="c-callout c-callout--insight"><span class="c-callout__label">The one week that shows</span>
          <p>11–17 May is the pale band. That was the week everything slipped, and it is the only week I would like back.</p></div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="One square per day, darker means more done"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">The pattern underneath</div>
    <h2 class="c-title c-title--xl" data-anim>Distance went up in the months I <em>slept more</em>, not the months I tried harder</h2>
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*1.2)">
      <div><div class="c-chart" id="km" data-chart="area" data-height="240" data-unit="km"
           data-alt="Monthly running distance in 2026 beat 2025 every month, peaking at 125 km in June."
           data-labels="Jan,Feb,Mar,Apr,May,Jun"
           data-series='[{"name":"2026","values":[78,96,121,104,88,125],"color":"var(--cat-1)"},{"name":"2025","values":[71,74,82,90,86,97],"dash":true,"color":"var(--cat-6)"}]'></div>
      <div class="c-legend" data-legend-for="km"></div></div>
      <div>
        <ul class="c-list c-list--dot">
          <li><b>March and June were the two best months</b> and also the two with the most sleep.</li>
          <li><b>May was the emptiest week of the year</b>, and the only month that went backwards.</li>
          <li><b>Effort was not the variable.</b> I tried hardest in May.</li>
        </ul>
        <div class="c-callout c-callout--insight"><span class="c-callout__label">What I take from it</span>
          <p>Protect sleep and the rest mostly follows. That is not a new idea, but this is the first time I have my own data saying it.</p></div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide t-grad">
  <div class="k-bgfx k-bgfx--rings" style="color:#79C6A8"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Carrying into July</div>
    <h2 class="c-title c-title--xxl" data-anim style="font-size:calc(var(--fs)*3.6);max-width:70%">Three things to keep, <em style="color:#79C6A8">one to stop</em></h2>
    <ul class="c-list c-list--num" data-anim style="margin-top:calc(var(--sp)*1.6);max-width:72%">
      <li><b>Keep the evening writing hour</b> — the only habit that never needed a reminder.</li>
      <li><b>Keep one Sunday a month with nothing planned.</b> Three so far; it should be six.</li>
      <li><b>Keep pottery</b>, still badly.</li>
      <li><b>Stop checking the second inbox.</b> Deleted 9 June and not missed once.</li>
    </ul>
  </div>
  <footer class="sheet__foot" data-foot data-l="Sofia Almeida · half-year review"></footer>
</section>
```
