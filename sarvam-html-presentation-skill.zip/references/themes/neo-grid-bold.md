---
name: Neo-Grid Bold
slug: neo-grid-bold
scheme: light
fonts: https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&family=JetBrains+Mono:wght@400;500&display=swap
---

# Neo-Grid Bold

Editorial neo-brutalism (adapted from the MIT-licensed "Neo-Grid Bold"
system): off-white paper, all-black chunky borders and offset shadows, one
signature neon yellow, Space Grotesk display with JetBrains Mono labels.
Confident, graphic, design-led — a deck that looks intentional from across
the room.

**Use for:** Design and product reviews, launch decks, workshop and offsite
materials, portfolio and capability presentations, hackathon or internal
demos — work that should feel bold and design-literate.
**Avoid for:** Formal reporting, financial or policy audiences, and any
context where the aesthetic would read as louder than the content.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#0A0A0A; --ink-2:#4A4A45; --ink-3:#8A8A85;
  --paper:#F5F4EF; --paper-2:#ECECE8; --paper-3:#F0EFE9;
  --rule:#0A0A0A; --rule-2:#0A0A0A;
  --accent:#0A0A0A; --accent-ink:#F5F4EF; --accent-soft:#F4FFB0;
  --signal:#E5484D; --ok:#0E8A5F; --warn:#B7791F;
  --cat-1:#0A0A0A; --cat-2:#8A8A85; --cat-3:#E6FF3D; --cat-4:#C9C9C0; --cat-5:#4A4A45; --cat-6:#DEDED2;
  --app-bg:#E2E2DC;
  --font-display:"Space Grotesk","Helvetica Neue",Arial,sans-serif;
  --font-body:"Space Grotesk","Helvetica Neue",Arial,sans-serif;
  --font-mono:"JetBrains Mono",ui-monospace,Menlo,monospace;
  --radius:0px;
}
.c-title{font-weight:700;letter-spacing:-.022em;text-transform:uppercase}
.c-title--xl{line-height:1.05}
.c-eyebrow{font-family:var(--font-mono);letter-spacing:.14em;color:var(--ink)}
/* the block — bordered, hard-shadowed container, the signature device */
.t-block{background:var(--paper);border:3px solid var(--ink);
  box-shadow:.55cqw .55cqw 0 var(--ink);padding:calc(var(--sp)*1) calc(var(--sp)*1.1)}
.t-block--yellow{background:#E6FF3D}
.t-block b{display:block;font:700 calc(var(--fs)*.72)/1.2 var(--font-display);
  text-transform:uppercase;letter-spacing:.04em;margin-bottom:calc(var(--sp)*.45)}
.t-block p{margin:0;font-size:calc(var(--fs)*.86);line-height:1.5;color:var(--ink-2)}
.t-block--yellow p{color:var(--ink)}
/* yellow highlight tape behind a word */
.t-tape{background:#E6FF3D;padding:0 .18em;box-decoration-break:clone;-webkit-box-decoration-break:clone}
/* mono index label */
.t-idx{font:500 calc(var(--fs)*.7)/1 var(--font-mono);letter-spacing:.1em;color:var(--ink-2)}
/* black divider/closing canvas */
.sheet--slide.t-blackout{background:#0A0A0A;color:#F5F4EF;--ink:#F5F4EF;--ink-2:#C9C9C0;--ink-3:#8A8A85;
  --paper-2:rgba(245,244,239,.08);--paper-3:rgba(245,244,239,.05);
  --rule:rgba(245,244,239,.4);--rule-2:#E6FF3D;
  --accent:#E6FF3D;--accent-ink:#0A0A0A;--accent-soft:rgba(230,255,61,.18)}
.t-blackout .c-eyebrow{color:#E6FF3D}
```

## Slide grammar

- Cover: paper, a mono eyebrow, an uppercase xxl title with one `t-tape`
  yellow highlight, and nothing decorative — the type is the poster.
- Content slides: mono eyebrow with an index (`01 — CONTEXT`), uppercase xl
  action title, thick `l-rule--strong`, one composition.
- `t-block` grids carry the argument: options, principles, workstreams —
  identical blocks, one `t-block--yellow` for the focal item at most.
- Charts are ink-first; yellow (`--cat-3`) marks exactly one focal series
  or bar. Grays fill. Never chart in yellow alone on paper.
- `t-tape` highlights one phrase per slide at most; the device dies with
  repetition.
- Dividers and closing use `t-blackout` with a yellow eyebrow and an
  uppercase claim.
- Keep density medium: big type eats space — split rather than shrink.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Studio Hardline',
  docTitle:'Design system v3 · review',
  date:'July 2026',
  source:'Source: Studio Hardline component audit, July 2026.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide">
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">STUDIO HARDLINE · DS-V3 REVIEW · JUL 2026</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:82%">Half our UI ships from <span class="t-tape">twelve components</span></h1>
    <p class="c-subtitle" data-anim style="max-width:56%;text-transform:none">The v3 audit: what earned its place, what gets deleted, and the migration plan.</p>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">02 — USAGE AUDIT</div>
    <h2 class="c-title c-title--xl" data-anim>Twelve components carry 52% of production usage</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-chart" id="usage" data-chart="hbars" data-height="235" data-unit="% of instances"
             data-labels="Top 12 components,Next 24,Next 40,Long tail (81)"
             data-series='[{"name":"Share of production instances","values":[52,27,14,7],"colors":["var(--cat-3)","var(--cat-1)","var(--cat-2)","var(--cat-4)"]}]'
             data-alt="Twelve components account for 52 percent of production instances while the 81-component long tail accounts for 7 percent."></div>
      </div>
      <div class="t-block t-block--yellow" data-anim>
        <b>The call</b>
        <p>Deprecate the 81-component tail this quarter. Every hour spent maintaining a component used seven times is an hour taken from the twelve that matter.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: component audit, 4,120 screens"></footer>
</section>
```
