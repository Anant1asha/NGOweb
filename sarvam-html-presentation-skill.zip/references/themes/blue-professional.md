---
name: Blue Professional
slug: blue-professional
scheme: light
fonts: https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap
---

# Blue Professional

Clean modern professional (adapted from the MIT-licensed "Blue Professional"
system): warm cream paper, one electric cobalt that does all the work, Space
Grotesk headlines over Inter, soft cobalt-tinted cards and hairlines. The
general-purpose business deck when the content should lead and the design
should simply be *good*.

**Use for:** Product and business updates, proposals, plans, project
kickoffs, client presentations, internal reviews — everyday professional
work that wants a modern, confident, uncomplicated look.
**Avoid for:** Formal institutional contexts (government-official, signal)
or expressive brand work (creative-editorial-studio).

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#111111; --ink-2:#55554E; --ink-3:#8F8F86;
  --paper:#FDFAE7; --paper-2:#F5F1D8; --paper-3:#F9F6E0;
  --rule:#CFD2F0; --rule-2:#A9AEE8;
  --accent:#1E2BFA; --accent-ink:#FDFAE7; --accent-soft:#E4E6FD;
  --signal:#E5484D; --ok:#0E8A5F; --warn:#B7791F;
  --cat-1:#1E2BFA; --cat-2:#111111; --cat-3:#7B84F5; --cat-4:#9A9A8E; --cat-5:#3D45B8; --cat-6:#C9C9BA;
  --app-bg:#EFEBD6;
  --font-display:"Space Grotesk","Helvetica Neue",Arial,sans-serif;
  --font-body:"Inter","Helvetica Neue",Arial,sans-serif;
  --font-mono:ui-monospace,SFMono-Regular,Menlo,monospace;
  --radius:6px;
}
.c-title{font-weight:600;letter-spacing:-.02em}
.c-eyebrow{color:var(--accent);letter-spacing:.16em}
/* cobalt cover/closing canvas */
.sheet--slide.t-cobalt{background:#1E2BFA;color:#FDFAE7;--ink:#FDFAE7;--ink-2:#C9CDF8;--ink-3:#9BA2EE;
  --paper-2:rgba(253,250,231,.1);--paper-3:rgba(253,250,231,.06);
  --rule:rgba(253,250,231,.28);--rule-2:rgba(253,250,231,.5);
  --accent:#FDFAE7;--accent-ink:#1E2BFA;--accent-soft:rgba(253,250,231,.14)}
/* soft card — the workhorse container */
.t-card{background:rgba(30,43,250,.04);border:1px solid var(--rule);border-radius:var(--radius);
  padding:calc(var(--sp)*1) calc(var(--sp)*1.1)}
.t-card b{display:block;font:600 calc(var(--fs)*.7)/1 var(--font-display);letter-spacing:.14em;
  text-transform:uppercase;color:var(--accent);margin-bottom:calc(var(--sp)*.5)}
.t-card p{margin:0;font-size:calc(var(--fs)*.88);line-height:1.55;color:var(--ink-2)}
/* pill tag */
.t-tag{display:inline-block;font:600 calc(var(--fs)*.66)/1 var(--font-display);letter-spacing:.1em;
  text-transform:uppercase;color:var(--accent);border:1px solid var(--rule-2);
  border-radius:99px;padding:calc(var(--sp)*.35) calc(var(--sp)*.8)}
/* next-step banner */
.t-next{background:var(--accent-soft);border-radius:var(--radius);
  padding:calc(var(--sp)*.9) calc(var(--sp)*1.1)}
.t-next b{display:block;font:600 calc(var(--fs)*.7)/1 var(--font-display);letter-spacing:.14em;
  text-transform:uppercase;color:var(--accent);margin-bottom:calc(var(--sp)*.45)}
.t-next p{margin:0;font-size:calc(var(--fs)*.94);line-height:1.5;color:var(--ink)}
```

## Slide grammar

- Cover (`t-cobalt`): eyebrow with team and date, Space Grotesk xxl title
  stating the outcome, one-line subtitle. Optional faint `k-bgfx--grid`.
- Content slides on cream: eyebrow, xl action title, `l-rule`, one
  composition. Cobalt leads charts; ink is the comparator; periwinkle and
  warm grays fill.
- `t-card` grids (`l-3`) carry plans, workstreams, and options — identical
  treatment for peers, ≤22 words each.
- One `t-next` banner per slide at most, stating the action that follows
  from the evidence.
- `t-tag` pills mark status (On track / At risk) sparingly; semantic colors
  only when genuinely good/bad.
- Interactive extras where they help the room: `data-count` on the KPI row,
  a sortable table for workstream status, a switcher on the metric chart.
- Closing (`t-cobalt`): decisions or next steps with owners and dates.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Bluewick Systems',
  docTitle:'Platform migration · plan review',
  date:'July 2026',
  source:'Source: Bluewick delivery tracker, sprint 14 close.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide t-cobalt">
  <div class="k-bgfx k-bgfx--grid" style="color:#fff"></div>
  <div class="sheet__pad sheet__pad--center" style="padding-left:8cqw">
    <div class="c-eyebrow" data-anim="fade">Platform team · plan review · July 2026</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:74%">Migration lands in October — two risks stand between us and it</h1>
    <p class="c-subtitle" data-anim style="max-width:56%">Where the eight workstreams are, what changed since May, and the two calls we need today.</p>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Progress · story points shipped</div>
    <h2 class="c-title c-title--xl" data-anim>Velocity recovered to plan after the June re-scope</h2>
    <hr class="l-rule" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-chart" id="vel" data-chart="line" data-height="240" data-unit="points/sprint"
             data-labels="S8,S9,S10,S11,S12,S13,S14"
             data-series='[{"name":"Shipped","values":[41,38,29,33,42,47,49],"color":"var(--cat-1)"},{"name":"Plan","values":[44,44,44,44,44,46,46],"dash":true,"color":"var(--cat-4)"}]'
             data-alt="Story points shipped per sprint dipped to 29 in sprint 10 and recovered above the 46-point plan by sprint 14."></div>
        <div class="c-legend" data-legend-for="vel"></div>
      </div>
      <div class="t-next" data-anim>
        <b>Next step</b>
        <p>Hold scope through August. The two sprints above plan are buffer, not room for additions.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: delivery tracker, sprint 14 close"></footer>
</section>
```
