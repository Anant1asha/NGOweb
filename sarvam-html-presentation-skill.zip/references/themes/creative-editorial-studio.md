---
name: Creative Editorial Studio
slug: creative-editorial-studio
scheme: mixed
fonts: https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,700;1,9..40,400&family=Instrument+Serif:ital@0;1&display=swap
---

# Creative Editorial Studio

A studio flexing typography: Bricolage Grotesque at poster sizes, cobalt and hot pink, Instrument Serif italics for asides, outlined display words, marquees, swatches, and type specimens. The type IS the design; everything else stays out of its way.

**Use for:** Brand-system reviews, creative pitches, rebrands, campaign concepts, design-studio presentations and approvals.
**Avoid for:** Institutional briefings, dense technical or policy content, audiences that read expressiveness as unseriousness.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#0E0E10; --ink-2:#3A3A42; --ink-3:#74747E;
  --paper:#FFFDF7; --paper-2:#E9E7FF; --paper-3:#F6F4FF;
  --rule:#D9D6CC; --rule-2:#B4B0FF;
  --accent:#2417E8; --accent-ink:#FFFDF7; --accent-soft:#E9E7FF;
  --signal:#FF6E8A; --ok:#1F8A5F; --warn:#E08A2C;
  --cat-1:#2417E8; --cat-2:#FF6E8A; --cat-3:#0E0E10; --cat-4:#8B84FF; --cat-5:#FFB3C2; --cat-6:#C9C6FF;
  --app-bg:#CFCCC1;
  --font-display:"Bricolage Grotesque","Helvetica Neue",Impact,sans-serif;
  --font-body:"DM Sans","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:"DM Sans",Arial,sans-serif;
  --radius:0px;
}
.c-title{font-weight:700;letter-spacing:-.035em;line-height:.98}
.c-title--xl{font-size:calc(var(--fs)*3.9)}
.c-title--xxl{font-size:calc(var(--fs)*6.2);font-weight:800;letter-spacing:-.045em;line-height:.88;text-transform:uppercase}
.c-eyebrow{letter-spacing:.24em;font-weight:700}
.c-subtitle{font-family:"Instrument Serif","Iowan Old Style",Georgia,serif;font-style:italic;
  font-size:calc(var(--fs)*1.6);line-height:1.24;color:var(--ink-2)}
.c-pullquote p{font-family:"Instrument Serif",Georgia,serif;font-style:italic;font-weight:400;
  font-size:calc(var(--fs)*2);letter-spacing:-.01em;line-height:1.16}
.sheet--invert{--paper:#FFFDF7}
.sheet--accent{--ink:#FFFDF7;--ink-2:#DDDCFF;--ink-3:#B4AEFF;--rule:rgba(255,253,247,.35);
  --paper-2:rgba(255,253,247,.12);--accent:#FF6E8A;--accent-soft:rgba(255,110,138,.16)}
.sheet--accent .c-eyebrow{color:#FFB3C2}
/* devices */
.t-out{color:transparent;-webkit-text-stroke:.14cqw currentColor}
.t-studio{display:flex;align-items:baseline;gap:calc(var(--sp)*.7);font:700 calc(var(--fs)*.82)/1 var(--font-body);
  letter-spacing:.2em;text-transform:uppercase}
.t-studio em{font-style:normal;color:var(--signal)}
.t-studio .yr{margin-left:auto;font-variant-numeric:tabular-nums}
.t-rot{position:absolute;right:2.4cqw;top:6.5cqw;writing-mode:vertical-rl;z-index:3;
  font:700 calc(var(--fs)*.72)/1 var(--font-body);letter-spacing:.28em;text-transform:uppercase;color:var(--signal)}
.t-marquee{position:absolute;left:0;right:0;bottom:0;background:var(--ink);color:var(--paper);overflow:hidden;
  font:700 calc(var(--fs)*.68)/1 var(--font-body);letter-spacing:.22em;text-transform:uppercase;
  padding:1cqw 0;white-space:nowrap;z-index:2;display:flex}
.t-marquee div{display:flex;gap:1.6cqw;padding-right:1.6cqw;animation:t-march 26s linear infinite}
.t-marquee i{font-style:normal;color:var(--signal)}
@keyframes t-march{to{transform:translateX(-100%)}}
@media (prefers-reduced-motion:reduce){.t-marquee div{animation:none}}
.t-swatches{display:grid;grid-template-columns:repeat(var(--n,3),1fr);gap:calc(var(--sp)*.7)}
.t-sw{aspect-ratio:1/1.2;border:1.5px solid var(--ink);display:flex;align-items:flex-end;padding:calc(var(--sp)*.6)}
.t-sw b{font:700 calc(var(--fs)*.68)/1.3 var(--font-body);letter-spacing:.08em;text-transform:uppercase}
.t-specimen{border:1.5px solid var(--ink);padding:calc(var(--sp)*1.1)}
.t-specimen .aa{font-family:var(--font-display);font-weight:800;font-size:calc(var(--fs)*4.4);line-height:.86;letter-spacing:-.04em}
.t-specimen .row{display:flex;justify-content:space-between;align-items:baseline;margin-top:calc(var(--sp)*.8);
  font:700 calc(var(--fs)*.66)/1 var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:var(--ink-3)}
.t-ba{display:grid;grid-template-columns:1fr 1fr;gap:0;border:1.5px solid var(--ink)}
.t-ba > div{padding:calc(var(--sp)*.9)}
.t-ba > div:first-child{border-right:1.5px solid var(--ink);background:var(--paper-3)}
.t-ba b{display:block;font:700 calc(var(--fs)*.66)/1 var(--font-body);letter-spacing:.16em;text-transform:uppercase;
  color:var(--ink-3);margin-bottom:calc(var(--sp)*.6)}
.t-ba p{margin:0;font-size:calc(var(--fs)*.88);line-height:1.45;color:var(--ink-2)}
.t-num{font-family:var(--font-display);font-weight:800;font-size:calc(var(--fs)*9);line-height:.8;
  letter-spacing:-.05em;color:var(--signal)}
.t-num small{display:block;font-family:var(--font-body);font-weight:700;font-size:calc(var(--fs)*.74);
  letter-spacing:.2em;text-transform:uppercase;color:currentColor;margin-top:calc(var(--sp)*1);opacity:.9}
```

## Slide grammar

- Cover and one or two dividers go full-bleed cobalt (`sheet--accent`) with uppercase xxl titles mixing solid and `t-out` outlined words, the `t-rot` vertical tag, and a `t-marquee` strip along the bottom.
- The studio mark `t-studio` anchors light slides top-left. Subtitles and commentary use the Instrument Serif italic `c-subtitle`.
- Show, don't describe: palettes as `t-swatches`/`t-sw` blocks with their hex names, type as a `t-specimen` (giant Aa, weights row), decisions as `t-ba` before/after panes.
- One slide may be a single `t-num` — a giant pink number with a small caption. Give it the whole slide.
- Pink (`--signal`) punctuates: one emphasised word, the marquee separators, the big stat. Cobalt does structural work. Never let both fight on one slide.
- Copy is short and declarative; wit is welcome, filler is not. Body stays DM Sans regular at normal sizes — contrast is the tool.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Kettle & Vane',
  client:'Ostro Ferry Company',
  docTitle:'Ostro Ferry rebrand · case report',
  date:'2026',
  source:'Gangway survey, February 2026 · n = 212',
  footer:{ left:'', center:'', right:'' },
  slideFooter:{ left:'{docTitle}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide sheet--accent" style="background:var(--cat-1)">
  <div class="k-bgfx k-bgfx--glow" style="color:#FF6E8A"></div>
  <div class="sheet__pad sheet__pad--end">
    <div class="t-studio" style="margin-bottom:auto" data-anim="fade">Kettle &amp; Vane · Design Studio<span class="yr">Board sign-off · June 2026</span></div>
    <h1 class="c-title c-title--xxl" data-anim>Ostro <span class="t-out">Ferry</span> <span style="color:var(--signal)">Rebrand</span></h1>
    <p class="c-subtitle" data-anim style="max-width:52%;margin-top:calc(var(--sp)*1.4)">Forty-one years of navy blue, and nobody could tell which boat was theirs.</p>
  </div>
  <footer class="sheet__foot" data-foot data-l="Identity system v3"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide sheet--invert">
  <div class="k-bgfx k-bgfx--wave" style="color:#FF6E8A"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="l-cols l-2a" style="align-items:end">
      <div class="t-num" data-anim="scale"><span data-count="61" data-suffix="%">61%</span><small>Named a competitor at the gangway</small></div>
      <div data-anim>
        <p class="c-prose" style="color:#DDDCFF">We asked 212 passengers one question while they were boarding: which company operates this boat?</p>
        <hr class="l-rule" style="background:rgba(255,253,247,.35)">
        <p class="c-prose" style="color:#DDDCFF">Nineteen per cent named a company that stopped trading in 2004. Only twelve per cent named Ostro unprompted.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Gangway survey · Feb 2026 · n = 212"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">05 — The system</div>
    <h2 class="c-title c-title--xl" data-anim>Three things never change. <span style="color:var(--signal)">One thing does.</span></h2>
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*1.4)">
      <div class="t-specimen">
        <div class="aa">Aa Ostro</div>
        <div class="row"><span>Bricolage Grotesque</span><span>800 / −4.5%</span></div>
        <p class="c-prose" style="font-size:calc(var(--fs)*.9);margin-top:calc(var(--sp)*.8)">One file, one measurement: cap height equals one third of the hull band.</p>
      </div>
      <div>
        <div class="t-swatches" style="--n:3">
          <div class="t-sw" style="background:var(--cat-1);color:var(--paper)"><b>North<br>2417E8</b></div>
          <div class="t-sw" style="background:var(--cat-2)"><b>Harbour<br>FF6E8A</b></div>
          <div class="t-sw" style="background:var(--cat-3);color:var(--paper)"><b>Night<br>0E0E10</b></div>
        </div>
        <ul class="c-list c-list--num c-list--rule" style="margin-top:calc(var(--sp)*.9)">
          <li>The mark, the wordmark, and the hull band are fixed.</li>
          <li>Band colour carries the route, and nothing else does.</li>
          <li>Legible at 400 m or it does not ship.</li>
        </ul>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Kettle &amp; Vane · Ostro Ferry identity v3"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide sheet--accent" style="background:var(--cat-3)">
  <div class="k-bgfx k-bgfx--rings" style="color:#FF6E8A"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">What we need today</div>
    <h2 class="c-title c-title--xxl" data-anim style="font-size:calc(var(--fs)*4.6);max-width:80%">Sign off the three fixed elements</h2>
    <p class="c-subtitle" data-anim style="max-width:58%;margin-top:calc(var(--sp)*1.4)">The route palette can keep moving until the September refit. The fixed elements cannot — the sign shop needs them in August.</p>
    <div class="c-statrow c-statrow--bare" style="--cols:3;border-top-color:rgba(255,253,247,.35);margin-top:calc(var(--sp)*2)" data-anim>
      <div class="c-stat"><span class="c-stat__label">Sign-off needed by</span><b class="c-stat__value">8 Aug</b></div>
      <div class="c-stat"><span class="c-stat__label">First vessel in refit</span><b class="c-stat__value">14 Sep</b></div>
      <div class="c-stat"><span class="c-stat__label">Fleet complete</span><b class="c-stat__value">Mar 2028</b></div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Kettle &amp; Vane"></footer>
</section>
```
