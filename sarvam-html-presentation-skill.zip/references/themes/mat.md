---
name: Mat
slug: mat
scheme: dark
fonts: https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=DM+Sans:opsz,wght@9..40,400;9..40,500&family=DM+Mono:wght@400&display=swap
---

# Mat

Mid-century modern with wood undertones (adapted from the MIT-licensed
"Mat" system): dark sage-green canvas, warm bone type, one burnt-orange
accent, heavy rounded Bricolage Grotesque display over DM Sans, DM Mono
kickers. Warm, grounded, and quietly confident — a dark deck that doesn't
feel like a terminal.

**Use for:** Team and culture reviews, product vision talks, offsite
openers, roadmap narratives, studio updates — work decks that want warmth
and character without losing seriousness.
**Avoid for:** Formal reporting, audit or policy contexts, and dense
multi-chart evidence better served by light analytical themes.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#F0E8D2; --ink-2:#BDB49B; --ink-3:#939180;
  --paper:#232E26; --paper-2:#2E3D30; --paper-3:#29372C;
  --rule:#3A463B; --rule-2:#4C5A4E;
  --accent:#C07030; --accent-ink:#F0E8D2; --accent-soft:rgba(192,112,48,.16);
  --signal:#C05252; --ok:#8FB07C; --warn:#C8A227;
  --cat-1:#C07030; --cat-2:#F0E8D2; --cat-3:#8FB07C; --cat-4:#A8916B; --cat-5:#5C7A62; --cat-6:#6E7A66;
  --app-bg:#1A231C;
  --font-display:"Bricolage Grotesque","Helvetica Neue",Arial,sans-serif;
  --font-body:"DM Sans","Helvetica Neue",Arial,sans-serif;
  --font-mono:"DM Mono",ui-monospace,Menlo,monospace;
  --radius:4px;
}
.c-title{font-weight:800;letter-spacing:-.015em}
.c-eyebrow{font-family:var(--font-mono);letter-spacing:.18em;color:var(--accent)}
/* cream material card — the light panel on the dark surface */
.t-card{background:#EDE6D0;color:#1E2820;border-radius:var(--radius);
  padding:calc(var(--sp)*1) calc(var(--sp)*1.1)}
.t-card b{display:block;font:700 calc(var(--fs)*.7)/1 var(--font-mono);letter-spacing:.16em;
  text-transform:uppercase;color:#C07030;margin-bottom:calc(var(--sp)*.5)}
.t-card p{margin:0;font-size:calc(var(--fs)*.86);line-height:1.5;color:rgba(30,40,32,.75)}
.t-card strong{display:block;font-family:var(--font-display);font-weight:800;
  font-size:calc(var(--fs)*1.9);line-height:1.05;color:#1E2820;margin-bottom:calc(var(--sp)*.4)}
/* warm glow — covers and closing only, the wood undertone */
.t-glow{position:absolute;right:-12cqw;bottom:-16cqw;width:44cqw;height:44cqw;border-radius:50%;
  background:radial-gradient(circle,rgba(122,78,36,.5),transparent 65%);pointer-events:none}
/* orange marker underline for one phrase */
.t-mark{box-shadow:inset 0 -0.35em 0 rgba(192,112,48,.45)}
```

## Slide grammar

- Cover: dark sage with the `t-glow` in the corner, mono eyebrow, heavy
  Bricolage xxl title with one `t-mark` underline, one-line subtitle.
- Content slides: mono eyebrow, Bricolage xl action title, `l-rule`, one
  composition. No glow, no decoration — the palette is the character.
- `t-card` cream cards carry the numbers and commitments: a `strong` value,
  a mono label, two lines of context. Grids of two or three, identical
  treatment.
- Charts: burnt orange leads, bone is the comparator, sage tones fill.
  Dashed bone for plan/target lines. One chart per slide.
- `t-mark` underlines one phrase per slide at most.
- Deltas use `--ok` sage-green and `--signal` muted red sparingly; most
  numbers stay bone.
- Closing: dark with the glow, commitments as `t-card`s with owners and
  dates.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Timberline Works',
  docTitle:'H2 roadmap · team review',
  date:'July 2026',
  source:'Source: Timberline delivery and hiring trackers, July 2026.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide">
  <div class="t-glow"></div>
  <div class="sheet__pad sheet__pad--center" style="padding-left:8cqw">
    <div class="c-eyebrow" data-anim="fade">Timberline Works · H2 roadmap · July 2026</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:76%">Ship <span class="t-mark">half as much</span>, twice as finished</h1>
    <p class="c-subtitle" data-anim style="max-width:54%">The H2 plan: four launches, two platform bets, and the maintenance debt we finally pay down.</p>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">H1 retrospective · launch quality</div>
    <h2 class="c-title c-title--xl" data-anim>Post-launch fix time dropped 60% when we cut concurrent projects</h2>
    <hr class="l-rule" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-chart" id="fix" data-chart="bars" data-height="235" data-unit="days of fixes"
             data-labels="Q1 25,Q2 25,Q3 25,Q4 25,Q1 26,Q2 26"
             data-series='[{"name":"Fix days per launch","values":[18,21,16,11,8,7],"color":"var(--cat-1)"},{"name":"Concurrent projects","values":[9,10,8,6,5,5],"color":"var(--cat-3)"}]'
             data-alt="Days spent on post-launch fixes fell from 21 to 7 per launch as concurrent projects were cut from 10 to 5."></div>
        <div class="c-legend" data-legend-for="fix"></div>
      </div>
      <div class="t-card" data-anim>
        <b>H2 commitment</b>
        <strong>5 max</strong>
        <p>Concurrent projects stay capped at five. New work queues rather than splitting the team thinner.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: delivery tracker, 14 launches"></footer>
</section>
```
