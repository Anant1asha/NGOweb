---
name: Editorial Forest
slug: editorial-forest
scheme: mixed
fonts: https://fonts.googleapis.com/css2?family=Source+Serif+4:ital,opsz,wght@0,8..60,400;0,8..60,600;0,8..60,700;1,8..60,400&family=JetBrains+Mono:wght@400;500&display=swap
---

# Editorial Forest

Quiet, intentional quarterly-review aesthetic (adapted from the MIT-licensed
"Editorial Forest" system): forest green and dusty pink on warm cream, set
entirely in Source Serif 4 with JetBrains Mono kickers. The deck reads like
a well-made annual report — serif evidence, hairline rules, one pink
emphasis used sparingly, deep-green bookends.

**Use for:** Quarterly and annual reviews, team retrospectives, program
updates, planning readouts, sustainability and culture reports — work that
should feel considered rather than urgent.
**Avoid for:** High-pressure pitches, dense dashboards (data-infographic),
or formal audit contexts (government-official).

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#1A1A17; --ink-2:#4C4C41; --ink-3:#8C8C7C;
  --paper:#EFE7D4; --paper-2:#E6DCC4; --paper-3:#F3EDE0;
  --rule:#D8CFB6; --rule-2:#BFB598;
  --accent:#2E4A2A; --accent-ink:#EFE7D4; --accent-soft:#DFE6D6;
  --signal:#D27E96; --ok:#2E4A2A; --warn:#B7791F;
  --cat-1:#2E4A2A; --cat-2:#1A1A17; --cat-3:#D27E96; --cat-4:#A8A183; --cat-5:#3A5A36; --cat-6:#CBC3A6;
  --app-bg:#E2D9C0;
  --font-display:"Source Serif 4",Georgia,serif;
  --font-body:"Source Serif 4",Georgia,serif;
  --font-mono:"JetBrains Mono",ui-monospace,Menlo,monospace;
  --radius:2px;
}
.c-title{font-weight:600;letter-spacing:-.01em}
.c-eyebrow{font-family:var(--font-mono);letter-spacing:.18em;color:var(--accent)}
/* deep-green bookends — cover, dividers, closing */
.sheet--slide.t-forest{background:#243A21;color:#EFE7D4;--ink:#EFE7D4;--ink-2:#C9C9AE;--ink-3:#9AA388;
  --rule:rgba(239,231,212,.18);--rule-2:rgba(239,231,212,.34);
  --paper-2:rgba(239,231,212,.07);--paper-3:rgba(239,231,212,.04);
  --accent:#E89CB1;--accent-soft:rgba(232,156,177,.16);--accent-ink:#243A21}
.t-forest .c-eyebrow{color:#E89CB1}
/* pink italic emphasis — at most one phrase per slide */
.t-em{font-style:italic;color:#C4647E}
.t-forest .t-em{color:#E89CB1}
/* quiet evidence note — one implication under an exhibit */
.t-quiet{background:var(--paper-2);border-left:4px solid var(--accent);
  padding:calc(var(--sp)*.9) calc(var(--sp)*1.1)}
.t-quiet b{display:block;font:500 calc(var(--fs)*.68)/1 var(--font-mono);letter-spacing:.16em;
  text-transform:uppercase;color:var(--accent);margin-bottom:calc(var(--sp)*.5)}
.t-quiet p{margin:0;font-size:calc(var(--fs)*.94);line-height:1.55;color:var(--ink)}
/* season/section label used on dividers */
.t-season{font:500 calc(var(--fs)*.72)/1 var(--font-mono);letter-spacing:.3em;
  text-transform:uppercase;color:var(--ink-3)}
```

## Slide grammar

- Cover (`t-forest`): mono eyebrow with period and team, serif xxl title
  stating the season's headline, one-line subtitle. No textures.
- Content slides open with a mono eyebrow, a serif xl action title, and
  `l-rule`. One composition per slide; generous space is part of the look.
- The workhorse is `l-2a`/`l-2b`: chart or table on the wide side, a
  `t-quiet` note or a short bolded-lead `c-list` opposite.
- Pink (`t-em`, `--cat-3`, `--signal`) is punctuation, not a theme: one
  italic phrase, one focal series, or one delta — never all three at once.
- Green (`--cat-1`) leads every chart; secondary series take ink and khaki.
- Dividers are `t-forest` with a `t-season` label and a serif claim.
- Closing (`t-forest`) does work: next quarter's commitments with owners.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Fernway Studio',
  docTitle:'Q2 review',
  date:'July 2026',
  source:'Source: Fernway delivery tracker and finance close, Q2 2026.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide t-forest">
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Q2 2026 · Fernway Studio</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:72%">The quarter we stopped <span class="t-em">chasing</span> and started choosing</h1>
    <p class="c-subtitle" data-anim style="max-width:54%">Twelve client engagements, three we declined, and the margin that followed.</p>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Revenue · by engagement type</div>
    <h2 class="c-title c-title--xl" data-anim>Retainers now carry 58% of revenue, up from a third last year</h2>
    <hr class="l-rule" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-chart" id="rev" data-chart="stack" data-height="245" data-pct="true"
             data-labels="Q2 25,Q3 25,Q4 25,Q1 26,Q2 26"
             data-series='[{"name":"Retainers","values":[34,39,45,52,58],"color":"var(--cat-1)"},{"name":"Projects","values":[54,49,44,38,33],"color":"var(--cat-4)"},{"name":"Workshops","values":[12,12,11,10,9],"color":"var(--cat-3)"}]'
             data-alt="Retainer revenue grew from 34 to 58 percent of the mix across five quarters while project work fell from 54 to 33 percent."></div>
        <div class="c-legend" data-legend-for="rev"></div>
      </div>
      <div class="t-quiet" data-anim>
        <b>What it means</b>
        <p>Recurring work absorbed the spring slowdown that hurt us last year — <span class="t-em">the calmer pipeline is a choice, not luck</span>.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: finance close, Q2 2026"></footer>
</section>
```
