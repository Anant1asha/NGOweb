---
name: Consulting Report
slug: consulting-report
scheme: light
fonts: none
---

# Consulting Report

Enterprise analytical reporting: Helvetica everywhere, white report surfaces
with deep-navy bookends, near-black action titles, and one disciplined blue
carrying the analysis. Lime appears on the cover title and almost nowhere
else. Flat panels, hairline rules, complete legends — evidence without
theatre.

**Use for:** Market research, operating reviews, financial analysis, benchmarks, surveys, KPI reporting, segment comparisons, chart-led quantitative recommendations.
**Avoid for:** Sparse keynote storytelling, expressive brand work, or decks whose argument outweighs their data (use strategy-consulting).

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#12181F; --ink-2:#4A4A4A; --ink-3:#8C8C8C;
  --paper:#FFFFFF; --paper-2:#F2F4F7; --paper-3:#F8F9FB;
  --rule:#DCDCDC; --rule-2:#BFBFBF;
  --accent:#2F6FED; --accent-ink:#FFFFFF; --accent-soft:#DCEAFE;
  --signal:#12181F; --ok:#1F7A4C; --warn:#8C8C8C;
  --cat-1:#2F6FED; --cat-2:#12181F; --cat-3:#BFBFBF; --cat-4:#C9D94A; --cat-5:#0B1C2C; --cat-6:#8C8C8C;
  --app-bg:#E3E6EA;
  --font-display:"Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-body:"Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:ui-monospace,SFMono-Regular,Menlo,monospace;
  --radius:0px;
}
.c-title{letter-spacing:-.025em;font-weight:700}
.c-title--xl{line-height:1.06}
/* navy bookends — cover and closing slides only */
.sheet--slide.t-navy{background:#0B1C2C;color:#FFFFFF;--ink:#FFFFFF;--ink-2:#C7D3E2;--ink-3:#8FA3B8;
  --rule:rgba(255,255,255,.18);--paper-2:rgba(255,255,255,.06);--paper-3:rgba(255,255,255,.04);
  --accent:#C9D94A;--accent-soft:rgba(201,217,74,.14);--accent-ink:#0B1C2C}
.t-navy .c-title--xxl{color:#C9D94A}
/* insight banner — one implication attached to a chart */
.t-insight{background:#DCEAFE;border-left:6px solid #2F6FED;padding:calc(var(--sp)*.9) calc(var(--sp)*1.1)}
.t-insight b{display:block;font:700 calc(var(--fs)*.72)/1 var(--font-body);letter-spacing:.14em;
  text-transform:uppercase;color:#2F6FED;margin-bottom:calc(var(--sp)*.5)}
.t-insight p{margin:0;font-size:calc(var(--fs)*.95);line-height:1.5;color:#12181F}
/* dark spotlight — rare, one decisive number */
.t-spot{background:#0F1E30;color:#FFFFFF;padding:calc(var(--sp)*1.1)}
.t-spot b{display:block;font:700 calc(var(--fs)*.72)/1 var(--font-body);letter-spacing:.14em;
  text-transform:uppercase;color:#C9D94A;margin-bottom:calc(var(--sp)*.5)}
.t-spot p{margin:0;font-size:calc(var(--fs)*.95);line-height:1.5;color:#C7D3E2}
/* numbered priority cards — identical treatment for every peer */
.t-prio{background:#FFFFFF;border:1px solid #DCDCDC;border-top:6px solid #2F6FED;
  padding:calc(var(--sp)*1) calc(var(--sp)*1.1)}
.t-prio i{display:block;font-style:normal;font-weight:700;color:#2F6FED;
  font-size:calc(var(--fs)*1.4);margin-bottom:calc(var(--sp)*.5);font-variant-numeric:tabular-nums}
.t-prio b{display:block;font-size:calc(var(--fs)*1);margin-bottom:calc(var(--sp)*.4)}
.t-prio p{margin:0;font-size:calc(var(--fs)*.86);line-height:1.5;color:#4A4A4A}
```

## Slide grammar

- Cover and closing are the only navy slides (`t-navy`): lime xxl title, white
  subtitle, `c-metagrid--light` for client · engagement · date. No chart
  graphics or textures on the cover.
- Every content slide: eyebrow section label, xl **action title stating the
  finding** ("Enterprise expansion lifts recurring revenue while preserving
  margin", never "Revenue analysis"), `l-rule--strong`, one composition.
- Chart-plus-insight is the workhorse: `l-2a` with the chart (title in
  `c-panel__label`, unit declared, legend if multi-series) and a `t-insight`
  banner carrying exactly one implication.
- KPI strips are `c-statrow--bare`: 72-point peer values, one blue focal
  metric at most, everything else ink. No red for negative — a minus sign and
  ink is the house style (`--signal` is ink on purpose).
- Vary chart families across the deck — trend `line`, ranking `hbars`,
  comparison `bars`, mix `donut`/`stack` — chosen by the question each slide
  answers. Series order: blue, ink, gray, lime, navy (`--cat-1…5`).
- Priorities close the deck: one grid of identical `t-prio` cards (same fill,
  same blue top rule, ≤22 words each), count matching the action title.
- Lime belongs to the cover title, the spotlight label, and at most one
  stable fourth series. Never use it as a general accent. No shadows,
  gradients, 3D, or decorative textures anywhere.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  brand:    'Sarvam Co-Work',
  org:      'Advisory · Strategy & Operations',
  client:   'Client name',
  docTitle: 'Operating review',
  date:     'July 2026',
  source:   'Source: client finance extract, June 2026',
  slideFooter: { left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are reference compositions. Adapt their structure and rhythm; replace
every word, number, and id with the actual content.

```html
<section class="sheet sheet--slide t-navy">
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow c-eyebrow--muted" data-anim="fade">Operating review · FY26 H1</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:16ch">Service margin held while volume grew 23%</h1>
    <p class="c-subtitle" data-anim>Half-year evidence across four regions, with three priorities for H2.</p>
    <dl class="c-metagrid c-metagrid--light" style="--cols:3;max-width:60%" data-anim>
      <div><dt>Client</dt><dd>Northgate Logistics</dd></div>
      <div><dt>Engagement</dt><dd>NGL-1188</dd></div>
      <div><dt>Date</dt><dd>July 2026</dd></div>
    </dl>
  </div>
  <footer class="sheet__foot" data-foot data-l="Advisory · Operating review" data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Volume · Exhibit 2</div>
    <h2 class="c-title c-title--xl" data-anim>Two corridors carry the entire H1 volume gain</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-panel__label"><span>Shipment growth by corridor</span><span>H1 FY26 vs H1 FY25</span></div>
        <div class="c-chart" id="ex2" data-chart="hbars" data-height="230" data-unit="%"
             data-labels="West–North,North–East,South hub,East–West,Intra-metro"
             data-series='[{"name":"Growth","values":[38,31,9,4,2]}]'
             data-alt="West–North and North–East corridors grew 38 and 31 percent; all others under 10"></div>
        <p class="c-figure__caption">West–North and North–East account for 87% of net new shipments.</p>
      </div>
      <div class="l-stack">
        <ul class="c-list">
          <li><b>Capacity, not demand, is the ceiling.</b> Both growth corridors ran above 92% fleet utilisation from March.</li>
          <li><b>The south hub is flat by design.</b> Contract renewals were deliberately deferred to Q3.</li>
        </ul>
        <div class="t-insight l-end">
          <b>Implication</b>
          <p>H2 capex should follow the two proven corridors before any new-lane investment.</p>
        </div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Recommendations</div>
    <h2 class="c-title c-title--xl" data-anim>Three priorities protect the margin through H2</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="l-cols l-3" data-anim>
      <div class="t-prio"><i>01</i><b>Re-price the two growth corridors</b>
        <p>Index rates to the June fuel baseline; recovers an estimated ₹9 cr annualised.</p></div>
      <div class="t-prio"><i>02</i><b>Gate sub-scale lanes</b>
        <p>Hold new lanes to a 70% utilisation hurdle before dedicated fleet is assigned.</p></div>
      <div class="t-prio"><i>03</i><b>Advance the south-hub renewals</b>
        <p>Close Q3 renewals in August while service scores are at their peak.</p></div>
    </div>
    <div class="c-statrow c-statrow--bare" style="--cols:3;margin-top:calc(var(--sp)*1.4)" data-anim>
      <div class="c-stat"><span class="c-stat__label">Margin protected</span>
        <b class="c-stat__value" data-count="14" data-prefix="₹" data-suffix=" cr" data-dec="0">₹14 cr</b>
        <span class="c-stat__note">Annualised, midpoint of the three moves</span></div>
      <div class="c-stat"><span class="c-stat__label">Decision needed by</span>
        <b class="c-stat__value">Aug 15</b>
        <span class="c-stat__note">To land re-pricing inside the Q3 billing cycle</span></div>
      <div class="c-stat"><span class="c-stat__label">Net new headcount</span>
        <b class="c-stat__value">0</b>
        <span class="c-stat__note">All three moves run with the current team</span></div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Assessment: advisory scoring, July 2026"></footer>
</section>
```
