---
name: Education Teaching
slug: education-teaching
scheme: mixed
fonts: https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Source+Sans+3:ital,wght@0,400;0,600;0,700;1,400&display=swap
---

# Education Teaching

A lesson that teaches, not a lecture that scrolls: Outfit display, Source Sans body, teal board slides, amber emphasis, worked examples in steps, named misconceptions, live checks for understanding, and an exit ticket. Built around predict → try → check → explain.

**Use for:** Lessons, lectures, workshops, training, guided demonstrations, worked examples, knowledge checks.
**Avoid for:** Board reporting, investor pitching, passive read-out decks with no facilitation intent.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#16211F; --ink-2:#425049; --ink-3:#77857E;
  --paper:#FBFCFB; --paper-2:#EDF3F1; --paper-3:#F5F9F7;
  --rule:#D7E1DD; --rule-2:#BACAC4;
  --accent:#0F6E63; --accent-ink:#FFFFFF; --accent-soft:#E6F2F0;
  --signal:#C4562F; --ok:#2E8B57; --warn:#E0A32E;
  --cat-1:#0F6E63; --cat-2:#E0A32E; --cat-3:#4E8FA8; --cat-4:#C4562F; --cat-5:#7BA894; --cat-6:#CFDDD8;
  --app-bg:#DFE6E3;
  --font-display:"Outfit","Helvetica Neue",Arial,sans-serif;
  --font-body:"Source Sans 3","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:"Outfit",Arial,sans-serif;
  --radius:8px;
}
.c-title{letter-spacing:-.02em}
.e-math{font-family:"Source Sans 3",Georgia,serif;font-style:italic;font-size:1.06em}
.e-math sub,.e-math sup{font-style:normal}
/* lesson header strip */
.e-head{display:flex;align-items:center;gap:calc(var(--sp)*1);background:var(--accent);color:#fff;
  border-radius:var(--radius);padding:calc(var(--sp)*.9) calc(var(--sp)*1.2)}
.e-head b{font-family:var(--font-display);font-weight:700;font-size:calc(var(--fs)*1.15)}
.e-head span{font-size:calc(var(--fs)*.86);opacity:.9}
.e-head .sep{width:1px;align-self:stretch;background:rgba(255,255,255,.35)}
.e-head .r{margin-left:auto;text-align:right}
/* learning objectives — the box that tells you what to write */
.e-obj{border:2px solid var(--accent);border-radius:var(--radius);padding:calc(var(--sp)*1) calc(var(--sp)*1.2);
  background:var(--accent-soft)}
.e-obj > b{display:block;font:600 calc(var(--fs)*.74)/1 var(--font-body);letter-spacing:.14em;text-transform:uppercase;
  color:var(--accent);margin-bottom:calc(var(--sp)*.4)}
.e-obj > i{display:block;font-style:italic;font-size:calc(var(--fs)*.9);color:var(--ink-2);margin-bottom:calc(var(--sp)*.7)}
.e-obj ol{margin:0;padding-left:calc(var(--fs)*1.5);counter-reset:eo;list-style:none}
.e-obj li{counter-increment:eo;position:relative;font-size:calc(var(--fs)*.98);line-height:1.5;
  margin-bottom:calc(var(--sp)*.45);color:var(--ink)}
.e-obj li::before{content:counter(eo);position:absolute;left:calc(var(--fs)*-1.5);top:.12em;
  width:calc(var(--fs)*1.05);height:calc(var(--fs)*1.05);border-radius:50%;background:var(--accent);color:#fff;
  font:700 calc(var(--fs)*.68)/calc(var(--fs)*1.05) var(--font-display);text-align:center}
.e-obj li b{font-weight:700}
/* key terms */
.e-terms{display:grid;grid-template-columns:repeat(var(--cols,2),1fr);gap:calc(var(--sp)*.7)}
.e-term{border-left:3px solid var(--cat-2);background:var(--paper-2);border-radius:0 var(--radius) var(--radius) 0;
  padding:calc(var(--sp)*.7) calc(var(--sp)*.9)}
.e-term b{display:block;font-family:var(--font-display);font-weight:600;font-size:calc(var(--fs)*.98)}
.e-term span{font-size:calc(var(--fs)*.84);line-height:1.45;color:var(--ink-2)}
/* worked example */
.e-eg{border:1px solid var(--rule);border-radius:var(--radius);overflow:hidden}
.e-eg__hd{background:var(--ink);color:#fff;padding:calc(var(--sp)*.65) calc(var(--sp)*1.1);
  font:600 calc(var(--fs)*.78)/1.3 var(--font-body);letter-spacing:.1em;text-transform:uppercase;display:flex}
.e-eg__hd span{margin-left:auto;letter-spacing:.02em;text-transform:none;opacity:.75;font-weight:400}
.e-eg__bd{padding:calc(var(--sp)*1)}
.e-step{display:grid;grid-template-columns:calc(var(--fs)*1.6) 1fr;gap:calc(var(--sp)*.8);
  padding:calc(var(--sp)*.55) 0;border-bottom:1px dashed var(--rule)}
.e-step:last-child{border-bottom:0}
.e-step__n{width:calc(var(--fs)*1.6);height:calc(var(--fs)*1.6);border-radius:50%;border:1.5px solid var(--accent);
  color:var(--accent);font:700 calc(var(--fs)*.76)/calc(var(--fs)*1.5) var(--font-display);text-align:center}
.e-step p{margin:0;font-size:calc(var(--fs)*.95);line-height:1.5;color:var(--ink-2)}
.e-step p b{color:var(--ink)}
.e-step em{display:block;font-style:normal;font-size:calc(var(--fs)*.8);color:var(--accent);margin-top:.25em}
.e-work{font-family:"Source Sans 3",Georgia,serif;font-size:calc(var(--fs)*1.05);color:var(--ink);
  background:var(--paper-3);border-radius:4px;padding:calc(var(--sp)*.45) calc(var(--sp)*.7);
  display:inline-block;margin-top:.3em}
/* misconception */
.e-miss{border:1px dashed var(--signal);border-radius:var(--radius);padding:calc(var(--sp)*1);
  background:color-mix(in srgb,var(--signal) 6%,var(--paper))}
.e-miss b{display:block;font:600 calc(var(--fs)*.74)/1 var(--font-body);letter-spacing:.14em;text-transform:uppercase;
  color:var(--signal);margin-bottom:calc(var(--sp)*.6)}
.e-miss .wrong{text-decoration:line-through;text-decoration-color:var(--signal);color:var(--ink-3)}
.e-miss .right{color:var(--ok);font-weight:600}
.e-miss p{margin:0;font-size:calc(var(--fs)*.94);line-height:1.5;color:var(--ink-2)}
.e-miss p+p{margin-top:calc(var(--sp)*.5)}
/* your turn */
.e-turn{border:1px solid var(--rule);border-top:3px solid var(--cat-2);border-radius:0 0 var(--radius) var(--radius);
  padding:calc(var(--sp)*1)}
.e-turn b{display:block;font:600 calc(var(--fs)*.74)/1 var(--font-body);letter-spacing:.14em;text-transform:uppercase;
  color:var(--warn);margin-bottom:calc(var(--sp)*.6)}
.e-turn ol{margin:0;padding-left:calc(var(--fs)*1.3);font-size:calc(var(--fs)*.95);line-height:1.7;color:var(--ink-2)}
.e-turn ol li{margin-bottom:calc(var(--sp)*.35)}
.e-turn .ans{font-size:calc(var(--fs)*.78);color:var(--ink-3);border-top:1px dashed var(--rule);
  margin-top:calc(var(--sp)*.7);padding-top:calc(var(--sp)*.5)}
/* teacher note */
.e-note{background:var(--paper-2);border-radius:var(--radius);padding:calc(var(--sp)*.8) calc(var(--sp)*.95)}
.e-note b{display:block;font:600 calc(var(--fs)*.7)/1 var(--font-body);letter-spacing:.13em;text-transform:uppercase;
  color:var(--ink-3);margin-bottom:calc(var(--sp)*.45)}
.e-note p{margin:0;font-size:calc(var(--fs)*.84);line-height:1.48;color:var(--ink-2)}
/* timing plan */
.e-timing{display:grid;grid-template-columns:auto 1fr;gap:0 calc(var(--sp)*1)}
.e-timing dt{font-family:var(--font-display);font-weight:600;font-size:calc(var(--fs)*.88);color:var(--accent);
  font-variant-numeric:tabular-nums;padding:calc(var(--sp)*.42) 0;border-top:1px solid var(--rule);white-space:nowrap}
.e-timing dd{margin:0;font-size:calc(var(--fs)*.92);line-height:1.45;color:var(--ink-2);
  padding:calc(var(--sp)*.42) 0;border-top:1px solid var(--rule)}
.e-timing dd b{color:var(--ink);font-weight:600}
/* exit ticket */
.e-exit{border:2px dashed var(--accent);border-radius:var(--radius);padding:calc(var(--sp)*1);
  background:var(--paper-3)}
.e-exit b{display:block;font-family:var(--font-display);font-weight:700;font-size:calc(var(--fs)*1.05);
  color:var(--accent);margin-bottom:calc(var(--sp)*.5)}
.e-exit ol{margin:0;padding-left:calc(var(--fs)*1.3);font-size:calc(var(--fs)*.94);line-height:1.9;color:var(--ink-2)}
.e-rule{border-bottom:1px solid var(--rule-2);display:inline-block;min-width:8ch}
/* interactive slider widget */
.e-slider{display:flex;align-items:center;gap:calc(var(--sp)*.8);margin-top:calc(var(--sp)*.8);
  font-size:calc(var(--fs)*.86);color:var(--ink-2)}
.e-slider input[type=range]{flex:1;accent-color:var(--accent);height:calc(var(--fs)*1)}
.e-slider output{font-family:var(--font-display);font-weight:700;color:var(--accent);
  font-variant-numeric:tabular-nums;min-width:7ch;text-align:right}
.e-readout{display:flex;gap:calc(var(--sp)*1.2);margin-top:calc(var(--sp)*.8);flex-wrap:wrap}
.e-readout div{background:var(--paper-2);border-radius:var(--radius);padding:calc(var(--sp)*.55) calc(var(--sp)*.85)}
.e-readout dt{font:600 calc(var(--fs)*.68)/1 var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--ink-3)}
.e-readout dd{margin:.3em 0 0;font-family:var(--font-display);font-weight:700;font-size:calc(var(--fs)*1.3);
  color:var(--ink);font-variant-numeric:tabular-nums}
.e-readout dd.hit{color:var(--accent)}
/* poll / check for understanding */
.e-poll{display:grid;gap:calc(var(--sp)*.6)}
.e-poll button{appearance:none;text-align:left;font:inherit;font-size:calc(var(--fs)*.98);cursor:pointer;
  background:var(--paper);border:1.5px solid var(--rule);border-radius:var(--radius);
  padding:calc(var(--sp)*.7) calc(var(--sp)*1);color:var(--ink-2);display:flex;gap:calc(var(--sp)*.8);
  transition:border-color .15s,background .15s,color .15s}
.e-poll button:hover{border-color:var(--accent);color:var(--ink)}
.e-poll button i{font-style:normal;font-family:var(--font-display);font-weight:700;color:var(--accent)}
.e-poll button.is-right{border-color:var(--ok);background:color-mix(in srgb,var(--ok) 10%,var(--paper));color:var(--ink)}
.e-poll button.is-wrong{border-color:var(--signal);background:color-mix(in srgb,var(--signal) 8%,var(--paper))}
.e-poll button .why{margin-left:auto;font-size:calc(var(--fs)*.8);opacity:0;transition:opacity .2s}
.e-poll button.is-right .why,.e-poll button.is-wrong .why{opacity:1}
.sheet--slide.e-board{background:#0F6E63;color:#F2F8F6;--ink:#F2F8F6;--ink-2:#C9E1DC;--ink-3:#9DC4BC;
  --rule:rgba(255,255,255,.22);--accent:#E0A32E;--accent-soft:rgba(224,163,46,.16);--paper-2:rgba(255,255,255,.09)}
```

## Slide grammar

- Cover on the teal board (`e-board`): course eyebrow, title naming the skill learners leave with, `e-head` strip with level · duration · materials.
- Objectives early, in an `e-obj` box — two or three, each starting with an observable verb (compute, sketch, explain). Key terms as `e-terms`/`e-term` cards.
- Worked example: `e-eg` frame, `e-eg__hd` title bar, then `e-step` rows — instruction in prose, working in `e-work`, the why in the `em` line. One concept per example.
- Name the trap with `e-miss`: the `wrong` strikethrough belief next to the `right` correction. Then hand it over: `e-turn` practice items with the answer under the dashed `ans` rule.
- Check understanding live: `e-poll` buttons (`data-poll`, `data-right` on the correct one — the theme's deck script wires marking), or the `e-slider` widget pattern for parameter exploration; adapt its readout logic, keep its structure.
- Amber highlights the moment of insight; teal owns structure. End with an `e-exit` ticket of two or three questions. Timing (`e-timing`) belongs in handouts, not on teaching slides.

## Deck script (includes this template’s widget wiring)

Adapt the values; keep the structure. This template ships widget script beyond `Doc.init` — include it after the core script and adapt its data, not its wiring.

```js
Doc.init({
  org:'Mathematics Department',
  docTitle:'Unit 4 · Lesson 1 — Introducing the derivative',
  author:'Prepared for Year 12',
  date:'Autumn term 2026',
  source:'Lesson materials — adapt freely for your class',
  footer:{ left:'{docTitle}', center:'{madeWith}', right:'{page} / {pages}' },
  slideFooter:{ left:'{org}', center:'{madeWith}', right:'{page} / {pages}' }
});

/* ---- interactive: secant becoming a tangent ---- */
window.addEventListener('DOMContentLoaded', function(){
  var svg=document.getElementById('secant'); if(!svg) return;
  var X0=44, Y0=210, SX=92, SY=11.5;               // origin and units→px
  var fx=function(x){ return x*x; };
  var px=function(x){ return X0 + x*SX; };
  var py=function(y){ return Y0 - y*SY; };
  var d='', first=true;
  for(var x=0;x<=4.5;x+=0.05){ if(py(fx(x))<14) break; d+=(first?'M':'L')+px(x).toFixed(1)+' '+py(fx(x)).toFixed(1); first=false; }
  document.getElementById('curve').setAttribute('d',d);
  var g='';
  for(var i=1;i<=4;i++){ g+='M'+px(i)+' 12 V210 '; }
  document.getElementById('gridv').setAttribute('d',g);

  var a=2, chord=document.getElementById('chord'), tang=document.getElementById('tang'),
      pA=document.getElementById('pA'), pB=document.getElementById('pB'),
      labA=document.getElementById('labA'), labB=document.getElementById('labB'),
      rise=document.getElementById('rise'),
      out=document.getElementById('hOut'), gOut=document.getElementById('gOut'),
      range=document.getElementById('hRange');

  function extend(x1,y1,x2,y2,el){
    var m=(y2-y1)/(x2-x1||1e-9);
    el.setAttribute('x1',X0); el.setAttribute('y1',y1+m*(X0-x1));
    el.setAttribute('x2',470); el.setAttribute('y2',y1+m*(470-x1));
  }
  function draw(h){
    var b=a+h, ya=fx(a), yb=fx(b), grad=(yb-ya)/h;
    pA.setAttribute('cx',px(a)); pA.setAttribute('cy',py(ya));
    pB.setAttribute('cx',px(b)); pB.setAttribute('cy',py(yb));
    labA.setAttribute('x',px(a)-44); labA.setAttribute('y',py(ya)+16);
    labB.setAttribute('x',px(b)+8);  labB.setAttribute('y',py(yb)-6);
    labB.textContent='B ('+b.toFixed(2)+', '+yb.toFixed(2)+')';
    extend(px(a),py(ya),px(b),py(yb),chord);
    extend(px(a),py(ya),px(a+1),py(ya+4),tang);
    rise.innerHTML='<path d="M'+px(a)+' '+py(ya)+' V'+py(yb)+' H'+px(b)+'"/>';
    out.textContent='h = '+h.toFixed(2);
    gOut.textContent=grad.toFixed(2);
    gOut.classList.toggle('hit', Math.abs(grad-4)<0.05);
  }
  range.addEventListener('input',function(){ draw(Math.max(0.01, this.value/100)); });
  draw(2);
});

/* ---- interactive: check-for-understanding poll ---- */
window.addEventListener('DOMContentLoaded', function(){
  var poll=document.getElementById('poll'); if(!poll) return;
  poll.addEventListener('click', function(e){
    var b=e.target.closest('button'); if(!b) return;
    [].forEach.call(poll.children, function(c){
      c.classList.toggle('is-right', c.dataset.ok==='1');
      c.classList.toggle('is-wrong', c===b && c.dataset.ok!=='1');
    });
  });
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide e-board">
  <div class="k-bgfx k-bgfx--dots" style="color:#E0A32E"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Unit 4 · Lesson 1 of 6</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:70%">How fast is it changing <em style="color:#E0A32E">right now</em>?</h1>
    <p class="c-subtitle" data-anim style="max-width:52%;color:#C9E1DC">Average speed over a second is easy. Speed at exactly one second is the whole unit.</p>
    <div class="c-chips" data-anim style="margin-top:calc(var(--sp)*1.6)">
      <span class="c-chip" style="border-color:rgba(255,255,255,.3);color:#C9E1DC">Chord</span>
      <span class="c-chip" style="border-color:rgba(255,255,255,.3);color:#C9E1DC">Tangent</span>
      <span class="c-chip" style="border-color:rgba(255,255,255,.3);color:#C9E1DC">Limit</span>
      <span class="c-chip" style="border-color:rgba(255,255,255,.3);color:#C9E1DC">Derivative</span>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Year 12 Mathematics"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Guided exploration · drag the slider</div>
    <h2 class="c-title c-title--xl" data-anim>Slide the second point towards the first and watch the gradient settle</h2>
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*.9)">
      <div>
        <svg id="secant" data-noqa viewBox="0 0 480 230" role="img" aria-label="A curve with a chord that becomes a tangent" style="width:100%;height:auto;display:block;background:var(--paper-3);border-radius:8px">
          <g stroke="var(--rule)" stroke-width="1">
            <path d="M44 12 V210 M44 210 H466" stroke="var(--ink-3)"/>
            <path id="gridv" d="" opacity=".5"/>
          </g>
          <path id="curve" fill="none" stroke="var(--cat-1)" stroke-width="2.5"/>
          <line id="chord" stroke="var(--cat-2)" stroke-width="2.5"/>
          <line id="tang" stroke="var(--ink-3)" stroke-width="1.5" stroke-dasharray="5 4"/>
          <g id="rise" stroke="var(--ink-3)" stroke-width="1" stroke-dasharray="3 3"></g>
          <circle id="pA" r="5" fill="var(--cat-1)"/>
          <circle id="pB" r="5" fill="var(--cat-2)"/>
          <text id="labA" font-size="11" fill="var(--ink-2)">A (2, 4)</text>
          <text id="labB" font-size="11" fill="var(--cat-2)">B</text>
        </svg>
        <label class="e-slider">Move B closer to A
          <input id="hRange" type="range" min="1" max="200" value="200" aria-label="Distance h between the two points">
          <output id="hOut">h = 2.00</output>
        </label>
      </div>
      <div>
        <dl class="e-readout">
          <div><dt>Gradient of chord AB</dt><dd id="gOut">6.00</dd></div>
          <div><dt>Gradient of tangent at A</dt><dd class="hit">4.00</dd></div>
        </dl>
        <div class="c-callout c-callout--insight" style="margin-top:calc(var(--sp)*1)"><span class="c-callout__label">Record as you go</span>
          <p>Write down the chord gradient for <span class="e-math">h</span> = 2, 1, 0.5, 0.1 and 0.01. What number is it heading for? Does it ever get there?</p></div>
        <div class="e-miss" style="margin-top:calc(var(--sp)*.9)">
          <b>Predict before you drag</b>
          <p>Will the chord gradient be bigger or smaller than the tangent gradient? Commit to an answer with the person next to you before moving the slider.</p>
        </div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="f(x) = x²  ·  point A at x = 2"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Worked example · five steps, every time</div>
    <h2 class="c-title c-title--xl" data-anim>Find the gradient of <span class="e-math">f(x) = x²</span> at <span class="e-math">x</span> = 2</h2>
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*.9)">
      <div class="e-eg" style="border:0">
        <div class="e-eg__bd" style="padding:0">
          <div class="e-step"><div class="e-step__n">1</div><p><b>Two points.</b><span class="e-work">f(2) = 4 · f(2+h) = (2+h)²</span></p></div>
          <div class="e-step"><div class="e-step__n">2</div><p><b>Expand.</b><span class="e-work">(2+h)² = 4 + 4h + h²</span></p></div>
          <div class="e-step"><div class="e-step__n">3</div><p><b>Gradient fraction.</b><span class="e-work">(4h + h²) ÷ h</span></p></div>
          <div class="e-step"><div class="e-step__n">4</div><p><b>Cancel — h is not zero yet.</b><span class="e-work">= 4 + h</span></p></div>
          <div class="e-step"><div class="e-step__n">5</div><p><b>Let h → 0.</b><span class="e-work" style="background:var(--accent-soft);color:var(--accent);font-weight:700">f′(2) = 4</span></p></div>
        </div>
      </div>
      <div>
        <div class="e-miss"><b>The mistake to avoid</b>
          <p><span class="wrong">Setting h = 0 at step 3.</span></p>
          <p>That gives <span class="e-math">0 ÷ 0</span>, which is not a number. <span class="right">Simplify first, cancel, then let h go.</span></p></div>
        <div class="e-turn" style="margin-top:calc(var(--sp)*.9)"><b>Your turn — two minutes, in pairs</b>
          <ol><li>Gradient of <span class="e-math">x²</span> at <span class="e-math">x</span> = 5</li>
              <li>Gradient of <span class="e-math">x² + 3</span> at <span class="e-math">x</span> = 2</li></ol></div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Unit 4 · Lesson 1"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Check for understanding · click an answer</div>
    <h2 class="c-title c-title--xl" data-anim>If <span class="e-math">f′(3) = 7</span>, what does that tell us?</h2>
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*1)">
      <div class="e-poll" id="poll">
        <button data-ok="0"><i>A</i><span>The curve passes through the point (3, 7).</span><span class="why">Confuses the value with the gradient</span></button>
        <button data-ok="1"><i>B</i><span>At <span class="e-math">x</span> = 3 the curve is rising at 7 units for every 1 unit across.</span><span class="why">Correct</span></button>
        <button data-ok="0"><i>C</i><span>The gradient of the chord from 3 to 7 is 1.</span><span class="why">Chord, not tangent</span></button>
        <button data-ok="0"><i>D</i><span>The curve has a maximum at <span class="e-math">x</span> = 7.</span><span class="why">A maximum needs f′ = 0</span></button>
      </div>
      <div class="e-exit">
        <b>Exit ticket</b>
        <ol>
          <li>In one sentence: what does <span class="e-math">f′(3) = 7</span> tell you?</li>
          <li>Chord gradient from <span class="e-math">x</span>=1 to <span class="e-math">x</span>=1.1 on <span class="e-math">y = x²</span>?</li>
          <li>One thing you are still unsure about.</li>
        </ol>
        <p class="c-source" style="margin-top:calc(var(--sp)*.8)">Hand in at the door. Homework: Exercise 4A, questions 1–6, and 7 if you want the stretch.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Unit 4 · Lesson 1"></footer>
</section>
```
