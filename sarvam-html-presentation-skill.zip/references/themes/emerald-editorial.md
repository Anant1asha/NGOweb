---
name: Emerald Editorial
slug: emerald-editorial
scheme: mixed
fonts: https://fonts.googleapis.com/css2?family=Bodoni+Moda:opsz,wght@6..96,700;6..96,900&family=Manrope:wght@400;600;700&display=swap
---

# Emerald Editorial

Magazine-cover business deck (adapted from the MIT-licensed "Emerald
Editorial" system): vivid emerald surfaces, deep navy ink, warm cream paper,
a heavy Bodoni display serif over Manrope, and double-rule masthead
ornaments. Confident and graphic — a business review that looks like it was
art-directed.

**Use for:** Business reviews with presence — growth stories, product and
brand performance readouts, offsite keynotes, launch retrospectives, work
that should feel editorial and assured.
**Avoid for:** Sober audit or policy contexts, dense analytical deep-dives
(insight-deepdive), or engineering reviews (technical-systems).

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#0F1A5C; --ink-2:#1B2774; --ink-3:#5A64A8;
  --paper:#F1E9D6; --paper-2:#E7DEC5; --paper-3:#F5EFDF;
  --rule:rgba(15,26,92,.22); --rule-2:rgba(15,26,92,.85);
  --accent:#1FA36B; --accent-ink:#F1E9D6; --accent-soft:#D8F2E4;
  --signal:#C24141; --ok:#1E8E5A; --warn:#B7791F;
  --cat-1:#0F1A5C; --cat-2:#2DC684; --cat-3:#8A93C9; --cat-4:#B9AA82; --cat-5:#25B377; --cat-6:#CFC7AC;
  --app-bg:#E4DCC6;
  --font-display:"Bodoni Moda",Didot,"Playfair Display",serif;
  --font-body:"Manrope","Helvetica Neue",Arial,sans-serif;
  --font-mono:ui-monospace,SFMono-Regular,Menlo,monospace;
  --radius:0px;
}
.c-title{font-weight:900;letter-spacing:.002em}
.c-title--xxl{line-height:1.02}
.c-eyebrow{letter-spacing:.24em;color:var(--ink)}
.c-stat__value{font-family:var(--font-display);font-weight:900;letter-spacing:0}
/* emerald cover/divider canvas */
.sheet--slide.t-emerald{background:#3CD896;color:#0F1A5C;
  --paper-2:rgba(15,26,92,.08);--paper-3:rgba(15,26,92,.05);
  --rule:rgba(15,26,92,.3);--rule-2:rgba(15,26,92,.85);
  --accent:#0F1A5C;--accent-ink:#3CD896;--accent-soft:rgba(15,26,92,.1)}
/* masthead — double rule above and below a centered label */
.t-masthead{text-align:center;border-top:3px solid var(--rule-2);border-bottom:1px solid var(--rule-2);
  padding:calc(var(--sp)*.55) 0;font:700 calc(var(--fs)*.72)/1 var(--font-body);
  letter-spacing:.3em;text-transform:uppercase}
/* issue folio — small numbered corner label */
.t-folio{font:700 calc(var(--fs)*.66)/1.4 var(--font-body);letter-spacing:.2em;
  text-transform:uppercase;color:var(--ink-3)}
/* verdict banner — the editorial one-liner under an exhibit */
.t-verdict{border-top:3px solid var(--rule-2);padding-top:calc(var(--sp)*.8)}
.t-verdict b{display:block;font:700 calc(var(--fs)*.68)/1 var(--font-body);letter-spacing:.22em;
  text-transform:uppercase;color:var(--accent);margin-bottom:calc(var(--sp)*.45)}
.t-verdict p{margin:0;font-family:var(--font-display);font-weight:700;
  font-size:calc(var(--fs)*1.18);line-height:1.35;color:var(--ink)}
```

## Slide grammar

- Cover (`t-emerald`): `t-masthead` with the organisation and period, then a
  massive Bodoni xxl title stating the year's claim, and a one-line
  standfirst. The emerald canvas appears only on cover, dividers, closing.
- Content slides on cream: eyebrow, Bodoni xl action title, `l-rule`, one
  composition. Navy leads every chart; emerald is the second series and the
  focal highlight.
- The signature move is the `t-verdict`: a Bodoni one-liner under the
  evidence carrying the editorial judgement. At most one per slide.
- Stat rows use `c-statrow--bare`; values render in Bodoni via the theme.
  Keep peer numbers identical in treatment, one emerald focal number at most.
- Dividers (`t-emerald`) carry a `t-folio` chapter number and a short claim.
- Closing (`t-emerald`) states the asks with owners and dates.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Verdant & Main',
  docTitle:'FY26 in review',
  date:'July 2026',
  source:'Source: Verdant & Main management accounts, FY26.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide t-emerald">
  <div class="sheet__pad sheet__pad--center">
    <div class="t-masthead" data-anim="fade">Verdant &amp; Main · FY26 review</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:80%;margin-top:calc(var(--sp)*1.4)">The year the stores out-earned the site</h1>
    <p class="c-subtitle" data-anim style="max-width:56%">Twelve months, nine cities, and the retail bet that paid for itself early.</p>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Channel economics · FY26</div>
    <h2 class="c-title c-title--xl" data-anim>Store contribution per order is now double the site's</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-chart" id="chan" data-chart="bars" data-height="240" data-unit="₹/order"
             data-labels="FY24,FY25,FY26"
             data-series='[{"name":"Stores","values":[64,88,124],"color":"var(--cat-2)"},{"name":"Online","values":[71,66,61],"color":"var(--cat-1)"}]'
             data-alt="Store contribution per order rose from 64 to 124 rupees over three years while online fell from 71 to 61."></div>
        <div class="c-legend" data-legend-for="chan"></div>
      </div>
      <div class="t-verdict" data-anim>
        <b>The verdict</b>
        <p>Retail stopped being a marketing expense in FY25 — it is now the margin engine, and FY27 capex should treat it that way.</p>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: management accounts, FY26"></footer>
</section>
```
