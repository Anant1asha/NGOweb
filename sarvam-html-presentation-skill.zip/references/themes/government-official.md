---
name: Government Official
slug: government-official
scheme: light
fonts: https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Public+Sans:wght@400;500;600;700&display=swap
---

# Government Official

Audit-office authority: Libre Baskerville headings, Public Sans utility, deep navy with a single gold rule, numbered findings, and recommendation/response pairs. Every statement reads as if it will be quoted in committee.

**Use for:** Government briefings, public-sector audits, committee evidence, policy findings, programme evaluations, formal accountability reporting.
**Avoid for:** Startup pitches, creative showcases, or anything that should feel promotional.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#1B1B18; --ink-2:#454540; --ink-3:#6F6F68;
  --paper:#FDFDFB; --paper-2:#F0EFE9; --paper-3:#F7F6F1;
  --rule:#CFCBC0; --rule-2:#B3AE9F;
  --accent:#12395B; --accent-ink:#FFFFFF; --accent-soft:#EDF2F7;
  --signal:#8A2226; --ok:#2F6B45; --warn:#A87F2C;
  --cat-1:#12395B; --cat-2:#3E7096; --cat-3:#A87F2C; --cat-4:#8A2226; --cat-5:#6D7C86; --cat-6:#BFCBD4;
  --app-bg:#DFDDD5;
  --font-display:"Libre Baskerville","Iowan Old Style",Georgia,"Times New Roman",serif;
  --font-body:"Public Sans","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:"Public Sans",Arial,sans-serif;
  --radius:0px;
}
.c-title{font-family:var(--font-display);font-weight:700;letter-spacing:0;line-height:1.24}
.c-title--xl{line-height:1.2;letter-spacing:-.008em}
.c-title--xxl{line-height:1.14;letter-spacing:-.012em}
.c-section{font-family:var(--font-display);font-weight:700}
.c-pullquote p{font-family:var(--font-display)}
/* notice banners */
.t-notice{position:absolute;left:0;right:0;top:0;background:var(--accent);color:#fff;z-index:2;
  font:600 calc(var(--fs)*.66)/1 var(--font-body);letter-spacing:.22em;text-transform:uppercase;
  text-align:center;padding:.85cqw 0}
.t-notice--foot{top:auto;bottom:0}
hr.t-gold{border:0;height:2px;background:var(--warn);margin:calc(var(--sp)*1.4) 0 0}
hr.t-gold--thin{height:1px}
.t-crest{display:flex;align-items:center;gap:calc(var(--sp)*1.2);color:var(--accent)}
.t-crest svg{width:calc(var(--fs)*6.6);height:calc(var(--fs)*6.6);flex:0 0 auto}
.t-crest__org{font-family:var(--font-display);font-weight:700;font-size:calc(var(--fs)*1.28);line-height:1.3}
.t-crest__org span{display:block;font-family:var(--font-body);font-weight:500;font-size:calc(var(--fs)*.76);
  letter-spacing:.16em;text-transform:uppercase;color:var(--ink-3);margin-top:.45em}
.t-seal .ring{fill:none;stroke:currentColor;stroke-width:2}
.t-seal .thin{fill:none;stroke:currentColor;stroke-width:1}
.t-seal text{font-family:"Public Sans",Arial,sans-serif;font-weight:600;letter-spacing:2.2px;font-size:8.2px;fill:currentColor}
/* numbered clauses */
.t-clause{display:grid;grid-template-columns:calc(var(--fs)*3.2) 1fr;gap:0 calc(var(--sp)*.9);
  margin:calc(var(--sp)*.9) 0}
.t-clause__n{font-variant-numeric:tabular-nums;font-weight:600;color:var(--accent);font-size:calc(var(--fs)*.98)}
.t-clause p{margin:0 0 calc(var(--sp)*.6);font-size:calc(var(--fs)*.98);line-height:1.6;color:var(--ink-2)}
.t-clause p:last-child{margin-bottom:0}
/* recommendation / response pair */
.t-rec{border:1px solid var(--accent);border-left:5px solid var(--accent);background:var(--accent-soft);
  padding:calc(var(--sp)*1) calc(var(--sp)*1.1);margin:calc(var(--sp)*1.1) 0 0}
.t-rec b{display:block;font:600 calc(var(--fs)*.7)/1 var(--font-body);letter-spacing:.16em;text-transform:uppercase;
  color:var(--accent);margin-bottom:calc(var(--sp)*.6)}
.t-rec p{margin:0;font-size:calc(var(--fs)*1);line-height:1.55}
.t-resp{background:var(--paper-2);border-top:2px solid var(--warn);padding:calc(var(--sp)*.9) calc(var(--sp)*1.1)}
.t-resp b{display:block;font:600 calc(var(--fs)*.7)/1 var(--font-body);letter-spacing:.16em;text-transform:uppercase;
  color:var(--ink-3);margin-bottom:calc(var(--sp)*.5)}
.t-resp p{margin:0;font-family:var(--font-display);font-style:italic;font-size:calc(var(--fs)*.88);line-height:1.55;color:var(--ink-2)}
.t-rating{font:600 calc(var(--fs)*.72)/1 var(--font-body);letter-spacing:.08em;text-transform:uppercase;
  padding:.35em .6em;border:1px solid currentColor;white-space:nowrap}
.t-rating--red{color:var(--signal)}.t-rating--amber{color:var(--warn)}.t-rating--green{color:var(--ok)}
.sheet--slide .t-topbar{position:absolute;left:0;right:0;top:0;height:.75cqw;background:var(--accent);z-index:2}
.sheet--slide .t-topbar::after{content:"";position:absolute;left:0;right:0;bottom:-1px;height:1px;background:var(--warn)}
```

## Slide grammar

- Every slide carries the `t-topbar` navy strip with its gold hairline. The cover adds the `t-crest` seal and organisation, a Baskerville xxl title, and a `t-notice` classification banner when applicable.
- Findings are numbered clauses: `t-clause` with tabular numbers (2.14, 2.15 …). Cite paragraph numbers when referring across slides, as a committee would.
- Recommendations use `t-rec` (navy-edged) paired immediately with the department's `t-resp` (gold-topped, italic serif). Never present a recommendation without its response or an explicit "response awaited".
- Ratings: `t-rating--red/amber/green` outlined chips in value-for-money tables; a `d`-style dense table is not part of this template — use `c-table` with `hr.t-gold` separators.
- Charts stay austere: single-series `bars`/`hbars` in navy, gold only for a target line. No background textures anywhere.
- Tone: passive-institutional is acceptable here ("The programme did not achieve…"), but every finding still leads with the number.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Office of the Auditor General',
  docTitle:'Rural Broadband Subsidy Programme',
  docRef:'No. 24 of 2026',
  date:'22 July 2026',
  confidential:'Official — for publication',
  source:'Source: departmental returns, audited by this Office.',
  footer:{ left:'{docTitle} · {docRef}', center:'{madeWith}', right:'Page {page} of {pages}' },
  slideFooter:{ left:'{org} · {docRef}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide">
  <div class="t-topbar"></div>
  <div class="k-bgfx k-bgfx--grid" style="color:var(--accent)"></div>
  <div class="sheet__pad sheet__pad--center" style="padding-top:6cqw">
    <div class="t-crest" data-anim="fade">
      <svg class="t-seal"><use href="#emblem"/></svg>
      <div class="t-crest__org">Office of the Auditor General<span>Performance Audit Directorate</span></div>
    </div>
    <h1 class="c-title c-title--xl" data-anim style="margin-top:calc(var(--sp)*1.8);max-width:80%">Rural Broadband Subsidy Programme: value for money after four years</h1>
    <p class="c-subtitle" data-anim style="font-family:var(--font-display);font-style:italic">Briefing to the Public Accounts Committee · Report No. 24 of 2026</p>
  </div>
  <footer class="sheet__foot" data-foot data-l="Official — for publication"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="t-topbar"></div>
  <div class="sheet__pad">
    <div class="c-eyebrow" style="color:var(--warn)" data-anim="fade">Contents of this briefing</div>
    <h2 class="c-title c-title--xl" data-anim>What we examined, and where the programme stands</h2>
    <hr class="t-gold" data-anim="wipe" style="margin-top:calc(var(--sp)*1)">
    <div class="l-cols l-2 l-fill" data-anim style="margin-top:calc(var(--sp)*1.2)">
      <ul class="c-list c-list--num c-list--rule">
        <li><b>Scope and audit standard</b> — period 2022–26, ISSAI 3000</li>
        <li><b>Delivery against the connection target</b> — Part 3</li>
        <li><b>Unit cost and the 2024 assumption</b> — Part 4</li>
      </ul>
      <ul class="c-list c-list--num c-list--rule" style="counter-reset:cl 3">
        <li><b>Regional allocation and reallocation</b> — Part 5</li>
        <li><b>Recommendations and departmental response</b> — Part 7</li>
        <li><b>Matters for the Committee</b> — closing</li>
      </ul>
    </div>
    <div class="c-statrow" style="--cols:4" data-anim>
      <div class="c-stat"><span class="c-stat__label">Connected</span><b class="c-stat__value" data-count="812" data-suffix="k" data-dec="0">812k</b><span class="c-stat__note">of 1.2m undertaken</span></div>
      <div class="c-stat"><span class="c-stat__label">Unit subsidy</span><b class="c-stat__value">£1,140</b><span class="c-stat__note">forecast £780</span></div>
      <div class="c-stat"><span class="c-stat__label">Regions behind</span><b class="c-stat__value">5 of 8</b><span class="c-stat__note">87% of the shortfall</span></div>
      <div class="c-stat"><span class="c-stat__label">Recommendations</span><b class="c-stat__value">7</b><span class="c-stat__note">six accepted</span></div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="t-topbar"></div>
  <div class="sheet__pad">
    <div class="c-eyebrow" style="color:var(--warn)" data-anim="fade">Part 3 · Delivery</div>
    <h2 class="c-title c-title--xl" data-anim>Five regions account for 87% of the shortfall</h2>
    <hr class="t-gold" data-anim="wipe" style="margin-top:calc(var(--sp)*.9)">
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*1.1)">
      <div class="c-chart" data-chart="hbars" data-height="300" data-unit="%" data-max="100" data-target="88"
           data-alt="Connection rates range from 96% in North Uplands to 29% in Far Coast against the 88% programme target."
           data-labels="North Uplands,Eastern Fens,Southern Weald,West Marches,Central Vale,Northern Isles,Border Hills,Far Coast"
           data-series='[{"name":"Connected","values":[96,91,88,62,58,41,37,29],"colors":["var(--cat-1)","var(--cat-1)","var(--cat-1)","var(--cat-3)","var(--cat-3)","var(--cat-4)","var(--cat-4)","var(--cat-4)"]}]'></div>
      <div>
        <p class="c-prose">Wayleave negotiation and civil engineering in dispersed terrain explain most of the variance. Both risks appear in the 2022 business case; neither was carried into the unit cost assumption used at the 2024 spending review.</p>
        <div class="t-rec" style="margin-top:calc(var(--sp)*1)"><b>Recommendation 4</b>
          <p>Republish the unit cost assumption per region within six months, and reallocate subsidy that cannot be absorbed before the 2027 deadline.</p></div>
        <div class="t-resp"><b>Departmental response</b><p>Accepted. Regional unit costs to be published with the autumn update.</p></div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Figure 3.1 · rule marks the profiled position"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="t-topbar"></div>
  <div class="sheet__pad">
    <div class="c-eyebrow" style="color:var(--warn)" data-anim="fade">Part 8 · Conclusion</div>
    <h2 class="c-title c-title--xl" data-anim>Good service to those it reaches; two thirds of those it promised</h2>
    <hr class="t-gold" data-anim="wipe" style="margin-top:calc(var(--sp)*.9)">
    <table class="c-table" data-anim style="margin-top:calc(var(--sp)*1.2)">
      <thead><tr><th>Criterion</th><th style="text-align:left">Basis of conclusion</th><th>Assessment</th></tr></thead>
      <tbody>
        <tr><td>Economy</td><td style="text-align:left">Unit cost exceeded forecast by 46% with no revised assumption published.</td><td><span class="t-rating t-rating--red">Not demonstrated</span></td></tr>
        <tr><td>Efficiency</td><td style="text-align:left">Wayleave stage is 41% of elapsed time; no standard process across regions.</td><td><span class="t-rating t-rating--amber">Partly</span></td></tr>
        <tr><td>Effectiveness</td><td style="text-align:left">Satisfaction 84% among connected households; speeds meet specification.</td><td><span class="t-rating t-rating--green">Demonstrated</span></td></tr>
      </tbody>
    </table>
    <div class="c-callout c-callout--caution" data-anim><span class="c-callout__label">Matter for the Committee</span>
      <p>Recommendation 7, quarterly reporting to Parliament, was not accepted. The Committee may wish to test whether an annual return is sufficient when the trajectory is being replanned twice within one spending period.</p></div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>
```
