---
name: Strategy Consulting
slug: strategy-consulting
scheme: light
fonts: https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap
---

# Strategy Consulting

Top-tier strategy-firm language: warm paper, deep navy ink, one disciplined signal red, Inter Tight display. The deck argues — every slide is a step in a storyline that ends in a decision. Evidence appears as exhibits with numbers, captions, and a stated implication.

**Use for:** Strategy engagements, board reviews, executive diagnostics, transformation plans, recommendation storylines, decision matrices.
**Avoid for:** Chart-per-slide analytical reporting (use consulting-report) or dense multi-view dashboards (use data-infographic).

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#0A2540; --ink-2:#3D5166; --ink-3:#7C8B9B;
  --paper:#FFFFFF; --paper-2:#F3F1EC; --paper-3:#FAFAF8;
  --rule:#DAD5CA; --rule-2:#C3CDD6;
  --accent:#C8102E; --accent-ink:#FFFFFF; --accent-soft:#FBEDEF;
  --signal:#C8102E; --ok:#1F7A4C; --warn:#B07D18;
  --cat-1:#0A2540; --cat-2:#4E7396; --cat-3:#A7B8C7; --cat-4:#C8102E; --cat-5:#6E8298; --cat-6:#D6DEE5;
  --app-bg:#E6E4DF;
  --font-display:"Inter Tight","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-body:"Inter","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:ui-monospace,SFMono-Regular,Menlo,monospace;
  --radius:2px;
}
.c-title,.c-section{letter-spacing:-.022em}
/* firm mark */
.t-mark{font-family:var(--font-display);font-weight:700;font-size:calc(var(--fs)*1.5);letter-spacing:.01em}
.t-mark i{font-style:normal;color:var(--accent)}
.t-band{position:absolute;left:0;right:0;top:0;height:1.5cqw;background:var(--accent);z-index:2}
.t-band--side{left:0;top:0;bottom:0;right:auto;width:1.1cqw;height:auto}
/* cover */
.t-cover .c-title--xxl{max-width:15ch}
.t-cover .c-metagrid{border-top-color:color-mix(in srgb,var(--paper) 34%,transparent)}
.t-cover .c-metagrid dt{color:#8FA6BC}
.sheet--invert .c-subtitle{color:#B9C7D6}
.sheet--invert .c-eyebrow{color:#8FA6BC}
/* harvey ball table sits on the accent-free palette */
.c-table .c-harvey{color:var(--ink)}
.c-table--matrix th:not(:first-child),.c-table--matrix td:not(:first-child){text-align:center;width:13%}
.t-exhibitno{font-variant-numeric:tabular-nums}
.t-storyline{counter-reset:sl}
.t-storyline > div{counter-increment:sl;position:relative;padding-left:calc(var(--fs)*2.6);
  padding-bottom:calc(var(--sp)*1);border-left:1px solid var(--rule);margin-left:calc(var(--fs)*.7)}
.t-storyline > div:last-child{border-left-color:transparent;padding-bottom:0}
.t-storyline > div::before{content:counter(sl);position:absolute;left:calc(var(--fs)*-.72);top:0;
  width:calc(var(--fs)*1.45);height:calc(var(--fs)*1.45);border-radius:50%;background:var(--ink);color:#fff;
  font:600 calc(var(--fs)*.76)/calc(var(--fs)*1.45) var(--font-display);text-align:center}
.t-storyline b{display:block;font-size:calc(var(--fs)*1.02);color:var(--ink);margin-bottom:.25em}
.t-storyline p{margin:0;font-size:calc(var(--fs)*.9);line-height:1.5;color:var(--ink-2)}
```

## Slide grammar

- Cover: `sheet--invert` with the red `t-band--side`, a faint white `k-bgfx--grid`, an eyebrow carrying meeting and date, an xxl title that states the stake ("Where the next £40m of margin actually lives"), and a one-line subtitle naming the recommendation horizon.
- Storyline slide early in the deck: three `c-panel`s labelled 01 Situation / 02 Complication / 03 Resolution, the resolution panel tinted `--accent-soft`; close with one `c-takeaway` naming the decision being asked for.
- Exhibit slides: eyebrow "Exhibit n", xl action title, `l-rule--strong`, then `l-2a` — chart with `c-switch` metric switcher and caption on the wide side, a bolded-lead `c-list` of findings on the narrow side.
- Options slide: `c-table--matrix` with `c-harvey` ratings, then a `c-statrow--bare` of two or three decision-critical numbers with `data-count`.
- Palette discipline: navy (`--cat-1`) carries data; red is reserved for the takeaway, the band, and the one focal series. Never use red for chart categories at large.
- Titles are claims with numbers, not topics. The `c-takeaway` appears at most once per slide and always names an action.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Meridian Partners',
  client:'Northwind Foods',
  docTitle:'Margin diagnostic',
  docRef:'NWF-2231',
  date:'June 2026',
  confidential:'Confidential — not for distribution',
  source:'Source: Northwind finance extract (Apr 2026); Meridian SKU-level bridge, n = 1,840.',
  footer:{ left:'{client} · {docTitle}', center:'{madeWith}', right:'{page} / {pages}' },
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide sheet--invert">
  <div class="t-band t-band--side"></div>
  <div class="k-bgfx k-bgfx--grid" style="color:#fff"></div>
  <div class="sheet__pad sheet__pad--center" style="padding-left:8cqw">
    <div class="c-eyebrow" data-anim="fade">Board review · 18 June 2026</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:74%">Where the next £40m of margin actually lives</h1>
    <p class="c-subtitle" data-anim style="max-width:52%">Diagnostic findings and the three moves we recommend starting in July.</p>
  </div>
  <footer class="sheet__foot" data-foot data-l="MERIDIAN · Engagement NWF-2231" data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">The argument in three steps</div>
    <h2 class="c-title c-title--xl" data-anim>Demand is intact, cost recovery is not, and three moves close the gap</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="l-cols l-3 l-fill" data-anim>
      <div class="c-panel"><div class="c-panel__label"><span>01 · Situation</span></div>
        <p class="c-prose">Volume finished within 40bps of plan and share held in all eight categories. Private label is not losing on shelf.</p></div>
      <div class="c-panel"><div class="c-panel__label"><span>02 · Complication</span></div>
        <p class="c-prose">The peer set repriced in 2.4 months. Northwind took 5.8. Compounded across four quarters, that is £28m.</p></div>
      <div class="c-panel" style="background:var(--accent-soft)"><div class="c-panel__label"><span style="color:var(--accent)">03 · Resolution</span></div>
        <p class="c-prose">Cadence, a promotion payback gate and recipe change control. £18–22m recovered without touching range.</p></div>
    </div>
    <div class="c-takeaway" data-anim>
      <span class="c-takeaway__label">Decision</span>
      <p>We are asking the board to approve the cadence change in July, ahead of the other two.</p>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Meridian Partners · Northwind margin diagnostic"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Exhibit 4</div>
    <h2 class="c-title c-title--xl" data-anim>Two categories carry 71% of the shortfall</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-panel__label"><span>Select a view</span>
          <span class="c-switch" data-switch-for="ex4"></span></div>
        <div class="c-chart" id="ex4" data-chart="bars" data-height="245" data-unit="£m"
             data-alt="Chilled and bakery carry £28.4m of the £40.1m gap to plan across six categories."
             data-labels="Chilled,Bakery,Ambient,Frozen,Drinks,Other"
             data-series='[{"name":"Gap to plan","values":[16.2,12.2,6.1,3.6,1.4,0.6],"color":"var(--cat-1)"}]'
             data-sets='{"Gap to plan":{"unit":"£m","series":[{"name":"Gap to plan","values":[16.2,12.2,6.1,3.6,1.4,0.6],"color":"var(--cat-1)"}],"caption":"Chilled and bakery account for £28.4m of the £40.1m gap."},"Repricing lag":{"unit":"months","series":[{"name":"Months to shelf","values":[6.9,6.4,4.1,3.8,2.2,2.0],"color":"var(--cat-4)"}],"caption":"The two categories with the largest gap are also the slowest to reprice."},"Share change":{"unit":"pts","series":[{"name":"Share change","values":[-0.3,-0.1,0.2,0.0,0.1,-0.2],"color":"var(--cat-2)"}],"caption":"No category lost more than 0.3 points of share over the period."}}'></div>
        <p class="c-figure__caption" data-caption-for="ex4">Chilled and bakery account for £28.4m of the £40.1m gap.</p>
      </div>
      <ul class="c-list" data-anim>
        <li><b>Cadence, not pricing power.</b> Median 5.8 months from input move to shelf, against 2.4 for the peer set.</li>
        <li><b>Promotions outlive their payback.</b> 41% of chilled promotions never recovered incremental cost.</li>
        <li><b>Spec creep goes unpriced.</b> Bakery recipe changes added 3.1p per unit with no list move.</li>
        <li><b>Share held throughout.</b> Volume is within 40bps of plan, so this is not a demand problem.</li>
      </ul>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Recommendation</div>
    <h2 class="c-title c-title--xl" data-anim>Sequence the cadence fix first — it is the only fast, cheap, low-risk move</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <table class="c-table c-table--matrix" data-anim>
      <thead><tr><th>Intervention</th><th>Margin impact</th><th>Speed to value</th><th>Effort</th><th>Execution risk</th></tr></thead>
      <tbody>
        <tr><td>Quarterly price-review cadence</td><td><i class="c-harvey" data-v="4"></i></td><td><i class="c-harvey" data-v="4"></i></td><td><i class="c-harvey" data-v="1"></i></td><td><i class="c-harvey" data-v="1"></i></td></tr>
        <tr><td>Promotion payback gate</td><td><i class="c-harvey" data-v="3"></i></td><td><i class="c-harvey" data-v="3"></i></td><td><i class="c-harvey" data-v="2"></i></td><td><i class="c-harvey" data-v="2"></i></td></tr>
        <tr><td>Recipe change-control board</td><td><i class="c-harvey" data-v="2"></i></td><td><i class="c-harvey" data-v="1"></i></td><td><i class="c-harvey" data-v="2"></i></td><td><i class="c-harvey" data-v="0"></i></td></tr>
        <tr><td>Supplier index re-contracting</td><td><i class="c-harvey" data-v="3"></i></td><td><i class="c-harvey" data-v="1"></i></td><td><i class="c-harvey" data-v="4"></i></td><td><i class="c-harvey" data-v="3"></i></td></tr>
      </tbody>
    </table>
    <div class="c-statrow c-statrow--bare" style="--cols:3;margin-top:calc(var(--sp)*1.4)" data-anim>
      <div class="c-stat"><b class="c-stat__value" data-count="20" data-prefix="£" data-suffix="m" data-dec="0">£20m</b>
        <span class="c-stat__note">Midpoint recovered in four quarters from cadence alone</span></div>
      <div class="c-stat"><b class="c-stat__value">2.4 mo</b>
        <span class="c-stat__note">Target lag from input move to shelf <span class="c-delta c-delta--up">−3.4 mo</span></span></div>
      <div class="c-stat"><b class="c-stat__value">0 FTE</b>
        <span class="c-stat__note">Net headcount change required in phase one</span></div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Assessment: Meridian scoring, June 2026"></footer>
</section>
```
