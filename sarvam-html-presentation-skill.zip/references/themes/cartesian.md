---
name: Cartesian
slug: cartesian
scheme: light
fonts: https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Inter:wght@400;500;600&display=swap
---

# Cartesian

Quiet warm-neutral classicism (adapted from the MIT-licensed "Cartesian"
system): stone and greige surfaces, classical Playfair Display headlines
over Inter, thin warm hairlines, a single muted greige accent. Tasteful and
unhurried — authority through composure rather than color.

**Use for:** Partner and executive briefings, advisory readouts, firm
overviews, thought-leadership talks, proposals to conservative audiences —
work that should feel established and calm.
**Avoid for:** Energetic launches, dense data stories (data-infographic),
or teaching decks that need warmth and interaction cues.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#1A1A1A; --ink-2:#5A5A5A; --ink-3:#8A8A82;
  --paper:#EDE8E0; --paper-2:#E2DBD1; --paper-3:#E8E2D8;
  --rule:#B8B0A4; --rule-2:#9A9184;
  --accent:#6E6357; --accent-ink:#EDE8E0; --accent-soft:#DDD6CA;
  --signal:#A85A5A; --ok:#6B7D5E; --warn:#A88B5C;
  --cat-1:#1A1A1A; --cat-2:#8A8178; --cat-3:#B8B0A4; --cat-4:#5A5A5A; --cat-5:#C9C2B4; --cat-6:#7A7268;
  --app-bg:#E0DACF;
  --font-display:"Playfair Display",Georgia,serif;
  --font-body:"Inter","Helvetica Neue",Arial,sans-serif;
  --font-mono:ui-monospace,SFMono-Regular,Menlo,monospace;
  --radius:0px;
}
.c-title{font-weight:600;letter-spacing:0}
.c-title--xxl{font-weight:400}
.c-eyebrow{letter-spacing:.28em;color:var(--ink-2)}
/* stone interlude — darker warm panel slide for statements and dividers */
.sheet--slide.t-stone{background:#3A352E;color:#EDE8E0;--ink:#EDE8E0;--ink-2:#C6BFB2;--ink-3:#989082;
  --paper-2:rgba(237,232,224,.07);--paper-3:rgba(237,232,224,.04);
  --rule:rgba(237,232,224,.24);--rule-2:rgba(237,232,224,.44);
  --accent:#C9B896;--accent-soft:rgba(201,184,150,.16);--accent-ink:#3A352E}
/* plate — thin-rule framed figure or table, the classical device */
.t-plate{border:1px solid var(--rule);padding:calc(var(--sp)*1) calc(var(--sp)*1.1);
  background:var(--paper-3)}
.t-plate figcaption,.t-plate .t-plate__cap{font-size:calc(var(--fs)*.72);color:var(--ink-2);
  letter-spacing:.06em;text-transform:uppercase;margin-top:calc(var(--sp)*.6)}
/* serif italic aside */
.t-aside{font-family:var(--font-display);font-style:italic;font-size:calc(var(--fs)*1.06);
  line-height:1.5;color:var(--ink-2);border-left:2px solid var(--rule-2);
  padding-left:calc(var(--sp)*1)}
```

## Slide grammar

- Cover: paper, a widely letterspaced eyebrow, a Playfair xxl title at
  weight 400 — the elegance is the lightness — and a one-line subtitle.
- Content slides: eyebrow, Playfair xl action title, `l-rule`, one
  composition with generous margins. Nothing decorative on content slides.
- Evidence sits in a `t-plate` (framed chart or booktabs table with an
  uppercase caption); the implication sits in a `t-aside` italic or a short
  bolded-lead `c-list`.
- Charts are ink-and-stone: ink focal series, greige and sand for context.
  One or two series preferred; deltas in muted `--ok`/`--signal` earth
  tones.
- Use one `t-stone` interlude for the central statement, and `t-stone`
  dividers for chapters in longer decks.
- Numbers speak quietly: `c-statrow--bare`, no count-up theatrics unless
  the room expects a reveal.
- Closing: the recommendation in Playfair, then owners and dates.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Harlan Advisory',
  docTitle:'Succession readiness review',
  date:'July 2026',
  source:'Source: Harlan partner interviews (n = 22) and firm records, H1 2026.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide">
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Harlan Advisory · prepared for the partnership</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:72%">Succession is a decade of habits, not a handover</h1>
    <p class="c-subtitle" data-anim style="max-width:52%">Findings from twenty-two partner interviews and thirty years of firm records.</p>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Client continuity · by transition type</div>
    <h2 class="c-title c-title--xl" data-anim>Gradual transitions retain 88% of client revenue; abrupt ones, 54%</h2>
    <hr class="l-rule" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div class="t-plate">
        <div class="c-chart" id="cont" data-chart="bars" data-height="225" data-unit="% revenue retained"
             data-labels="3+ yr overlap,1–3 yr,Under 1 yr,Unplanned"
             data-series='[{"name":"Revenue retained after 2 years","values":[88,79,61,54],"color":"var(--cat-1)"}]'
             data-alt="Client revenue retained two years after transition falls from 88 percent with a three-year overlap to 54 percent when unplanned."></div>
        <div class="t-plate__cap">Revenue retained 24 months post-transition, 41 transitions, 1996–2024</div>
      </div>
      <p class="t-aside" data-anim>The pattern has held for thirty years: clients stay with relationships they watched being built.</p>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: firm records, 41 transitions"></footer>
</section>
```
