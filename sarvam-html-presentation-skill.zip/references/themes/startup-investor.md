---
name: Startup Investor
slug: startup-investor
scheme: mixed
fonts: https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap
---

# Startup Investor

A board update that respects the board's time: Space Grotesk metrics, dark forest green with vivid coral, a TL;DR panel up front, KPI cards with deltas, cohort tables, and explicit asks. Numbers first, narrative second, asks always.

**Use for:** Investor updates, board meetings, fundraising progress, SaaS metrics, runway and growth reviews, decision-oriented founder communications.
**Avoid for:** Decks without real metrics, risks, and asks; academic or policy contexts.

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#12211C; --ink-2:#3E524B; --ink-3:#7A8B84;
  --paper:#FFFFFF; --paper-2:#F1F4F2; --paper-3:#F8FAF9;
  --rule:#DCE3DF; --rule-2:#BFCCC6;
  --accent:#FF5C35; --accent-ink:#FFFFFF; --accent-soft:#FFF0EB;
  --signal:#D93A20; --ok:#1B7A55; --warn:#C98A16;
  --cat-1:#1B4D3E; --cat-2:#FF5C35; --cat-3:#4E9C82; --cat-4:#C98A16; --cat-5:#8FB8A8; --cat-6:#D7E2DD;
  --app-bg:#DFE5E2;
  --font-display:"Space Grotesk","Helvetica Neue",Arial,sans-serif;
  --font-body:"Inter","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:"Space Grotesk",Arial,sans-serif;
  --radius:8px;
}
.c-title{letter-spacing:-.03em}
.c-stat__value{font-family:var(--font-display)}
.t-logo{display:flex;align-items:center;gap:calc(var(--sp)*.7);font-family:var(--font-display);
  font-weight:700;font-size:calc(var(--fs)*1.35);letter-spacing:-.02em}
.t-logo i{width:calc(var(--fs)*1.5);height:calc(var(--fs)*1.5);border-radius:50%;background:var(--accent);
  display:inline-block;position:relative;flex:0 0 auto}
.t-logo i::after{content:"";position:absolute;inset:26%;border-radius:50%;background:var(--paper)}
.t-logo span{margin-left:auto;font-family:var(--font-body);font-weight:500;font-size:calc(var(--fs)*.8);
  letter-spacing:.14em;text-transform:uppercase;color:var(--ink-3)}
.t-tldr{background:var(--ink);color:var(--paper);border-radius:var(--radius);padding:calc(var(--sp)*1.2)}
.t-tldr b{display:block;font:600 calc(var(--fs)*.72)/1 var(--font-body);letter-spacing:.16em;text-transform:uppercase;
  color:var(--accent);margin-bottom:calc(var(--sp)*.7)}
.t-tldr p{margin:0;font-size:calc(var(--fs)*1.08);line-height:1.5;color:#DCE6E1}
.t-tldr p+p{margin-top:calc(var(--sp)*.6)}
.t-kpi{display:grid;grid-template-columns:repeat(var(--cols,4),1fr);gap:calc(var(--sp)*.8)}
.t-kpi>div{background:var(--paper-3);border:1px solid var(--rule);border-radius:var(--radius);
  padding:calc(var(--sp)*.9) calc(var(--sp)*1)}
.t-kpi dt{font:600 calc(var(--fs)*.7)/1 var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--ink-3)}
.t-kpi dd{margin:calc(var(--sp)*.5) 0 0;font-family:var(--font-display);font-weight:700;
  font-size:calc(var(--fs)*1.95);line-height:1;letter-spacing:-.03em}
.t-kpi small{display:block;font-family:var(--font-body);font-weight:500;font-size:calc(var(--fs)*.76);
  margin-top:calc(var(--sp)*.45);color:var(--ink-3)}
.t-kpi .up{color:var(--ok)}.t-kpi .down{color:var(--signal)}
.t-cohort{width:100%;border-collapse:separate;border-spacing:2px;font-size:calc(var(--fs)*.8);
  font-variant-numeric:tabular-nums}
.t-cohort th{font:600 calc(var(--fs)*.68)/1 var(--font-body);letter-spacing:.08em;text-transform:uppercase;
  color:var(--ink-3);padding-bottom:calc(var(--sp)*.4)}
.t-cohort td{text-align:center;padding:calc(var(--sp)*.42) 0;border-radius:3px;color:var(--ink)}
.t-cohort td:first-child{text-align:left;background:none;color:var(--ink-2);font-weight:500}
.t-cohort .h5{background:#1B4D3E;color:#fff}.t-cohort .h4{background:#4E9C82;color:#fff}
.t-cohort .h3{background:#8FB8A8}.t-cohort .h2{background:#C4D8D0}.t-cohort .h1{background:#E4EDE9}
.t-ask{border:1.5px solid var(--ink);border-radius:var(--radius);padding:calc(var(--sp)*1);display:flex;
  gap:calc(var(--sp)*1);align-items:baseline}
.t-ask b{font-family:var(--font-display);font-weight:700;color:var(--accent);flex:0 0 auto}
.t-ask p{margin:0;font-size:calc(var(--fs)*.95);line-height:1.5;color:var(--ink-2)}
.sheet--slide.t-dark{background:#12211C;color:#EAF1EE;--ink:#EAF1EE;--ink-2:#B7C8C1;--ink-3:#7F958C;
  --rule:rgba(255,255,255,.16);--paper-2:rgba(255,255,255,.07);--paper-3:rgba(255,255,255,.05);
  --accent:#FF7A57;--accent-soft:rgba(255,92,53,.16)}
.t-dark .t-kpi>div{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.14)}
```

## Slide grammar

- Every slide opens with the `t-logo` row (mark + company, period label right). The cover doubles as the TL;DR: a `t-tldr` dark panel with two or three sentences a director could repeat verbatim.
- KPIs are `t-kpi` cards: label, Space Grotesk value (`data-count`), and a `small` comparison line with `up`/`down` colouring. Four cards, never more; every value names its period.
- Retention is a `t-cohort` heat table (`h1`–`h5` cell classes). Growth is one `area` or `line` chart with a dashed plan series and a legend — plan vs actual, not vanity curves.
- The one-number slide uses `t-dark` with a `c-bignum` — ARR, runway, or the raise; give it no companions.
- Asks are `t-ask` boxes: bold coral label ("Ask 1"), one sentence, one owner. Risks get the same honesty (`c-callout--caution` with the mitigation).
- Coral is the focal colour: the ask, the delta that matters, the logo dot. Forest green carries everything structural. Never colour a bad number green.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Cadence',
  docTitle:'Q2 2026 board update',
  date:'July 2026',
  confidential:'Confidential — board and observers',
  source:'Source: internal billing system, 30 June 2026',
  footer:{ left:'Cadence · {docTitle}', center:'{madeWith}', right:'{page} / {pages}' },
  slideFooter:{ left:'{confidential}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide t-dark">
  <div class="k-bgfx k-bgfx--orbit" style="color:#FF7A57"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="t-logo" data-anim="fade"><i></i>Cadence<span>Board update · Q2 2026</span></div>
    <h1 class="c-title c-title--xxl" data-anim style="margin-top:calc(var(--sp)*1.6);max-width:70%">Revenue beat plan. Enterprise sales did not.</h1>
    <p class="c-subtitle" data-anim style="max-width:52%">$6.4m ARR, 12% ahead — and one missing compliance document behind every enterprise loss.</p>
  </div>
  <footer class="sheet__foot" data-foot data-l="Confidential · board and observers"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Quarter in numbers</div>
    <h2 class="c-title c-title--xl" data-anim>Ahead on ARR, behind on the mix</h2>
    <dl class="t-kpi" style="--cols:4;margin-top:calc(var(--sp)*1.1)" data-anim>
      <div><dt>ARR</dt><dd data-count="6.4" data-prefix="$" data-suffix="m">$6.4m</dd><small class="up">+12% vs plan</small></div>
      <div><dt>NRR</dt><dd data-count="118" data-suffix="%" data-dec="0">118%</dd><small class="up">+6 pts QoQ</small></div>
      <div><dt>Enterprise closed</dt><dd style="color:var(--signal)">4 / 11</dd><small class="down">−7 vs forecast</small></div>
      <div><dt>Runway</dt><dd>19 mo</dd><small>no raise assumed</small></div>
    </dl>
    <div class="l-cols l-2a l-fill" data-anim style="margin-top:calc(var(--sp)*1.1)">
      <div>
        <div class="c-panel__label"><span>ARR against plan</span><span class="c-switch" data-switch-for="arr"></span></div>
        <div class="c-chart" id="arr" data-chart="line" data-height="155" data-unit="$m"
             data-alt="ARR grew from $2.1m to $6.4m over twelve months, finishing $0.7m ahead of plan."
             data-labels="Jul,Aug,Sep,Oct,Nov,Dec,Jan,Feb,Mar,Apr,May,Jun"
             data-series='[{"name":"Actual","values":[2.1,2.3,2.6,2.9,3.3,3.7,4.1,4.4,4.9,5.4,5.9,6.4],"color":"var(--cat-1)"},{"name":"Plan","values":[2.1,2.3,2.5,2.8,3.1,3.4,3.7,4.0,4.4,4.8,5.3,5.7],"dash":true,"color":"var(--cat-6)"}]'
             data-sets='{"ARR":{"unit":"$m","series":[{"name":"Actual","values":[2.1,2.3,2.6,2.9,3.3,3.7,4.1,4.4,4.9,5.4,5.9,6.4],"color":"var(--cat-1)"},{"name":"Plan","values":[2.1,2.3,2.5,2.8,3.1,3.4,3.7,4.0,4.4,4.8,5.3,5.7],"dash":true,"color":"var(--cat-6)"}],"caption":"Ahead of plan since February, on self-serve expansion."},"Burn":{"unit":"$k","series":[{"name":"Monthly burn","values":[280,286,291,298,304,309,312,308,311,309,310,310],"color":"var(--cat-2)"}],"caption":"Burn flat since January despite three engineering hires."},"Margin":{"unit":"%","series":[{"name":"Gross margin","values":[61,62,63,64,66,67,69,70,71,72,74,74],"color":"var(--cat-3)"}],"caption":"Batching shipped in May; inference cost per request down 34%."}}'></div>
        <div class="c-legend" data-legend-for="arr"></div>
        <p class="c-figure__caption" data-caption-for="arr">Ahead of plan since February, on self-serve expansion.</p>
      </div>
      <div>
        <div class="c-panel__label"><span>Net new ARR by source, Q2</span><span>$k</span></div>
        <div class="c-chart" data-chart="bars" data-height="155" data-unit="$k"
             data-alt="Expansion added $840k of net-new ARR and self-serve $510k, while churn took back $170k."
             data-labels="Expansion,Self-serve,Enterprise,Churn"
             data-series='[{"name":"Net new","values":[840,510,320,-170],"color":"var(--cat-1)"}]'></div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide t-dark">
  <div class="k-bgfx k-bgfx--glow" style="color:#FF7A57"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="l-cols l-2a" style="align-items:center">
      <div data-anim="scale">
        <div class="c-bignum" style="color:var(--accent)"><span data-count="7" data-dec="0">7</span> of 7
          <small style="color:#B7C8C1">Enterprise losses that named the same missing document</small></div>
      </div>
      <div data-anim>
        <p class="c-prose" style="color:#B7C8C1;font-size:calc(var(--fs)*1.12)">Every enterprise deal we lost in Q2 reached security review and stopped there. Not price. Not features. Not the competitor.</p>
        <hr class="l-rule">
        <ul class="c-list c-list--dot">
          <li><b>Four deals paused</b>, explicitly pending a SOC 2 report.</li>
          <li><b>Three went to a competitor</b> that has one.</li>
          <li><b>Pipeline is intact</b> — none of the seven disqualified us on product.</li>
        </ul>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Loss review · eleven forecast deals, seven lost, four closed"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">What we need from the board</div>
    <h2 class="c-title c-title--xl" data-anim>One decision today, two things to watch</h2>
    <hr class="l-rule l-rule--accent" data-anim="wipe">
    <div class="l-stack l-fill" data-anim style="margin-top:calc(var(--sp)*1.1)">
      <div class="t-ask"><b>Decide</b><p><b>Pull SOC 2 Type II forward two quarters</b>, funded by deferring two Q4 hires. $180k and one engineer for eleven weeks. Report in November.</p></div>
      <div class="t-ask"><b>Approve</b><p><b>Senior engineering band to the 65th percentile.</b> Two late declines this quarter, both on band rather than the work.</p></div>
      <div class="l-cols l-2">
        <div class="c-callout c-callout--caution"><span class="c-callout__label">Watch · concentration</span>
          <p>Top twenty accounts are 38% of ARR, up from 31%. One renegotiates in September; downside modelled at −$420k.</p></div>
        <div class="c-callout c-callout--action"><span class="c-callout__label">Watch · hiring</span>
          <p>Two senior roles open more than 90 days. Without Ask 2 the batching roadmap slips and margin flattens.</p></div>
      </div>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>
```
