---
name: Insight Deep-Dive
slug: insight-deepdive
scheme: light
fonts: https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap
---

# Insight Deep-Dive

Analytical deep-dive in the idiom of a top strategy firm — the McKinsey
school of governing thoughts, numbered exhibits, and chapter trackers —
redrawn modern for the screen: midnight ink, one electric blue, Fraunces
serif governing thoughts over Inter data typography, flat sharp surfaces,
hairline rules. Every
exhibit is numbered, sourced, footnoted — and interactive: metric switchers,
legend toggles, sortable tables, tooltips, counting numbers. The structure
scales from an 8-slide readout to a 40-slide study without changing its
grammar (see "Scaling the structure" below).

**Use for:** Deep-dive analyses, market and sector studies, diagnostic
readouts, economics teardowns, scenario and sensitivity work, and
evidence-led storylines that end in a decision — at any length.
**Avoid for:** Short pitches and keynotes (use startup-investor or
strategy-consulting), dense multi-view dashboards (use data-infographic).

## Theme CSS — copy verbatim into the THEME block

```css
:root{
  --ink:#051C2C; --ink-2:#3A4A58; --ink-3:#7E8B96;
  --paper:#FFFFFF; --paper-2:#F0F3F5; --paper-3:#F7F9FA;
  --rule:#D9DFE3; --rule-2:#B9C2C9;
  --accent:#2251FF; --accent-ink:#FFFFFF; --accent-soft:#E7ECFF;
  --signal:#E5484D; --ok:#0E8A5F; --warn:#B7791F;
  --cat-1:#2251FF; --cat-2:#051C2C; --cat-3:#00A9F4; --cat-4:#99AEBB; --cat-5:#6E79D6; --cat-6:#C3D2DC;
  --app-bg:#E7EBEE;
  --font-display:"Fraunces",Georgia,serif;
  --font-body:"Inter","Helvetica Neue",Arial,sans-serif;
  --font-mono:ui-monospace,SFMono-Regular,Menlo,monospace;
  --radius:0px;
}
.c-title{font-weight:600;letter-spacing:-.012em}
.c-title--xl{line-height:1.14}
.c-eyebrow{color:var(--accent);letter-spacing:.16em}
.c-stat__value{font-family:var(--font-display);font-weight:600;letter-spacing:-.01em}
/* midnight bookends and dividers */
.sheet--slide.t-deep{background:#051C2C;color:#FFFFFF;--ink:#FFFFFF;--ink-2:#B9C7D3;--ink-3:#7E93A3;
  --rule:rgba(255,255,255,.16);--rule-2:rgba(255,255,255,.3);
  --paper-2:rgba(255,255,255,.06);--paper-3:rgba(255,255,255,.04);
  --accent:#5B7BFF;--accent-soft:rgba(91,123,255,.16);--accent-ink:#051C2C}
.t-deep .c-eyebrow{color:#00A9F4}
/* electric edge — covers and dividers only */
.t-edge{position:absolute;left:0;top:0;bottom:0;width:1.1cqw;background:#2251FF;z-index:2}
/* governing thought — serif claim between hairlines, exec summary + dividers */
.t-gt{border-top:1px solid var(--rule-2);border-bottom:1px solid var(--rule-2);
  padding:calc(var(--sp)*1.3) 0;margin:calc(var(--sp)*.6) 0}
.t-gt p{margin:0;font-family:var(--font-display);font-weight:500;font-size:calc(var(--fs)*1.62);
  line-height:1.32;letter-spacing:-.01em;max-width:34ch}
.t-gt em{font-style:normal;color:var(--accent)}
/* chapter tracker — dividers only */
.t-tracker{display:flex;gap:calc(var(--sp)*1.4);margin-top:calc(var(--sp)*1.6)}
.t-tracker span{font:600 calc(var(--fs)*.78)/1.4 var(--font-body);letter-spacing:.1em;
  text-transform:uppercase;color:var(--ink-3);padding-top:calc(var(--sp)*.7);
  border-top:3px solid var(--rule);flex:1}
.t-tracker span i{display:block;font-style:normal;font-family:var(--font-mono);
  font-size:calc(var(--fs)*.7);margin-bottom:calc(var(--sp)*.3)}
.t-tracker .is-on{color:var(--ink);border-top-color:#2251FF}
.t-deep .t-tracker .is-on{color:#fff;border-top-color:#00A9F4}
/* insight banner — one implication under an exhibit */
.t-insight{background:var(--accent-soft);border-left:5px solid var(--accent);
  padding:calc(var(--sp)*.9) calc(var(--sp)*1.1)}
.t-insight b{display:block;font:700 calc(var(--fs)*.7)/1 var(--font-body);letter-spacing:.14em;
  text-transform:uppercase;color:var(--accent);margin-bottom:calc(var(--sp)*.45)}
.t-insight p{margin:0;font-size:calc(var(--fs)*.94);line-height:1.5;color:var(--ink)}
/* scenario card — base / upside / downside */
.t-scen{border:1px solid var(--rule);border-top:4px solid var(--cat-4);
  padding:calc(var(--sp)*1) calc(var(--sp)*1.1);background:var(--paper)}
.t-scen--focus{border-top-color:#2251FF;background:var(--paper-3)}
.t-scen b{display:block;font:700 calc(var(--fs)*.7)/1 var(--font-body);letter-spacing:.14em;
  text-transform:uppercase;color:var(--ink-3);margin-bottom:calc(var(--sp)*.7)}
.t-scen--focus b{color:var(--accent)}
.t-scen strong{display:block;font-family:var(--font-display);font-weight:600;
  font-size:calc(var(--fs)*2.3);line-height:1;letter-spacing:-.01em;margin-bottom:calc(var(--sp)*.5)}
.t-scen p{margin:0;font-size:calc(var(--fs)*.84);line-height:1.5;color:var(--ink-2)}
/* numbered recommendation card */
.t-reco{border:1px solid var(--rule);padding:calc(var(--sp)*1) calc(var(--sp)*1.1);background:var(--paper)}
.t-reco i{display:block;font-style:normal;font-family:var(--font-display);font-weight:600;
  color:var(--accent);font-size:calc(var(--fs)*1.5);margin-bottom:calc(var(--sp)*.5);
  font-variant-numeric:tabular-nums}
.t-reco b{display:block;font-size:calc(var(--fs)*.98);margin-bottom:calc(var(--sp)*.4)}
.t-reco p{margin:0;font-size:calc(var(--fs)*.84);line-height:1.5;color:var(--ink-2)}
.t-reco small{display:block;margin-top:calc(var(--sp)*.6);font:600 calc(var(--fs)*.7)/1.4 var(--font-body);
  letter-spacing:.06em;text-transform:uppercase;color:var(--ink-3)}
/* numbered footnote line above the footer */
.t-note{margin-top:auto;padding-top:calc(var(--sp)*.6);border-top:1px solid var(--rule);
  font-size:calc(var(--fs)*.68);line-height:1.5;color:var(--ink-3)}
.t-note sup{color:var(--accent);font-weight:600}
```

## Slide grammar

- **Cover** (`t-deep` + `t-edge`): eyebrow with study name and date, Fraunces
  xxl title that states the headline finding with its number, one-line
  subtitle naming scope and method. Optional faint `k-bgfx--grid`.
- **Executive summary** immediately after the cover: a `t-gt` governing
  thought (the whole deck in one serif sentence, key number in `<em>`),
  a `c-statrow--bare` of three decisive numbers with `data-count`, and one
  `c-takeaway` naming the decision the deck asks for.
- **Chapter dividers** (`t-deep` + `t-edge`) instead of an agenda slide: a
  serif chapter claim plus the `t-tracker` with the current chapter `is-on`.
  One divider per chapter of 3–6 exhibits; see the scaling rules.
- **Exhibit slides** are the body of the deck. Eyebrow reads
  `Exhibit 04 · unit`; the xl title states the finding with a number;
  `l-rule--strong`; then one composition — most often `l-2a`/`l-2b` with the
  chart on the wide side and a bolded-lead `c-list` or `t-insight` opposite.
  Number exhibits sequentially across the whole deck.
- **Interactivity is the house style — every chapter (or the whole deck,
  when unchaptered) must use at least two of:** a `c-switch` metric switcher (`data-sets` with 2–3 genuinely
  different cuts), a `c-legend` on any multi-series chart (mandatory), a
  `c-table--sortable` benchmark, `data-tip` tooltips on heat-grid cells,
  `data-count` on stat values. Never fake these; wire them by chart id.
- **Footnote discipline:** claims that need qualification take `<sup>1</sup>`
  in the text and a `t-note` line above the footer; every exhibit slide's
  footer carries the specific source via `data-l`.
- **Scenarios and sensitivity** close the analysis: three `t-scen` cards
  (focus the base case with `t-scen--focus`), then a switcher chart showing
  the outcome under each lever.
- **Recommendations** are numbered `t-reco` cards — identical treatment,
  ≤22 words each, an owner-and-date `small` line. The closing slide
  (`t-deep`) does work: decisions requested, owners, dates.
- **Palette discipline:** electric blue is the focal series and the insight
  apparatus; midnight and cyan carry secondary series; `--cat-4/6` grays for
  context. Red only for genuinely negative deltas. Serif only for titles,
  governing thoughts, and big numbers — body and data are always Inter.
- Vary chart families across chapters — trend `line`/`area`, ranking
  `hbars`, comparison `bars`, mix `stack`/`donut`, relationship `scatter`,
  estimate `dot` with error bars — chosen by the question each exhibit
  answers.

## Scaling the structure

The grammar is constant; only the chaptering scales with slide count. Never
pad to reach a count or compress evidence to duck under one.

| Deck length | Structure |
|---|---|
| ~8–11 slides | Cover · exec summary · 4–7 exhibits · scenarios or recommendations · closing. **No chapter dividers, no tracker** — the exec summary is the map. |
| ~12–25 slides | Add 3–5 chapters, each opened by a `t-deep` divider with the `t-tracker`. Scenarios and recommendations form the final chapter. |
| ~26–40 slides | 5–7 chapters. Exhibit numbering runs across the whole deck. Every chapter closes its last exhibit with a `c-takeaway` so a reader can follow takeaways alone. Re-anchor long chapters with a `t-gt` governing thought mid-chapter. |

At every length: exhibits stay numbered and sourced, each chapter (or the
deck, when unchaptered) uses at least two interactive devices, and the
closing slide asks for decisions.

## Deck script

Adapt the values; keep the structure.

```js
Doc.init({
  org:'Atlas & Co',
  client:'Swiftbasket',
  docTitle:'Grocery delivery economics — deep dive',
  docRef:'SWB-0472',
  date:'July 2026',
  confidential:'Confidential — working draft',
  source:'Source: Swiftbasket order ledger FY24–FY26; Atlas city panel, n = 41 cities.',
  slideFooter:{ left:'{source}', center:'{madeWith}', right:'{page} / {pages}' }
});
```

## Example slides

These are the reference compositions, shipped working. Adapt their structure
and rhythm; replace every word, number, and id with the actual content. Do
not ship any of this sample text or data.

```html
<section class="sheet sheet--slide t-deep">
  <div class="t-edge"></div>
  <div class="k-bgfx k-bgfx--grid" style="color:#fff"></div>
  <div class="sheet__pad sheet__pad--center" style="padding-left:8cqw">
    <div class="c-eyebrow" data-anim="fade">Grocery delivery economics · July 2026</div>
    <h1 class="c-title c-title--xxl" data-anim style="max-width:76%">Fourteen cities can pay for the other twenty-seven</h1>
    <p class="c-subtitle" data-anim style="max-width:56%">A deep dive into Swiftbasket's order economics across 41 cities, FY24–FY26.</p>
  </div>
  <footer class="sheet__foot" data-foot data-l="ATLAS &amp; CO · Engagement SWB-0472" data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Executive summary</div>
    <h2 class="c-title c-title--xl" data-anim>The economics work — but only where order density does</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="t-gt" data-anim>
      <p>Contribution turns positive at <em>1,150 orders per store per day</em>; fourteen cities are past it, and they fund the rest.</p>
    </div>
    <div class="c-statrow c-statrow--bare l-fill" style="--cols:3" data-anim>
      <div class="c-stat"><b class="c-stat__value" data-count="14">14</b><span class="c-stat__note">Cities past break-even density, FY26</span></div>
      <div class="c-stat"><b class="c-stat__value" data-count="-31" data-suffix=" ₹">−31 ₹</b><span class="c-stat__note">Contribution per order, bottom quartile</span></div>
      <div class="c-stat"><b class="c-stat__value" data-count="8">8</b><span class="c-stat__note">Quarters to network break-even in the base case</span></div>
    </div>
    <div class="c-takeaway" data-anim>
      <span class="c-takeaway__label">Decision</span>
      <p>Concentrate FY27 capex in the fourteen dense cities; hold the rest at maintenance until density clears 900.</p>
    </div>
  </div>
  <footer class="sheet__foot" data-foot></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide t-deep">
  <div class="t-edge"></div>
  <div class="sheet__pad sheet__pad--center">
    <div class="c-eyebrow" data-anim="fade">Chapter 02</div>
    <h2 class="c-title c-title--xxl" data-anim style="max-width:70%">Unit economics: the order pays before the store does</h2>
    <div class="t-tracker" data-anim>
      <span><i>01</i>Market</span>
      <span class="is-on"><i>02</i>Unit economics</span>
      <span><i>03</i>Competition</span>
      <span><i>04</i>Path to profit</span>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-r=""></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Exhibit 05 · ₹ per order</div>
    <h2 class="c-title c-title--xl" data-anim>Delivery cost fell ₹18 in two years — all of it from density, not wages</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="l-cols l-2a l-fill" data-anim>
      <div>
        <div class="c-panel__label"><span>Select a cut</span>
          <span class="c-switch" data-switch-for="ex5"></span></div>
        <div class="c-chart" id="ex5" data-chart="bars" data-height="245" data-unit="₹/order"
             data-labels="FY24,FY25,FY26"
             data-series='[{"name":"Delivery cost","values":[64,53,46],"color":"var(--cat-1)"}]'
             data-sets='{"Delivery cost":{"unit":"₹/order","series":[{"name":"Delivery cost","values":[64,53,46],"color":"var(--cat-1)"}],"caption":"Cost per drop fell from ₹64 to ₹46 as batching rose."},"Orders per rider-hour":{"unit":"orders/hr","series":[{"name":"Orders per rider-hour","values":[1.6,2.1,2.6],"color":"var(--cat-3)"}],"caption":"Riders carry 63% more orders per hour than in FY24."},"Rider cost per hour":{"unit":"₹/hr","series":[{"name":"Rider cost per hour","values":[102,108,118],"color":"var(--cat-4)"}],"caption":"Hourly rider cost rose 16% — density beat wage inflation."}}'
             data-alt="Delivery cost per order fell from 64 to 46 rupees between FY24 and FY26 while rider wages rose 16%."></div>
        <p class="c-figure__caption" data-caption-for="ex5">Cost per drop fell from ₹64 to ₹46 as batching rose.</p>
      </div>
      <div class="t-insight" data-anim>
        <b>What it means</b>
        <p>Wage inflation is real but beaten 2:1 by batching. Every new order in a dense zone is cheaper than the last<sup>1</sup>.</p>
      </div>
    </div>
    <p class="t-note" data-anim="fade"><sup>1</sup> Marginal cost estimated on zones above 800 orders/day; sparse zones show the opposite sign.</p>
  </div>
  <footer class="sheet__foot" data-foot data-l="Source: rider telemetry, 214k shifts, FY24–FY26"></footer>
</section>

<!-- ===== -->

<section class="sheet sheet--slide">
  <div class="sheet__pad">
    <div class="c-eyebrow" data-anim="fade">Exhibit 11 · contribution per order, ₹</div>
    <h2 class="c-title c-title--xl" data-anim>Even the downside case clears zero by FY29</h2>
    <hr class="l-rule l-rule--strong" data-anim="wipe">
    <div class="l-cols l-3 l-fill" data-anim>
      <div class="t-scen"><b>Downside</b><strong data-count="4" data-prefix="₹">₹4</strong>
        <p>AOV flat, fee caps bite, density +12%/yr. Break-even slips to FY29 Q2.</p></div>
      <div class="t-scen t-scen--focus"><b>Base</b><strong data-count="19" data-prefix="₹">₹19</strong>
        <p>AOV +4%/yr, current fees, density +22%/yr on the FY26 exit rate.</p></div>
      <div class="t-scen"><b>Upside</b><strong data-count="31" data-prefix="₹">₹31</strong>
        <p>Ad revenue reaches 3.1% of GMV and batching gains hold through FY28.</p></div>
    </div>
    <div class="c-takeaway" data-anim>
      <span class="c-takeaway__label">So what</span>
      <p>The plan survives its own downside; the decision is pace, not direction.</p>
    </div>
  </div>
  <footer class="sheet__foot" data-foot data-l="Model: Atlas contribution bridge v3, FY26 exit rates"></footer>
</section>
```
