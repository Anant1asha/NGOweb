/* ==DECK-CORE-JS v2== */
/* ===========================================================================
   DECK CORE runtime (slides-only build of DOCKIT)
   Embed VERBATIM, including sentinel comments. The validator hash-checks it.
   Doc.init(config)  — brand, footers, source, theme colours (all optional)
   Doc.setTheme({accent:'#...'})  — recolour live
   Charts, tooltips, sortable tables, reveal animation, present mode.
   =========================================================================== */
(function(){
'use strict';

/* ---------------------------------------------------------------- config  */
var CFG = {
  brand:        'Sarvam Co-Work',
  madeWith:     'Made with Sarvam Co-Work',
  org:          '',
  docTitle:     '',
  docRef:       '',
  client:       '',
  author:       '',
  date:         '',
  confidential: '',
  source:       'Sample data — set via Doc.init({source})',
  slideFooter:  { left:'{source}', center:'{madeWith}', right:'{page} / {pages}' },
  theme:        {}
};
function deep(t,s){ for(var k in s){ if(s[k]&&s[k].constructor===Object){ t[k]=deep(t[k]||{},s[k]); } else t[k]=s[k]; } return t; }
function fill(tpl,extra){
  return String(tpl||'').replace(/\{(\w+)\}/g,function(_,k){
    if(extra&&k in extra) return extra[k];
    return (k in CFG)? CFG[k] : '';
  }).replace(/\s+·\s+·\s+/g,' · ').replace(/^\s*·\s*|\s*·\s*$/g,'').trim();
}

/* ---------------------------------------------------------------- theme   */
function setTheme(obj){
  var r=document.documentElement;
  for(var k in obj) r.style.setProperty('--'+k.replace(/[A-Z]/g,function(c){return '-'+c.toLowerCase();}), obj[k]);
}

/* ------------------------------------------------------------ injected css */
var CSS = '.k-tip{position:fixed;z-index:9999;pointer-events:none;opacity:0;transform:translate(-50%,-130%);'
+'background:#101014;color:#fff;font:500 11.5px/1.4 var(--font-body);padding:6px 9px;border-radius:5px;'
+'white-space:nowrap;transition:opacity .12s;box-shadow:0 8px 24px -10px rgba(0,0,0,.8)}'
+'.k-tip.is-on{opacity:1}.k-tip em{font-style:normal;opacity:.6;display:block;font-size:10px;letter-spacing:.07em;text-transform:uppercase}'
+'.k-tip b{font-weight:700}'
+'.c-chart .k-grow{transform:scaleY(0);transform-origin:bottom;transform-box:fill-box;'
+'transition:transform .75s cubic-bezier(.22,1,.36,1)}'
+'.c-chart .k-growx{transform:scaleX(0);transform-origin:left;transform-box:fill-box;'
+'transition:transform .75s cubic-bezier(.22,1,.36,1)}'
+'.is-in .c-chart .k-grow,.is-in .c-chart .k-growx{transform:none}'
+'.c-chart .k-draw{stroke-dasharray:var(--len);stroke-dashoffset:var(--len);'
+'transition:stroke-dashoffset 1.1s cubic-bezier(.33,1,.68,1)}'
+'.is-in .c-chart .k-draw{stroke-dashoffset:0}'
+'.c-chart .k-fadein{opacity:0;transition:opacity .5s ease .45s}.is-in .c-chart .k-fadein{opacity:1}'
+'@media (prefers-reduced-motion:reduce){.c-chart .k-grow,.c-chart .k-growx{transform:none}'
+'.c-chart .k-draw{stroke-dashoffset:0}.c-chart .k-fadein{opacity:1}}';

/* ---------------------------------------------------------------- tooltip */
var tip;
function tipShow(html,x,y){ if(!tip) return; tip.innerHTML=html; tip.style.left=x+'px'; tip.style.top=y+'px'; tip.classList.add('is-on'); }
function tipHide(){ if(tip) tip.classList.remove('is-on'); }

/* ---------------------------------------------------------------- charts  */
var RAMP=['var(--cat-1)','var(--cat-2)','var(--cat-3)','var(--cat-4)','var(--cat-5)','var(--cat-6)'];
function niceMax(v){
  if(v<=0) return 1;
  var e=Math.pow(10,Math.floor(Math.log10(v))), n=v/e;
  var s=n<=1?1:n<=2?2:n<=2.5?2.5:n<=5?5:10;
  return s*e;
}
function fmt(v,unit){
  var s=''+((Math.abs(v)>=1000)? v.toLocaleString() : (Math.round(v*100)/100));
  if(!unit) return s;
  /* currency units ("₹", "₹ lakh", "$ M") prefix the symbol: ₹14.6 lakh, -₹8.4 lakh */
  var cur=unit.match(/^([₹$€£])\s*(.*)$/);
  if(cur) return (s.charAt(0)==='-'?'-'+cur[1]+s.slice(1):cur[1]+s)+(cur[2]?' '+cur[2]:'');
  return s+' '+unit;
}
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }
function el(tag,attrs,inner){
  var a='';
  for(var k in attrs) if(attrs[k]!==undefined&&attrs[k]!==null) a+=' '+k+'="'+attrs[k]+'"';
  return '<'+tag+a+'>'+(inner||'')+'</'+tag+'>';
}
function parse(node){
  var d={};
  d.type   = node.dataset.chart;
  d.labels = (node.dataset.labels||'').split(',').map(function(s){return s.trim();}).filter(Boolean);
  d.series = JSON.parse(node.dataset.series||'[]');
  d.unit   = node.dataset.unit||'';
  d.height = +(node.dataset.height||0);
  d.max    = node.dataset.max? +node.dataset.max : null;
  d.ymax   = node.dataset.ymax? +node.dataset.ymax : null;
  d.stackPct = node.dataset.pct==='true';
  d.valueLabels = node.dataset.valueLabels!=='false';
  d.baseline = node.dataset.baseline? +node.dataset.baseline : null;
  d.target = node.dataset.target? +node.dataset.target : null;
  d.xlabel = node.dataset.xlabel||''; d.ylabel=node.dataset.ylabel||'';
  d.xunit  = node.dataset.xunit||'';
  d.series.forEach(function(s,i){ if(!s.color) s.color = (d.series.length===1? 'var(--accent)' : RAMP[i%6]); });
  if(d.type==='scatter') d.series.forEach(function(s){ s.points=s.points||[]; });
  return d;
}
/* Nice value scale covering the FULL data range — negative values extend the
   axis below zero instead of being plotted outside the plot area. lo/hi are
   multiples of a nice step, so zero always falls on a gridline. */
function niceScale(vals,dmax){
  var mx=Math.max.apply(null,vals), mn=Math.min.apply(null,vals);
  var hi=(dmax!=null)?dmax:Math.max(0,mx*1.1), lo=Math.min(0,mn*1.1);
  if(hi<=lo) hi=lo+1;
  var step=niceMax((hi-lo)/5);
  return {lo:Math.floor(lo/step+1e-9)*step, hi:Math.ceil(hi/step-1e-9)*step, step:step};
}
function axisY(sc,H,T,B,W,L){
  var out='', k=Math.round((sc.hi-sc.lo)/sc.step);
  for(var i=0;i<=k;i++){
    var v=sc.lo+sc.step*i, y=B-(B-T)*(i/k);
    out+=el('line',{x1:L,x2:W,y1:y.toFixed(1),y2:y.toFixed(1),class:'k-axis'});
    out+=el('text',{x:L-7,y:(y+4.2).toFixed(1),'text-anchor':'end','font-size':12},esc(fmt(v,'')));
  }
  return out;
}
function bars(d,W){
  var H=d.height||300,T=22,B=H-36,L=44;
  var vals=[].concat.apply([],d.series.map(function(s){return s.values;}));
  var sc=niceScale(vals,d.max);
  var Y=function(v){ return B-(B-T)*((v-sc.lo)/(sc.hi-sc.lo)); };
  var y0=Y(Math.max(sc.lo,0));
  var n=d.labels.length, band=(W-L)/n, gap=band*0.28, sw=(band-gap)/d.series.length;
  var s=axisY(sc,H,T,B,W,L);
  s+=el('line',{x1:L,x2:W,y1:y0.toFixed(1),y2:y0.toFixed(1),class:'k-base'});
  d.series.forEach(function(se,si){
    se.values.forEach(function(v,i){
      var yv=Y(v), x=L+band*i+gap/2+sw*si;
      var y=Math.min(yv,y0), h=Math.max(Math.abs(y0-yv),1);
      s+=el('rect',{x:x.toFixed(1),y:y.toFixed(1),width:sw.toFixed(1),height:h.toFixed(1),
        fill:se.color,class:'k-bar k-grow',
        style:'transition-delay:'+(i*55+si*30)+'ms'+(v<0?';transform-origin:top':''),
        'data-tip':'<em>'+esc(d.labels[i])+'</em><b>'+esc(fmt(v,d.unit))+'</b>'+(d.series.length>1?' · '+esc(se.name):'')});
      if(d.valueLabels&&d.series.length===1)
        s+=el('text',{x:(x+sw/2).toFixed(1),y:(v<0?y+h+15:y-6.5).toFixed(1),'text-anchor':'middle','font-size':13,class:'k-val k-fadein'},esc(fmt(v,'')));
    });
  });
  d.labels.forEach(function(l,i){
    s+=el('text',{x:(L+band*i+band/2).toFixed(1),y:B+19,'text-anchor':'middle','font-size':12},esc(l));
  });
  if(d.xlabel) s+=el('text',{x:(L+(W-L)/2).toFixed(1),y:H-3,'text-anchor':'middle','font-size':11.5},esc(d.xlabel));
  return {svg:s,H:H};
}
function hbars(d,W){
  var n=d.labels.length, rowH=d.height? d.height/n : 30, H=rowH*n+16, L=Math.round(W*0.24);
  var vals=d.series[0].values, max=d.max||niceMax(Math.max.apply(null,vals));
  /* right gutter sized to the widest value label (~7.2px/char at 12px) so
     labels always clear the track regardless of number/unit length */
  var texts=vals.map(function(v){return fmt(v,d.unit);});
  var gut=Math.max.apply(null,texts.map(function(t){return t.length;}))*7.2+18;
  var TW=W-L-gut;
  var s='';
  vals.forEach(function(v,i){
    var y=i*rowH+5, bw=TW*(v/max);
    s+=el('rect',{x:L,y:y,width:TW.toFixed(1),height:rowH*0.56,fill:'var(--paper-2)',rx:2});
    s+=el('rect',{x:L,y:y,width:Math.max(bw,1).toFixed(1),height:rowH*0.56,rx:2,
      fill:d.series[0].colors?d.series[0].colors[i]:d.series[0].color,class:'k-bar k-growx',
      style:'transition-delay:'+(i*60)+'ms','data-tip':'<em>'+esc(d.labels[i])+'</em><b>'+esc(texts[i])+'</b>'});
    if(d.target!=null){ var tx=L+TW*(d.target/max);
      s+=el('line',{x1:tx.toFixed(1),x2:tx.toFixed(1),y1:y-3,y2:y+rowH*0.56+3,stroke:'var(--ink)','stroke-width':1.4}); }
    s+=el('text',{x:L-8,y:y+rowH*0.44,'text-anchor':'end','font-size':12},esc(d.labels[i]));
    s+=el('text',{x:W-2,y:y+rowH*0.44,'text-anchor':'end','font-size':12,class:'k-val k-fadein'},esc(texts[i]));
  });
  return {svg:s,H:H};
}
function stack(d,W){
  var H=d.height||300,T=18,B=H-36,L=44,n=d.labels.length,band=(W-L)/n,bw=band*0.6;
  var totals=d.labels.map(function(_,i){ return d.series.reduce(function(a,s){return a+s.values[i];},0); });
  var max=d.stackPct?100:(d.max||niceMax(Math.max.apply(null,totals)*1.05));
  var s=d.stackPct?'':axisY({lo:0,hi:max,step:max/4},H,T,B,W,L);
  s+=el('line',{x1:L,x2:W,y1:B,y2:B,class:'k-base'});
  d.labels.forEach(function(l,i){
    var acc=0, x=L+band*i+(band-bw)/2;
    d.series.forEach(function(se,si){
      var v=d.stackPct? se.values[i]/totals[i]*100 : se.values[i];
      var h=(B-T)*(v/max), y=B-h-acc;
      s+=el('rect',{x:x.toFixed(1),y:y.toFixed(1),width:bw.toFixed(1),height:Math.max(h,.5).toFixed(1),fill:se.color,
        class:'k-seg k-grow',style:'transition-delay:'+(i*50+si*40)+'ms',
        'data-tip':'<em>'+esc(l)+' · '+esc(se.name)+'</em><b>'+esc(fmt(se.values[i],d.unit))+(d.stackPct?' ('+v.toFixed(0)+'%)':'')+'</b>'});
      acc+=h;
    });
    s+=el('text',{x:(L+band*i+band/2).toFixed(1),y:B+19,'text-anchor':'middle','font-size':12},esc(l));
  });
  return {svg:s,H:H};
}
function lineChart(d,W,area){
  var H=d.height||300,T=20,B=H-36,L=44,n=d.labels.length;
  var vals=[].concat.apply([],d.series.map(function(s){return s.values;}));
  var sc=niceScale(vals,d.max);
  var X=function(i){ return L+(W-L)*(n===1?0.5:i/(n-1)); };
  var Y=function(v){ return B-(B-T)*((v-sc.lo)/(sc.hi-sc.lo)); };
  var y0=Y(Math.max(sc.lo,0));
  var s=axisY(sc,H,T,B,W,L);
  s+=el('line',{x1:L,x2:W,y1:y0.toFixed(1),y2:y0.toFixed(1),class:'k-base'});
  d.series.forEach(function(se,si){
    var pts=se.values.map(function(v,i){ return X(i).toFixed(1)+' '+Y(v).toFixed(1); });
    var path='M'+pts.join(' L');
    if(area&&si===0) s+=el('path',{d:path+' L'+X(n-1).toFixed(1)+' '+y0.toFixed(1)+' L'+X(0).toFixed(1)+' '+y0.toFixed(1)+' Z',
      fill:se.color,opacity:.12,class:'k-fadein'});
    s+=el('path',{d:path,fill:'none',stroke:se.color,'stroke-width':se.dash?1.6:2.1,
      'stroke-dasharray':se.dash?'6 4':null,'stroke-linecap':'round','stroke-linejoin':'round',
      class:se.dash?'k-fadein':'k-draw',style:'--len:'+(W*2.2)});
    se.values.forEach(function(v,i){
      s+=el('circle',{cx:X(i).toFixed(1),cy:Y(v).toFixed(1),r:se.dash?0:3.4,fill:se.color,class:'k-pt k-fadein'});
      s+=el('circle',{cx:X(i).toFixed(1),cy:Y(v).toFixed(1),r:11,fill:'transparent',
        'data-tip':'<em>'+esc(d.labels[i])+' · '+esc(se.name)+'</em><b>'+esc(fmt(v,d.unit))+'</b>'});
    });
  });
  d.labels.forEach(function(l,i){
    if(n>8 && i%Math.ceil(n/6)!==0 && i!==n-1) return;
    s+=el('text',{x:X(i).toFixed(1),y:B+19,'text-anchor':i===0?'start':(i===n-1?'end':'middle'),'font-size':12},esc(l));
  });
  return {svg:s,H:H};
}
function donut(d,W){
  var H=d.height||220, R=Math.min(W,H)/2-6, r=R*0.58, cx=H/2+4, cy=H/2, tot=0;
  var vals=d.series[0].values, cols=d.series[0].colors||RAMP;
  vals.forEach(function(v){tot+=v;});
  var a=-Math.PI/2, s='';
  vals.forEach(function(v,i){
    var f=v/tot, a2=a+f*Math.PI*2, big=f>0.5?1:0;
    var p=['M',cx+R*Math.cos(a),cy+R*Math.sin(a),'A',R,R,0,big,1,cx+R*Math.cos(a2),cy+R*Math.sin(a2),
           'L',cx+r*Math.cos(a2),cy+r*Math.sin(a2),'A',r,r,0,big,0,cx+r*Math.cos(a),cy+r*Math.sin(a),'Z'].join(' ');
    s+=el('path',{d:p,fill:cols[i%cols.length],class:'k-seg k-fadein',style:'transition-delay:'+(i*70)+'ms',
      'data-tip':'<em>'+esc(d.labels[i])+'</em><b>'+esc(fmt(v,d.unit))+' · '+(f*100).toFixed(0)+'%</b>'});
    a=a2;
  });
  var lx=H+22, ly=cy-vals.length*10+8;
  vals.forEach(function(v,i){
    s+=el('rect',{x:lx,y:ly+i*20-8.5,width:10,height:10,rx:2,fill:cols[i%cols.length]});
    s+=el('text',{x:lx+16,y:ly+i*20,'font-size':12},esc(d.labels[i]));
    s+=el('text',{x:W,y:ly+i*20,'text-anchor':'end','font-size':12,class:'k-val'},(v/tot*100).toFixed(0)+'%');
  });
  return {svg:s,H:H};
}
function dots(d,W){
  var H=d.height||300,T=20,B=H-38,L=48,n=d.labels.length;
  var vals=[].concat.apply([],d.series.map(function(s){return s.values;}));
  var lo=d.baseline!=null?d.baseline:Math.min.apply(null,vals)*0.97;
  var hi=d.max||Math.max.apply(null,vals)*1.03;
  var X=function(i){ return L+(W-L-14)*(n===1?0.5:i/(n-1)); };
  var Y=function(v){ return B-(B-T)*((v-lo)/(hi-lo)); };
  var s='';
  for(var i=0;i<=4;i++){ var v=lo+(hi-lo)*i/4, y=Y(v);
    s+=el('line',{x1:L,x2:W-4,y1:y.toFixed(1),y2:y.toFixed(1),class:'k-axis'});
    s+=el('text',{x:L-7,y:(y+4.2).toFixed(1),'text-anchor':'end','font-size':12},v.toFixed(1)); }
  s+=el('line',{x1:L,x2:L,y1:T,y2:B,class:'k-base'});
  d.series.forEach(function(se,si){
    var pts=se.values.map(function(v,i){return X(i).toFixed(1)+' '+Y(v).toFixed(1);});
    s+=el('path',{d:'M'+pts.join(' L'),fill:'none',stroke:se.color,'stroke-width':1.8,
      'stroke-dasharray':se.dash?'5 3.5':null,class:'k-draw',style:'--len:'+(W*2.2)});
    se.values.forEach(function(v,i){
      var e=(se.err&&se.err[i])||0;
      if(e) s+=el('path',{d:'M'+X(i)+' '+Y(v-e)+' V'+Y(v+e)+' M'+(X(i)-5)+' '+Y(v-e)+' H'+(X(i)+5)+
        ' M'+(X(i)-5)+' '+Y(v+e)+' H'+(X(i)+5),stroke:se.color,'stroke-width':1.1,fill:'none',class:'k-fadein'});
      s+=el(se.square?'rect':'circle',se.square
        ?{x:X(i)-4,y:Y(v)-4,width:8,height:8,fill:'var(--paper)',stroke:se.color,'stroke-width':1.6,class:'k-fadein'}
        :{cx:X(i).toFixed(1),cy:Y(v).toFixed(1),r:4,fill:se.color,class:'k-fadein'});
      s+=el('circle',{cx:X(i).toFixed(1),cy:Y(v).toFixed(1),r:11,fill:'transparent',
        'data-tip':'<em>'+esc(d.labels[i])+' · '+esc(se.name)+'</em><b>'+esc(fmt(v,d.unit))+(e?' ± '+e:'')+'</b>'});
    });
  });
  d.labels.forEach(function(l,i){ s+=el('text',{x:X(i).toFixed(1),y:B+19,'text-anchor':'middle','font-size':12},esc(l)); });
  if(d.xlabel) s+=el('text',{x:(L+(W-L)/2).toFixed(1),y:H-3,'text-anchor':'middle','font-size':11.5},esc(d.xlabel));
  return {svg:s,H:H};
}
function spark(d,W){
  var H=d.height||60,vals=d.series[0].values,mn=Math.min.apply(null,vals),mx=Math.max.apply(null,vals);
  var X=function(i){return (W)*(i/(vals.length-1));},Y=function(v){return H-4-(H-12)*((v-mn)/((mx-mn)||1));};
  var pts=vals.map(function(v,i){return X(i).toFixed(1)+' '+Y(v).toFixed(1);});
  var s=el('path',{d:'M'+pts.join(' L')+' L'+W+' '+H+' L0 '+H+' Z',fill:d.series[0].color,opacity:.13})
       +el('path',{d:'M'+pts.join(' L'),fill:'none',stroke:d.series[0].color,'stroke-width':2,class:'k-draw',style:'--len:'+(W*2.2)})
       +el('circle',{cx:X(vals.length-1),cy:Y(vals[vals.length-1]),r:3.4,fill:d.series[0].color,class:'k-fadein'});
  return {svg:s,H:H};
}
function scatter(d,W){
  var H=d.height||300,T=18,B=H-36,L=44;
  var pts=[].concat.apply([],d.series.map(function(s){return s.points;}));
  var xs=pts.map(function(q){return q[0];}), ys=pts.map(function(q){return q[1];});
  var xmax=d.max||niceMax(Math.max.apply(null,xs)*1.05), ymax=d.ymax||niceMax(Math.max.apply(null,ys)*1.08);
  var X=function(v){return L+(W-L-6)*(v/xmax);}, Y=function(v){return B-(B-T)*(v/ymax);};
  var s='',i;
  for(i=0;i<=4;i++){ var yv=ymax*i/4, yy=Y(yv);
    s+=el('line',{x1:L,x2:W-6,y1:yy.toFixed(1),y2:yy.toFixed(1),class:'k-axis'});
    s+=el('text',{x:L-7,y:(yy+4.2).toFixed(1),'text-anchor':'end','font-size':12},esc(fmt(yv,'')));
  }
  for(i=0;i<=4;i++){ var xv=xmax*i/4;
    s+=el('text',{x:X(xv).toFixed(1),y:B+19,'text-anchor':'middle','font-size':12},esc(fmt(xv,'')));
  }
  s+=el('line',{x1:L,x2:W-6,y1:B,y2:B,class:'k-base'});
  d.series.forEach(function(se,si){
    se.points.forEach(function(q,j){
      s+=el('circle',{cx:X(q[0]).toFixed(1),cy:Y(q[1]).toFixed(1),r:(q[2]||4),fill:se.color,opacity:.78,
        class:'k-seg k-fadein',style:'transition-delay:'+(j*22)+'ms',
        'data-tip':'<em>'+esc(q[3]||se.name)+'</em><b>'+esc(fmt(q[0],d.xunit||''))+' · '+esc(fmt(q[1],d.unit))+'</b>'});
    });
  });
  if(d.xlabel) s+=el('text',{x:(L+(W-L)/2).toFixed(1),y:H-3,'text-anchor':'middle','font-size':11.5},esc(d.xlabel));
  return {svg:s,H:H};
}
var RENDER={bars:bars,scatter:scatter,hbars:hbars,stack:stack,donut:donut,dot:dots,spark:spark,
  line:function(d,W){return lineChart(d,W,false);},area:function(d,W){return lineChart(d,W,true);}};

function drawChart(node){
  var d=parse(node), f=RENDER[d.type];
  var host=node.closest('.sheet');
  var sw=host?host.clientWidth:0, nw=node.clientWidth||0;
  var W=(sw>0&&nw>0)? Math.max(220,Math.min(1600,Math.round(1000*nw/sw))) : 1000;
  node.dataset.w=W;
  if(!f) return;
  var hidden=(node.dataset.hidden||'').split(',').filter(Boolean);
  d.series=d.series.filter(function(s){ return hidden.indexOf(s.name)<0; });
  if(!d.series.length) d.series=parse(node).series.slice(0,1);
  var out=f(d,W);
  node.innerHTML='<svg viewBox="0 0 '+W+' '+out.H+'" preserveAspectRatio="xMidYMid meet" role="img" aria-label="'
    +esc(node.dataset.alt||d.type+' chart')+'">'+out.svg+'</svg>';
  if(host&&host.classList.contains('is-in')){ settleChart(node); }
}
/* Fail-safe: once a slide is revealed, chart marks must not depend on CSS
   transform/dash transitions resolving (they don't in some embeds, print
   pipelines and SVG-transform-buggy engines). Stripping the animation
   classes leaves the marks in their plain, fully-visible state. */
function settleChart(node){
  node.querySelectorAll('.k-grow,.k-growx,.k-draw,.k-fadein').forEach(function(m){
    m.classList.remove('k-grow','k-growx','k-draw','k-fadein');
    m.style.removeProperty('transition-delay');
  });
}
function buildLegend(node){
  var box=document.querySelector('[data-legend-for="'+node.id+'"]');
  if(!box) return;
  var series=JSON.parse(node.dataset.series||'[]');
  series.forEach(function(s,i){ if(!s.color) s.color=(series.length===1?'var(--accent)':RAMP[i%6]); });
  box.innerHTML=series.map(function(s){
    return '<button type="button" aria-pressed="true" data-series="'+esc(s.name)+'">'
      +'<i class="'+(s.dash?'is-dash':'')+'" style="'+(s.dash?'color:'+s.color:'background:'+s.color)+'"></i>'
      +esc(s.name)+'</button>';
  }).join('');
  box.addEventListener('click',function(e){
    var b=e.target.closest('button[data-series]'); if(!b) return;
    var on=b.getAttribute('aria-pressed')==='true';
    var hid=(node.dataset.hidden||'').split(',').filter(Boolean);
    if(on){ hid.push(b.dataset.series); } else { hid=hid.filter(function(x){return x!==b.dataset.series;}); }
    b.setAttribute('aria-pressed',String(!on));
    node.dataset.hidden=hid.join(',');
    drawChart(node);
  });
}
function buildSwitch(node){
  var box=document.querySelector('[data-switch-for="'+node.id+'"]');
  if(!box||!node.dataset.sets) return;
  var sets=JSON.parse(node.dataset.sets);
  box.innerHTML=Object.keys(sets).map(function(k,i){
    return '<button type="button" data-set="'+esc(k)+'" aria-pressed="'+(i===0)+'">'+esc(k)+'</button>';
  }).join('');
  box.addEventListener('click',function(e){
    var b=e.target.closest('button[data-set]'); if(!b) return;
    [].forEach.call(box.children,function(c){ c.setAttribute('aria-pressed',String(c===b)); });
    var s=sets[b.dataset.set];
    if(s.labels) node.dataset.labels=s.labels.join(',');
    if(s.series) node.dataset.series=JSON.stringify(s.series);
    if(s.unit!==undefined) node.dataset.unit=s.unit;
    if(s.max!==undefined) node.dataset.max=s.max;
    node.dataset.hidden='';
    var host=node.closest('.sheet'); if(host) host.classList.remove('is-in');
    drawChart(node);
    requestAnimationFrame(function(){ if(host) host.classList.add('is-in'); });
    buildLegend(node);
    var cap=document.querySelector('[data-caption-for="'+node.id+'"]');
    if(cap&&s.caption) cap.innerHTML=s.caption;
  });
}

/* ------------------------------------------------------------ count-up    */
function countUp(node){
  var to=parseFloat(node.dataset.count), dec=(node.dataset.dec!==undefined)?+node.dataset.dec:
    ((String(to).split('.')[1]||'').length);
  var pre=node.dataset.prefix||'', suf=node.dataset.suffix||'', t0=null, dur=900;
  if(window.matchMedia('(prefers-reduced-motion:reduce)').matches){ node.textContent=pre+to.toFixed(dec)+suf; return; }
  function step(t){
    if(!t0) t0=t;
    var p=Math.min((t-t0)/dur,1), e=1-Math.pow(1-p,3);
    node.textContent=pre+(to*e).toFixed(dec)+suf;
    if(p<1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ------------------------------------------------------------ tables      */
function sortable(tb){
  tb.querySelectorAll('th[data-sort]').forEach(function(th,ci){
    th.addEventListener('click',function(){
      var idx=[].indexOf.call(th.parentNode.children,th);
      var dir=th.getAttribute('aria-sort')==='ascending'?'descending':'ascending';
      tb.querySelectorAll('th[data-sort]').forEach(function(o){o.removeAttribute('aria-sort');});
      th.setAttribute('aria-sort',dir);
      var body=tb.tBodies[0], rows=[].slice.call(body.rows);
      rows.sort(function(a,b){
        var x=a.cells[idx].dataset.v||a.cells[idx].textContent, y=b.cells[idx].dataset.v||b.cells[idx].textContent;
        var nx=parseFloat(String(x).replace(/[^0-9.\-]/g,'')), ny=parseFloat(String(y).replace(/[^0-9.\-]/g,''));
        var r=(!isNaN(nx)&&!isNaN(ny))? nx-ny : String(x).localeCompare(String(y));
        return dir==='ascending'? r : -r;
      });
      rows.forEach(function(r){ body.appendChild(r); });
    });
  });
}

/* ------------------------------------------------------------ reveal      */
function stagger(sheet){
  var i=0;
  sheet.querySelectorAll('[data-anim]').forEach(function(n){
    if(!n.style.getPropertyValue('--d')) n.style.setProperty('--d',(n.dataset.d||(i*70))+'ms');
    i++;
  });
}
function reveal(sheet){
  sheet.classList.add('is-in');
  sheet.querySelectorAll('[data-count]').forEach(countUp);
  setTimeout(function(){ sheet.querySelectorAll('.c-chart[data-chart]').forEach(settleChart); },1500);
}
function unreveal(sheet){
  sheet.classList.remove('is-in');
  sheet.querySelectorAll('[data-count]').forEach(function(n){ n.textContent=(n.dataset.prefix||'')+'0'+(n.dataset.suffix||''); });
}

/* ------------------------------------------------------------ overflow    */
function sheetOverflows(s){
  var pad=s.querySelector('.sheet__pad'); if(!pad) return false;
  var cs=getComputedStyle(pad);
  var limH=pad.clientHeight-parseFloat(cs.paddingBottom||'0');
  var limW=pad.clientWidth-parseFloat(cs.paddingRight||'0');
  if(!limH||!limW) return false;
  var over=false;
  [].forEach.call(pad.children,function(c){
    if(getComputedStyle(c).position==='absolute') return;
    if(c.offsetTop+c.offsetHeight>limH+2 || c.offsetLeft+c.offsetWidth>limW+2) over=true;
  });
  return over;
}
/* Overflow guard + autofit. All slide dimensions derive from --fs/--sp, so an
   overflowing slide is shrunk uniformly (3% steps, floor 0.78) until its
   content fits the fixed 16:9 canvas — words are never clipped. The badge
   only remains when even the floor can't absorb the excess: that slide has
   too much content and must be split at the source. */
function checkOverflow(){
  document.querySelectorAll('.sheet--slide').forEach(function(s){
    if(!s.clientWidth) return;               /* hidden (present mode) — keep last fit */
    var f=1; s.style.setProperty('--fit',f);
    while(sheetOverflows(s) && f>0.781){ f-=0.03; s.style.setProperty('--fit',f.toFixed(3)); }
    var over=sheetOverflows(s);
    s.classList.toggle('k-overflow',over);
    if(over) console.warn('DECK: slide overflows even at minimum autofit — split this slide.',s);
  });
}

/* ------------------------------------------------------------ present     */
var slides=[], cur=0;
function present(on){
  document.body.dataset.mode = on? 'present':'';
  if(on){
    slides=[].slice.call(document.querySelectorAll('.sheet--slide'));
    cur=0; show(0);
    requestAnimationFrame(function(){ document.querySelectorAll('.c-chart[data-chart]').forEach(drawChart); });
    if(document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(function(){});
  }else{
    if(document.fullscreenElement&&document.exitFullscreen) document.exitFullscreen().catch(function(){});
    slides.forEach(function(s){ s.classList.remove('is-current'); reveal(s); });
    document.querySelectorAll('[data-mode-btn]').forEach(function(x){ x.setAttribute('aria-pressed','false'); });
  }
}
function show(i){
  if(!slides.length) return;
  cur=Math.max(0,Math.min(i,slides.length-1));
  slides.forEach(function(s,j){
    s.classList.toggle('is-current',j===cur);
    if(j!==cur) unreveal(s);
  });
  var s=slides[cur];
  unreveal(s);
  requestAnimationFrame(function(){ requestAnimationFrame(function(){ reveal(s); }); });
  var hud=document.querySelector('.k-present-hud .k-pos');
  if(hud) hud.textContent=(cur+1)+' / '+slides.length;
}

/* ------------------------------------------------------------ boot        */
function init(cfg){ if(cfg) deep(CFG,cfg); if(CFG.theme) setTheme(CFG.theme); }

function boot(){
  var st=document.createElement('style'); st.textContent=CSS; document.head.appendChild(st);
  tip=document.createElement('div'); tip.className='k-tip'; document.body.appendChild(tip);

  /* slots */
  document.querySelectorAll('[data-slot]').forEach(function(n){
    var v=CFG[n.dataset.slot]; if(v!==undefined&&v!=='') n.innerHTML=fill(String(v));
  });

  /* footers */
  var decks=[].slice.call(document.querySelectorAll('.sheet--slide'));
  decks.forEach(function(sheet,i){
    var f=sheet.querySelector('[data-foot]'); if(!f) return;
    var ctx={page:(f.dataset.page||i+1),pages:(f.dataset.pages||decks.length)};
    var L=f.dataset.l!==undefined?f.dataset.l:CFG.slideFooter.left;
    var C=f.dataset.c!==undefined?f.dataset.c:CFG.slideFooter.center;
    var R=f.dataset.r!==undefined?f.dataset.r:CFG.slideFooter.right;
    var h='';
    if(L) h+='<span class="k-foot-l">'+fill(L,ctx)+'</span>';
    if(C) h+='<span class="k-foot-c">'+fill(C,ctx)+'</span>';
    if(R) h+='<span class="k-foot-r">'+fill(R,ctx)+'</span>';
    f.innerHTML=h;
  });

  /* charts */
  var n=0;
  document.querySelectorAll('.c-chart[data-chart]').forEach(function(c){
    if(!c.id) c.id='chart-'+(++n);
    drawChart(c); buildLegend(c); buildSwitch(c);
  });
  document.querySelectorAll('.c-table--sortable').forEach(sortable);

  /* tooltips (delegated, covers charts + heatgrids + anything with data-tip) */
  document.addEventListener('mouseover',function(e){
    var t=e.target.closest('[data-tip]'); if(!t) return;
    var r=t.getBoundingClientRect();
    tipShow(t.dataset.tip,r.left+r.width/2,r.top);
    var ch=t.closest('.c-chart'); if(ch){ ch.classList.add('is-hover'); t.classList.add('is-active'); }
  });
  document.addEventListener('mouseout',function(e){
    var t=e.target.closest('[data-tip]'); if(!t) return;
    tipHide(); t.classList.remove('is-active');
    var ch=t.closest('.c-chart'); if(ch) ch.classList.remove('is-hover');
  });

  /* reveal on scroll */
  document.querySelectorAll('.sheet').forEach(stagger);
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){
      es.forEach(function(en){ if(en.isIntersecting){ reveal(en.target); io.unobserve(en.target); } });
    },{threshold:.18});
    document.querySelectorAll('.sheet').forEach(function(s){ io.observe(s); });
  }else{
    document.querySelectorAll('.sheet').forEach(reveal);
  }

  /* redraw charts if the layout width changes materially */
  if('ResizeObserver' in window){
    var rt; var ro=new ResizeObserver(function(es){
      var need=es.some(function(e){
        var nd=e.target, W=+nd.dataset.w||0, s=nd.closest('.sheet');
        if(!s||!s.clientWidth||!nd.clientWidth) return false;
        return Math.abs(Math.round(1000*nd.clientWidth/s.clientWidth)-W)>4;
      });
      if(!need) return;
      clearTimeout(rt); rt=setTimeout(function(){
        document.querySelectorAll('.c-chart[data-chart]').forEach(drawChart); },120);
    });
    document.querySelectorAll('.c-chart[data-chart]').forEach(function(c){ ro.observe(c); });
  }

  /* present controls */
  document.querySelectorAll('[data-mode-btn="present"]').forEach(function(b){
    b.addEventListener('click',function(){ b.setAttribute('aria-pressed','true'); present(true); });
  });
  document.addEventListener('keydown',function(e){
    if(document.body.dataset.mode!=='present') return;
    if(e.key==='ArrowRight'||e.key==='PageDown'||e.key===' '){ e.preventDefault(); show(cur+1); }
    if(e.key==='ArrowLeft'||e.key==='PageUp'){ e.preventDefault(); show(cur-1); }
    if(e.key==='Home'){ e.preventDefault(); show(0); }
    if(e.key==='End'){ e.preventDefault(); show(slides.length-1); }
    if(e.key==='Escape'){ present(false); }
  });
  document.addEventListener('click',function(e){
    if(document.body.dataset.mode!=='present') return;
    if(e.target.closest('.k-present-hud')||e.target.closest('[data-tip]')||e.target.closest('button')) return;
    show(cur+1);
  });
  var tx=null,ty=null;
  document.addEventListener('touchstart',function(e){
    if(document.body.dataset.mode!=='present') return;
    tx=e.touches[0].clientX; ty=e.touches[0].clientY;
  },{passive:true});
  document.addEventListener('touchend',function(e){
    if(document.body.dataset.mode!=='present'||tx===null) return;
    var dx=e.changedTouches[0].clientX-tx, dy=e.changedTouches[0].clientY-ty;
    tx=ty=null;
    if(Math.abs(dx)<40||Math.abs(dx)<Math.abs(dy)) return;
    show(dx<0? cur+1 : cur-1);
  },{passive:true});
  var hud=document.querySelector('.k-present-hud');
  if(hud){
    hud.querySelector('[data-hud="prev"]').addEventListener('click',function(){show(cur-1);});
    hud.querySelector('[data-hud="next"]').addEventListener('click',function(){show(cur+1);});
    hud.querySelector('[data-hud="exit"]').addEventListener('click',function(){present(false);});
  }

  /* overflow guard — content taller or wider than the canvas gets a visible badge */
  checkOverflow();
  if(document.fonts&&document.fonts.ready) document.fonts.ready.then(function(){ checkOverflow(); });
  window.addEventListener('load',checkOverflow);
  var ovt; window.addEventListener('resize',function(){ clearTimeout(ovt); ovt=setTimeout(checkOverflow,150); });
}

window.Doc={init:init,setTheme:setTheme,config:CFG,redraw:function(){
  document.querySelectorAll('.c-chart[data-chart]').forEach(drawChart);}};
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();
/* ==END-DECK-CORE-JS== */
