#!/usr/bin/env python3
"""Extract PowerPoint text, images, and notes into a deterministic JSON file."""

import argparse
import json
import sys
from pathlib import Path


def extract_pptx(file_path: Path, output_dir: Path) -> list[dict]:
    """Return slide data and write extracted images under output_dir/assets."""
    try:
        from pptx import Presentation
        from pptx.enum.shapes import MSO_SHAPE_TYPE
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "python-pptx is required; install it with "
            "`python3 -m pip install python-pptx==1.0.2`"
        ) from exc

    prs = Presentation(file_path)
    slides_data = []
    assets_dir = output_dir / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)

    for slide_num, slide in enumerate(prs.slides):
        slide_data = {
            "number": slide_num + 1,
            "title": "",
            "content": [],
            "images": [],
            "notes": "",
        }

        for shape in slide.shapes:
            if shape.has_text_frame:
                if shape == slide.shapes.title:
                    slide_data["title"] = shape.text
                else:
                    slide_data["content"].append(
                        {"type": "text", "content": shape.text}
                    )

            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                image = shape.image
                image_ext = image.ext
                image_name = (
                    f"slide{slide_num + 1}_img"
                    f"{len(slide_data['images']) + 1}.{image_ext}"
                )
                image_path = assets_dir / image_name
                image_path.write_bytes(image.blob)

                slide_data["images"].append(
                    {
                        "path": (Path("assets") / image_name).as_posix(),
                        "width": shape.width,
                        "height": shape.height,
                    }
                )

        if slide.has_notes_slide:
            notes_frame = slide.notes_slide.notes_text_frame
            slide_data["notes"] = notes_frame.text

        slides_data.append(slide_data)

    return slides_data


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract PPTX text, images, and notes to extracted-slides.json."
    )
    parser.add_argument("input", type=Path, help="Source .pptx file")
    parser.add_argument(
        "output_dir",
        type=Path,
        nargs="?",
        default=Path("."),
        help="Destination directory (default: current directory)",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.input.is_file():
        print(f"error: input file not found: {args.input}", file=sys.stderr)
        return 2
    if args.input.suffix.lower() != ".pptx":
        print(f"error: expected a .pptx file, received: {args.input}", file=sys.stderr)
        return 2

    args.output_dir.mkdir(parents=True, exist_ok=True)
    try:
        slides = extract_pptx(args.input, args.output_dir)
    except Exception as exc:
        print(f"error: failed to extract {args.input}: {exc}", file=sys.stderr)
        return 1

    output_path = args.output_dir / "extracted-slides.json"
    output_path.write_text(
        json.dumps(slides, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "output": str(output_path),
                "slides": len(slides),
                "images": sum(len(slide["images"]) for slide in slides),
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
