#!/usr/bin/env python3
"""
validate-themes.py — catalog linter. Run after adding or editing any theme.

Checks every references/themes/<slug>.md for:
  1. Frontmatter (name, slug matching the filename, scheme, fonts).
  2. A theme CSS block defining every required token; CSS discipline.
  3. A consistent entry in references/template-index.json.
  4. Example slides that survive the real deck validator: each theme's
     ```html fences are wrapped in the standard skeleton with the current
     cores and the theme's CSS, then run through validate-deck.py
     (example-content markers disabled; warnings ignored, failures reported).

Exit 0 when the catalog is clean; 1 otherwise. Stdlib only.
"""
import importlib.util
import io
import json
import re
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
THEMES = ROOT / 'references' / 'themes'
INDEX = ROOT / 'references' / 'template-index.json'

spec = importlib.util.spec_from_file_location('validate_deck', Path(__file__).parent / 'validate-deck.py')
vd = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vd)

INDEX_FIELDS = ['slug', 'name', 'tagline', 'mood', 'tone', 'occasion',
                'formality', 'density', 'scheme', 'best_for', 'avoid_for', 'design_md']

SKELETON = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Theme smoke</title>
{font_link}
<style>
{core_css}

/* ---- THEME ---- */
{theme_css}
</style>
</head>
<body>
<div class="k-bar">
  <div class="k-bar__name">Theme smoke <span>catalog lint</span></div>
  <div class="k-seg" role="group" aria-label="Presentation controls">
    <button data-mode-btn="present" aria-pressed="false">Present</button>
  </div>
</div>
<main class="k-stage">
{slides}
</main>
<div class="k-present-hud" aria-hidden="true">
  <button data-hud="prev" aria-label="Previous slide">&larr;</button>
  <span class="k-pos">1 / 1</span>
  <button data-hud="next" aria-label="Next slide">&rarr;</button>
  <button data-hud="exit" aria-label="Exit present mode">Esc</button>
</div>
<style>@page{{size:1280px 720px;margin:0}}</style>
<script>
{core_js}
</script>
<script>
Doc.init({{ source: 'Catalog smoke build', slideFooter: {{ left:'{{source}}', center:'{{madeWith}}', right:'{{page}} / {{pages}}' }} }});
</script>
</body>
</html>
"""


def frontmatter(src):
    m = re.match(r'---\n(.*?)\n---\n', src, re.S)
    if not m:
        return None
    out = {}
    for line in m.group(1).splitlines():
        if ':' in line:
            k, v = line.split(':', 1)
            out[k.strip()] = v.strip()
    return out


def main():
    errors, checked = [], 0
    core_css = (ROOT / 'assets' / 'deck-core.css').read_text(encoding='utf-8')
    core_js = (ROOT / 'assets' / 'deck-core.js').read_text(encoding='utf-8')
    index = json.loads(INDEX.read_text(encoding='utf-8'))
    by_slug = {t.get('slug'): t for t in index.get('templates', [])}

    theme_files = sorted(THEMES.glob('*.md'))
    if index.get('template_count') != len(index.get('templates', [])):
        errors.append(f"index: template_count={index.get('template_count')} but "
                      f"{len(index.get('templates', []))} entries")
    for slug, entry in by_slug.items():
        p = ROOT / entry.get('design_md', '')
        if not p.is_file():
            errors.append(f"index: {slug}: design_md {entry.get('design_md')!r} does not exist")
        missing = [f for f in INDEX_FIELDS if not entry.get(f)]
        if missing:
            errors.append(f"index: {slug}: missing fields {missing}")

    vd.EXAMPLE_MARKERS = []  # theme examples ARE sample content, by design

    for path in theme_files:
        checked += 1
        slug = path.stem
        src = path.read_text(encoding='utf-8')
        pre = f'{slug}:'

        fm = frontmatter(src)
        if not fm:
            errors.append(f'{pre} missing frontmatter')
            continue
        if fm.get('slug') != slug:
            errors.append(f"{pre} frontmatter slug {fm.get('slug')!r} != filename")
        for key in ('name', 'scheme', 'fonts'):
            if not fm.get(key):
                errors.append(f'{pre} frontmatter missing {key!r}')
        if fm.get('scheme') not in ('light', 'dark', 'mixed'):
            errors.append(f"{pre} scheme {fm.get('scheme')!r} not light/dark/mixed")
        if slug not in by_slug:
            errors.append(f'{pre} no entry in template-index.json')

        css_m = re.search(r'```css\n(.*?)```', src, re.S)
        if not css_m:
            errors.append(f'{pre} no ```css theme block')
            continue
        theme_css = css_m.group(1)
        for tok in vd.REQUIRED_TOKENS:
            if not re.search(re.escape(tok) + r'\s*:', theme_css):
                errors.append(f'{pre} theme CSS does not define {tok}')
        if re.search(r'\d(vw|vh|vmin|vmax)\b', theme_css):
            errors.append(f'{pre} theme CSS uses viewport units — sizes derive from --fs/--sp/cqw')
        # px font-size is banned except inside SVG-scoped rules, where px means
        # viewBox user units and scales with the drawing.
        for rule in theme_css.split('}'):
            sel = rule.split('{')[0]
            if re.search(r'\btext\b|\bsvg\b', sel):
                continue
            for m in re.finditer(r'font-size\s*:\s*[\d.]+px', rule):
                errors.append(f'{pre} theme CSS uses px font-size ({m.group(0)}) — use calc(var(--fs)*n)')

        slides = '\n'.join(m.group(1) for m in re.finditer(r'```html\n(.*?)```', src, re.S))
        if not slides.strip():
            errors.append(f'{pre} no ```html example slides')
            continue

        fonts = fm.get('fonts', 'none')
        font_link = '' if fonts == 'none' else f'<link href="{fonts}" rel="stylesheet">'
        html = SKELETON.format(font_link=font_link, core_css=core_css,
                               theme_css=theme_css, core_js=core_js, slides=slides)
        with tempfile.NamedTemporaryFile('w', suffix=f'-{slug}.html', delete=False) as f:
            f.write(html)
            tmp = f.name
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = vd.main(tmp)
        if rc != 0:
            report = '\n'.join('    ' + ln for ln in buf.getvalue().splitlines()
                               if ln.startswith('FAIL'))
            errors.append(f'{pre} example slides fail the deck validator:\n{report}')

    files_on_disk = {p.stem for p in theme_files}
    for slug in by_slug:
        if slug not in files_on_disk:
            errors.append(f'index: {slug}: listed but references/themes/{slug}.md missing')

    for e in errors:
        print(f'FAIL  {e}')
    print(f'\n{checked} themes checked, {len(by_slug)} index entries — {len(errors)} problems')
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
