#!/usr/bin/env python3
"""
refresh-core.py — swap the embedded core blocks in an existing deck for the
current assets/deck-core.css and assets/deck-core.js. Use after the core
assets change so an already-generated deck passes the validator's hash check
without being regenerated.

Usage: python3 refresh-core.py path/to/deck.html
"""
import sys
from pathlib import Path

CSS_S = '/* ==DECK-CORE-CSS v2== */'
CSS_E = '/* ==END-DECK-CORE-CSS== */'
JS_S  = '/* ==DECK-CORE-JS v2== */'
JS_E  = '/* ==END-DECK-CORE-JS== */'

ASSETS = Path(__file__).resolve().parent.parent / 'assets'


def swap(src, start, end, replacement):
    i = src.find(start)
    j = src.find(end)
    if i == -1 or j == -1 or j < i:
        return None
    return src[:i] + replacement.strip() + src[j + len(end):]


def main():
    if len(sys.argv) != 2:
        print(__doc__.strip())
        sys.exit(2)
    deck = Path(sys.argv[1])
    src = deck.read_text(encoding='utf-8')
    for label, s, e, asset in (('core CSS', CSS_S, CSS_E, 'deck-core.css'),
                               ('core JS', JS_S, JS_E, 'deck-core.js')):
        fresh = (ASSETS / asset).read_text(encoding='utf-8')
        out = swap(src, s, e, fresh)
        if out is None:
            print(f'FAIL  {label}: sentinel block not found in {deck.name}')
            sys.exit(1)
        src = out
        print(f'ok    {label} refreshed from assets/{asset}')
    deck.write_text(src, encoding='utf-8')
    print(f'done  {deck} updated — re-run validate-deck.py to confirm')


if __name__ == '__main__':
    main()
