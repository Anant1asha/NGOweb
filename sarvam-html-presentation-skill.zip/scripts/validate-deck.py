#!/usr/bin/env python3
"""Validate a generated Sarvam HTML deck.

Three layers, standard library only:
  1. Substrate integrity — the embedded core CSS/JS must hash-match assets/.
  2. Structure — slides, theme tokens, chart data, self-containment.
  3. Design + content lints (WARN) — the slop checklist: topic-label titles,
     bullet-only slides, repeated compositions, chart monotony, missing
     units/legends/sources/alt text, banned phrases, filler slides.

Exit 1 on any FAIL. Warnings do not fail the build but must be read.
"""
import sys, re, json, hashlib
from html.parser import HTMLParser
from pathlib import Path

CSS_S = '/* ==DECK-CORE-CSS v2== */'
CSS_E = '/* ==END-DECK-CORE-CSS== */'
JS_S  = '/* ==DECK-CORE-JS v2== */'
JS_E  = '/* ==END-DECK-CORE-JS== */'

ASSETS = Path(__file__).resolve().parent.parent / 'assets'

REQUIRED_TOKENS = ['--ink', '--ink-2', '--ink-3', '--paper', '--paper-2', '--paper-3',
                   '--rule', '--accent', '--accent-ink', '--accent-soft',
                   '--cat-1', '--cat-2', '--cat-3', '--cat-4', '--cat-5', '--cat-6',
                   '--app-bg', '--font-display', '--font-body']

CHART_TYPES = {'bars', 'hbars', 'stack', 'line', 'area', 'donut', 'dot', 'scatter', 'spark'}
LABELLED_TYPES = {'bars', 'hbars', 'stack', 'line', 'area', 'donut', 'dot'}

GENERIC_TITLES = {'agenda', 'thank you', 'thanks', 'questions', 'q&a', 'q & a',
                  'key takeaways', 'takeaways', 'conclusion', 'overview',
                  'introduction', 'summary', 'about us'}

BANNED = [r'\bleverag\w*', r'\bdelve\w*', r'\bseamless\w*', r'\bcutting.edge\b',
          r'\bholistic\w*', r'\brobust\b', r'\bunlock\w*', r'\bempower\w*',
          r'\bsynerg\w*', r'\bgame.chang\w*', r'\binnovative solution\w*',
          r'\bbest.in.class\b', r'\bstate.of.the.art\b', r"in today's",
          r'\bfast.paced world\b', r'\bparadigm\b', r'\bworld.class\b']

# Strings that only occur in reference/example material and must not ship.
EXAMPLE_MARKERS = ['Sample data — set via Doc.init', 'Northwind', 'Meridian Partners',
                   'NWF-2231', 'Northgate Logistics', 'NGL-1188', 'Kettle & Vane',
                   'Ostro Ferry', 'RFC-0142', 'WP-2026-14', 'UMI-2026',
                   'Reef Ecophysiology', 'Urban Mobility Index', 'ledger-platform',
                   'No. 24 of 2026', 'Swiftbasket', 'Atlas & Co', 'SWB-0472',
                   'Fernway', 'Verdant & Main', 'Calder Institute', 'Ledger & Line',
                   'Bluewick', 'Studio Hardline', 'Harlan Advisory', 'Timberline Works']

LAYOUT_SIG = ['l-2a', 'l-2b', 'l-2', 'l-3', 'l-4', 'c-statrow', 'c-bignum', 'c-heatgrid',
              'c-timeline', 'c-waffle', 'c-matrix2', 'd-band', 'd-sm', 'd-hero', 't-kpi',
              't-cohort', 'e-eg', 'e-poll', 't-storyline', 'c-pullquote']

# Blocks that each occupy meaningful slide height; too many on one slide
# means the fixed 16:9 canvas will clip (the runtime badge is ground truth).
MAJOR_BLOCKS = {'c-callout', 'c-panel', 'c-statrow', 'c-bignum', 'c-heatgrid', 'c-timeline',
                'c-matrix2', 'c-pullquote', 'c-table', 'd-table', 'd-band', 'd-sm', 'd-hero',
                't-insight', 't-spot', 't-prio', 't-kpi', 't-tldr', 't-ask', 't-cohort',
                'e-eg', 'e-obj', 'e-miss', 'e-turn', 'e-exit', 't-storyline'}


class DeckParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.slides = []
        self.cur = None
        self.depth = 0            # section nesting depth inside a slide
        self.in_skip = None       # 'script' | 'style'
        self.title_depth = 0
        self.stage_count = 0
        self.legend_targets = set()
        self.caption_targets = set()
        self.switch_targets = set()
        self.external_srcs = []
        self.stylesheets = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        cls = a.get('class', '')
        classes = cls.split()
        if tag in ('script', 'style'):
            self.in_skip = tag
            if tag == 'script' and a.get('src'):
                self.external_srcs.append(a['src'])
        if tag == 'link' and a.get('rel') == 'stylesheet':
            self.stylesheets.append(a.get('href', ''))
        if 'k-stage' in classes:
            self.stage_count += 1
        if tag == 'section':
            if 'sheet--slide' in classes:
                self.cur = {'classes': classes, 'titles': [], 'text': [],
                            'charts': [], 'lists': [], 'anims': 0, 'foot': False,
                            'bgfx': 0, 'inline': [], 'sig': set(), 'tag_spans': 0,
                            'blocks': 0, 'callouts': 0, 'line': self.getpos()[0]}
                self.depth = 1
                self.slides.append(self.cur)
                return
            elif self.cur:
                self.depth += 1
        if not self.cur:
            return
        if 'sheet__tag' in classes:
            self.cur['tag_spans'] += 1
        if 'sheet__foot' in classes or 'data-foot' in a:
            self.cur['foot'] = True
        if 'k-bgfx' in classes:
            self.cur['bgfx'] += 1
        if 'data-anim' in a:
            self.cur['anims'] += 1
        if 'c-title' in classes:
            self.title_depth += 1
            self.cur['titles'].append('')
        if 'c-list' in classes or 'c-checklist' in classes:
            self.cur['lists'].append({'classes': classes, 'items': 0})
        if tag == 'li' and self.cur['lists']:
            self.cur['lists'][-1]['items'] += 1
        if 'data-chart' in a:
            self.cur['charts'].append({k: v for k, v in a.items()})
            self.cur['sig'].add('chart:' + a.get('data-chart', '?'))
            if a.get('data-chart') != 'spark':
                self.cur['blocks'] += 1
        if any(c in MAJOR_BLOCKS for c in classes):
            self.cur['blocks'] += 1
        if 'c-callout' in classes or 't-insight' in classes:
            self.cur['callouts'] += 1
        if 'c-table' in classes or 'd-table' in classes:
            self.cur['sig'].add('table')
        for s in LAYOUT_SIG:
            if s in classes:
                self.cur['sig'].add(s)
        st = a.get('style', '')
        if st:
            self.cur['inline'].append(st)
        if 'data-legend-for' in a: self.legend_targets.add(a['data-legend-for'])
        if 'data-caption-for' in a: self.caption_targets.add(a['data-caption-for'])
        if 'data-switch-for' in a: self.switch_targets.add(a['data-switch-for'])

    def handle_endtag(self, tag):
        if tag in ('script', 'style'):
            self.in_skip = None
        if self.cur and tag == 'section':
            self.depth -= 1
            if self.depth <= 0:
                self.cur = None
        if self.title_depth and tag in ('h1', 'h2', 'h3', 'p', 'div', 'span'):
            # closed the title element (titles are single elements in practice)
            self.title_depth = 0

    def handle_data(self, data):
        if self.in_skip or not self.cur:
            return
        t = data.strip()
        if not t:
            return
        self.cur['text'].append(t)
        if self.title_depth and self.cur['titles']:
            self.cur['titles'][-1] += (' ' if self.cur['titles'][-1] else '') + t


def norm(s):
    return re.sub(r'\s+', '', s)


def block(src, start, end):
    i = src.find(start)
    j = src.find(end)
    if i < 0 or j < 0 or j < i:
        return None
    return src[i:j + len(end)]


def main(path):
    fails, warns = [], []
    src = Path(path).read_text(encoding='utf-8')

    # -- 1. substrate integrity ------------------------------------------------
    for label, s, e, asset in (('core CSS', CSS_S, CSS_E, 'deck-core.css'),
                               ('core JS', JS_S, JS_E, 'deck-core.js')):
        got = block(src, s, e)
        if got is None:
            fails.append(f'{label}: sentinel block missing — embed assets/{asset} verbatim')
            continue
        want = (ASSETS / asset).read_text(encoding='utf-8')
        want = block(want, s, e) or want
        if hashlib.sha256(norm(got).encode()).hexdigest() != hashlib.sha256(norm(want).encode()).hexdigest():
            fails.append(f'{label}: embedded block differs from assets/{asset} — re-copy it verbatim, never edit or re-type it')

    # -- 2. structure ----------------------------------------------------------
    p = DeckParser()
    p.feed(src)
    slides = p.slides

    if not slides:
        fails.append('no .sheet--slide sections found')
    if p.stage_count != 1:
        fails.append(f'expected exactly one .k-stage, found {p.stage_count}')
    if 'Doc.init(' not in src:
        fails.append('Doc.init({...}) call missing')
    if 'data-mode-btn="present"' not in src:
        fails.append('Present button missing from the k-bar')
    if 'k-present-hud' not in src:
        fails.append('present-mode HUD missing')
    if '@page' not in src:
        fails.append('print @page rule missing (expected @page{size:1280px 720px;margin:0})')
    for u in p.external_srcs:
        fails.append(f'external script forbidden: {u}')
    for h in p.stylesheets:
        if 'fonts.googleapis.com' not in h:
            fails.append(f'external stylesheet forbidden (only Google Fonts allowed): {h}')

    theme = ''
    css_end = src.find(CSS_E)
    style_close = src.find('</style>', css_end) if css_end > 0 else -1
    if css_end > 0 and style_close > 0:
        theme = src[css_end + len(CSS_E):style_close]
    for tok in REQUIRED_TOKENS:
        if not re.search(re.escape(tok) + r'\s*:', theme):
            fails.append(f'theme block does not define required token {tok}')

    # deck-specific CSS discipline (theme + custom, core excluded)
    for m in re.finditer(r'font-size\s*:\s*([\d.]+)px', theme):
        warns.append(f'theme/custom CSS uses a px font-size ({m.group(0)}) — sizes must derive from --fs')
    if re.search(r'\d(vw|vh|vmin|vmax)\b', theme):
        warns.append('theme/custom CSS uses viewport units — use cqw/--fs so slides scale')

    # scan for example leaks outside the embedded core blocks
    authored = src
    for s, e in ((CSS_S, CSS_E), (JS_S, JS_E)):
        b = block(authored, s, e)
        if b:
            authored = authored.replace(b, '')
    for mk in EXAMPLE_MARKERS:
        if mk in authored:
            fails.append(f'reference/example content leaked into the deck: {mk!r}')
    init = re.search(r'Doc\.init\(\s*\{(.*?)\}\s*\)', authored, re.S)
    if init and not re.search(r'\bsource\s*:', init.group(1)):
        warns.append('Doc.init sets no source — footers will show the sample-data default')

    charts, legend_needed = [], []
    for idx, sl in enumerate(slides, 1):
        if sl['tag_spans']:
            fails.append(f'slide {idx}: remove <span class="sheet__tag"> viewing aids')
        for st in sl['inline']:
            if re.search(r'font-size\s*:\s*[\d.]+px', st):
                fails.append(f'slide {idx}: inline px font-size — use calc(var(--fs)*n)')
            if re.search(r'\d(vw|vh|vmin|vmax)\b', st):
                fails.append(f'slide {idx}: inline viewport units — use cqw or tokens')
        text_all = ' '.join(sl['text'])
        if re.search(r'\{\w+\}', text_all):
            fails.append(f'slide {idx}: unresolved {{placeholder}} in visible text')
        for ch in sl['charts']:
            charts.append((idx, ch))
            t = ch.get('data-chart', '')
            if t not in CHART_TYPES:
                fails.append(f'slide {idx}: unknown chart type {t!r}')
            try:
                series = json.loads(ch.get('data-series', '[]'))
            except ValueError as e:
                fails.append(f'slide {idx}: data-series is not valid JSON ({e})')
                continue
            labels = [s for s in ch.get('data-labels', '').split(',') if s.strip()]
            if t in LABELLED_TYPES:
                for se in series:
                    vals = se.get('values', [])
                    if labels and vals and len(labels) != len(vals):
                        fails.append(f'slide {idx}: chart {t}: {len(labels)} labels vs {len(vals)} values in series {se.get("name","?")!r}')
            if 'data-sets' in ch:
                try:
                    json.loads(ch['data-sets'])
                except ValueError as e:
                    fails.append(f'slide {idx}: data-sets is not valid JSON ({e})')
            if not ch.get('data-alt'):
                fails.append(f'slide {idx}: chart missing data-alt (one sentence stating the finding)')
            if len(series) > 1:
                legend_needed.append((idx, ch))

    # -- 3. design + content lints (WARN) ---------------------------------------
    for idx, ch in legend_needed:
        cid = ch.get('id', '')
        if cid not in p.legend_targets:
            warns.append(f'slide {idx}: multi-series chart {cid or "(no id)"} has no c-legend (data-legend-for)')
    for idx, ch in charts:
        t = ch.get('data-chart')
        if t in LABELLED_TYPES and t != 'spark' and not ch.get('data-unit') and ch.get('data-pct') != 'true':
            warns.append(f'slide {idx}: chart {t} declares no data-unit — name the unit somewhere explicit')
    if len(charts) >= 3:
        from collections import Counter
        counts = Counter(ch.get('data-chart') for _, ch in charts if ch.get('data-chart') != 'spark')
        if counts:
            top, n = counts.most_common(1)[0]
            if n >= 3 and n / max(1, sum(counts.values())) > 0.6:
                warns.append(f'{n} of {sum(counts.values())} charts are {top!r} — vary chart families where the questions differ')

    prev_sig = None
    for idx, sl in enumerate(slides, 1):
        title = (sl['titles'][0].strip() if sl['titles'] else '')
        tl = title.lower().rstrip('.?!')
        words = title.split()
        is_coverish = idx == 1 or 'sheet--accent' in sl['classes'] or not sl['foot']
        if tl in GENERIC_TITLES:
            warns.append(f'slide {idx}: filler/topic title {title!r} — titles state findings; closing slides do work')
        elif title and len(words) <= 2 and not is_coverish and not sl['charts']:
            warns.append(f'slide {idx}: title {title!r} looks like a topic label — state the finding')
        if len(words) >= 4:
            caps = sum(1 for w in words[1:] if w[:1].isupper() and w.lower() not in ('i',))
            if caps >= len(words) - 1:
                warns.append(f'slide {idx}: title {title!r} is in Title Case — use sentence case')
        if len(words) > 14:
            warns.append(f'slide {idx}: title is {len(words)} words — trim to the claim')

        body_sig = sl['sig']
        if prev_sig is not None and body_sig and body_sig == prev_sig:
            warns.append(f'slides {idx-1}→{idx}: identical body composition {sorted(body_sig)} — vary the layout')
        prev_sig = body_sig

        only_lists = bool(sl['lists']) and not sl['charts'] and not (body_sig - {'l-2', 'l-2a', 'l-2b'})
        if only_lists and not is_coverish:
            warns.append(f'slide {idx}: bullets are the only evidence — prefer a stat row, table, chart, or paired panels')
        for lst in sl['lists']:
            if lst['items'] > 4:
                warns.append(f'slide {idx}: a list has {lst["items"]} items — cap at 4 or restructure')
        if sl['anims'] > 8:
            warns.append(f'slide {idx}: {sl["anims"]} data-anim marks — animate 3–6 major blocks only')
        wc = len(' '.join(sl['text']).split())
        if wc > 170:
            warns.append(f'slide {idx}: ~{wc} words — split the slide instead of packing it')
        if sl['blocks'] >= 7 or sl['callouts'] >= 4:
            warns.append(f'slide {idx}: {sl["blocks"]} major blocks ({sl["callouts"]} callout-style) '
                         f'— likely overflows the 16:9 canvas; split the slide and check the '
                         f'browser for the red Overflow badge')
        text_all = ' '.join(sl['text'])
        for pat in BANNED:
            m = re.search(pat, text_all, re.I)
            if m:
                warns.append(f'slide {idx}: banned phrase {m.group(0)!r} — say something specific instead')

    bgfx_total = sum(sl['bgfx'] for sl in slides)
    if bgfx_total > 3:
        warns.append(f'{bgfx_total} background textures — reserve k-bgfx for covers and dividers')
    no_foot = [i for i, sl in enumerate(slides, 1) if not sl['foot']]
    if len(no_foot) > max(2, len(slides) // 3):
        warns.append(f'{len(no_foot)} slides have no footer ({no_foot}) — content slides carry data-foot')

    # -- report -----------------------------------------------------------------
    for f in fails:
        print(f'FAIL  {f}')
    for w in warns:
        print(f'WARN  {w}')
    print(f'\n{Path(path).name}: {len(slides)} slides, {len(charts)} charts — '
          f'{len(fails)} failures, {len(warns)} warnings')
    return 1 if fails else 0


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('usage: validate-deck.py <deck.html>')
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
