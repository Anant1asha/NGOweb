---
name: sarvam-html-presentation
description: Creates self-contained HTML slide decks from topics, source documents, existing HTML, or PowerPoint files. Use when the user asks for slides, a presentation, pitch deck, talk deck, executive briefing, or PPT/PPTX-to-HTML conversion. For new decks, infer the task and intent, shortlist two to four relevant choices from the maintained template catalog, and use the clarification tool to let the user choose before generating; if the user asks for a style the catalog lacks, synthesize one on the same substrate.
---
# Sarvam HTML Presentation Skill

Create one authored HTML deck by **assembling a tested component library, not
by authoring CSS**. The core substrate (`assets/deck-core.css` +
`assets/deck-core.js`) is embedded verbatim and hash-checked; a selected theme
supplies tokens and a small component vocabulary; you supply content and
composition. Your craft goes into the words, the evidence, and the choice of
composition — not into reinventing charts, grids, or type scales.

## Output contract

- One self-contained `.html` file. Only external requests: the theme's Google
Fonts link. Supplied images may remain relative assets.
- Slides are 16:9 CSS containers (`.sheet--slide`); every size derives from
`--fs`/`--sp`/`--pad` in `cqw`, so the deck scales identically in the review
scroll, fullscreen present mode, and print. Never use `px` type sizes,
`vw/vh` units, or media queries inside a sheet.
- Core CSS and JS embedded **verbatim including sentinel comments** — the
validator rejects edited or re-typed cores.
- Charts via the declarative `data-chart` engine. Never hand-author chart SVG.
- Present mode, keyboard/click/swipe navigation, reveal animation,
reduced-motion support, and 1280×720 print come from the core for free.

## Workflow

### 1. Infer the brief

Identify the mode: new deck, source-to-slides, PowerPoint conversion, or
existing-HTML edit. For a new deck, infer audience, outcome, narrative angle,
and evidence depth from the request and material. Do not run a generic
questionnaire — the only required clarification is the template choice below.

- Talk, keynote, pitch → speaker-led, fewer words, bigger claims.
- Report, review, briefing → reading-first, denser evidence.
- No slide count given → use the count the content needs; never pad or cram.

### 2. Choose the look

Read [references/template-index.json](references/template-index.json) — it is
the single source of routing truth; never route from memory or to unlisted
slugs. Match **tone-first**:

- Lead with `mood`, `tone`, `occasion`, and `best_for` — match the *feeling*
the deck should have, not the industry. A confident editorial template can
carry a tech talk; a warm reflective one can carry a finance retro if that
is the taste the user signals.
- `avoid_for` is a soft warning, not a veto — if the user explicitly asks for
that look, the user wins.
- `formality` and `density` sanity-check against audience and content volume;
flag a genuine mismatch rather than silently obeying it.
- `scheme` is a hard signal only when the user asks for light or dark.
- When the user names a firm, brand, or style ("McKinsey", "NYT graphics",
"zine"), search **every** template's metadata for it before deciding.
Shortlist all honest matches and describe how they differ (e.g. classic
consulting idiom vs. its modern data-led sibling); synthesize a custom
theme only when nothing in the catalog genuinely matches.

Shortlist **two to four genuinely different candidates**: the obvious fit,
one alternative that reads warmer or quieter, and — when the brief has
latitude — one wildcard that reinterprets it.

Then clarify, always **before generating**:

- Use the clarification tool: recommended option first marked `Recommended`,
each option a human-readable name plus one sentence on its character.
Never expose bare slugs.
- If the request carries no tone signal at all, add one question in the same
clarification round asking about occasion and desired mood (e.g.
authoritative and analytical · warm and editorial · bold and design-led ·
playful). Re-route if the answer contradicts the shortlist.
- When candidates are visually far apart and the deck title is already
known, optionally build one-slide cover previews — full skeleton, one
cover per candidate, populated with the real title — and give the user
the file paths so they can compare looks directly.
- Skip the clarification only when the user explicitly names a template or a
style, or the request is an edit to an existing deck.

**Requested style not in the catalog?** If the user names an aesthetic, a
brand, a reference deck/site/screenshot, or answers the clarification with
free text the catalog cannot honestly serve, do not force the nearest
template. Read [references/custom-theme.md](references/custom-theme.md) and
synthesize a bespoke theme on the same substrate — same token contract, same
components, same validator. Offer to save a successful bespoke theme into
the catalog.

For an existing HTML deck, preserve its architecture and visual system; do not
migrate it to this substrate unless the user asks for a redesign.

### 3. Map the content

Read all supplied material. Inventory every important section, decision,
number, table, requirement, image, and speaker note, and map it to a slide
sequence that argues — situation before complication, evidence before
recommendation. Split content rather than dropping it or shrinking it.

Numbers come from the material, never from imagination. If the user supplies
no data for a claim, write the claim without a fabricated statistic, or ask.
Real source lines go in `Doc.init({source})` and slide footers.

For `.pptx`:

```bash
python3 scripts/extract-pptx.py input.pptx output-directory
```

Then read `output-directory/extracted-slides.json` and preserve source order,
content, images, and notes while redesigning. If the deck uses supplied
images, read [references/image-handling.md](references/image-handling.md)
first; never overwrite originals or repeat an image except a consistent logo.

### 4. Load the architecture

Always read, in full, before generating:

- [references/deck-template.md](references/deck-template.md) — file skeleton
and slide anatomy.
- [references/components.md](references/components.md) — component and chart
vocabulary.
- The one selected theme in `references/themes/<slug>.md` — tokens, grammar,
and working example slides.

Embed `assets/deck-core.css` and `assets/deck-core.js` verbatim. Copy the
theme CSS verbatim. The theme's example slides show the intended rhythm and
voice — adapt their structure, replace every word and number.

### 5. Write the slides

**Titles carry the argument.** Every content-slide title states a finding —
short, specific, usually with the number ("Two corridors carry the entire H1
volume gain"), never a topic label ("Volume analysis"). Read the titles alone
top to bottom: they must work as a complete summary of the deck. Sentence
case, no title case, no colons-with-subtitle constructions.

**One idea per slide.** The title makes the claim; the body is its evidence:
one chart, one table, one comparison, one worked example. If a slide needs two
ideas, it is two slides.

**Prefer components over bullets.** Numbers go in stat rows or KPI cards with
units and periods; comparisons in tables or paired panels; trends in charts;
processes in timelines or steps. When a list is genuinely right, four items or
fewer, each with a bold lead and a specific point. Never nest bullets.

**No filler slides.** No agenda, no "Thank you", no "Questions?", no
"Key takeaways" that restates titles. The closing slide does work: decision
requested, owners, dates, or the single number to remember.

**Write like a person who was there.** Concrete subjects and verbs; numbers
with units, periods, and comparators; the theme's voice (an audit clause, a
founder's TL;DR, a teacher's prompt read differently). Banned: "leverage",
"delve", "robust", "seamless", "cutting-edge", "holistic", "innovative
solutions", "in today's fast-paced world", "unlock", "empower", "journey",
adjective pairs like "clear and compelling", and any sentence that could
appear unchanged in someone else's deck.

### 6. Compose the slides

- Choose the chart by the question, not for variety's sake — but a deck whose
every exhibit is the same chart type is usually answering lazily; the
routing in `components.md` gives the mapping.
- Do not repeat the same body composition on consecutive slides; the theme's
grammar lists its patterns — rotate through them as the content allows.
- Fill honestly: a slide should use roughly two-thirds to nine-tenths of the
pad height. Too empty → merge or promote to a focus slide (`c-bignum`,
pullquote). Too full → split.
- Respect the canvas budget. A slide holds the title block plus **one** main
composition, plus at most one strip (stat row or insight banner). Two
stacked multi-row compositions — e.g. three callout rows *and* a panel
grid — will not fit the fixed 16:9 canvas; that is two slides. When in
doubt, split: the deck gains a slide, the audience loses nothing.
- `data-anim` on 3–6 major blocks per slide, not on every list item. One
`k-bgfx` texture at most, covers and dividers only.
- Color is meaning: the theme's accent marks the focal point; `--cat-*` in
order for series; semantic colors only for genuine good/bad. Never introduce
hex values in slide markup — use tokens.
- Every chart: `data-alt` sentence, declared unit, legend when multi-series,
source in the footer. Interactive extras (switcher, legend toggles,
sortable tables, count-ups) where they let the audience interrogate the
evidence, not as decoration.
- Deck-specific CSS is a last resort: under \~40 lines, token-derived sizes
only, and only for a component neither core nor theme provides.

### 7. Validate, fix, deliver

```bash
python3 scripts/validate-deck.py /path/to/deck.html
```

Fix every FAIL, then re-run until clean. Read every WARN and act on it unless
you have a stated reason not to — warnings encode the slop checklist
(topic-label titles, bullet-only slides, repeated compositions, missing
units/sources/alt text, banned phrases, filler slides).

Then inspect the source once more: all source content represented in order;
theme grammar followed; no leftover example text, ids, or sample numbers.

QA is source-first and must not require a browser. Use one only if already
available. For PDF, native Print → Save as PDF (slides print 1280×720).

Deliver the file path, selected template, slide count, and controls (Present
button, arrows/click/swipe, Esc). Open the HTML when the environment supports
it.

## Gotchas

- The core blocks are byte-sacred. If a behavior seems missing, you are
looking for a theme class or a `data-` attribute, not a core edit.
- `data-series` and `data-sets` are JSON in single-quoted attributes: double
quotes inside, no trailing commas, labels count matching values count.
- Charts size from `data-height` in 1000-per-sheet-width units; don't wrap
charts in fixed-height boxes.
- `sheet--invert`/`sheet--accent`/theme dark variants re-map tokens — check
the theme CSS before adding per-element colors on dark slides.
- Footers come from `data-foot` + `Doc.init`; don't hand-write footer text
into slides. Blank a slot with `data-r=""`, don't omit the footer element
(covers may drop it deliberately).
- No slide scrolls internally. No content is omitted to satisfy a slide
count. Split the slide instead.
- Slides are fixed canvases with `overflow:hidden` — content that doesn't
fit is silently clipped behind the footer. The runtime stamps any clipped
slide with a red "Overflow — split this slide" badge (review mode only).
A deck must never ship with that badge visible; fix by splitting, never by
shrinking type, padding, or chart heights.
- Keep the `k-bar` and present HUD exactly as the skeleton has them.

## Reference map

- [references/template-index.json](references/template-index.json) — routing
metadata for every template; the single source of routing truth.
- [references/deck-template.md](references/deck-template.md) — always read.
- [references/components.md](references/components.md) — always read.
- `references/themes/<slug>.md` — read exactly the selected one.
- [references/custom-theme.md](references/custom-theme.md) — read when
synthesizing a bespoke style the catalog lacks.
- [assets/deck-core.css](assets/deck-core.css),
[assets/deck-core.js](assets/deck-core.js) — embed verbatim, never edit.
- [scripts/extract-pptx.py](scripts/extract-pptx.py) — for `.pptx` input;
requires `python-pptx==1.0.2`.
- [scripts/validate-deck.py](scripts/validate-deck.py) — run on every deck;
Python standard library only.
- [scripts/validate-themes.py](scripts/validate-themes.py) — catalog linter;
run after adding or editing any theme file.
- [scripts/refresh-core.py](scripts/refresh-core.py) — re-embed current core
assets into an existing deck after a core update.

