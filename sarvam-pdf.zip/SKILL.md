---
name: sarvam-pdf
description: Reads, creates, and manipulates PDF files with pure-Python libraries, and verifies generated PDF layout before delivery. Use when the user mentions a .pdf file or wants to extract text or tables from a PDF, create or generate a PDF, merge or split PDFs, rotate pages, add a watermark, encrypt or decrypt a PDF, or render a PDF page to an image. Do not use for Word, Excel, PowerPoint, or non-PDF documents. If the user's request for a new PDF has incomplete context, use the clarify tool to ask — mainly about the intended audience, document length, and style/tone, plus anything else that would sharpen the result — before generating.
---

# PDF Processing

All operations use pure-Python libraries, already available in the sandbox. One task maps to exactly one library — do not substitute alternatives.

| Task | Library |
|------|---------|
| Create / generate a PDF | `reportlab` (Platypus flowables) |
| Extract text & tables | `pdfplumber` |
| Merge / split / rotate / encrypt / watermark | `pypdf` |
| Render a PDF page to an image | `pypdfium2` |

## Guides (read the one your task needs)

| Task | Guide |
|------|-------|
| **Writing the content** of a generated document — structure, headings, length/redundancy, anti-slop, numbers, and per-document-type rules (reports, finance, RFPs, memos) | [writing.md](writing.md) — **required before drafting** |
| **Generating a PDF** with reportlab — page geometry, wrapping, centring, headers/footers, lists, fonts (incl. Indic scripts), tables, cards, vertical rhythm, and the gotchas each prevents | [pdf_creation.md](pdf_creation.md) — **required before writing reportlab code** |
| **Reading or manipulating an existing PDF** — coordinate-level extraction, custom table settings, split/rotate/encrypt/watermark/crop/metadata, rendering, batch processing | [pdf_ops.md](pdf_ops.md) |
| **Verifying a generated PDF** before delivery — the QA gate, per-failure-class fixes, thresholds | [qa.md](qa.md) — **required** |

## Creating a PDF

**Do not narrate your work.** No "Now I'll build…", "Let me run the gate…",
"I need to fix…", "Almost there — one last fix…". Build, run the gate,
deliver. The user sees the result, not the process.

If the request leaves audience, length, or style/tone unclear, use the clarify
tool to ask before building — a wrong guess here costs a full regeneration.

1. **Plan the content.** Read [writing.md](writing.md), then outline the
   document's sections and each section's one-line finding before drafting.
2. **Build with reportlab.** Read [pdf_creation.md](pdf_creation.md) — it carries
   every formatting-safe pattern and the specific failure each one prevents.
   Always build from **Platypus flowables** inside a `SimpleDocTemplate`; never
   lay out body text with `canvas.drawString` (it does not wrap and runs off the
   page). `scripts/create_sample_pdf.py` is a complete worked example combining
   all the patterns — run it to see correct output.
3. **Gate it.** Run the QA gate once, ship if exit 0.

## Verify before delivering

**No visual QA.** Never render pages to images for QA — no PNG previews, no
image-description/vision tools, no pixel analysis; the gate below plus text
extraction are the complete QA (full rule: [qa.md](qa.md)).

Run the gate. It splits output into **FAIL** (blocking — collisions, overflow,
table bleed) and **WARN** (cosmetic — centring, spacing, valign, frame fill).
Only FAIL causes exit 1. Ship on exit 0 even if WARNs are present.

```bash
python scripts/run_qa.py out.pdf
```

```
Deliver-a-PDF checklist:
- [ ] 1. Build the PDF with reportlab (Platypus flowables, patterns in pdf_creation.md)
- [ ] 2. Gate: python scripts/run_qa.py out.pdf
- [ ] 3. If exit 0: present_output(artifact_id) — ship now. WARNs are fine.
       If exit 1: fix ONLY the FAIL messages, rebuild, re-run once.
       Do NOT fix WARNs. One fix round max.
- [ ] 4. present_output(artifact_id)
```

The gate covers: **alignment** (centring=WARN, collisions=FAIL, overflow=FAIL),
**whitespace** (all WARN — spacing never blocks), and **tables** (bleed=FAIL,
fill/valign/splits=WARN). Writing quality is not machine-checked — apply
[writing.md](writing.md) while drafting. Glyph correctness is not machine-checked
either — if the document contains any non-Latin-1 script, run the notdef check
in [pdf_creation.md](pdf_creation.md) § Fonts for Indic scripts before delivering.

## Extracting text & tables

```python
import pdfplumber

with pdfplumber.open("in.pdf") as pdf:
    text = "\n".join((page.extract_text() or "") for page in pdf.pages)
    first_table = pdf.pages[0].extract_tables()
```

See [pdf_ops.md](pdf_ops.md) for coordinate-level extraction and custom table settings.

## Merge / split / rotate / encrypt / watermark

```python
from pypdf import PdfReader, PdfWriter

# Merge
writer = PdfWriter()
for path in ["a.pdf", "b.pdf"]:
    for page in PdfReader(path).pages:
        writer.add_page(page)
with open("merged.pdf", "wb") as f:
    writer.write(f)
```

See [pdf_ops.md](pdf_ops.md) for split, rotate, encrypt, watermark, and crop snippets.

## Render a PDF page to an image

```python
import pypdfium2 as pdfium

pdf = pdfium.PdfDocument("in.pdf")
image = pdf[0].render(scale=2.0).to_pil()   # scale 2.0 ≈ 144 DPI
image.save("page_1.png")
```

`scripts/convert_pdf_to_images.py <in.pdf> <out_dir/>` renders every page to a PNG.

## Scripts reference

Quick index of everything in `scripts/`; each is documented in full where noted — open that file when you need the exact invocation or JSON shape, not just the one-liner.

| Script | Purpose | Full detail |
|---|---|---|
| `create_sample_pdf.py` | Working reference PDF exercising every formatting-safe pattern | pdf_creation.md |
| `convert_pdf_to_images.py <in.pdf> <out_dir/>` | Render every page to a PNG (user-facing feature — never a QA step) | pdf_ops.md |
| `run_qa.py out.pdf` | **The QA gate** — runs all three checks below in one invocation | qa.md |
| `check_layout.py out.pdf` | Alignment QA (part of the gate) | qa.md |
| `check_spacing.py out.pdf` | Whitespace / vertical-rhythm QA (part of the gate) | qa.md |
| `check_tables.py out.pdf` | Table-integrity QA (part of the gate) | qa.md |
