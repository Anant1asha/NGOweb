"""Generate a formatting-safe sample PDF with reportlab.

This is the canonical reference implementation for PDF creation. It demonstrates
every pattern that prevents common formatting errors:
- explicit page geometry (size + margins) so content width is known
- wrapping body text with Paragraph flowables (never canvas.drawString)
- a header and a page-number footer drawn in the margin via onPage callbacks
- bullet and numbered lists via ListFlowable (never typed/unicode bullets)
- a wide table whose colWidths sum to the frame width, with Paragraph cells

Usage:
    python create_sample_pdf.py [output.pdf]
"""

import sys

from reportlab.lib import colors
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    ListFlowable,
    ListItem,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

_STYLES = getSampleStyleSheet()
TITLE = ParagraphStyle("title", parent=_STYLES["Title"], fontName="Helvetica-Bold")
H1 = ParagraphStyle("h1", parent=_STYLES["Heading1"], fontName="Helvetica-Bold",
                    fontSize=14, leading=18, spaceBefore=10, spaceAfter=6)
BODY = ParagraphStyle("body", parent=_STYLES["Normal"], fontName="Helvetica",
                      fontSize=10, leading=13, spaceAfter=8)


def _header_footer(canvas, doc):
    """Draw the header and footer in the page margin on every page."""
    canvas.saveState()
    page_width, page_height = doc.pagesize
    canvas.setFont("Helvetica", 9)
    canvas.setFillColor(colors.HexColor("#555555"))
    canvas.drawString(doc.leftMargin, page_height - 0.6 * inch, "Sarvam PDF Sample")
    canvas.drawRightString(
        page_width - doc.rightMargin, 0.5 * inch,
        f"Page {canvas.getPageNumber()}",
    )
    canvas.restoreState()


def build(output_path: str) -> str:
    doc = SimpleDocTemplate(
        output_path, pagesize=LETTER,
        leftMargin=inch, rightMargin=inch, topMargin=inch, bottomMargin=inch,
        title="Sarvam PDF Sample",
    )

    cell = ParagraphStyle("cell", parent=BODY, fontSize=9, leading=11, spaceAfter=0)
    cell_head = ParagraphStyle("cellhead", parent=cell, textColor=colors.white)

    story = [
        Paragraph("Formatting-Safe PDF", TITLE),
        Spacer(1, 12),
        Paragraph("Wrapping body text", H1),
        Paragraph(
            "This paragraph is a Paragraph flowable, so reportlab wraps it to the "
            "frame width and never lets it run off the page. Leading is set to about "
            "1.2x the font size so the lines do not collide. " * 6,
            BODY,
        ),
        Paragraph("Bullet and numbered lists", H1),
        ListFlowable(
            [ListItem(Paragraph("Bullets come from ListFlowable, not typed glyphs.", BODY)),
             ListItem(Paragraph("Each item is itself a wrapping Paragraph.", BODY)),
             ListItem(Paragraph("Chemical example with markup: H<sub>2</sub>O.", BODY))],
            bulletType="bullet",
        ),
        Spacer(1, 6),
        ListFlowable(
            [ListItem(Paragraph("First numbered step.", BODY)),
             ListItem(Paragraph("Second numbered step.", BODY))],
            bulletType="1",
        ),
        Paragraph("A wide table", H1),
    ]

    data = [
        [Paragraph("Component", cell_head), Paragraph("Description", cell_head),
         Paragraph("Status", cell_head)],
        [Paragraph("Renderer", cell),
         Paragraph("Long cell text wraps to the column width because the cell is a "
                   "Paragraph and the column widths sum to the frame width.", cell),
         Paragraph("OK", cell)],
        [Paragraph("Extractor", cell),
         Paragraph("Padding in the TableStyle keeps rows from colliding.", cell),
         Paragraph("OK", cell)],
    ]
    col_widths = [0.22 * doc.width, 0.63 * doc.width, 0.15 * doc.width]
    table = Table(data, colWidths=col_widths, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2E5A88")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#999999")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(table)

    doc.build(story, onFirstPage=_header_footer, onLaterPages=_header_footer)
    return output_path


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "sample.pdf"
    path = build(out)
    print(f"Wrote {path}")
