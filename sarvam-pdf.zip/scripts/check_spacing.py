#!/usr/bin/env python3
"""Deterministic whitespace / vertical-rhythm QA for a generated PDF.

Alignment QA (``check_layout.py``) proves things line up; this proves the page
is *filled well*. It catches the whitespace defects a quick glance waves
through and that alignment checks do not model:

  1. A heading stranded at the bottom of a page with its body on the next page
     (orphan heading) — e.g. "Funding & Milestones" alone at the foot of page 2.
  2. A non-last page left largely empty at the bottom (under-filled page).
  3. Content that starts too far below the top margin (a big top gap) — e.g. a
     "Disclaimer" pushed a third of the way down the page.
  4. An oversized gap between two elements mid-page (before/after a table,
     between a header rule and the body, between a heading and its text).

Thresholds are fractions of the page's usable height (between the top-margin /
header anchor and the footer / bottom-margin anchor), so they scale with page
size and margins instead of being magic point counts.

Usage:
    python scripts/check_spacing.py <file.pdf>
        [--top-gap FRAC] [--gap FRAC] [--trailing FRAC]

Exit code 0 = all pages well-composed; 1 = at least one FAIL; 2 = unreadable.
"""

from __future__ import annotations

import argparse
import statistics
import sys

try:
    import pdfplumber
except ImportError:
    print("check_spacing: pdfplumber is not installed. Run:\n"
          "    pip install pdfplumber\n", file=sys.stderr)
    sys.exit(2)

# check_layout.py lives beside this script; Python puts the script's own
# directory on sys.path[0], so a plain import resolves it. Reuse the exact
# geometry the alignment checker uses so both agree on what an element is.
from check_layout import (  # noqa: E402
    FOOTER_BAND_PT,
    HEADER_BAND_PT,
    MAX_ISSUES,
    Box,
    extract_page_geometry,
)


# --- Tunable thresholds (fractions of usable page height; all justified) ----

# Content that starts more than this fraction of the usable height below the
# top anchor is "too low". 0.15 of a ~9 in Letter body is ~1.3 in of dead space
# above the first element — well beyond a normal top margin.
DEFAULT_TOP_GAP_FRAC = 0.25
# A single gap between two consecutive elements larger than this fraction is an
# oversized hole (before/after a table, header-to-body, heading-to-body).
DEFAULT_INTER_GAP_FRAC = 0.30
# A non-last page whose bottom is emptier than this fraction is under-filled.
# High enough that a page that simply ends on a paragraph boundary is fine.
DEFAULT_TRAILING_FRAC = 0.50
# When the LAST element on a non-last page is heading-like, even this much
# trailing space means the heading is orphaned from its body — reflow it.
ORPHAN_TRAILING_FRAC = 0.20
# A line taller than this multiple of the body's median line height is a
# heading (a larger font), used to detect orphaned headings.
HEADING_HEIGHT_RATIO = 1.30
# An image covering more than this fraction of the page area is a full-bleed
# background, not content — including it would mask a genuinely under-filled
# page. Smaller images (logos, figures, photos) count as content so a page
# filled by a picture is not falsely flagged empty.
BACKGROUND_IMAGE_AREA_RATIO = 0.60


def _height(b: Box) -> float:
    return b.bottom - b.top


def _content_elements(geom) -> list[Box]:
    """Body-flow elements in vertical order: text lines (minus page furniture),
    decorative dividers, each table as a single block, and non-background
    images (so a page filled by a figure/photo is not read as under-filled)."""
    els = [
        b for b in geom.text_lines
        if b.kind not in ("HEADER", "FOOTER", "TABLE_CELL")
    ]
    els += [r for r in geom.rules if r.kind == "DECORATIVE_DIVIDER"]
    for x0, top, x1, bottom in geom.table_bboxes:
        els.append(Box(left=x0, right=x1, top=top, bottom=bottom,
                       text="[table]", kind="TABLE"))
    page_area = geom.page_width * geom.page_height
    for x0, top, x1, bottom in geom.image_bboxes:
        area = (x1 - x0) * (bottom - top)
        if page_area > 0 and area / page_area > BACKGROUND_IMAGE_AREA_RATIO:
            continue  # full-bleed background, not content
        els.append(Box(left=x0, right=x1, top=top, bottom=bottom,
                       text="[image]", kind="IMAGE"))
    els.sort(key=lambda b: b.top)
    return els


def _top_anchor(geom) -> float:
    """Y of the top margin: the header rule/text bottom if present, else the
    nominal top-margin band. Returned in top-origin points."""
    tops = [r.bottom for r in geom.rules
            if r.kind == "HEADER_FOOTER_LINE" and r.top < HEADER_BAND_PT]
    tops += [b.bottom for b in geom.text_lines if b.kind == "HEADER"]
    return max(tops) if tops else HEADER_BAND_PT


def _bottom_anchor(geom) -> float:
    """Y of the bottom margin: the footer top if present, else the nominal
    bottom-margin band."""
    limit = geom.page_height - FOOTER_BAND_PT
    bots = [b.top for b in geom.text_lines if b.kind == "FOOTER"]
    bots += [r.top for r in geom.rules
             if r.kind == "HEADER_FOOTER_LINE" and r.top > limit]
    return min(bots) if bots else limit


def _body_median_height(geom) -> float:
    heights = [_height(b) for b in geom.text_lines
               if b.kind in ("BODY_LEFT", "CENTERED", "OTHER")]
    return statistics.median(heights) if heights else 12.0


def check_page(
    geom, page_num: int, is_last_page: bool,
    top_gap_frac: float, inter_gap_frac: float, trailing_frac: float,
) -> list[str]:
    issues: list[str] = []

    def fail(msg: str) -> None:
        if len(issues) < MAX_ISSUES:
            issues.append(f"page {page_num}: {msg}")

    els = _content_elements(geom)
    if not els:
        return issues  # blank page or furniture-only; nothing to compose

    top_anchor = _top_anchor(geom)
    bottom_anchor = _bottom_anchor(geom)
    usable = bottom_anchor - top_anchor
    if usable <= 0:
        return issues  # degenerate geometry; skip rather than emit noise

    first, last = els[0], els[-1]
    median_h = _body_median_height(geom)

    def _is_heading(el: Box) -> bool:
        return (el.kind not in ("IMAGE", "TABLE")
                and _height(el) > median_h * HEADING_HEIGHT_RATIO)

    # 1. Top gap — content starts too far below the top margin.
    top_gap = first.top - top_anchor
    if top_gap / usable > top_gap_frac:
        fail(f"content starts {top_gap:.0f}pt ({top_gap / usable:.0%}) below the "
             f"top margin — move it up or rebalance the page")

    # 1b. Widowed section tail — the page opens with 1-2 stray body lines
    #     left over from the previous page's section, then a new heading
    #     starts. That 90/10 split reads as a mistake: the tail should have
    #     stayed with its section (KeepTogether the section's last block) or
    #     the section break should move earlier.
    if page_num > 1:
        lead: list[Box] = []
        first_heading = None
        for el in els:
            if _is_heading(el):
                first_heading = el
                break
            if el.kind in ("IMAGE", "TABLE"):
                lead = []  # a figure/table opener is not a widowed line
                break
            lead.append(el)
        if first_heading is not None and 1 <= len(lead) <= 2:
            fail(f'{len(lead)} widowed line(s) from the previous section sit above '
                 f'the heading "{first_heading.text[:40]}" — keep the previous '
                 f"section's tail together (KeepTogether its last paragraph[s]) "
                 f"or move the section break so the tail stays with its section")

    # 2 & 3. Trailing space at the bottom of a non-last page.
    if not is_last_page:
        trailing = bottom_anchor - last.bottom
        frac = trailing / usable
        # Only a *text* line can be an orphaned heading. A tall trailing image or
        # table is not a "heading"; it falls through to the under-filled branch.
        if _is_heading(last) and frac > ORPHAN_TRAILING_FRAC:
            fail(f'heading "{last.text[:40]}" is stranded at the page bottom with '
                 f"{frac:.0%} empty below — start it on the next page "
                 f"(KeepTogether / keepWithNext / PageBreak)")
        elif frac > trailing_frac:
            fail(f"page is under-filled — {trailing:.0f}pt ({frac:.0%}) empty at the "
                 f"bottom; pull later content up or rebalance")

        # 3b. Heading + a sliver of its body at the page bottom — the section
        #     squeezes only 1-2 lines in before the break, with the rest on
        #     the next page. Nearly as bad as a bare orphaned heading, and the
        #     orphan check can't see it (the heading isn't last). Only fires
        #     when the heading starts in the bottom quarter of the page, so a
        #     short final section on a well-filled page doesn't false-positive.
        SLIVER_MAX_BODY_LINES = 2
        last_heading_idx = None
        for i in range(len(els) - 1, -1, -1):
            if _is_heading(els[i]):
                last_heading_idx = i
                break
        if last_heading_idx is not None:
            tail = els[last_heading_idx + 1:]
            if (tail and len(tail) <= SLIVER_MAX_BODY_LINES
                    and all(t.kind not in ("IMAGE", "TABLE") and not _is_heading(t)
                            for t in tail)
                    and els[last_heading_idx].top > bottom_anchor - 0.25 * usable):
                fail(f'heading "{els[last_heading_idx].text[:40]}" starts at the page '
                     f"bottom with only {len(tail)} line(s) of its body before the "
                     f"page break — start the section on the next page "
                     f"(keepWithNext + KeepTogether with its first paragraph) "
                     f"instead of splitting off a sliver")

    # 4. Oversized gap between two consecutive mid-page elements.
    for cur, nxt in zip(els, els[1:]):
        gap = nxt.top - cur.bottom
        if gap > 0 and gap / usable > inter_gap_frac:
            fail(f'{gap:.0f}pt ({gap / usable:.0%}) gap before "{nxt.text[:36]}" '
                 f"— tighten spaceBefore/spaceAfter")

    return issues


def main() -> int:
    ap = argparse.ArgumentParser(description="Deterministic whitespace QA (advisory)")
    ap.add_argument("pdf")
    ap.add_argument("--top-gap", type=float, default=DEFAULT_TOP_GAP_FRAC,
                    help=f"max top gap as a fraction of usable height (default {DEFAULT_TOP_GAP_FRAC})")
    ap.add_argument("--gap", type=float, default=DEFAULT_INTER_GAP_FRAC,
                    help=f"max mid-page gap as a fraction of usable height (default {DEFAULT_INTER_GAP_FRAC})")
    ap.add_argument("--trailing", type=float, default=DEFAULT_TRAILING_FRAC,
                    help=f"max bottom emptiness on a non-last page (default {DEFAULT_TRAILING_FRAC})")
    args = ap.parse_args()

    try:
        pdf = pdfplumber.open(args.pdf)
    except FileNotFoundError:
        print(f"check_spacing: file not found: {args.pdf}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"check_spacing: could not open {args.pdf}: {exc}", file=sys.stderr)
        return 2

    all_issues: list[str] = []
    with pdf:
        total = len(pdf.pages)
        for i, page in enumerate(pdf.pages, start=1):
            geom = extract_page_geometry(page, i)
            issues = check_page(
                geom, i, is_last_page=(i == total),
                top_gap_frac=args.top_gap, inter_gap_frac=args.gap,
                trailing_frac=args.trailing,
            )
            print(f"page {i}/{total}: {'WARN' if issues else 'PASS'}")
            all_issues.extend(issues)

    if all_issues:
        print(f"\nSPACING WARN ({len(all_issues)} advisory issue(s)):")
        for msg in all_issues:
            print(f"  - {msg}")
        print("\n(cosmetic — does not block delivery. Spacing never blocks.)")
    else:
        print("\nSPACING PASSED. Pages are well-composed.")
    return 0  # always 0 — spacing is advisory only


if __name__ == "__main__":
    sys.exit(main())
