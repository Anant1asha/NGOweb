"""Render each page of a PDF to a PNG image using pypdfium2 (pure-Python wheels, no system binaries).

Usage:
    python convert_pdf_to_images.py <input.pdf> <output_dir/> [--scale 2.0]

Pages are written as <output_dir>/page_1.png, page_2.png, ... Large pages are
downscaled so the longest side is at most max_dim pixels.
"""

import argparse
import os

import pypdfium2 as pdfium
from PIL import Image


def convert(pdf_path: str, output_dir: str, scale: float = 2.0, max_dim: int = 2000) -> int:
    os.makedirs(output_dir, exist_ok=True)
    pdf = pdfium.PdfDocument(pdf_path)
    try:
        count = len(pdf)
        for i in range(count):
            page = pdf[i]
            image = page.render(scale=scale).to_pil()
            width, height = image.size
            if width > max_dim or height > max_dim:
                factor = min(max_dim / width, max_dim / height)
                image = image.resize((int(width * factor), int(height * factor)),
                                     Image.LANCZOS)
            image_path = os.path.join(output_dir, f"page_{i + 1}.png")
            image.save(image_path)
            print(f"Saved page {i + 1} as {image_path} (size: {image.size})")
        print(f"Converted {count} page(s) to PNG images")
        return count
    finally:
        pdf.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Render PDF pages to PNG images")
    parser.add_argument("input_pdf")
    parser.add_argument("output_dir")
    parser.add_argument("--scale", type=float, default=2.0,
                        help="Render scale; 1.0 = 72 DPI, 2.0 ≈ 144 DPI (default: 2.0)")
    args = parser.parse_args()
    convert(args.input_pdf, args.output_dir, scale=args.scale)
