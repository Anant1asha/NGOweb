#!/usr/bin/env python3
"""Deterministic geometric layout QA for a generated PDF.

Extracts element bounding boxes with ``pdfplumber`` and asserts alignment,
overlap, and overflow invariants exactly, from coordinates.

Why this exists: a glance silently passed a pull-quote that sat 37 pt
(~6% of an A4 width) off-centre from its divider. Geometry does not forgive.
See ``qa.md``.

What it checks, per page:
  1. Centred text lines are centred on the content box.
  2. Decorative dividers (short horizontal rules) are centred on the content box.
  3. Each divider is centred on the centred text it sits next to  <- the 6% bug.
  4. Title and subtitle (first two centred lines) share a centre.
  5. Body / bullet left edges cluster within one indent band.
  6. Distinct text lines do not collide (overlap in both axes).
  7. No text overflows the content box horizontally.

Usage:
    python scripts/check_layout.py <file.pdf>
        [--tol 3.0] [--content-left PT --content-right PT]

Exit code 0 = every check passed; 1 = at least one FAIL (details on stdout);
2 = the file could not be read.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field

try:
    import pdfplumber
except ImportError:
    # Solve, don't punt: tell the caller exactly how to fix it.
    print(
        "check_layout: pdfplumber is not installed. Run:\n"
        "    pip install pdfplumber\n",
        file=sys.stderr,
    )
    sys.exit(2)


# --- Tunable thresholds (all justified; no voodoo constants) ----------------

# Alignment tolerance in PDF points. 6 pt ~= 0.08 in: lenient enough to let
# most first-pass builds ship without a fix cycle, still tight enough to catch
# genuinely off-centre elements. Cosmetic drift under this is not a defect.
DEFAULT_TOLERANCE_PT = 6.0
# Two words belong to the same visual line when their vertical spans overlap by
# at least this fraction of the shorter word's height. High enough that
# sub/superscripts (which pdfplumber emits as their own low/high word) merge
# into their line; low enough that separate lines stay separate.
LINE_GROUP_OVERLAP_RATIO = 0.6
# Two boxes are on the "same visual row" (multi-column) when their tops are
# within this many points — used to skip legitimate side-by-side content.
LINE_GROUP_PT = 3.0
# Header band measured from the top edge; footer band from the bottom edge.
# Elements inside these bands are page furniture, not body content.
HEADER_BAND_PT = 40.0
FOOTER_BAND_PT = 50.0
# A line is "intentionally centred" when it is indented from the content-left
# by more than this AND is narrower than CENTERED_MAX_WIDTH_RATIO of the box
# (a full-width justified paragraph is not "centred", it just fills the frame).
CENTERED_MIN_INDENT_PT = 30.0
CENTERED_MAX_WIDTH_RATIO = 0.75
# A centred element must be at least this wide. Stops a stray glyph (a
# sub/superscript that failed to merge, a bullet) from being mistaken for a
# centred title.
CENTERED_MIN_WIDTH_PT = 24.0
# A decorative divider "decorates" the text within this vertical gap; that text
# is expected to share the divider's centre (this is the pull-quote check).
DIVIDER_PAIR_MAX_GAP_PT = 40.0
# Only pair a divider with a block narrower than this (a full-width body line's
# centre is trivially the content centre, so pairing it proves nothing).
DIVIDER_PAIR_MAX_WIDTH_RATIO = 0.95
# ...and only when that block is indented from the content-left by more than
# this. A pull-quote is indented on both sides; a normal left-aligned body line
# starts at the content margin (indent ~= 0) and is NOT expected to centre on a
# divider, so requiring an indent stops body text from false-positiving.
DIVIDER_PAIR_MIN_INDENT_PT = 10.0
# Two distinct lines "collide" only when they overlap by at least this fraction
# on BOTH axes. Consecutive wrapped lines overlap a point or two vertically
# (descenders) and multi-column cells barely overlap horizontally; requiring
# substantial overlap on both axes ignores those and catches real collisions.
COLLISION_MIN_OVERLAP_RATIO = 0.5
# Horizontal-rule width bands as a fraction of content width.
FULL_WIDTH_RULE_RATIO = 0.90   # header/footer line or a table grid line
DECORATIVE_RULE_RATIO = 0.70   # a short divider (e.g. ReportLab HRFlowable)
# A vector object is a horizontal rule when its vertical span is under this and
# its horizontal span exceeds this.
RULE_MAX_DY_PT = 2.0
RULE_MIN_DX_PT = 20.0
# Overflow past the content box we treat as a real defect (ignores hairline
# antialiasing / rounding).
OVERFLOW_SLACK_PT = 2.0
# Minimum clearance between body text and non-text elements ("touching"
# defect, from production feedback). 6pt against images/tables is lenient —
# only genuinely overlapping or fully-butted-up content is flagged. Rules
# get 3pt: an underline 3-5pt below its heading is a deliberate design
# device. Cell text inside its own table is exempt (cells touch gridlines
# by design). Cosmetic proximity under this is not a defect.
CLEARANCE_MIN_IMG_TABLE_PT = 6.0
CLEARANCE_MIN_RULE_PT = 3.0
# A text line must be at least this wide to help infer the content box; avoids
# letting a short centred title define the margins.
CONTENT_BOX_MIN_WIDTH_RATIO = 0.50
# Stop after this many issues so a badly-broken page stays readable.
MAX_ISSUES = 40


@dataclass
class Box:
    """One laid-out element: a text line or a horizontal rule."""

    left: float
    right: float
    top: float
    bottom: float
    text: str = ""
    kind: str = ""

    @property
    def center(self) -> float:
        return (self.left + self.right) / 2

    @property
    def width(self) -> float:
        return self.right - self.left


@dataclass
class PageGeometry:
    """Everything the geometric checks reason about one page."""

    page_num: int
    page_width: float
    page_height: float
    content_left: float
    content_right: float
    text_lines: list[Box] = field(default_factory=list)
    rules: list[Box] = field(default_factory=list)
    table_bboxes: list[tuple[float, float, float, float]] = field(default_factory=list)
    image_bboxes: list[tuple[float, float, float, float]] = field(default_factory=list)

    @property
    def content_center(self) -> float:
        return (self.content_left + self.content_right) / 2

    @property
    def content_width(self) -> float:
        return self.content_right - self.content_left


def _group_words_into_lines(words: list[dict]) -> list[Box]:
    """Cluster ``extract_words`` output into visual lines by vertical overlap.

    Overlap-based (not top-equality) grouping folds sub/superscripts and inline
    glyphs back into their line, which top-proximity grouping splits off.
    """
    groups: list[dict] = []
    for w in sorted(words, key=lambda x: (x["top"], x["x0"])):
        w_top, w_bottom = w["top"], w["bottom"]
        for g in groups:
            overlap = min(g["bottom"], w_bottom) - max(g["top"], w_top)
            shorter = min(g["bottom"] - g["top"], w_bottom - w_top)
            if shorter > 0 and overlap / shorter >= LINE_GROUP_OVERLAP_RATIO:
                g["words"].append(w)
                g["top"] = min(g["top"], w_top)
                g["bottom"] = max(g["bottom"], w_bottom)
                break
        else:
            groups.append({"top": w_top, "bottom": w_bottom, "words": [w]})

    boxes: list[Box] = []
    for g in groups:
        ws = g["words"]
        boxes.append(
            Box(
                left=min(w["x0"] for w in ws),
                right=max(w["x1"] for w in ws),
                top=min(w["top"] for w in ws),
                bottom=max(w["bottom"] for w in ws),
                text=" ".join(w["text"] for w in ws),
            )
        )
    return boxes


def _extract_rules(page) -> list[Box]:
    """Pull horizontal rules from vector lines and curves via their bboxes."""
    rules: list[Box] = []
    for obj in list(page.lines) + list(page.curves):
        left, right = float(obj["x0"]), float(obj["x1"])
        top, bottom = float(obj["top"]), float(obj["bottom"])
        if (bottom - top) < RULE_MAX_DY_PT and (right - left) > RULE_MIN_DX_PT:
            rules.append(Box(left=left, right=right, top=top, bottom=bottom))
    return rules


def _infer_content_box(
    page, text_lines: list[Box], rules: list[Box]
) -> tuple[float, float]:
    """Infer the content box (left/right text margins) from the layout itself.

    Uses wide body lines and full-width rules, which reliably span the content
    area. Falls back to a 10%/90% guess if the page has no wide elements.
    """
    min_wide = page.width * CONTENT_BOX_MIN_WIDTH_RATIO
    lefts: list[float] = []
    rights: list[float] = []
    for b in text_lines:
        if b.top >= HEADER_BAND_PT and b.bottom <= page.height - FOOTER_BAND_PT:
            if b.width >= min_wide:
                lefts.append(b.left)
                rights.append(b.right)
    for r in rules:
        if r.width >= min_wide:
            lefts.append(r.left)
            rights.append(r.right)
    if lefts and rights:
        return min(lefts), max(rights)
    return page.width * 0.10, page.width * 0.90


def _classify_text(b: Box, geom: PageGeometry) -> str:
    if b.top < HEADER_BAND_PT:
        return "HEADER"
    if b.bottom > geom.page_height - FOOTER_BAND_PT:
        return "FOOTER"
    for x0, top, x1, bottom in geom.table_bboxes:
        if b.left >= x0 - 5 and b.right <= x1 + 5 and top - 5 <= b.top <= bottom + 5:
            return "TABLE_CELL"
    indent = b.left - geom.content_left
    width_ratio = b.width / geom.content_width if geom.content_width else 1.0
    if (
        indent > CENTERED_MIN_INDENT_PT
        and width_ratio < CENTERED_MAX_WIDTH_RATIO
        and b.width >= CENTERED_MIN_WIDTH_PT
    ):
        return "CENTERED"
    if indent <= CENTERED_MIN_INDENT_PT:
        return "BODY_LEFT"
    return "OTHER"


def _classify_rule(r: Box, geom: PageGeometry) -> str:
    # A rule inside a table bbox is always table structure (grid line, card
    # border, cell divider) — never a decorative divider. This prevents stat-card
    # and table borders from being misclassified as pull-quote dividers.
    for x0, top, x1, bottom in geom.table_bboxes:
        if x0 - 5 <= r.left and r.right <= x1 + 5 and top - 5 <= r.top and r.bottom <= bottom + 5:
            return "TABLE_GRID"
    cw = geom.content_width or 1.0
    ratio = r.width / cw
    if ratio > FULL_WIDTH_RULE_RATIO:
        near_edge = r.top < HEADER_BAND_PT or r.bottom > geom.page_height - FOOTER_BAND_PT
        return "HEADER_FOOTER_LINE" if near_edge else "TABLE_GRID"
    if ratio < DECORATIVE_RULE_RATIO:
        return "DECORATIVE_DIVIDER"
    return "TABLE_GRID"


def extract_page_geometry(
    page,
    page_num: int,
    content_left: float | None = None,
    content_right: float | None = None,
) -> PageGeometry:
    """Extract and classify every element the geometric checks reason about on one page."""
    text_lines = _group_words_into_lines(
        page.extract_words(keep_blank_chars=True, x_tolerance=3, y_tolerance=3)
    )
    rules = _extract_rules(page)

    if content_left is None or content_right is None:
        inferred_left, inferred_right = _infer_content_box(page, text_lines, rules)
        content_left = inferred_left if content_left is None else content_left
        content_right = inferred_right if content_right is None else content_right

    geom = PageGeometry(
        page_num=page_num,
        page_width=float(page.width),
        page_height=float(page.height),
        content_left=content_left,
        content_right=content_right,
        text_lines=text_lines,
        rules=rules,
        table_bboxes=[tuple(float(v) for v in t.bbox) for t in page.find_tables()],
        image_bboxes=[
            (float(im["x0"]), float(im["top"]), float(im["x1"]), float(im["bottom"]))
            for im in page.images
        ],
    )
    for b in geom.text_lines:
        b.kind = _classify_text(b, geom)
    for r in geom.rules:
        r.kind = _classify_rule(r, geom)
    return geom


def _overlap_ratio(a: Box, b: Box) -> float:
    """Fraction of the *smaller* box that overlaps, taken as the min over both
    axes. Near 1.0 only when the boxes substantially cover each other."""
    ox = min(a.right, b.right) - max(a.left, b.left)
    oy = min(a.bottom, b.bottom) - max(a.top, b.top)
    if ox <= 0 or oy <= 0:
        return 0.0
    min_w = min(a.width, b.width)
    min_h = min(a.bottom - a.top, b.bottom - b.top)
    fx = ox / min_w if min_w > 0 else 0.0
    fy = oy / min_h if min_h > 0 else 0.0
    return min(fx, fy)


def _nearest_neighbours(rule: Box, candidates: list[Box]) -> list[Box]:
    """Nearest non-overlapping text line above and below a rule, if any."""
    above = [b for b in candidates if b.bottom <= rule.top]
    below = [b for b in candidates if b.top >= rule.bottom]
    out: list[Box] = []
    if above:
        out.append(min(above, key=lambda b: rule.top - b.bottom))
    if below:
        out.append(min(below, key=lambda b: b.top - rule.bottom))
    return out


def check_page(geom: PageGeometry, tol: float) -> tuple[list[str], list[str]]:
    """Run every geometric invariant on one page.

    Returns (hard_fails, soft_warns):
      - hard_fails: real defects that block delivery — collisions, overflow,
        text overlapping images/tables. These cause exit 1.
      - soft_warns: cosmetic drift — centring, divider alignment, clearance
        proximity. Informational; never block delivery.
    """
    hard: list[str] = []
    soft: list[str] = []
    cc = geom.content_center
    pn = geom.page_num

    def hfail(msg: str) -> None:
        if len(hard) < MAX_ISSUES:
            hard.append(f"page {pn}: {msg}")

    def warn(msg: str) -> None:
        if len(soft) < MAX_ISSUES:
            soft.append(f"page {pn}: {msg}")

    centered = [b for b in geom.text_lines if b.kind == "CENTERED"]
    dividers = [r for r in geom.rules if r.kind == "DECORATIVE_DIVIDER"]

    # 1. Centred text vs content centre — SOFT (cosmetic drift).
    for b in centered:
        d = b.center - cc
        if abs(d) > tol:
            warn(f'centred text off-centre by {d:+.1f}pt: "{b.text[:50]}"')

    # 2. Decorative dividers vs content centre — SOFT.
    for r in dividers:
        d = r.center - cc
        if abs(d) > tol:
            warn(f"decorative divider at top={r.top:.0f} off-centre by {d:+.1f}pt")

    # 3. Divider vs the block it decorates — SOFT.
    pairable = [
        b for b in geom.text_lines
        if b.kind not in ("HEADER", "FOOTER", "TABLE_CELL")
        and (b.width / geom.content_width if geom.content_width else 1.0)
        < DIVIDER_PAIR_MAX_WIDTH_RATIO
        and (b.left - geom.content_left) > DIVIDER_PAIR_MIN_INDENT_PT
        and b.width >= CENTERED_MIN_WIDTH_PT
    ]
    for r in dividers:
        for b in _nearest_neighbours(r, pairable):
            gap = min(abs(b.top - r.bottom), abs(r.top - b.bottom))
            if gap > DIVIDER_PAIR_MAX_GAP_PT:
                continue
            d = r.center - b.center
            if abs(d) > tol:
                warn(
                    f"divider at top={r.top:.0f} vs its text "
                    f'"{b.text[:32]}" off by {d:+.1f}pt'
                )

    # 4. Title vs subtitle — SOFT.
    if len(centered) >= 2:
        first_two = sorted(centered, key=lambda b: b.top)[:2]
        d = first_two[0].center - first_two[1].center
        if abs(d) > tol:
            warn(f"title vs subtitle centres differ by {d:+.1f}pt")

    # 5. Distinct text lines collide — HARD (unreadable text).
    checkable = [b for b in geom.text_lines if b.kind != "TABLE_CELL"]
    for i, a in enumerate(checkable):
        for b in checkable[i + 1 :]:
            if abs(a.top - b.top) < LINE_GROUP_PT:
                continue  # same visual row
            if _overlap_ratio(a, b) >= COLLISION_MIN_OVERLAP_RATIO:
                hfail(f'text collision: "{a.text[:24]}" overlaps "{b.text[:24]}"')

    # 6. Text overflows the content box — HARD (text runs off the page).
    for b in geom.text_lines:
        if b.kind in ("HEADER", "FOOTER", "TABLE_CELL"):
            continue
        if b.right > geom.content_right + OVERFLOW_SLACK_PT:
            hfail(
                f"text overflows right margin by "
                f'{b.right - geom.content_right:.1f}pt: "{b.text[:40]}"'
            )
        if b.left < geom.content_left - OVERFLOW_SLACK_PT:
            hfail(
                f"text overflows left margin by "
                f'{geom.content_left - b.left:.1f}pt: "{b.text[:40]}"'
            )

    # 7. Clearance — overlap is HARD (unreadable), proximity is SOFT.
    def _gap(b: Box, x0: float, top: float, x1: float, bottom: float) -> float | None:
        x_overlap = min(b.right, x1) - max(b.left, x0)
        y_overlap = min(b.bottom, bottom) - max(b.top, top)
        if x_overlap > 0 and y_overlap > 0:
            return -min(x_overlap, y_overlap)  # intersecting
        if x_overlap > 0:
            return top - b.bottom if b.bottom <= top else b.top - bottom
        if y_overlap > 0:
            return x0 - b.right if b.right <= x0 else b.left - x1
        return None

    flowing = [b for b in geom.text_lines
               if b.kind not in ("HEADER", "FOOTER", "TABLE_CELL")]
    for b in flowing:
        for label, boxes, min_clear in (
            ("image", geom.image_bboxes, CLEARANCE_MIN_IMG_TABLE_PT),
            ("table", geom.table_bboxes, CLEARANCE_MIN_IMG_TABLE_PT),
        ):
            for (x0, top, x1, bottom) in boxes:
                if b.left >= x0 - 5 and b.right <= x1 + 5 and top - 5 <= b.top <= bottom + 5:
                    continue
                g = _gap(b, x0, top, x1, bottom)
                if g is None or g >= min_clear:
                    continue
                if g < 0:
                    hfail(f'text "{b.text[:32]}" overlaps a {label} by {-g:.1f}pt '
                          f"— move it clear (spaceBefore/spaceAfter or Spacer)")
                else:
                    warn(f'text "{b.text[:32]}" sits {g:.1f}pt from a {label} '
                         f"(min {min_clear:.0f}pt) — elements are touching; add "
                         f"spaceBefore/spaceAfter or a Spacer")
        for r in geom.rules:
            if r.kind != "DECORATIVE_DIVIDER":
                continue
            g = _gap(b, r.left, r.top, r.right, r.bottom)
            if g is not None and 0 <= g < CLEARANCE_MIN_RULE_PT:
                warn(f'text "{b.text[:32]}" sits {g:.1f}pt from a divider rule '
                     f"(min {CLEARANCE_MIN_RULE_PT:.1f}pt) — touching; add space "
                     f"around the rule")

    return hard, soft


def main() -> int:
    ap = argparse.ArgumentParser(description="Deterministic geometric layout QA")
    ap.add_argument("pdf")
    ap.add_argument("--tol", type=float, default=DEFAULT_TOLERANCE_PT,
                    help=f"alignment tolerance in points (default {DEFAULT_TOLERANCE_PT})")
    ap.add_argument("--content-left", type=float, default=None,
                    help="override inferred content-left margin (points)")
    ap.add_argument("--content-right", type=float, default=None,
                    help="override inferred content-right margin (points)")
    args = ap.parse_args()

    try:
        pdf = pdfplumber.open(args.pdf)
    except FileNotFoundError:
        print(f"check_layout: file not found: {args.pdf}", file=sys.stderr)
        return 2
    except Exception as exc:  # pdfminer raises many types on malformed input
        print(f"check_layout: could not open {args.pdf}: {exc}", file=sys.stderr)
        return 2

    all_hard: list[str] = []
    all_soft: list[str] = []
    with pdf:
        for i, page in enumerate(pdf.pages, start=1):
            geom = extract_page_geometry(
                page, i, args.content_left, args.content_right
            )
            hard, soft = check_page(geom, args.tol)
            status = "FAIL" if hard else ("WARN" if soft else "PASS")
            print(
                f"page {i}: content_center={geom.content_center:.1f} "
                f"content_width={geom.content_width:.1f} "
                f"| centred={sum(b.kind == 'CENTERED' for b in geom.text_lines)} "
                f"dividers={sum(r.kind == 'DECORATIVE_DIVIDER' for r in geom.rules)} "
                f"tables={len(geom.table_bboxes)} "
                f"-> {status}"
            )
            all_hard.extend(hard)
            all_soft.extend(soft)

    if all_soft:
        print(f"\nLAYOUT WARN ({len(all_soft)} cosmetic issue(s)) at tol={args.tol}pt:")
        for msg in all_soft:
            print(f"  - {msg}")
        print("(cosmetic — does not block delivery)")

    if all_hard:
        print(f"\nLAYOUT FAIL ({len(all_hard)} blocking issue(s)) at tol={args.tol}pt:")
        for msg in all_hard:
            print(f"  - {msg}")
        print("\nFix these blocking issues, rebuild, re-run. Do not present_output yet.")
        return 1

    if all_soft:
        print(f"\nLAYOUT PASSED with {len(all_soft)} cosmetic warning(s) at tol={args.tol}pt.")
    else:
        print(f"\nLAYOUT PASSED at tol={args.tol}pt.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
