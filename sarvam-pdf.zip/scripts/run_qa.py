#!/usr/bin/env python3
"""The single QA gate for a generated PDF — run this ONCE after building.

Runs every geometric check in one invocation and prints one consolidated
report:

  1. check_layout.py   — alignment: centring, collisions, horizontal overflow
  2. check_spacing.py  — whitespace: orphan headings, widowed tails, slivers,
                         under-filled pages, oversized gaps
  3. check_tables.py   — tables: frame fill, column tiling, bleed, row
                         anchors, page-split integrity

Writing quality (concise headings, anti-slop, numbers with units/basis) is
governed by writing.md and applied while drafting — it is not machine-checked.

Each check splits its output into:
  - FAIL (blocking): real defects that make the PDF unreadable — collisions,
    text overflow, cross-column bleed. Only these cause exit 1.
  - WARN (advisory): cosmetic drift — centring, spacing, valign, frame fill.
    Never blocks delivery.

Usage:
    python scripts/run_qa.py out.pdf [--tol 6.0]

Exit 0 = deliver the PDF now (may carry cosmetic WARNs). Exit 1 = fix the
blocking FAIL messages, rebuild, re-run once. Exit 2 = unreadable file.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys

CHECKS = [
    ("layout",  "check_layout.py",  "alignment (centring, collisions, overflow)"),
    ("spacing", "check_spacing.py", "whitespace (advisory — never blocks)"),
    ("tables",  "check_tables.py",  "tables (bleed blocks; fill/valign advisory)"),
]


def main() -> int:
    ap = argparse.ArgumentParser(description="Single QA gate for a generated PDF")
    ap.add_argument("pdf")
    ap.add_argument("--tol", type=float, default=None,
                    help="alignment tolerance in points (passed to check_layout)")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    worst = 0
    failed: list[str] = []

    for key, script, blurb in CHECKS:
        cmd = [sys.executable, os.path.join(here, script), args.pdf]
        if key == "layout" and args.tol is not None:
            cmd += ["--tol", str(args.tol)]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        print(f"--- {key}: {blurb} ---")
        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()
        if out:
            print(out)
        if err:
            print(err, file=sys.stderr)
        print()
        if proc.returncode != 0:
            failed.append(key)
        worst = max(worst, proc.returncode)

    if worst == 0:
        print("ALL QA PASSED — the PDF is verified; deliver it now.")
        print("(Cosmetic WARNs above do not block delivery.)")
    else:
        print(f"QA GATE FAILED ({', '.join(failed)}). Fix ONLY the FAIL messages "
              f"above — WARN messages are cosmetic and ship as-is. Rebuild, then "
              f"re-run run_qa.py once.")
    return worst


if __name__ == "__main__":
    sys.exit(main())
