#!/usr/bin/env python3
"""Deterministic table-integrity QA for a generated PDF.

``check_layout.py`` proves elements align and ``check_spacing.py`` proves pages
fill; this proves *tables* are internally sound — the single most common
programmatic-PDF defect. Per data table, per page:

  1. Fills the content frame — the table width matches the content width (page
     width minus margins). A narrower table leaves visible gaps on both sides;
     the usual root cause is column-width fractions that sum to <1.0 (too
     narrow) or >1.0 (overflows the right margin).
  2. Column widths sum to the table width — the columns tile the table exactly.
     This is the root-cause check: when check 1 fails, this tells you the
     fractions are wrong.
  3. No cross-column text bleed — no word spills past its cell's right edge into
     the next column.
  4. Row vertical alignment — cells in a data row share a vertical centre.
     Compares CENTRES, not tops, so a ``VALIGN="MIDDLE"`` row with a 1-line cell
     beside a 2-line cell is NOT a false positive.
  5. Page-split integrity — a table that continues onto the next page must not
     leave a sliver (a 1-2 row remnant on either side of the break), and the
     continuation must repeat the header row (``repeatRows=1``). Detected by
     x-extent match between the last table on one page and the first on the
     next.

pdfplumber gotchas defended against (each caused a crash or false positive in
the wild):
  - ``Column`` / ``Row`` objects expose ``.bbox``, not ``.x0`` / ``.x1`` — always
    index the bbox tuple.
  - Canvas-drawn rectangles (a header band, a page frame) look like a
    full-page "table" — skip any table ~full page width anchored at ``x0`` ~= 0.
  - Two adjacent tables merged into one detection → column widths sum to MORE
    than the table width → skip the column-sum check rather than false-alarm.

The content frame (text margins) is inferred from the page layout the same way
``check_layout.py`` does, so this works on any generator; override with
``--content-left`` / ``--content-right`` if inference is off.

Usage:
    python scripts/check_tables.py <file.pdf>
        [--content-left PT --content-right PT]

Exit code 0 = every table sound (or no tables); 1 = at least one FAIL (details
on stdout); 2 = the file could not be read.
"""

from __future__ import annotations

import argparse
import sys

try:
    import pdfplumber
except ImportError:
    print(
        "check_tables: pdfplumber is not installed. Run:\n"
        "    pip install pdfplumber\n",
        file=sys.stderr,
    )
    sys.exit(2)

# check_layout.py lives beside this script (Python puts the script dir on
# sys.path[0]); reuse its content-box inference so all three geometric checkers
# agree on where the text margins are.
from check_layout import MAX_ISSUES, extract_page_geometry  # noqa: E402


# --- Tunable thresholds (all justified; no voodoo constants) ----------------

# Table-vs-frame width match. 8 pt ~= 2.8 mm: lenient — a table a few points
# narrower or wider than the frame is cosmetic, not a layout defect. Only
# substantial under-fill (a clearly too-narrow table) is flagged.
FRAME_FILL_TOL_PT = 8.0
# Columns should tile the table exactly; allow 2 pt of rounding.
COL_SUM_TOL_PT = 2.0
# A word whose right edge passes its cell edge by more than this is bleeding
# into the next column.
BLEED_TOL_PT = 1.5
# A cell's text centre may sit this far from its row's geometric centre before
# the row looks misaligned. ~1.4 mm absorbs leading/rounding.
VALIGN_TOL_PT = 4.0
# A detected "table" this wide (fraction of the PAGE width) anchored at the left
# edge is almost always a canvas-drawn rectangle, not a data table — skip it.
SPURIOUS_TABLE_WIDTH_RATIO = 0.98
SPURIOUS_TABLE_MAX_X0_PT = 5.0
# Only run the valign check on rows with at least this many populated cells;
# a single-cell row has nothing to align against.
VALIGN_MIN_CELLS = 2
# Page-split detection: the fragments of one table split across a page break
# share their x-extent within this tolerance...
SPLIT_X_MATCH_TOL_PT = 5.0
# ...the first fragment ends within this distance of the page's bottom edge,
# and the continuation starts within this distance of the page's top edge
# (both bands comfortably cover a 1in margin plus header/footer furniture).
SPLIT_BOTTOM_BAND_PT = 110.0
SPLIT_TOP_BAND_PT = 130.0
# A fragment with this many rows or fewer is a sliver: for a headed table the
# continuation needs the repeated header + at least 2 data rows to look
# intentional.
SPLIT_MIN_FRAGMENT_ROWS = 2


def _infer_frame(
    geom, page_width: float, table_x0s: list[float],
    override_left: float | None, override_right: float | None,
) -> tuple[float, float]:
    """Infer the content frame (the margin box) independently of table width.

    Subtlety: ``doc.width`` — what the skill sizes tables to — is the *margin
    box* width (page minus margins). reportlab then insets ordinary flowables
    (paragraphs) by the frame's default ~6 pt side padding, so body text sits at
    margin+padding, while a full-width table set to ``doc.width`` sits at the
    true margin. So the leftmost thing on the page is the best margin estimate:
    a correct full-width table reaches the margin (defining it); a too-narrow
    table does not, and left-aligned body text (at margin+padding) still pins
    the frame close enough to expose a big gap. Margins are assumed symmetric;
    override for asymmetric layouts.
    """
    if override_left is not None and override_right is not None:
        return override_left, override_right
    candidates = [
        b.left for b in geom.text_lines if b.kind in ("BODY_LEFT", "OTHER")
    ]
    candidates += table_x0s
    left = min(candidates) if candidates else page_width * 0.085
    left = override_left if override_left is not None else left
    right = override_right if override_right is not None else page_width - left
    return left, right


def _words_in_bbox(words: list[dict], bbox: tuple) -> list[dict]:
    """Words whose centre falls inside ``bbox`` = (x0, top, x1, bottom)."""
    x0, top, x1, bottom = bbox
    out = []
    for w in words:
        cx = (w["x0"] + w["x1"]) / 2
        cy = (w["top"] + w["bottom"]) / 2
        if x0 <= cx <= x1 and top <= cy <= bottom:
            out.append(w)
    return out


def _check_frame_fill(
    table_bbox: tuple, content_left: float, content_right: float, tol: float
) -> str | None:
    tx0, _, tx1, _ = table_bbox
    content_w = content_right - content_left
    left_gap = tx0 - content_left
    right_gap = content_right - tx1
    if abs((tx1 - tx0) - content_w) < tol and abs(left_gap) < tol:
        return None
    if abs(right_gap + 12.0) < tol and abs(left_gap) < tol:
        # Signature of the hAlign="LEFT" + doc.width combination: flush left
        # with body text but 12pt past its right edge (the frame's 6pt side
        # paddings). A width bug looks different (gaps on both sides).
        return (
            f"overhangs the text column by {-right_gap:.1f}pt on the right "
            f"(left edge flush) — an hAlign=\"LEFT\" table sized to doc.width; "
            f"either size it to doc.width - 12 (the text column) or drop "
            f"hAlign and let it center margin-to-margin"
        )
    return (
        f"does not fill the content frame: width={tx1 - tx0:.1f} vs frame "
        f"{content_w:.1f} (left_gap={left_gap:+.1f} right_gap={right_gap:+.1f}) "
        f"— column-width fractions likely do not sum to 1.0"
    )


def _check_column_sum(columns, table_w: float, tol: float) -> str | None:
    col_widths = [c.bbox[2] - c.bbox[0] for c in columns]  # .bbox, never .x0/.x1
    col_sum = sum(col_widths)
    if col_sum > table_w + tol:
        # Merged-table artifact (two adjacent tables detected as one): the sub
        # columns overlap the inherited full width. Skip, do not false-alarm.
        return None
    if abs(col_sum - table_w) > tol:
        widths = ", ".join(f"{w:.1f}" for w in col_widths)
        return (
            f"column widths [{widths}] sum to {col_sum:.1f}, not the table "
            f"width {table_w:.1f} — columns do not tile the table"
        )
    return None


def _check_bleed(rows, words: list[dict], tol: float) -> str | None:
    for row in rows:
        for cell in row.cells:
            if cell is None:
                continue
            cx1 = cell[2]
            for w in _words_in_bbox(words, cell):
                if w["x1"] > cx1 + tol:
                    return (
                        f'text "{w["text"][:24]}" bleeds {w["x1"] - cx1:.1f}pt '
                        f"past its column edge into the next column"
                    )
    return None


def _check_valign(rows, words: list[dict], tol: float) -> str | None:
    """A row is consistently aligned if its cells agree on ANY one anchor —
    tops (VALIGN=TOP), centres (MIDDLE), or bottoms (BOTTOM). We do not assume a
    mode: only flag a row where cells align on *none* of the three, which is the
    real defect. Comparing a single mode would false-positive every correct
    TOP-aligned row that has a 1-line cell beside a wrapped 2-line cell.
    """
    # Skip the first row (header — often a different height/style).
    for row in rows[1:]:
        row_top = row.bbox[1]
        tops, centers, bottoms = [], [], []
        for cell in row.cells:
            if cell is None:
                continue
            cell_words = _words_in_bbox(words, cell)
            if not cell_words:
                continue
            t = min(w["top"] for w in cell_words)
            b = max(w["bottom"] for w in cell_words)
            tops.append(t)
            bottoms.append(b)
            centers.append((t + b) / 2)
        if len(tops) < VALIGN_MIN_CELLS:
            continue
        spreads = (
            max(tops) - min(tops),
            max(centers) - min(centers),
            max(bottoms) - min(bottoms),
        )
        if min(spreads) > tol:
            return (
                f"row at top={row_top:.0f}: cells align on neither top, centre "
                f"nor bottom (min spread {min(spreads):.1f}pt) — a cell is "
                f"vertically misaligned; set a consistent VALIGN"
            )
    return None


def _first_row_text(table, words: list[dict]) -> str:
    """Whitespace-normalized text of a table's first row (its header, if any)."""
    if not table.rows:
        return ""
    x0, top, x1, bottom = table.rows[0].bbox
    row_words = _words_in_bbox(words, (x0, top, x1, bottom))
    return " ".join(w["text"] for w in sorted(row_words, key=lambda w: w["x0"]))


def check_page_split(prev, cur) -> list[str]:
    """Cross-page check: the last table on the previous page and the first
    table on this page, sharing one x-extent across the break, are two
    fragments of ONE split table. Flag sliver fragments and a missing repeated
    header. ``prev``/``cur`` are dicts: {num, tables, words, height}."""
    issues: list[str] = []
    if not prev["tables"] or not cur["tables"]:
        return issues
    pt, ct = prev["tables"][-1], cur["tables"][0]
    ends_low = pt.bbox[3] > prev["height"] - SPLIT_BOTTOM_BAND_PT
    starts_high = ct.bbox[1] < SPLIT_TOP_BAND_PT
    x_match = (abs(pt.bbox[0] - ct.bbox[0]) < SPLIT_X_MATCH_TOL_PT
               and abs(pt.bbox[2] - ct.bbox[2]) < SPLIT_X_MATCH_TOL_PT)
    if not (ends_low and starts_high and x_match):
        return issues

    p_rows, c_rows = len(pt.rows), len(ct.rows)
    if p_rows <= SPLIT_MIN_FRAGMENT_ROWS:
        issues.append(
            f"page {prev['num']} table: only {p_rows} row(s) before the page "
            f"break, with the rest on page {cur['num']} — a sliver start; keep "
            f"the table together (KeepTogether) or start it on the next page "
            f"(PageBreak before it)"
        )
    if c_rows <= SPLIT_MIN_FRAGMENT_ROWS:
        issues.append(
            f"page {cur['num']} table: only {c_rows} row(s) continue from the "
            f"table on page {prev['num']} — a sliver remnant; pull the last "
            f"row(s) onto page {prev['num']} (shorten preceding content or "
            f"tighten row padding) or split the table earlier"
        )
    elif _first_row_text(ct, cur["words"]) != _first_row_text(pt, prev["words"]):
        issues.append(
            f"page {cur['num']} table: continues the table from page "
            f"{prev['num']} without repeating the header row — pass "
            f"repeatRows=1 to Table(...) so every page of the table is headed"
        )
    return issues


def _is_spurious(table, page_width: float) -> bool:
    """A detected 'table' that is ~full page width anchored at the left edge is
    almost always a canvas-drawn rectangle (header band, page frame)."""
    tx0, _, tx1, _ = table.bbox
    return tx0 < SPURIOUS_TABLE_MAX_X0_PT and (tx1 - tx0) >= page_width * SPURIOUS_TABLE_WIDTH_RATIO


def _data_tables(page) -> list:
    return [t for t in page.find_tables() if not _is_spurious(t, float(page.width))]


def check_page(page, page_num: int, tables: list, content_left: float, content_right: float) -> tuple[list[str], list[str]]:
    hard: list[str] = []
    soft: list[str] = []

    def hfail(idx: int, msg: str) -> None:
        if len(hard) < MAX_ISSUES:
            hard.append(f"page {page_num} table {idx}: {msg}")

    def warn(idx: int, msg: str) -> None:
        if len(soft) < MAX_ISSUES:
            soft.append(f"page {page_num} table {idx}: {msg}")

    words = page.extract_words(keep_blank_chars=False, x_tolerance=2, y_tolerance=2)

    for idx, table in enumerate(tables, start=1):
        tx0, _, tx1, _ = table.bbox
        table_w = tx1 - tx0

        # Frame fill — SOFT (cosmetic gap, not unreadable).
        msg = _check_frame_fill(table.bbox, content_left, content_right, FRAME_FILL_TOL_PT)
        if msg:
            warn(idx, msg)

        # Column sum — SOFT (structural but cosmetic; the table still renders).
        try:
            msg = _check_column_sum(table.columns, table_w, COL_SUM_TOL_PT)
            if msg:
                warn(idx, msg)
        except (AttributeError, IndexError):
            pass  # degenerate column geometry; other checks still run

        # Bleed — HARD (text spilling into the wrong column is unreadable).
        msg = _check_bleed(table.rows, words, BLEED_TOL_PT)
        if msg:
            hfail(idx, msg)

        # Valign — SOFT (cosmetic misalignment, not unreadable).
        msg = _check_valign(table.rows, words, VALIGN_TOL_PT)
        if msg:
            warn(idx, msg)

    return hard, soft


def main() -> int:
    ap = argparse.ArgumentParser(description="Deterministic table-integrity QA")
    ap.add_argument("pdf")
    ap.add_argument("--content-left", type=float, default=None,
                    help="override inferred content-left margin (points)")
    ap.add_argument("--content-right", type=float, default=None,
                    help="override inferred content-right margin (points)")
    args = ap.parse_args()

    try:
        pdf = pdfplumber.open(args.pdf)
    except FileNotFoundError:
        print(f"check_tables: file not found: {args.pdf}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"check_tables: could not open {args.pdf}: {exc}", file=sys.stderr)
        return 2

    all_hard: list[str] = []
    all_soft: list[str] = []
    total_tables = 0
    prev_page = None  # cross-page state for the split-table check
    with pdf:
        for i, page in enumerate(pdf.pages, start=1):
            geom = extract_page_geometry(page, i)
            tables = _data_tables(page)
            content_left, content_right = _infer_frame(
                geom, float(page.width), [t.bbox[0] for t in tables],
                args.content_left, args.content_right,
            )
            hard, soft = check_page(page, i, tables, content_left, content_right)
            cur_page = {
                "num": i, "tables": tables, "height": float(page.height),
                "words": page.extract_words(keep_blank_chars=False,
                                            x_tolerance=2, y_tolerance=2),
            }
            if prev_page is not None:
                # Page-split issues are advisory (cosmetic, not unreadable).
                soft.extend(check_page_split(prev_page, cur_page))
            prev_page = cur_page
            total_tables += len(tables)
            status = "FAIL" if hard else ("WARN" if soft else "PASS")
            print(f"page {i}: tables={len(tables)} -> {status}")
            all_hard.extend(hard)
            all_soft.extend(soft)

    if all_soft:
        print(f"\nTABLE WARN ({len(all_soft)} advisory issue(s)):")
        for msg in all_soft:
            print(f"  - {msg}")
        print("(cosmetic — does not block delivery)")

    if all_hard:
        print(f"\nTABLE FAIL ({len(all_hard)} blocking issue(s)):")
        for msg in all_hard:
            print(f"  - {msg}")
        print(
            "\nFix these blocking issues, rebuild, re-run. Do not present_output yet."
        )
        return 1

    if total_tables == 0:
        print("\nTABLE PASSED: no data tables found — nothing to check.")
    elif all_soft:
        print(f"\nTABLE PASSED with {len(all_soft)} cosmetic warning(s) ({total_tables} table(s)).")
    else:
        print(f"\nTABLE PASSED ({total_tables} table(s) sound).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
