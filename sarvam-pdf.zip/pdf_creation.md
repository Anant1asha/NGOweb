# PDF Creation Guide (reportlab)

Every formatting-safe pattern for generating a PDF. Each one prevents a specific
failure, and the QA gate ([qa.md](qa.md)) asserts most of them.

Always build from **Platypus flowables** inside a `SimpleDocTemplate`. Never lay
out body text with `canvas.drawString` — it does not wrap and runs off the page.
`scripts/create_sample_pdf.py` combines every pattern below; run it to see
correct output.

## Contents

- Page geometry — know your content width
- Wrapping text — use Paragraph, set leading
- Centring: indent is not alignment
- Headers & footers — draw in the margin via onPage callbacks
- Bullet & numbered lists — use ListFlowable, never typed bullets
- Fonts: Helvetica, and characters it lacks
- Fonts for Indic scripts (Devanagari)
- Tables that do not break layout
- Table colours: background and text must be chosen together
- Professional tables — compact numeric variant
- Equal-height side-by-side cards
- Multi-template documents: NextPageTemplate ordering
- Vertical rhythm — keep sections whole, fill the page
- reportlab API gotchas (naming collisions, double-wrapping)

## Page geometry — know your content width

Set page size and margins explicitly so every flowable wraps to a known width.

```python
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate

doc = SimpleDocTemplate(
    "out.pdf", pagesize=LETTER,
    leftMargin=inch, rightMargin=inch, topMargin=inch, bottomMargin=inch,
)
content_width = doc.width  # page width minus left+right margins; use for tables
```

## Wrapping text — use Paragraph, set leading

`Paragraph` auto-wraps to the frame width. Set `leading` to ~1.2× the font size so lines do not collide.

```python
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Paragraph, Spacer

styles = getSampleStyleSheet()
body = ParagraphStyle("body", parent=styles["Normal"], fontName="Helvetica",
                      fontSize=10, leading=13, spaceAfter=8)

story = [Paragraph("Long text wraps automatically inside the frame. " * 20, body)]
```

`KeepTogether([...])` stops a block splitting across a page break; `KeepInFrame(maxWidth, maxHeight, [flowable], mode="shrink")` fits content to a fixed box.

## Centring: indent is not alignment

`leftIndent` / `rightIndent` only **shrink the frame** — they do not centre text. A style with indents but no `alignment` inherits its parent's (often `TA_JUSTIFY`/`TA_LEFT`), so text sits left-aligned inside the indented frame and its visual centre drifts off the page centre. Set alignment **explicitly** on anything centred (pull-quotes, captions under a rule):

```python
from reportlab.lib.enums import TA_CENTER

quote = ParagraphStyle("quote", parent=body, alignment=TA_CENTER,  # required — indents alone do NOT centre
                       leftIndent=16, rightIndent=16)
```

A centred element and the rule above it must share one centre — `scripts/check_layout.py` asserts this. When drawing that rule on the `canvas`, anchor it to the same centre, not the left margin: `canvas.rect(cx - w/2, y, w, h)` where `cx = page_width / 2`. A rule at `canvas.rect(leftMargin, ...)` beside a `canvas.drawCentredString(cx, ...)` will not line up.

**Asymmetric indents shift the page's apparent centre.** `check_layout.py` infers the content centre from the union of the page's elements, so a block indented on one side only drags that centre sideways and makes genuinely-centred titles report as off-centre. Keep `leftIndent=0, rightIndent=0` on body styles; indent only where it is symmetric and deliberate.

## Headers & footers — draw in the margin via onPage callbacks

Headers and footers belong in the page margin, drawn by `onFirstPage`/`onLaterPages` — never as flowables in the story. Use `canvas.getPageNumber()` for page numbers.

```python
def _header_footer(canvas, doc):
    canvas.saveState()
    w, h = doc.pagesize
    canvas.setFont("Helvetica", 9)
    canvas.drawString(doc.leftMargin, h - 0.6 * inch, "Document Title")          # header
    canvas.drawRightString(w - doc.rightMargin, 0.5 * inch,                       # footer
                           f"Page {canvas.getPageNumber()}")
    canvas.restoreState()

doc.build(story, onFirstPage=_header_footer, onLaterPages=_header_footer)
```

## Bullet & numbered lists — use ListFlowable, never typed bullets

Never hand-type `•`, `-`, or unicode bullet glyphs, and never use unicode sub/superscripts. Use `ListFlowable` + `ListItem`.

```python
from reportlab.platypus import ListFlowable, ListItem

bullets = ListFlowable(
    [ListItem(Paragraph("First point", body)),
     ListItem(Paragraph("Second point", body))],
    bulletType="bullet",   # filled round bullet
)
numbered = ListFlowable(
    [ListItem(Paragraph("Step one", body)),
     ListItem(Paragraph("Step two", body))],
    bulletType="1",        # 1. 2. 3.
)
```

**Bullet markers and the left margin (verified):** with the defaults above the marker lands exactly on the content margin. What pushes markers *outside* it is `leftIndent` on the **item paragraph's style** or on the `ListItem` itself (or a negative `bulletIndent`) — the marker is positioned relative to those indents, so `ListItem(..., leftIndent=6)` moves the bullet 6 pt further left, not the text right. Fix by removing the per-item `leftIndent` and using `ListFlowable(..., leftIndent=...)` alone for nesting. Do not trial-and-error indent combinations.

For sub/superscripts inside a `Paragraph`, use markup, never unicode glyphs (the built-in fonts lack them and render as black boxes): `Paragraph("H<sub>2</sub>O and x<super>2</super>", body)`.

## Fonts: Helvetica, and characters it lacks

**Helvetica is the document font — headings and body** (`Helvetica-Bold` for headings). **Never restyle a document in DejaVu** (or another substitute TTF) to gain Unicode coverage — it renders visibly worse and production documents set in it were rejected on looks. Solve missing glyphs per character instead.

The 14 built-in Type 1 fonts (Helvetica, Times, Courier + bold/italic) cover only Latin-1 — 256 glyphs. Other Unicode characters have **no glyph** and render as black boxes or the wrong character (telltale: text extraction shows a wrong letter where the symbol should be).

| Category | Missing characters | Fix (stay in Helvetica) |
|----------|-------------------|-----|
| Bullets / decorative | `•` `●` `■` `▶` `★` `✓` `→` `✗` | `ListFlowable` for bullets; draw accents with `canvas.rect()`/`canvas.circle()` in `onPage` callbacks |
| Currency | `₹` `€` `£` `¥` `¢` | ASCII: `Rs.`, `EUR`, `GBP`, `JPY`, `cents` |
| Sub/superscript | `²` `³` `½` | `<sub>`/`<super>` markup inside a `Paragraph` |

Register a TTF only when the user explicitly requires a non-Latin-1 glyph (insists on `₹`, or wants non-Latin text) — and then for those runs only, not as the document face, preferring a user-supplied font over DejaVu.

## Fonts for Indic scripts (Devanagari)

Three rules, all verified against a production build:

**1. Use AnnapurnaSIL for mixed Latin + Devanagari.**

```python
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont("Indic",     "/usr/share/fonts/truetype/annapurna/AnnapurnaSIL-Regular.ttf"))
pdfmetrics.registerFont(TTFont("Indic-Bold", "/usr/share/fonts/truetype/annapurna/AnnapurnaSIL-Bold.ttf"))
```

Do **not** use `NotoSansDevanagari-*` or `NotoSerifDevanagari-*` for mixed-script content: reportlab renders **Latin characters at zero width** in them. `pdfmetrics.stringWidth()` still reports a plausible number, but the glyphs stack on top of each other, breaking every width-dependent behaviour — wrapping, and the centring check in `check_layout.py`, which then fails against text that really is centred. AnnapurnaSIL has correct widths for both scripts and ships Regular **and** Bold. `Lohit-Devanagari.ttf` (`/usr/share/fonts/truetype/lohit-devanagari/`) also renders Latin correctly but has no verified bold face.

**2. Glyph coverage is per-script.** An Indic font carries its own script plus basic ASCII — not scholarly diacritics (e.g. `Ṡ` U+1E60, upper Sa in Bhatkhande notation) and not other Indic scripts (Bengali, Tamil, Gurmukhi…). A missing glyph renders as a blank/notdef box, raises no error, and passes the geometry gate. Count nulls before delivering:

```python
import pdfplumber

with pdfplumber.open("out.pdf") as pdf:
    nulls = sum(1 for page in pdf.pages for ch in page.chars if ch["text"] == "\x00")
print("notdef chars:", nulls)   # must be 0
```

Fix a non-zero count by substituting an ASCII convention for the diacritic (`Ṡ` → `S'`) and transliterating other-script text into the registered font's script (`বসন্ত বাহার` → `Bosonto Bahar`).

**3. reportlab does not shape complex scripts.** It maps codepoints to glyphs one at a time, with no shaping engine (no HarfBuzz/Pango). Even with correct metrics, dense Devanagari can render with wrong conjunct formation (`क` + `्` + `ष` not combining into `क्ष`), reph reordering, or matra positioning. Neither the null-check nor the geometry gate detects this — both read extracted text and coordinates, not glyph shapes. Keep Devanagari runs short and formulaic (titles, single words, notation keys); treat paragraph-length Devanagari prose as a standing risk.

## Tables that do not break layout

Give `colWidths` that sum to `doc.width`, wrap every cell in a `Paragraph` so text wraps, and set padding in the `TableStyle` so rows do not collide.

```python
from reportlab.platypus import Table, TableStyle
from reportlab.lib import colors

cell = ParagraphStyle("cell", parent=body, fontSize=9, leading=11)
header = ParagraphStyle("cellhead", parent=cell, textColor=colors.white)

data = [
    [Paragraph("Product", header), Paragraph("Notes", header), Paragraph("Qty", header)],
    [Paragraph("Widget", cell), Paragraph("Wraps to the column width automatically", cell), Paragraph("12", cell)],
]
col_widths = [0.25 * doc.width, 0.55 * doc.width, 0.20 * doc.width]  # sums to doc.width
table = Table(data, colWidths=col_widths, repeatRows=1)
table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2E5A88")),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#999999")),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("TOPPADDING", (0, 0), (-1, -1), 4),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
]))
```

Column-width fractions **must sum to 1.0** — less leaves gaps on both sides, more overflows the right margin. This is the single most common table defect; `scripts/check_tables.py` asserts it.

**Table width vs. alignment — pick one of these two combinations.** The platypus frame insets flowables by 6 pt per side, so body text spans `doc.width - 12` and a `doc.width` table is 12 pt wider than the text column:

```python
# (a) Full-margin table, symmetric (default hAlign="CENTER"):
#     spans margin to margin, 6pt wider than body text on each side — clean.
table = Table(data, colWidths=[f * doc.width for f in fracs], repeatRows=1)

# (b) Flush-left with body text (hAlign="LEFT"): size to the TEXT column,
#     not doc.width, or the table sticks 12pt past the body's right edge.
text_w = doc.width - 12  # frame's 6pt left+right padding
table = Table(data, colWidths=[f * text_w for f in fracs], repeatRows=1, hAlign="LEFT")
```

Never combine `hAlign="LEFT"` with widths summing to `doc.width` — that is the overhang defect `check_tables.py` flags as not filling the frame.

**Never nest tables inside another table's cells to build a row of panels.** Each nested `Table` auto-sizes to its own content, so `check_tables.py` measures each against the full content frame and flags every one (a row of six cards → six failures). Build the row as columns of one table — see "Equal-height side-by-side cards" below.

## Table colours: background and text must be chosen together

Whenever a `TableStyle` sets a `BACKGROUND`, set that same range's `TEXTCOLOR` in the same style. The default text colour is black, unreadable on a dark fill, and the geometry gate cannot see contrast — the table passes QA and ships with an invisible header row.

```python
table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2E5A88")),  # dark header fill
    ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),                # REQUIRED with it
    ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#F3ECE0")), # light body fill
    ("TEXTCOLOR",  (0, 1), (-1, -1), colors.HexColor("#1A1A1A")), # dark text on light
]))
```

A cell holding a `Paragraph` takes its colour from the **paragraph style**, not `TEXTCOLOR` — hence the separate `header = ParagraphStyle(..., textColor=colors.white)` above. Set the colour wherever the text actually renders; the rule is the same either way: dark fill → light text, light fill → dark text.

## Professional tables — compact numeric variant

A numeric-data variant of the full pattern above.

```python
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle

doc = SimpleDocTemplate("report.pdf")
data = [
    ["Product", "Q1", "Q2", "Q3", "Q4"],
    ["Widgets", "120", "135", "142", "158"],
    ["Gadgets", "85", "92", "98", "105"],
]
table = Table(data, colWidths=[0.4 * doc.width] + [0.15 * doc.width] * 4)
table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2E5A88")),
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
    ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#999999")),
    ("TOPPADDING", (0, 0), (-1, -1), 4),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
]))
doc.build([table])
```

## Equal-height side-by-side cards

For stat cards, feature boxes, or any side-by-side panels with backgrounds: build all cards as **columns of a single `Table`** so every column shares row heights (separate nested tables each auto-size, so a card with more text grows taller than its neighbours). Use narrow spacer columns (empty-string cells) for gaps, and apply `BACKGROUND`/`BOX` per card column spanning all rows.

```python
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import Paragraph, Table, TableStyle

_styles = getSampleStyleSheet()
num_style = ParagraphStyle("num", parent=_styles["Normal"], fontName="Helvetica-Bold",
                           fontSize=17, leading=18)
lbl_style = ParagraphStyle("lbl", parent=_styles["Normal"], fontName="Helvetica-Bold",
                           fontSize=7.6, leading=9)
desc_style = ParagraphStyle("desc", parent=_styles["Normal"], fontName="Helvetica",
                            fontSize=7.6, leading=9)


def stat_row(items, cw, bg=colors.HexColor("#EAF1E6"), gap=6):
    """Equal-height row of (num, label, desc) stat cards. `cw` = content width."""
    n = len(items)
    card_w = (cw - (n - 1) * gap) / n

    col_widths = []                            # interleave cards with gap columns
    for i in range(n):
        col_widths.append(card_w)
        if i < n - 1:
            col_widths.append(gap)

    rows = [[], [], []]                        # [num], [label], [desc] across all cards
    for i, (num, label, desc) in enumerate(items):
        rows[0].append(Paragraph(num, num_style))
        rows[1].append(Paragraph(label, lbl_style))
        rows[2].append(Paragraph(desc, desc_style))
        if i < n - 1:                          # empty spacer cell in each row
            for r in rows:
                r.append("")

    tbl = Table(rows, colWidths=col_widths)
    style = [("VALIGN", (0, 0), (-1, -1), "TOP")]
    for i in range(n):
        col = 2 * i                            # card columns are even; gaps are odd
        style.append(("BACKGROUND", (col, 0), (col, -1), bg))
        style.append(("BOX", (col, 0), (col, -1), 0.5, colors.HexColor("#D8DED2")))
        style.append(("LEFTPADDING", (col, 0), (col, -1), 8))
        style.append(("RIGHTPADDING", (col, 0), (col, -1), 8))
        style.append(("TOPPADDING", (col, 0), (col, 0), 7))
        style.append(("BOTTOMPADDING", (col, -1), (col, -1), 7))
    tbl.setStyle(TableStyle(style))
    return tbl

# usage — 3 equal-height cards across the full content width
market = stat_row([
    ("$28B", "TAM", "India precision-agriculture market by 2030"),
    ("$6.5B", "SAM", "Smallholder-addressable segment (plots < 2 ha)"),
    ("$180M", "SOM", "Beachhead: 5 states, 4 priority crops"),
], doc.width)
```

Verify with pdfplumber — all card rectangles should have identical heights:

```python
with pdfplumber.open("out.pdf") as pdf:
    heights = [r["height"] for r in pdf.pages[0].rects if r["height"] > 10]
    assert max(heights) - min(heights) < 1.0   # all within 1pt
```

## Multi-template documents: NextPageTemplate ordering

`SimpleDocTemplate` uses one page template. For a cover page framed differently from body pages, use `BaseDocTemplate` with multiple `PageTemplate`s and switch with `NextPageTemplate`. The switch must appear **before** the `PageBreak` that ends the current page — otherwise the page after the break still uses the old template (common bug: cover decoration bleeding onto page 2).

```python
story.append(cover_flowables)
story.append(NextPageTemplate("inner"))   # applies to the NEXT page — BEFORE the break
story.append(PageBreak())                  # ends the cover; page 2 now uses "inner"
story.append(body_flowables)
```

## Vertical rhythm — keep sections whole, fill the page

A heading must never sit alone at the bottom of a page with its body on the next. Give heading styles `keepWithNext=1`, or wrap the heading plus its first block in `KeepTogether([...])` — this is the **default** mechanism for keeping sections whole.

Use `PageBreak()` **only** when a section deserves a fresh page AND the previous page is already ~two-thirds filled. A `PageBreak()` after a half-empty page creates exactly the under-filled page `check_spacing.py` flags; one per section in a many-section document guarantees a failing gate. Reserve hard breaks for true chapter boundaries.

**Section-start rule:** a heading must not start in the bottom quarter of a page unless ~3 lines of its body fit with it — a heading with 1–2 lines before the break is a sliver split that `check_spacing.py` flags. Wrapping the heading with its first paragraph in `KeepTogether([...])` (plus `keepWithNext=1`) reflows the whole unit to the next page when space runs short.

**When `KeepTogether` is not enough:** reportlab estimates a flowable's height before placing it, so a table whose rows wrap can still split despite being wrapped. Put a `CondPageBreak(height)` before that block — it moves to the next page when less than `height` remains, a hard guarantee rather than an estimate.

Keep `Spacer` sizes and `spaceBefore`/`spaceAfter` modest so pages fill evenly and content does not start far below the top margin. `scripts/check_spacing.py` asserts all of this, against the same thresholds quoted here.

For designed multi-page documents (programs, brochures, one-section-per-page reports), do not drop one sparse section per page. `KeepInFrame(mode="shrink")` prevents *overflow* only — it does **not** stretch content to fill a frame. Fill a page with generous body type (11–12 pt, leading ~1.4×), ample card padding, and **substantive content blocks** (info boxes, stat rows, taglines, summaries). A mid-page gap over ~20% of page height is an under-filled page — `check_spacing.py` flags it.

```python
H1 = ParagraphStyle("h1", parent=styles["Heading1"], fontName="Helvetica-Bold",
                    fontSize=14, leading=18, spaceBefore=10, spaceAfter=6,
                    keepWithNext=1)  # heading never orphaned from its body
```

## reportlab API gotchas (naming collisions, double-wrapping)

Two build blockers that surface as the same confusing traceback —
`TypeError: Paragraph.split() missing 1 required positional argument: 'availHeight'`:

- **Do not name a helper after a flowable method.** A module-level `def para(...)` (or `split`, `wrap`, `draw`) can shadow the method reportlab calls internally on its own flowables. Prefix helpers: `P`, `mk_para`, `build_table`.
- **Decide once whether a builder takes strings or flowables.** If a helper wraps its arguments in `Paragraph(...)` internally, pass plain strings — an already-built `Paragraph` re-enters `Paragraph.__init__` with a flowable as its text and fails inside reportlab's text cleaner, far from the actual mistake.
