# PDF Operations Guide (read, extract, manipulate)

Patterns for working with PDFs that already exist — extracting their content and
manipulating their pages. For *generating* a new PDF with reportlab, see
[pdf_creation.md](pdf_creation.md) instead.

One task uses one library: `pdfplumber` to extract, `pypdf` to manipulate pages,
`pypdfium2` to render.

## Contents

- Manipulate pages with pypdf (split, rotate, encrypt, watermark, crop, metadata)
- Extract with coordinates and custom table settings (pdfplumber)
- Render pages to images (pypdfium2)
- Batch processing with error handling

## Manipulate pages with pypdf

### Split into one file per page

```python
from pypdf import PdfReader, PdfWriter

reader = PdfReader("in.pdf")
for i, page in enumerate(reader.pages):
    writer = PdfWriter()
    writer.add_page(page)
    with open(f"page_{i + 1}.pdf", "wb") as f:
        writer.write(f)
```

### Rotate pages

```python
reader = PdfReader("in.pdf")
writer = PdfWriter()
page = reader.pages[0]
page.rotate(90)            # clockwise, multiples of 90
writer.add_page(page)
with open("rotated.pdf", "wb") as f:
    writer.write(f)
```

### Encrypt / decrypt

```python
# Encrypt
reader = PdfReader("in.pdf")
writer = PdfWriter()
for page in reader.pages:
    writer.add_page(page)
writer.encrypt("user_password", "owner_password")
with open("encrypted.pdf", "wb") as f:
    writer.write(f)

# Decrypt (when you know the password)
reader = PdfReader("encrypted.pdf")
if reader.is_encrypted:
    reader.decrypt("user_password")
```

### Watermark (stamp one PDF onto another)

```python
watermark = PdfReader("watermark.pdf").pages[0]
reader = PdfReader("in.pdf")
writer = PdfWriter()
for page in reader.pages:
    page.merge_page(watermark)
    writer.add_page(page)
with open("watermarked.pdf", "wb") as f:
    writer.write(f)
```

### Crop a page

```python
reader = PdfReader("in.pdf")
writer = PdfWriter()
page = reader.pages[0]
page.mediabox.left = 50
page.mediabox.bottom = 50
page.mediabox.right = 550
page.mediabox.top = 750
writer.add_page(page)
with open("cropped.pdf", "wb") as f:
    writer.write(f)
```

### Read metadata

```python
meta = PdfReader("in.pdf").metadata
print(meta.title, meta.author, meta.subject, meta.creator)
```

## Extract with coordinates and custom table settings (pdfplumber)

```python
import pdfplumber

with pdfplumber.open("in.pdf") as pdf:
    page = pdf.pages[0]

    # Characters with coordinates
    for char in page.chars[:10]:
        print(char["text"], round(char["x0"], 1), round(char["top"], 1))

    # Text inside a bounding box (left, top, right, bottom)
    region = page.within_bbox((100, 100, 400, 200)).extract_text()

    # Tables with explicit ruling-line strategy for complex layouts
    tables = page.extract_tables({
        "vertical_strategy": "lines",
        "horizontal_strategy": "lines",
        "snap_tolerance": 3,
        "intersection_tolerance": 15,
    })
```

To load extracted tables into a DataFrame, use `pandas` (install `pandas` first):

```python
import pandas as pd

with pdfplumber.open("in.pdf") as pdf:
    rows = pdf.pages[0].extract_tables()[0]
df = pd.DataFrame(rows[1:], columns=rows[0])
```

## Render pages to images (pypdfium2)

```python
import pypdfium2 as pdfium

pdf = pdfium.PdfDocument("in.pdf")
for i in range(len(pdf)):
    image = pdf[i].render(scale=2.0).to_pil()   # scale 1.0 = 72 DPI
    image.save(f"page_{i + 1}.png")
pdf.close()
```

Use a higher `scale` (e.g. 3.0–4.0) for crisp output and a lower one for quick previews. `scripts/convert_pdf_to_images.py` wraps this with downscaling for very large pages.

Rendering is a **user-facing feature** ("convert this PDF to images") — it is never a QA step. See [qa.md](qa.md).

## Batch processing with error handling

```python
import glob
import os
from pypdf import PdfReader, PdfWriter


def merge_dir(input_dir: str, output_path: str) -> None:
    writer = PdfWriter()
    for pdf_file in sorted(glob.glob(os.path.join(input_dir, "*.pdf"))):
        try:
            for page in PdfReader(pdf_file).pages:
                writer.add_page(page)
        except Exception as exc:
            print(f"Skipped {pdf_file}: {exc}")
    with open(output_path, "wb") as f:
        writer.write(f)
```
