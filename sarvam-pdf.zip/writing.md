# Writing Guide — content rules for generated documents

Rules for *what the document says*, applied **before drafting any content** —
the layout patterns in SKILL.md make it render correctly; this file makes it
worth reading. AI-drafted documents fail review for predictable reasons
(verbose headings, filler prose, hype next to numbers); these rules are the
countermeasures.

## Contents
- Structure: lead with the point
- Length and redundancy: every section earns its place
- Headings: claims, not labels
- Anti-slop rules (kill the AI tells)
- Numbers and data
- Document-type rules (report, finance, RFP/proposal, memo/letter)

## Structure: lead with the point

- **BLUF (bottom line up front)** in every unit of the document: the document
  opens with its conclusion, each section opens with its finding, each
  paragraph opens with its point. Support follows; it never substitutes.
- An executive summary states **conclusions and recommendations**, not topics
  ("We recommend X because Y and Z" — never "This report examines…").
- One idea per paragraph; a paragraph over ~5 lines is doing two jobs.
- Section order follows the argument, not the research process. Nobody needs
  "Methodology" before the answer unless the audience is technical reviewers.

## Length and redundancy: every section earns its place

Long is not thorough — the most common failure of generated documents is
length without new information.

- **Calibrate length before drafting.** If the user stated a target length,
  hit it. If not, write the shortest version that fully covers the brief —
  length is a function of the brief's actual scope, never of the document
  type. When a draft keeps growing beyond what the content requires,
  consolidate and cut; do not keep writing.
- **Section-overlap test (before drafting):** list the planned sections, each
  with a one-line scope. If two sections' scopes substantially overlap — they
  would repeat the same facts from different angles (a who-is-this-for section
  next to another who-is-this-for section; a problem section next to a
  motivation section) — merge them into one. Every section must add
  information no other section carries.
- **State each fact once**, in the section where it does the most work; later
  mentions reference it ("as above") instead of restating it. If deleting a
  paragraph loses nothing, it was restatement — delete it.
- **Depth goes where the reader needs it**: appendices carry supporting
  detail (full tables, methodology, edge cases); the body carries the
  argument. Moving detail out is how a document gets shorter without losing
  substance.

## Headings: claims, not labels

- Section headings state the section's finding where the document type allows
  it ("Churn concentrates in month 2", not "Churn analysis"). Formal document
  types (RFPs, compliance docs) may require conventional labels — follow the
  convention there.
- **Hard cap 12 words** per heading; trim by cutting qualifiers, not meaning.
- A heading must not restate the section's first sentence.

## Anti-slop rules (kill the AI tells)

- **Banned words** — empty intensifiers; cut or replace with the specific
  fact they gesture at: *leverage, delve, robust, seamless, holistic,
  cutting-edge, state-of-the-art, world-class, best-in-class,
  next-generation, transformative, game-changing, unlock, empower, elevate,
  supercharge, streamline, revolutionize, innovative solutions, synergy*.
- **Banned constructions**:
  - Throat-clearing openers: "In today's fast-paced / rapidly-evolving X…",
    "Now more than ever…", "As we move into…".
  - The contrast crutch: "It's not just X, it's Y" / "X isn't just about Y".
  - Bold-fragment triads: "**Fast** — … **Reliable** — … **Secure** — …".
  - Filler transitions: "It is worth noting that", "It is important to
    understand that" — delete; the sentence survives without them.
- **The competitor test**: if a sentence still works with the subject swapped
  for a competitor's ("We deliver innovative solutions at scale"), it says
  nothing — replace it with a claim only this document could make.
- **No symmetric filler bullets** ("Enhanced performance / Improved
  reliability / Increased efficiency"). Parallel structure is good; parallel
  *emptiness* is the most recognizable slop tell. Each bullet carries a
  distinct, concrete fact.
- **Concrete or cut**: every claim carries a number, a name, or a date.
  "Significant growth" → "+38% YoY". "Several customers" → "11 customers,
  incl. HDFC and Airtel". A page with zero numbers or named entities is
  usually a page with no content.
- Plain language: short sentences, active voice, acronyms expanded on first
  use, "in order to" → "to".

## Numbers and data

- Every figure carries a **unit and scale** (`%`, `₹`, `$`, `k`/`M`/`B`/`Cr`)
  and a **basis/timeframe** (`+32% YoY`, `as of Q2 2026`).
- **Uniform precision and rounding** across the whole document — never mix
  "₹4.2 Cr" and "₹41,800,000", or "12.4%" and "9%" in the same table.
- Source every non-obvious figure (footnote or a source line under the
  table/chart).
- **Tables are for comparable facts, not prose.** Cells are terse fragments
  (aim ≤ ~10 words) — a value, a name, a short phrase — never full sentences
  or paragraphs. If a cell needs a sentence, that content belongs in the body
  and the table keeps only the comparable fact. Units in the header row, not
  repeated in every cell; totals rows actually sum; a table the prose fully
  explains is a table to delete.

## Document-type rules

**Reports / whitepapers**
- Executive summary ≤ 1 page, findings + recommendation, readable standalone.
- Each section's first paragraph is its finding; detail and method follow.
- Recommendations are specific and owned: *who* should do *what* by *when*.
- End with recommendations/next steps — not a summary that repeats the exec
  summary.

**Finance documents (reviews, reports, investor updates)**
- **Neutral register**: no hype adjectives within a sentence of a number
  ("strong growth of 12%" → "12% growth, vs. 9% plan").
- Every variance vs. plan / prior period gets one line of explanation —
  a number without a "because" is an open question, not a report.
- State the accounting basis where it changes interpretation (cash vs.
  accrual, FY vs. CY, audited vs. management numbers).
- Projections are labeled as projections, with their key assumptions.

**RFP responses / proposals**
- **Mirror the RFP's own terminology** — if they say "solution component",
  don't say "module"; evaluators score by mapping your text to their
  requirements.
- **Requirement → response traceability**: every numbered requirement gets an
  explicit response in the same order, ideally with a compliance matrix
  (Requirement | Compliant Y/N/Partial | Where addressed).
- Compliance statements are verifiable — "Compliant: supported since v2.3,
  deployed at 4 clients" — never bare capability claims the evaluator must
  take on faith.
- Win themes appear in the executive summary and are *evidenced* in the body,
  not repeated as slogans.

**Memos / letters**
- The decision requested or key message appears in the **first 3 lines**.
- One page unless impossible; attachments carry the detail.
- Letters: one purpose per letter; the reader knows what to do after one read.
