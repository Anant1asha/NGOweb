# Layout QA for generated PDFs

Every generated PDF runs **deterministic geometric QA** before delivery. The
gate splits its output into two categories:

- **FAIL** (blocking): real defects that make the PDF unreadable — text
  collisions, text overflow past the page, cross-column table bleed. Only
  these cause exit 1. Fix these, rebuild, re-run once.
- **WARN** (advisory): cosmetic drift — centring, spacing, valign, table frame
  fill, page-split slivers. These never block delivery. Ship with WARNs. Do
  NOT patch the build script to clear them.

Run the gate once. Ship if exit 0 (WARNs are fine). If exit 1, fix only the
FAIL messages, rebuild, re-run once. One fix round max.

## No visual QA — do not render pages to images

Do **NOT** render PDF pages to images as a QA step: no PNG previews, no
image-description / vision tools, no pixel analysis. This is a hard rule, not
a missing step. The geometric checks read exact coordinates from the PDF
itself and are strictly more reliable than looking at a render — in
production the render-and-describe path breaks on artifact plumbing, burns
tool rounds, and vision models hallucinate page content. (Rendering pages to
images stays available as a *user-facing feature* — "convert this PDF to
images" — see SKILL.md; it is never a QA step.) When the three checks pass,
deliver.

## Contents

- The gate: `run_qa.py` (one invocation)
- What each check asserts
- Required workflow (one build → one gate → ship)
- Tuning the content box and tolerance

## The gate: `run_qa.py` (one invocation)

```bash
python scripts/run_qa.py out.pdf
```

One command runs everything — alignment (`check_layout.py`), whitespace
(`check_spacing.py`), and tables (`check_tables.py`) — and prints one
consolidated report. Exit `0` = deliver now (may carry cosmetic WARNs);
`1` = fix only the FAIL messages, rebuild, re-run once; `2` = unreadable file.

Writing quality is **not** machine-checked: apply [writing.md](writing.md)
while drafting (concise claim headings, anti-slop rules, numbers with
units/basis), and re-read your section headings once against its rules before
building.

**The FAIL messages are self-sufficient**: each names the exact page, element,
offset, and the fix to make in the build script. Fix from the message. Do
**not** open the check scripts' source to interpret a failure — the message is
the whole contract. **WARN messages are cosmetic — do not fix them.**

## What each check asserts

### Alignment — `check_layout.py`

```bash
python scripts/check_layout.py out.pdf
```

Extracts bounding boxes with `pdfplumber`, classifies elements (table-aware),
and asserts, per page. Each check is categorized:

- **WARN**: centred text off-centre, decorative divider off-centre, divider vs
  its text block, title vs subtitle centre, text touching (but not overlapping)
  images/tables/dividers.
- **FAIL**: text collisions (two lines overlapping), text overflowing the
  content box horizontally, text overlapping an image or table.

The content box (left/right text margins) is **inferred from the layout**, so
the script works on any generator. Example WARN (does not block):

```
page 2: centred text off-centre by +8.1pt: "Executive Summary"
LAYOUT PASSED with 1 cosmetic warning(s) at tol=6.0pt.
```

### Whitespace / vertical rhythm — `check_spacing.py` (all advisory)

```bash
python scripts/check_spacing.py out.pdf
```

Alignment proves things line up; this proves the page is *filled well*. It
catches the whitespace defects a quick glance waves through, per page:

- a heading stranded at the bottom of a page with its body overflowing to the
  next (orphan heading);
- a heading with only **1–2 lines of its body** before the page break (a sliver
  start);
- a page opening with 1–2 **widowed lines** from the previous section before a
  new heading;
- a non-last page left largely empty at the bottom (under-filled);
- content starting too far below the top margin (a big top gap);
- an oversized gap between two elements (before/after a table, header-to-body,
  heading-to-body).

**All spacing issues are WARN — they never block delivery.** The script
always exits 0. These are informational only; do not patch the build script
to clear them. If you want to improve spacing, the fixes are:
- Orphan heading → `keepWithNext=1`, `KeepTogether([...])`, or `PageBreak()`.
- Under-filled page → pull later content up, or split content more evenly.
- Big top / mid gaps → reduce `Spacer` sizes and `spaceBefore` / `spaceAfter`.

### Table integrity — `check_tables.py`

```bash
python scripts/check_tables.py out.pdf
```

Tables are the most common source of visible programmatic-PDF defects. Per data
table, per page, each check is categorized:

- **WARN**: does not fill the content frame (column fractions don't sum to
  1.0), column widths don't tile the table, row vertical misalignment,
  page-split slivers / missing repeated header.
- **FAIL**: cross-column text bleed (a word spills past its cell edge into the
  next column — unreadable).

Only bleed blocks delivery. Frame fill, valign, and split issues are advisory.

It defends against the classic pdfplumber traps: `Column`/`Row` objects expose
`.bbox` (never `.x0`); canvas-drawn rectangles that look like full-page tables
are skipped; two adjacent tables merged into one detection skip the column-sum
check rather than false-alarm. Exits `0` when the PDF has no tables. Example
WARN (does not block):

```
page 2 table 1: does not fill the content frame: width=453.8 vs frame 493.2
        (left_gap=+19.7 right_gap=+19.7) — column-width fractions likely do not sum to 1.0
TABLE PASSED with 1 cosmetic warning(s) (1 table(s)).
```

**If you want to clear a table WARN** (optional — not required for delivery):
make the column-width fractions sum to exactly `1.0`:

```python
col_widths = [0.20 * doc.width, 0.42 * doc.width, 0.22 * doc.width, 0.16 * doc.width]
```

The content frame is inferred from the page (the leftmost body text / full-width
table defines the margin, assumed symmetric). For asymmetric margins pass them
explicitly: `--content-left PT --content-right PT`.

## Required workflow (one build → one gate → ship)

Build the PDF, run the gate once, ship. The gate exits 0 unless there are
blocking FAILs (collisions, overflow, table bleed). WARNs (centring, spacing,
valign, frame fill) never block — ship with them.

```
Deliver-a-PDF checklist:
- [ ] 1. Build the PDF with reportlab (Platypus flowables, patterns from SKILL.md)
- [ ] 2. Gate: python scripts/run_qa.py out.pdf
- [ ] 3. If exit 0: present_output(artifact_id) — ship now. WARNs are fine.
       If exit 1: fix ONLY the FAIL messages, rebuild, re-run once.
       Do NOT fix WARNs. One fix round max.
- [ ] 4. present_output(artifact_id)
```

Do not iterate on WARNs. The gate is a safety net against broken layout, not a
design tool. If it still fails after one fix round, deliver with a note.

## Tuning the content box and tolerance

- **Tolerance.** Default `--tol 6.0` points (~0.08 in). Lenient by design;
  tighten only if you need to catch subtle alignment drift.
- **Content box.** If `check_layout.py` prints a `content_center` /
  `content_width` that does not match your page margins (rare — happens when a
  page has no wide element to infer from), pass the true margins explicitly:

  ```bash
  python scripts/check_layout.py out.pdf --content-left 50.4 --content-right 544.9
  ```

  For a LETTER/A4 page with 1-inch margins the content centre is the page
  centre; `doc.width` in your reportlab script is exactly the content width.
