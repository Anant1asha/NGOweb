# Product Build Baseline — Phase 0 → Phase 1

**Organisation:** Annanth Aasha Foundation  
**Product:** Aasha Learning + Impact Ecosystem  
**Document type:** Build-governance baseline  
**Version:** 1.0  
**Status:** Phase 0 frozen; Phase 1 planning only

## 1. Relationship to the Brand Book

The Brand Book / Story is the narrative and visual reference. This document is the engineering-facing interpretation of the frozen product decisions.

Do not convert brand storytelling into technical requirements unless another build document explicitly does so.

## 2. Frozen architecture principles

### 2.1 Learning authority

The current learning/build truth is:

**AIOS + HIL-approved Learning Catalogue.**

The catalogue is a living product dataset, not a hard-coded frontend list.

### 2.2 Website authority boundary

The website is an interface and public experience.

It may:
- display published catalogue metadata;
- launch learning modules;
- display approved public evidence;
- communicate the ecosystem;
- provide authorised operational interfaces.

It may not:
- invent chapters;
- promote unapproved learning content;
- become the authoritative content store merely because a page contains content;
- determine whether a learning module is educationally approved.

### 2.3 AI memory boundary

Agentic memory may retain:
- validated patterns;
- previous decisions;
- transformation conventions;
- known failure modes;
- reusable workflow knowledge.

Memory cannot:
- approve content;
- publish content;
- overwrite canonical records;
- silently redefine requirements.

### 2.4 HIL boundary

Human review is mandatory for material changes to:
- learning content;
- assessment correctness;
- publication state;
- child-facing safety;
- public evidence;
- impact claims;
- privacy/security policy;
- financially sensitive claims.

## 3. Product layers

### Layer A — Public experience

Marketing/editorial website plus public learning catalogue and evidence surfaces.

### Layer B — Web application

Authorised experiences for teachers, facilitators, programme staff, reviewers and other approved roles.

### Layer C — Learning runtime

Self-contained learning modules capable of offline operation.

### Layer D — Operations / content factory

AI-assisted ingestion, transformation, validation, HIL approval and publishing workflow.

## 4. Current implementation boundary

The existing learning prototypes demonstrate the learning-engine direction.

They are not evidence that the new platform architecture has already been implemented.

Phase 1 architecture planning must define how existing approved assets can be incorporated without treating prototypes as canonical catalogue data.

## 5. Failure principle

If any optional infrastructure fails:
- approved learning should continue;
- canonical data should remain intact;
- jobs should be retryable;
- humans should be able to intervene;
- no AI memory write should become an automatic product mutation.

## 6. Build decision rule

For every proposed component ask:

1. Is it required for the current phase?
2. Is it already available?
3. Is there a simpler solution?
4. Does it preserve offline learning?
5. Does it preserve catalogue authority?
6. Does it preserve child privacy?
7. Can it be replaced later?
8. What is the rollback path?

If unanswered, defer to HIL/product-owner review.



## FINALIZED PHASE-1 TECHNOLOGY + ROLE BASELINE

This stack is the implementation baseline for Antigravity AIOS. It is deliberately modular and cost-reversible.

| Layer / Capability | Finalized technology/resource | Role |
|---|---|---|
| Public website | **Vercel** | Production public website, catalogue presentation and public ecosystem experience |
| Web application | **Vercel** | Authenticated/authorised web app and operational interfaces |
| Canonical application database | **Supabase PostgreSQL** | System of record for application data, permissions, progress and audit data |
| Backend/API/workers | **Railway** | Backend services, workers and scheduled/background processing where genuinely required |
| DNS / edge | **Cloudflare** | DNS and edge services |
| Object/media storage | **Cloudflare R2** | Application-controlled object storage for media/evidence/assets when required; accessed through a storage abstraction |
| Source + working + backup repository | **Personal Google Drive (~5 TB)** | Current learning resources, current assessment resources, source documents, working files, archives and backup copies; NOT the application system of record |
| Workflow orchestration | **Hosted n8n** | Workflow automation/orchestration across content, operations and integrations |
| Agentic memory | **Memo0 AI** | Reusable workflow knowledge, validated patterns, transformation conventions and known failure modes; NOT canonical truth |
| Primary AI/content assistance | **Gemini 2 Pro plan** | Content transformation, reasoning assistance, OCR cleanup, assessment assistance and validation assistance where appropriate |
| OCR/document processing adapter | **Telegram Bot API** | Optional low-cost OCR/document/image processing route; adapter only, not system of record |
| Human-in-the-loop build/operations | **Antigravity AIOS + HIL** | Build orchestration, implementation execution, review gates and controlled operational workflows |
| General AI working resource | **ChatGPT Go** | Product/engineering analysis, documentation, review and assistance |
| Open-source/model cache | **Hugging Face + suitable open-source/created models** | Replaceable processing/model capability; approved assets may be cached in Google Drive |
| Existing learning runtime | **Self-contained HTML/CSS/JS learning modules** | Offline-first child learning runtime independent of cloud services |
| Reserved future AI capacity | **Claude grant** | Future/conditional capacity; Phase-1 architecture must not depend on spending it |

### Stack invariants

1. **Supabase is the canonical application system of record.**
2. **Google Drive is source/working/archive/backup infrastructure, not the live application database.**
3. **Cloudflare R2 is object storage, not the application database.**
4. **Telegram is an adapter/utility, not a child-learning runtime or permanent evidence store.**
5. **Memo0 is agentic memory, not authority.**
6. **AI providers are replaceable processing capabilities, not runtime dependencies for children.**
7. **Existing self-contained learning HTML must continue to work without Vercel, Supabase, Railway, Cloudflare, Telegram, Memo0 or an AI provider.**
8. **No second primary database is introduced merely for convenience.**
9. **Open-source game templates must be licence-compatible and must sit behind an Aasha adapter.**
10. **Every external service must have a documented fallback or migration boundary where practical.**

## FINALIZED ROLE / RESPONSIBILITY MODEL

| Role | Responsibility | Must not do |
|---|---|---|
| **Product Owner / Foundation HIL authority** | Final product decisions, content/assessment approval, safety, privacy, evidence and publication gates | Delegate final authority to AI/memory |
| **Antigravity AIOS** | Execute the approved build plan, coordinate coding tasks, maintain implementation consistency and produce build artifacts | Invent product requirements or silently override frozen decisions |
| **Frontend/App Engineering** | Vercel application, UI, catalogue, dashboards, module delivery integration | Make the website the content authority |
| **Backend/Data Engineering** | Supabase schema/RLS, APIs, progress, assessment events, audit and Railway services | Create unnecessary microservices or a second system of record |
| **Content/Assessment Pipeline** | Source extraction, learning transformation, question generation/normalisation, validation and module assembly | Publish unapproved AI-generated content |
| **Game Template Engineering** | Evaluate, adapt and maintain reusable open-source game templates and Aasha adapters | Build a bespoke game for every chapter |
| **QA/Security/Accessibility** | Automated tests, runtime validation, licence/dependency review, security, accessibility and offline tests | Treat visual attractiveness as acceptance |
| **Workflow/Ops** | n8n workflows, Telegram adapter, Drive/R2 movement, scheduled processing and operational alerts | Put canonical truth into workflow tools |
| **Memo0 / AI utilities** | Retain reusable patterns and assist processing | Approve, publish or redefine canonical requirements |

The roles are organisational/technical boundaries, not necessarily separate people. One person may hold multiple roles during the pilot.
