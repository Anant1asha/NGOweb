# UI/UX Product Build Specification — Aasha
## Version 2.1

**Status:** Phase 1 planning only

## 1. Scope

This is an implementation-facing UI/UX specification.

The Brand Book remains the authority for the deeper brand story, visual language and narrative intent.

## 2. Product experience separation

### Public experience

Editorial, human, evidence-led and calm.

### Learning experience

Focused, interactive, playful where useful, low-distraction and child-safe.

### Operations experience

Dense enough for work, but clear and role-specific.

Do not make every surface look like a dashboard.

## 3. Design system structure

Create reusable tokens for:
- typography;
- spacing;
- radii;
- borders;
- elevation;
- semantic states;
- interaction states;
- responsive breakpoints.

Avoid hard-coded visual values scattered through components.

## 4. Component families

Build reusable components for:
- Header;
- Footer;
- Navigation;
- Page hero;
- Section;
- CTA;
- Catalogue card;
- Module metadata;
- Timeline;
- Evidence item;
- Impact metric;
- Status badge;
- Empty state;
- Error state;
- Modal/dialog;
- Form;
- Table/list;
- Progress indicator.

Learning-module UI remains independently implemented according to its runtime constraints.

## 5. Responsive behaviour

Mobile-first.

Required:
- no horizontal scrolling for normal pages;
- touch-safe controls;
- readable text;
- collapsible navigation;
- tables become cards/scrollable regions appropriately;
- images scale without layout breakage.

## 6. Catalogue UI

Do not hard-code:
- number of subjects;
- number of classes;
- number of chapters;
- specific chapter positions.

Render from catalogue data.

If zero modules match a filter:
show an honest empty state.

## 7. Learning UI

The child should normally see:
- current progress;
- one clear primary action;
- the current learning task;
- immediate feedback;
- optional language help;
- safe retry.

Avoid presenting multiple unrelated actions at once.

## 8. Language support UI

Word-level Hindi help must:
- be discoverable;
- not overwhelm English text;
- work on touch;
- remain readable;
- avoid excessive popups.

## 9. Evidence UI

Every evidence object should communicate its state:
- Draft;
- Submitted;
- Under review;
- Verified;
- Rejected;
- Published.

Do not use green “success” styling for merely submitted content.

## 10. Impact UI

Impact displays should answer:
- what happened?
- when?
- where at an appropriate aggregate level?
- how was it measured?
- what evidence supports it?
- what is still uncertain?

Prefer evidence trails and timelines over vanity-number walls.

## 11. Cohort UI

Use journey/timeline patterns.

Avoid:
- public rankings;
- competitive child tables;
- exposing individual child information to unauthorised users.

## 12. Forms

All forms require:
- explicit labels;
- validation;
- useful error messages;
- keyboard access;
- submit progress;
- duplicate-submit protection;
- success confirmation.

## 13. Accessibility

Target WCAG-aligned implementation:
- semantic HTML;
- keyboard access;
- focus states;
- contrast;
- reduced motion;
- alt text;
- form labels;
- screen-reader-friendly status changes.

Canvas visuals must have equivalent text explanations.

## 14. Performance

Public site:
- optimise images;
- lazy-load non-critical media;
- avoid unnecessary client-side JavaScript.

Learning runtime:
- preserve self-contained/offline constraints;
- no external font dependency;
- no external analytics;
- no required network request.

## 15. Content states

Every content-driven page needs:
- loading;
- loaded;
- empty;
- error;
- unpublished/not available;
- stale/cached where relevant.

## 16. Truthful UI

The interface must never make:
- a future feature look live;
- unverified evidence look verified;
- an illustrative image look like field evidence;
- a prototype look like production capability;
- a planned metric look like a measured result.

## 17. Brand-to-product rule

The UI should carry the spirit of the Brand Book without copying the Brand Book into product screens.

Use narrative context where useful; use functional UI where action is required.


## 18. Reusable Game-Template UI Rules

A game is an embedded learning interaction, not a separate mini-product.

### Required

- Aasha shell remains visible/recognisable.
- Learning objective remains obvious.
- Instructions remain concise and age-appropriate.
- Controls remain accessible.
- Feedback remains understandable.
- Game state maps to the canonical task.
- Aasha gamification remains consistent across games.
- No advertising, social feed or unrelated external links.
- No casino-like reward presentation.
- No visual treatment that makes the game more important than learning.

### Open-source theme adaptation

When adapting an open-source game:
- preserve the useful mechanic;
- customise the presentation for Aasha;
- remove unrelated branding;
- remove uncontrolled tracking/analytics;
- remove unnecessary external navigation;
- ensure the visual language works across Classes 1–10;
- retain more mature presentation for Classes 9–10;
- do not force a childish appearance onto older learners.

### Pedagogical rule

Use game interaction only when it improves understanding, practice, retrieval, reasoning, fluency or feedback. Otherwise use the simpler assessment renderer.

Aasha does not create a bespoke visual learning/game experience for every chapter.



## FINALIZED PHASE-1 TECHNOLOGY + ROLE BASELINE

This stack is the implementation baseline for Antigravity AIOS. It is deliberately modular and cost-reversible.

| Layer / Capability | Finalized technology/resource | Role |
|---|---|---|
| Public website | **Vercel** | Production public website, catalogue presentation and public ecosystem experience |
| Web application | **Vercel** | Authenticated/authorised web app and operational interfaces |
| Canonical application database | **Supabase PostgreSQL** | System of record for application data, permissions, progress and audit data |
| Backend/API/workers | **Railway** | Backend services, workers and scheduled/background processing where genuinely required |
| DNS / edge | **Cloudflare** | DNS and edge services |
| Object/media storage | **Cloudflare R2** | Application-controlled object storage for media/evidence/assets when required; accessed through a storage abstraction |
| Source + working + backup repository | **Personal Google Drive (~5 TB)** | Current learning resources, current assessment resources, source documents, working files, archives and backup copies; NOT the application system of record |
| Workflow orchestration | **Hosted n8n** | Workflow automation/orchestration across content, operations and integrations |
| Agentic memory | **Memo0 AI** | Reusable workflow knowledge, validated patterns, transformation conventions and known failure modes; NOT canonical truth |
| Primary AI/content assistance | **Gemini 2 Pro plan** | Content transformation, reasoning assistance, OCR cleanup, assessment assistance and validation assistance where appropriate |
| OCR/document processing adapter | **Telegram Bot API** | Optional low-cost OCR/document/image processing route; adapter only, not system of record |
| Human-in-the-loop build/operations | **Antigravity AIOS + HIL** | Build orchestration, implementation execution, review gates and controlled operational workflows |
| General AI working resource | **ChatGPT Go** | Product/engineering analysis, documentation, review and assistance |
| Open-source/model cache | **Hugging Face + suitable open-source/created models** | Replaceable processing/model capability; approved assets may be cached in Google Drive |
| Existing learning runtime | **Self-contained HTML/CSS/JS learning modules** | Offline-first child learning runtime independent of cloud services |
| Reserved future AI capacity | **Claude grant** | Future/conditional capacity; Phase-1 architecture must not depend on spending it |

### Stack invariants

1. **Supabase is the canonical application system of record.**
2. **Google Drive is source/working/archive/backup infrastructure, not the live application database.**
3. **Cloudflare R2 is object storage, not the application database.**
4. **Telegram is an adapter/utility, not a child-learning runtime or permanent evidence store.**
5. **Memo0 is agentic memory, not authority.**
6. **AI providers are replaceable processing capabilities, not runtime dependencies for children.**
7. **Existing self-contained learning HTML must continue to work without Vercel, Supabase, Railway, Cloudflare, Telegram, Memo0 or an AI provider.**
8. **No second primary database is introduced merely for convenience.**
9. **Open-source game templates must be licence-compatible and must sit behind an Aasha adapter.**
10. **Every external service must have a documented fallback or migration boundary where practical.**

## FINALIZED ROLE / RESPONSIBILITY MODEL

| Role | Responsibility | Must not do |
|---|---|---|
| **Product Owner / Foundation HIL authority** | Final product decisions, content/assessment approval, safety, privacy, evidence and publication gates | Delegate final authority to AI/memory |
| **Antigravity AIOS** | Execute the approved build plan, coordinate coding tasks, maintain implementation consistency and produce build artifacts | Invent product requirements or silently override frozen decisions |
| **Frontend/App Engineering** | Vercel application, UI, catalogue, dashboards, module delivery integration | Make the website the content authority |
| **Backend/Data Engineering** | Supabase schema/RLS, APIs, progress, assessment events, audit and Railway services | Create unnecessary microservices or a second system of record |
| **Content/Assessment Pipeline** | Source extraction, learning transformation, question generation/normalisation, validation and module assembly | Publish unapproved AI-generated content |
| **Game Template Engineering** | Evaluate, adapt and maintain reusable open-source game templates and Aasha adapters | Build a bespoke game for every chapter |
| **QA/Security/Accessibility** | Automated tests, runtime validation, licence/dependency review, security, accessibility and offline tests | Treat visual attractiveness as acceptance |
| **Workflow/Ops** | n8n workflows, Telegram adapter, Drive/R2 movement, scheduled processing and operational alerts | Put canonical truth into workflow tools |
| **Memo0 / AI utilities** | Retain reusable patterns and assist processing | Approve, publish or redefine canonical requirements |

The roles are organisational/technical boundaries, not necessarily separate people. One person may hold multiple roles during the pilot.
