# Annanth Aasha — Product Build Documentation Pack

## Purpose

This pack is the **product-build specification** for the Annanth Aasha website + web application and its learning-platform architecture.

The separate Annanth Aasha **Brand Book / Story / Constitution** remains the authority for brand voice, visual narrative, public storytelling, positioning and frozen organisational principles. These documents intentionally do **not** duplicate that material.

These files translate the approved product direction into build-ready requirements for an AI coding agent.

## Mandatory project status

**Phase 0: FROZEN.**  
**Phase 1: Architecture planning only.**  
**Implementation: NOT STARTED.**

No code should be generated merely because these documents describe a feature. A feature is implemented only when its phase is opened and its acceptance gate is approved.

## Non-negotiable authority rules

### Learning/content authority

**AIOS + HIL-approved Learning Catalogue = current learning/build truth.**

Therefore:

- PRD/TRD do **not** define a maximum catalogue size.
- The website does **not** define or own the catalogue.
- AI/agent memory does **not** define canonical product truth.
- The learning catalogue must be dynamic and data-driven.
- A newly HIL-approved learning module must be publishable without redesigning or hard-coding the website.
- Older prototypes and example chapters are implementation references, not automatic catalogue authority.

### Separation of concerns

- Brand Book / Story → brand and narrative authority.
- Phase-0 Constitution → frozen product/architecture governance authority.
- PRD → what the product must accomplish.
- TRD → how the product should be architected technically.
- App Flow → how users move through the product.
- UI/UX → how the product behaves and is presented.
- Backend Schema → how canonical application data is structured.
- Implementation Plan → exact build sequence and acceptance gates.

## Reading order for an AI coding agent

1. Brand Book / Story / Phase-0 Constitution
2. This README
3. PRD
4. TRD
5. App Flow
6. UI/UX
7. Backend Schema
8. Implementation Plan

If any ambiguity remains, do not guess. Record the ambiguity and stop at the relevant HIL/product-owner gate.


## Critical v3.1 architecture correction

**Aasha does not build a bespoke visual-learning experience or game for every chapter.**

Aasha maintains a reusable library of suitable interactive game templates, preferably adapted from appropriately licensed open-source projects. Chapter-specific educational content is represented independently as versioned assessment tasks. The assessment engine injects those tasks into an appropriate standard renderer or reusable game template.

Therefore:

**Question/task ≠ game template ≠ gamification.**

The preferred scaling model is:

**one reusable game shell × many chapter datasets**

rather than:

**one bespoke game × one chapter**.

Game selection is pedagogical, not decorative. Use a game only where the interaction improves understanding, practice, retrieval, reasoning, fluency or feedback.

## Finalized technology baseline

- **Vercel** → public website + web application
- **Supabase PostgreSQL** → canonical application database/system of record
- **Railway** → backend/API/workers/background jobs where required
- **Cloudflare** → DNS/edge
- **Cloudflare R2** → application-controlled object/media storage where required
- **Personal Google Drive (~5 TB)** → current learning resources, current assessment resources, source/working files, archives and backups; never the application system of record
- **Hosted n8n** → workflow orchestration
- **Memo0 AI** → agentic memory, never canonical authority
- **Gemini 2 Pro** → primary available AI assistance for content/assessment/OCR/validation workflows
- **Telegram Bot API** → optional OCR/document-processing adapter
- **Antigravity AIOS + HIL** → controlled implementation/build/review workflow
- **ChatGPT Go** → general product/engineering/documentation assistance
- **Hugging Face/open-source models** → replaceable model capability and approved cached resources
- **Existing self-contained HTML/CSS/JS modules** → independent offline learning runtime
- **Claude grant** → reserved future capacity, not a Phase-1 dependency

## Role boundary

Antigravity AIOS executes the approved implementation plan. It does not redefine the product. Product-owner/HIL decisions, approved versioned source material, the Learning Catalogue and explicit architecture decisions remain authoritative.
