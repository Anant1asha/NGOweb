# Product Requirements Document — Aasha
## Version 3.1 — Product Build Baseline

**Status:** Phase 0 frozen / Phase 1 architecture planning  
**Implementation:** Not started

## 1. Product definition

Aasha is a child-centred learning and impact ecosystem that makes prescribed school-book learning more understandable, interactive and meaningful, while creating a pathway from learning to responsible real-world action.

The product does not replace the school, teacher, curriculum or textbook.

The learning experience should move a child through:

**Understand → Explore → Practise → Learn from mistakes → Demonstrate understanding → Grow**

The wider ecosystem can extend this into:

**Learn → Act → Evidence → Reflect → Grow → Contribute → Opportunity**

## 2. Target audience

### Platform audience

Classes **1–10**.

The current catalogue can cover only a subset at any moment. This is not a product limitation.

The UI and content presentation must adapt by age/stage rather than forcing one interaction model across Classes 1–10.

### Primary learner

Children who may use:
- shared Android devices;
- low-end hardware;
- intermittent/no internet;
- English as an academic language with Hindi as a familiar understanding bridge;
- independent or facilitator-supported learning.

### Other users

- teachers/facilitators;
- parents/guardians;
- programme staff;
- reviewers/verifiers;
- volunteers;
- authorised administrators;
- supporters/sponsors.

## 3. Core product hypothesis

If prescribed school-book content is transformed into an interactive, concept-focused and language-accessible experience, children can develop stronger understanding and confidence than from passive reading alone.

The primary outcome is **understanding**, not screen time, downloads, coins or lesson completion.

## 4. Learning model

A learning module may contain:

1. introduction;
2. simple explanation;
3. visual representation;
4. interactive discovery;
5. worked example;
6. guided practice;
7. independent practice;
8. misconception feedback;
9. concept check;
10. progress/milestone.

The exact structure is content-dependent; the architecture must not require every chapter to contain the same number of steps.

## 5. Language Learning Engine

English remains the academic learning language.

Hindi is an understanding bridge.

Requirements:
- preserve English exposure;
- provide word-level or contextual Hindi help;
- support difficult academic vocabulary;
- support inline connective-word cues where configured;
- avoid converting lessons into Hinglish;
- remain usable on small screens;
- work offline inside approved learning modules.

## 6. Assessment + Reusable Game Architecture

Assessment is a **generic educational task capability**, not a closed list of quiz widgets.

Aasha must be able to represent appropriate questions and problems from the approved school-book chapter, including as applicable:
- MCQ;
- true/false;
- fill-in-the-blank;
- short answer;
- numeric answer;
- worked example;
- guided solve;
- step-by-step mathematics/numeric problems;
- equations and multi-step problems;
- word problems;
- matching;
- ordering/sequencing;
- classification;
- diagram/visual questions;
- graph/table interpretation;
- rapid-fire;
- memory match;
- worksheet-style assessment;
- other chapter-appropriate formats.

The question bank must be:
- versioned;
- source-linked;
- concept-linked;
- validated;
- HIL-approved before production publication.

### Question is not the game

A **question/task** contains educational meaning, answer logic, explanation and provenance.

A **game template** is a reusable interaction/presentation shell.

Aasha must NOT build a bespoke visual learning experience or game for every chapter.

Instead:

**Chapter content → versioned assessment task → standard renderer OR reusable game template**

### Reusable open-source game-template library

Aasha maintains a reusable library of suitable interactive game templates, preferably adapted from appropriately licensed open-source projects.

Each template should:
- have verified licensing and attribution requirements;
- preserve source/revision metadata;
- be adapted to Aasha's visual/interaction language;
- use an Aasha adapter;
- accept generic task data;
- return canonical assessment results;
- work offline where the learning module requires offline operation;
- remove uncontrolled external dependencies;
- pass mobile, accessibility, security and runtime validation.

One game may support many chapters, subjects and question types. Only the chapter-specific task/data/evaluation configuration changes.

### Pedagogical selection rule

Game selection is pedagogical rather than decorative.

Use a game only when its interaction improves:
- understanding;
- practice;
- retrieval;
- reasoning;
- fluency;
- feedback;
- conceptual exploration.

If a normal assessment renderer is pedagogically better, use it.

Do not create a game or simulation merely to satisfy a chapter quota.

### Assessment evaluation

The assessment engine, not the game, owns correctness.

For mathematics/numeric tasks, support deterministic evaluation for:
- exact numeric answers;
- accepted equivalent forms;
- fractions/decimals;
- units;
- justified tolerance;
- ordered solution steps;
- intermediate-step validation;
- method/approach validation where specified.

Where deterministic evaluation is possible, AI must not be the final scoring authority.

## 7. Gamification

The existing learning direction includes:
- XP;
- levels;
- badges;
- streaks;
- speed bonuses;
- chapter progress;
- celebrations;
- virtual Aasha Coins;
- educational utility items/themes.

Gamification must reinforce learning rather than exploit attention.

The game template does not own the Aasha reward economy. A canonical learning/assessment event is emitted first; the gamification layer then applies approved XP, Coins, level, badge, streak, speed-bonus, progress and celebration rules.

Aasha Coins must not be represented as:
- wages;
- cash;
- investment;
- cryptocurrency;
- guaranteed monetary return;
- payment for studying.

## 8. Learning catalogue requirements

### Authority

**AIOS + HIL-approved Learning Catalogue = current learning/build truth.**

### Functional requirements

The catalogue must support:
- arbitrary number of modules;
- class/grade;
- subject;
- chapter/module title;
- description;
- curriculum/source;
- version/edition;
- publication state;
- module asset reference;
- concept/step metadata where approved;
- language support metadata;
- last updated;
- HIL approval state.

### Critical acceptance requirement

A new approved module can be added by changing approved catalogue data/content assets without changing a hard-coded chapter array in the website.

## 9. Public website

The website should communicate:
- why learning comes first;
- how Aasha works;
- how learning connects to the wider ecosystem;
- what is actually happening;
- what evidence exists;
- how people can participate.

It should not become a generic donation website or a generic edtech dashboard.

## 10. Ecosystem features

### Eco Seva

A meaningful-care pathway involving activities such as planting/caring for nature where the programme actually supports them.

The system should support recurring activity/evidence records rather than treating every check-in as a new programme.

### Jal Seva

The child-facing activity is specifically the care of birds/animals through providing/filling water, including bird water pots where applicable.

Flow:
**notice → provide/fill water → check/refill → observe → continue**

Do not silently broaden Jal Seva into unrelated water-conservation claims.

### Aasha Economy

The intended behavioural pathway is:
**effort → earning → saving → patience → choice → contribution**

Full economy/store capabilities are phased features and must not be implied as currently live unless implemented and approved.

### Cohorts

Cohorts connect:
- participants;
- learning;
- activities;
- evidence;
- milestones;
- authorised supporters;
- aggregate outcomes.

## 11. Evidence and impact

Public claims must be based on appropriate records.

Evidence lifecycle:
**submitted → reviewed/verified → publishable**

Unverified activity is not public impact proof.

Impact reporting should distinguish:
- activity;
- output;
- learning outcome;
- behavioural outcome;
- verified evidence;
- interpretation/limitations.

## 12. Safety

The product must not introduce:
- uncontrolled child-facing open internet;
- child social networking;
- public child profiles;
- child-to-child messaging;
- advertising inside learning;
- manipulative reward mechanics;
- unreviewed AI-generated educational content.

## 13. Non-goals for the first platform build

Do not build by default:
- generic “Ask Anything” child chatbot;
- social feed;
- public leaderboard;
- full school ERP;
- unnecessary native apps;
- complex microservice infrastructure;
- real-money child economy;
- unverified impact automation.

## 14. Product acceptance

A feature is acceptable only if it:
- improves the learner journey or ecosystem evidence;
- respects the frozen authority chain;
- preserves offline learning where required;
- protects children;
- is testable;
- is versionable;
- has an explicit owner and acceptance criteria.



## FINALIZED PHASE-1 TECHNOLOGY + ROLE BASELINE

This stack is the implementation baseline for Antigravity AIOS. It is deliberately modular and cost-reversible.

| Layer / Capability | Finalized technology/resource | Role |
|---|---|---|
| Public website | **Vercel** | Production public website, catalogue presentation and public ecosystem experience |
| Web application | **Vercel** | Authenticated/authorised web app and operational interfaces |
| Canonical application database | **Supabase PostgreSQL** | System of record for application data, permissions, progress and audit data |
| Backend/API/workers | **Railway** | Backend services, workers and scheduled/background processing where genuinely required |
| DNS / edge | **Cloudflare** | DNS and edge services |
| Object/media storage | **Cloudflare R2** | Application-controlled object storage for media/evidence/assets when required; accessed through a storage abstraction |
| Source + working + backup repository | **Personal Google Drive (~5 TB)** | Current learning resources, current assessment resources, source documents, working files, archives and backup copies; NOT the application system of record |
| Workflow orchestration | **Hosted n8n** | Workflow automation/orchestration across content, operations and integrations |
| Agentic memory | **Memo0 AI** | Reusable workflow knowledge, validated patterns, transformation conventions and known failure modes; NOT canonical truth |
| Primary AI/content assistance | **Gemini 2 Pro plan** | Content transformation, reasoning assistance, OCR cleanup, assessment assistance and validation assistance where appropriate |
| OCR/document processing adapter | **Telegram Bot API** | Optional low-cost OCR/document/image processing route; adapter only, not system of record |
| Human-in-the-loop build/operations | **Antigravity AIOS + HIL** | Build orchestration, implementation execution, review gates and controlled operational workflows |
| General AI working resource | **ChatGPT Go** | Product/engineering analysis, documentation, review and assistance |
| Open-source/model cache | **Hugging Face + suitable open-source/created models** | Replaceable processing/model capability; approved assets may be cached in Google Drive |
| Existing learning runtime | **Self-contained HTML/CSS/JS learning modules** | Offline-first child learning runtime independent of cloud services |
| Reserved future AI capacity | **Claude grant** | Future/conditional capacity; Phase-1 architecture must not depend on spending it |

### Stack invariants

1. **Supabase is the canonical application system of record.**
2. **Google Drive is source/working/archive/backup infrastructure, not the live application database.**
3. **Cloudflare R2 is object storage, not the application database.**
4. **Telegram is an adapter/utility, not a child-learning runtime or permanent evidence store.**
5. **Memo0 is agentic memory, not authority.**
6. **AI providers are replaceable processing capabilities, not runtime dependencies for children.**
7. **Existing self-contained learning HTML must continue to work without Vercel, Supabase, Railway, Cloudflare, Telegram, Memo0 or an AI provider.**
8. **No second primary database is introduced merely for convenience.**
9. **Open-source game templates must be licence-compatible and must sit behind an Aasha adapter.**
10. **Every external service must have a documented fallback or migration boundary where practical.**

## FINALIZED ROLE / RESPONSIBILITY MODEL

| Role | Responsibility | Must not do |
|---|---|---|
| **Product Owner / Foundation HIL authority** | Final product decisions, content/assessment approval, safety, privacy, evidence and publication gates | Delegate final authority to AI/memory |
| **Antigravity AIOS** | Execute the approved build plan, coordinate coding tasks, maintain implementation consistency and produce build artifacts | Invent product requirements or silently override frozen decisions |
| **Frontend/App Engineering** | Vercel application, UI, catalogue, dashboards, module delivery integration | Make the website the content authority |
| **Backend/Data Engineering** | Supabase schema/RLS, APIs, progress, assessment events, audit and Railway services | Create unnecessary microservices or a second system of record |
| **Content/Assessment Pipeline** | Source extraction, learning transformation, question generation/normalisation, validation and module assembly | Publish unapproved AI-generated content |
| **Game Template Engineering** | Evaluate, adapt and maintain reusable open-source game templates and Aasha adapters | Build a bespoke game for every chapter |
| **QA/Security/Accessibility** | Automated tests, runtime validation, licence/dependency review, security, accessibility and offline tests | Treat visual attractiveness as acceptance |
| **Workflow/Ops** | n8n workflows, Telegram adapter, Drive/R2 movement, scheduled processing and operational alerts | Put canonical truth into workflow tools |
| **Memo0 / AI utilities** | Retain reusable patterns and assist processing | Approve, publish or redefine canonical requirements |

The roles are organisational/technical boundaries, not necessarily separate people. One person may hold multiple roles during the pilot.
