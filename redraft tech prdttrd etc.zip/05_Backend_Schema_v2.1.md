# Backend Schema Document — Aasha
## Version 2.1 — Build Planning Schema

**Status:** Architecture planning only  
**Database creation:** Not started

## 1. Canonical data rule

Once the full-stack backend exists, PostgreSQL is the canonical application database.

For learning content:
**AIOS + HIL-approved Learning Catalogue remains the approval/build authority.**

Database records cannot bypass HIL publication rules.

## 2. Identity

### users

- id UUID primary key
- auth_user_id UUID
- role
- status
- name
- created_at
- updated_at

### participant_profiles

- id UUID
- internal_reference
- cohort_id
- grade_level
- private_display_name
- status
- created_at
- updated_at

Do not expose internal identifiers publicly.

## 3. Roles

Minimum conceptual roles:
- admin;
- foundation_staff;
- verifier;
- teacher;
- facilitator;
- parent_guardian;
- sponsor;
- volunteer;
- participant.

Role permissions must be enforced server-side.

## 4. Learning catalogue

### learning_modules

- id
- slug
- title
- subject
- grade_min
- grade_max
- curriculum_reference
- description
- status
- current_version_id
- created_at
- updated_at

### learning_module_versions

- id
- module_id
- version_label
- edition
- asset_reference
- checksum
- concept_count
- step_count
- language_support JSONB
- source_reference
- workflow_version
- validation_status
- hil_status
- approved_by
- approved_at
- published_at
- supersedes_version_id
- created_at

No fixed maximum number of modules.

## 5. Concepts

### learning_concepts

- id
- module_version_id
- concept_key
- title
- sequence
- metadata JSONB

## 6. Questions

### questions

- id
- module_version_id
- concept_id
- type
- difficulty
- prompt
- answer_schema JSONB
- explanation
- misconception_code
- source_reference
- validation_status
- version
- created_at

### question_options

- id
- question_id
- option_key
- content
- is_correct
- sequence

AI-generated questions remain non-publishable until validated/HIL-approved.

## 7. Learning sessions/events

### learning_sessions

- id
- participant_id nullable
- module_version_id
- started_at
- ended_at
- device_reference
- sync_status

### learning_events

- id
- stable_event_id
- session_id
- participant_id
- module_version_id
- concept_id
- event_type
- payload JSONB
- occurred_at
- received_at

Use stable event IDs for deduplication.

## 8. Mastery

### mastery_states

- participant_id
- concept_id
- mastery_score
- mastery_level
- source_version
- calculated_at

Mastery should be derived from deterministic rules and traceable events.

## 9. Rewards

### reward_ledger

- id
- participant_id
- source_event_id
- reward_type
- amount
- reason_code
- created_at

Balance should be derived or safely materialised from the ledger.

Never trust a client-provided “current coin balance” as authority.

## 10. Cohorts

### cohorts

- id
- stable_code
- name
- description
- start_date
- end_date
- status
- aggregate_location
- created_at

### cohort_members

- cohort_id
- participant_id
- role
- joined_at
- left_at

### cohort_sponsors

- cohort_id
- sponsor_id
- relationship_type
- allocation_reference
- created_at

## 11. Activities

### activities

- id
- cohort_id
- participant_id nullable
- activity_type
- title
- description
- planned_at
- completed_at
- status
- created_by
- created_at

Activity types include:
- ECO_SEVA;
- JAL_SEVA;
- OTHER_APPROVED.

## 12. Evidence

### evidence_events

- id
- activity_id
- submitted_by
- event_date
- media_reference
- metadata JSONB
- verification_status
- visibility_status
- created_at

### evidence_verifications

- id
- evidence_id
- verifier_id
- decision
- notes
- verified_at

Suggested state machine:

draft → submitted → under_review → verified/rejected → published

## 13. Impact

### impact_events

- id
- source_type
- source_id
- impact_type
- summary
- measurement JSONB
- evidence_id
- verification_status
- public_visibility
- created_at

Public impact views must be generated only from records that satisfy publication rules.

## 14. Contributions

### contributions

- id
- contributor_id nullable
- provider
- external_reference
- amount
- currency
- received_at
- status
- receipt_reference
- created_at

### allocations

- id
- contribution_id
- cohort_id nullable
- programme_type nullable
- amount
- allocation_status
- created_at

Provider-specific payment details must be isolated from core domain records.

## 15. Stories

### stories

- id
- slug
- title
- summary
- body
- source_reference
- consent_status
- publication_status
- created_at
- updated_at

## 16. Media

### media_objects

- id
- storage_provider
- object_key
- content_type
- checksum
- visibility
- consent_reference
- created_at

## 17. Content jobs

### content_jobs

- id
- job_type
- source_reference
- workflow_version
- status
- started_at
- completed_at
- error_summary

### content_artifacts

- id
- job_id
- artifact_type
- artifact_reference
- version
- validation_status
- hil_status
- approved_at

### agent_runs

- id
- job_id
- agent_name
- provider
- model
- model_version
- prompt_version
- input_reference
- output_reference
- status
- created_at

## 18. Audit

### audit_log

- id
- actor_id
- action
- entity_type
- entity_id
- before JSONB
- after JSONB
- timestamp
- request_reference

Do not store unnecessary child PII in audit payloads.

## 19. RLS/public visibility

Public may see:
- published learning metadata;
- published stories;
- verified public evidence;
- aggregate impact;
- approved public cohort information.

Restricted:
- individual progress;
- participant records;
- verification workflows;
- private cohort data;
- contribution allocation details.

## 20. Indexing

Plan indexes for:
- module slug;
- publication status;
- subject/grade;
- participant/cohort relationships;
- event timestamps;
- evidence status;
- impact visibility;
- audit entity lookup.

## 21. Migration rules

- migrations are version controlled;
- destructive migrations require explicit review;
- production data migrations require backup/rollback;
- seed data must be labelled demo/test;
- no demo record can appear as real impact.


## 22. Assessment Task + Game Template Registry

### assessment_tasks

- id
- task_key
- version
- module_version_id
- concept_id
- task_type
- prompt
- input_schema JSONB
- answer_schema JSONB
- validation_rule JSONB
- solution_steps JSONB
- explanation
- misconception_data JSONB
- difficulty
- source_reference
- rendering_mode
- game_template_id nullable
- validation_status
- hil_status
- created_at
- updated_at

### assessment_task_variants

- id
- assessment_task_id
- variant_key
- content JSONB
- answer JSONB
- created_at

### game_templates

- id
- template_key
- name
- version
- source_repository
- source_revision
- licence
- attribution_text
- modification_notes
- supported_task_types JSONB
- adapter_version
- offline_status
- accessibility_status
- security_status
- approval_status
- created_at
- updated_at

### game_template_versions

- id
- game_template_id
- version_label
- source_revision
- asset_reference
- checksum
- adapter_version
- validation_status
- hil_status
- approved_at
- published_at
- supersedes_version_id

### mathematical evaluation metadata

Where required, `validation_rule` may define:
- exact numeric;
- tolerance;
- fraction/decimal equivalence;
- unit validation;
- algebraic equivalence;
- ordered step validation;
- intermediate result validation.

The canonical task remains independent of its game presentation.

## 23. Storage boundaries

- Supabase/PostgreSQL → canonical application data.
- Google Drive → source, working, current learning resources, current assessment resources, archives and backup copies.
- Cloudflare R2 → application-controlled object/media storage when required.
- Game template source/artefacts → tracked with repository/revision/licence metadata.
- Memo0 → agentic memory only.
- Telegram → transient processing/transport utility only.



## FINALIZED PHASE-1 TECHNOLOGY + ROLE BASELINE

This stack is the implementation baseline for Antigravity AIOS. It is deliberately modular and cost-reversible.

| Layer / Capability | Finalized technology/resource | Role |
|---|---|---|
| Public website | **Vercel** | Production public website, catalogue presentation and public ecosystem experience |
| Web application | **Vercel** | Authenticated/authorised web app and operational interfaces |
| Canonical application database | **Supabase PostgreSQL** | System of record for application data, permissions, progress and audit data |
| Backend/API/workers | **Railway** | Backend services, workers and scheduled/background processing where genuinely required |
| DNS / edge | **Cloudflare** | DNS and edge services |
| Object/media storage | **Cloudflare R2** | Application-controlled object storage for media/evidence/assets when required; accessed through a storage abstraction |
| Source + working + backup repository | **Personal Google Drive (~5 TB)** | Current learning resources, current assessment resources, source documents, working files, archives and backup copies; NOT the application system of record |
| Workflow orchestration | **Hosted n8n** | Workflow automation/orchestration across content, operations and integrations |
| Agentic memory | **Memo0 AI** | Reusable workflow knowledge, validated patterns, transformation conventions and known failure modes; NOT canonical truth |
| Primary AI/content assistance | **Gemini 2 Pro plan** | Content transformation, reasoning assistance, OCR cleanup, assessment assistance and validation assistance where appropriate |
| OCR/document processing adapter | **Telegram Bot API** | Optional low-cost OCR/document/image processing route; adapter only, not system of record |
| Human-in-the-loop build/operations | **Antigravity AIOS + HIL** | Build orchestration, implementation execution, review gates and controlled operational workflows |
| General AI working resource | **ChatGPT Go** | Product/engineering analysis, documentation, review and assistance |
| Open-source/model cache | **Hugging Face + suitable open-source/created models** | Replaceable processing/model capability; approved assets may be cached in Google Drive |
| Existing learning runtime | **Self-contained HTML/CSS/JS learning modules** | Offline-first child learning runtime independent of cloud services |
| Reserved future AI capacity | **Claude grant** | Future/conditional capacity; Phase-1 architecture must not depend on spending it |

### Stack invariants

1. **Supabase is the canonical application system of record.**
2. **Google Drive is source/working/archive/backup infrastructure, not the live application database.**
3. **Cloudflare R2 is object storage, not the application database.**
4. **Telegram is an adapter/utility, not a child-learning runtime or permanent evidence store.**
5. **Memo0 is agentic memory, not authority.**
6. **AI providers are replaceable processing capabilities, not runtime dependencies for children.**
7. **Existing self-contained learning HTML must continue to work without Vercel, Supabase, Railway, Cloudflare, Telegram, Memo0 or an AI provider.**
8. **No second primary database is introduced merely for convenience.**
9. **Open-source game templates must be licence-compatible and must sit behind an Aasha adapter.**
10. **Every external service must have a documented fallback or migration boundary where practical.**

## FINALIZED ROLE / RESPONSIBILITY MODEL

| Role | Responsibility | Must not do |
|---|---|---|
| **Product Owner / Foundation HIL authority** | Final product decisions, content/assessment approval, safety, privacy, evidence and publication gates | Delegate final authority to AI/memory |
| **Antigravity AIOS** | Execute the approved build plan, coordinate coding tasks, maintain implementation consistency and produce build artifacts | Invent product requirements or silently override frozen decisions |
| **Frontend/App Engineering** | Vercel application, UI, catalogue, dashboards, module delivery integration | Make the website the content authority |
| **Backend/Data Engineering** | Supabase schema/RLS, APIs, progress, assessment events, audit and Railway services | Create unnecessary microservices or a second system of record |
| **Content/Assessment Pipeline** | Source extraction, learning transformation, question generation/normalisation, validation and module assembly | Publish unapproved AI-generated content |
| **Game Template Engineering** | Evaluate, adapt and maintain reusable open-source game templates and Aasha adapters | Build a bespoke game for every chapter |
| **QA/Security/Accessibility** | Automated tests, runtime validation, licence/dependency review, security, accessibility and offline tests | Treat visual attractiveness as acceptance |
| **Workflow/Ops** | n8n workflows, Telegram adapter, Drive/R2 movement, scheduled processing and operational alerts | Put canonical truth into workflow tools |
| **Memo0 / AI utilities** | Retain reusable patterns and assist processing | Approve, publish or redefine canonical requirements |

The roles are organisational/technical boundaries, not necessarily separate people. One person may hold multiple roles during the pilot.
