# Implementation Plan — Aasha Website + Web App
## Version 3.1 — AI Coding Agent Build Sequence

**Status:** Phase 0 frozen. Phase 1 architecture planning only.  
**Implementation:** Not started.

## How to use this document

Build in order.

Do not jump directly to feature coding.

Every phase has:
- objective;
- activities;
- deliverables;
- acceptance gate;
- stop conditions.

The AI coding agent must not invent missing architecture decisions.

---

# PHASE 0 — FROZEN BASELINE

## Objective

Protect all approved decisions before engineering starts.

## Confirm

- Brand Book remains brand/story reference.
- AIOS + HIL-approved Learning Catalogue is current learning/build truth.
- PRD/TRD do not impose catalogue limits.
- Website is not catalogue authority.
- AI memory is not source of truth.
- offline learning remains independently capable.
- child safety remains non-negotiable.
- human approval remains required for canonical content/public evidence.

## Deliverable

A repository containing these build documents plus the separate Brand Book/Constitution references.

## Exit gate

Product owner confirms Phase 0 remains frozen.

---

# PHASE 1 — ARCHITECTURE PLANNING ONLY

## Objective

Produce the technical decisions required before scaffolding.

## Step 1 — Repository design

Define:
- public web app;
- authenticated app;
- backend;
- learning modules;
- content pipeline;
- infrastructure;
- tests;
- documentation.

### Deliverable

Repository structure specification.

## Step 2 — Architecture decision records

Decide and document:
- frontend framework;
- backend approach;
- Supabase usage;
- Railway usage;
- storage;
- authentication;
- testing;
- CI/CD;
- observability.

### Deliverable

ADR set with rationale and alternatives.

## Step 3 — Environment model

Define:
- development;
- preview/staging;
- production;
- environment variables;
- secret ownership;
- domain strategy.

### Deliverable

Environment specification.

## Step 4 — Data ownership map

Map each entity to:
- source of truth;
- read/write owner;
- public visibility;
- HIL requirement;
- retention requirement.

### Deliverable

Data ownership matrix.

## Step 5 — API contract planning

Define endpoints, payloads, validation and permissions before implementation.

### Deliverable

API contract document/OpenAPI specification.

## Step 6 — Catalogue contract

Define the machine-readable contract for:
- module metadata;
- version;
- asset reference;
- approval;
- publication.

### Deliverable

Catalogue schema and example records.

## Phase 1 acceptance gate

No unresolved major architecture decisions.

**No production code is written in this phase.**

---

# PHASE 2 — PROJECT SETUP / SCAFFOLDING

## Objective

Create the development foundation.

## Tasks

1. Initialise repository.
2. Configure package manager.
3. Configure TypeScript if selected.
4. Configure linting/formatting.
5. Configure test framework.
6. Configure environment validation.
7. Create public/app/backend workspace boundaries.
8. Configure GitHub repository and branch protection.
9. Configure CI checks.
10. Create development README.

## Deliverables

- working local project;
- CI pipeline;
- environment template;
- lint/test commands;
- architectural folder structure.

## Acceptance

A clean checkout can install, lint, test and build without undocumented manual steps.

---

# PHASE 3 — AUTHENTICATION + AUTHORISATION

## Objective

Secure staff/platform workflows without making basic offline learning dependent on login.

## Tasks

1. Configure Supabase Auth or approved auth architecture.
2. Define staff roles.
3. Implement session handling.
4. Implement protected routes.
5. Implement role guards.
6. Define RLS policies.
7. Add logout/session-expiry handling.
8. Add audit events for privileged actions.

## Deliverables

- login/logout;
- protected dashboard shell;
- role-aware routing;
- RLS policies;
- auth tests.

## Acceptance

Unauthorised users cannot access protected records even if they manipulate frontend requests.

---

# PHASE 4 — DATABASE

## Objective

Implement the canonical application data model.

## Tasks

1. Create migration baseline.
2. Create identity/role tables.
3. Create catalogue tables.
4. Create learning progress/event tables.
5. Create cohort/activity/evidence tables.
6. Create impact tables.
7. Create contribution/allocation tables where enabled.
8. Create content-job/agent-run tables.
9. Create audit log.
10. Add constraints/indexes.
11. Add RLS.
12. Create safe demo seed data.

## Deliverables

- migration history;
- database schema;
- RLS policy suite;
- seed/test fixtures.

## Acceptance

Schema supports unlimited catalogue modules and all critical relationships without hard-coded content assumptions.

---

# PHASE 5 — CORE UI / DESIGN SYSTEM

## Objective

Build the reusable interface foundation.

## Tasks

1. Create design tokens.
2. Build global layout.
3. Build responsive header/navigation.
4. Build footer.
5. Build typography and spacing.
6. Build CTA/button system.
7. Build cards, lists and timelines.
8. Build status badges.
9. Build loading/empty/error states.
10. Add accessibility primitives.
11. Add responsive testing.

## Deliverables

- reusable component library;
- public shell;
- authenticated shell;
- accessibility baseline.

## Acceptance

All subsequent pages can be assembled from shared components rather than page-specific duplication.

---

# PHASE 6 — PUBLIC WEBSITE

## Objective

Build the public product experience using the Brand Book as narrative reference and these documents as functional requirements.

## Tasks

1. Home.
2. Vision/Mission/Roadmap.
3. Learning.
4. Ecosystem.
5. Eco Seva.
6. Jal Seva.
7. Aasha Economy.
8. Cohorts.
9. Impact.
10. Transparency.
11. Stories.
12. Support.
13. Volunteer.
14. Apply/Hiring.
15. Contact.

## Critical implementation rule

Do not hard-code catalogue content into page components.

Public content must be versioned/managed according to the approved content architecture.

## Deliverables

Complete responsive public website.

## Acceptance

Every page has a distinct purpose and does not falsely present future capabilities as live.

---

# PHASE 7 — LEARNING CATALOGUE + MODULE DELIVERY

## Objective

Connect the website to the AIOS + HIL-approved Learning Catalogue.

## Tasks

1. Implement catalogue query.
2. Implement filtering.
3. Implement module detail.
4. Implement publication-state filtering.
5. Implement module launch.
6. Implement download/offline path where supported.
7. Integrate approved existing learning modules.
8. Add module version handling.
9. Add checksum/integrity metadata where appropriate.

## Critical test

Add a new approved catalogue record.

Expected:
- it appears automatically;
- no frontend chapter array changes;
- no redesign;
- old modules remain functional.

## Deliverables

Dynamic Learning Catalogue.

## Acceptance

**Catalogue size is not constrained by frontend code.**

---

# PHASE 8 — LEARNING RUNTIME + PROGRESS INTEGRATION

## Objective

Connect self-contained learning modules without breaking their offline operation.

## Tasks

1. Define module launch contract.
2. Define local profile handling.
3. Preserve localStorage/sessionStorage behaviour.
4. Define event schema.
5. Implement optional sync queue.
6. Implement event deduplication.
7. Implement deterministic mastery calculation.
8. Implement reward ledger integration.
9. Implement sync retry.
10. Test network loss during learning.

## Deliverables

- module launch;
- local progress;
- optional sync;
- event ingestion;
- mastery integration.

## Acceptance

Turning off the network does not break the core learning session.

---

# PHASE 9 — REUSABLE GAME TEMPLATE + ASSESSMENT ENGINE

## Objective

Implement the reusable assessment/task architecture and a legally compatible library of open-source game templates. Do NOT build a bespoke game for each chapter.

## Tasks

1. Finalise the canonical assessment-task schema.
2. Implement task versioning and provenance.
3. Implement deterministic evaluation contracts.
4. Support numeric and step-by-step mathematical evaluation.
5. Define the game-template registry.
6. Define the Aasha game-adapter contract.
7. Research suitable open-source game templates.
8. Verify licence, attribution and redistribution/customisation rights.
9. Pin source revisions and record modifications.
10. Remove uncontrolled external dependencies where permitted.
11. Adapt selected templates to Aasha's UI/UX and safety rules.
12. Connect templates to generic assessment tasks.
13. Test one game template against multiple chapters/subjects.
14. Implement standard-renderer fallback if a game fails.
15. Add accessibility, mobile, offline and security tests.
16. Obtain HIL approval before production use.

## Deliverables

- generic assessment-task contract;
- deterministic evaluator interfaces;
- game-template registry;
- open-source licence/attribution records;
- Aasha game adapters;
- reusable game bundles;
- fallback renderer;
- test coverage.

## Acceptance gate

At least one reusable game template must render substantially different educational task datasets without modifying its underlying game engine.

A new chapter must NOT require a new bespoke game.

---

# PHASE 10 — MAIN PLATFORM FEATURES

## 9.1 Teacher/Facilitator

Build:
- dashboard;
- cohorts;
- learner progress;
- concept difficulty view;
- learner detail;
- intervention notes where approved.

Deliverable:
usable facilitator workflow.

## 9.2 Cohorts

Build:
- create/edit;
- members;
- milestones;
- programme links;
- aggregate progress.

Deliverable:
cohort journey view.

## 9.3 Eco Seva

Build only the approved activity model.

Deliverable:
activity submission and lifecycle.

## 9.4 Jal Seva

Build:
- activity instructions;
- bird/animal water activity;
- check/refill records;
- evidence path.

Deliverable:
Jal Seva workflow consistent with frozen definition.

## 9.5 Evidence

Build:
- draft;
- upload;
- review;
- verification;
- publication state.

Deliverable:
auditable evidence workflow.

## 9.6 Impact

Build:
- aggregate metrics;
- evidence trail;
- methodology/context;
- public/private visibility.

Deliverable:
evidence-backed impact surfaces.

---

# PHASE 11 — AASHA ECONOMY

## Objective

Implement only after the ledger/security model is stable.

## Tasks

1. Define reward event rules.
2. Implement append-oriented ledger.
3. Calculate balances.
4. Implement saving states.
5. Implement virtual choices/store.
6. Add audit trail.
7. Add anti-duplication controls.

## Deliverable

Auditable virtual economy.

## Acceptance

A client cannot arbitrarily increase its own balance.

No real-money child transaction is introduced without a separate approved phase.

---

# PHASE 12 — CONTENT / AIOS INTEGRATIONS

## Objective

Connect the approved AI-assisted content factory without making AI authoritative.

## Tasks

1. Connect source ingestion.
2. Connect OCR adapter(s).
3. Create content job records.
4. Implement specialised agent contracts.
5. Record provenance.
6. Implement automated validation.
7. Route output to HIL.
8. Publish only approved artifacts.
9. Store validated patterns in Memo0 after approval.
10. Prevent rejected output from becoming validated memory.

## Deliverable

Controlled content-production pipeline.

## Acceptance

No agent can move an unapproved learning artifact directly to production.

---

# PHASE 13 — EXTERNAL INTEGRATIONS

Implement only where actually required.

Potential integrations:
- n8n workflows;
- Google Drive source/archive;
- Telegram OCR adapter;
- AI providers;
- storage/CDN;
- contribution provider;
- email/notification service.

For every integration:
- define adapter;
- timeout;
- retry;
- error handling;
- secret management;
- fallback;
- observability.

## Deliverable

Integration adapters with documented failure behaviour.

---

# PHASE 14 — TESTING

## 13.1 Unit tests

Test:
- catalogue filtering;
- permission rules;
- mastery;
- reward calculations;
- event deduplication;
- evidence state transitions;
- economy ledger;
- validation functions.

## 13.2 Integration tests

Test:
- auth → RLS;
- catalogue → module;
- learning event → mastery;
- activity → evidence → verification → impact;
- contribution → allocation where enabled.

## 13.3 End-to-end tests

Test:
- visitor journey;
- teacher journey;
- catalogue launch;
- learning completion;
- evidence submission;
- verification;
- public impact.

## 13.4 Offline tests

Disable network and verify:
- module loads;
- learning works;
- progress saves;
- games work;
- mastery works;
- rewards work;
- sync queues safely.

## 13.5 Security tests

Verify:
- unauthorised data access blocked;
- RLS;
- XSS;
- injection;
- upload validation;
- rate limiting;
- session security;
- secrets absent from client bundle.

## 13.6 Accessibility tests

Automated + manual:
- keyboard;
- focus;
- screen reader basics;
- contrast;
- reduced motion;
- mobile touch.

## 13.7 Performance tests

Test:
- low-end Android;
- slow network;
- catalogue loading;
- public page rendering;
- module load/render;
- backend latency.

## Deliverable

Release-quality test report with pass/fail evidence.

---

# PHASE 15 — DEPLOYMENT

## Objective

Deploy safely to preview/staging, then production.

## Tasks

1. Configure Vercel.
2. Configure Supabase production.
3. Configure Railway workers/API if used.
4. Configure Cloudflare DNS.
5. Configure environment secrets.
6. Configure migrations.
7. Configure backups.
8. Configure monitoring.
9. Configure error reporting.
10. Configure CI/CD.
11. Run staging acceptance.
12. Run production smoke tests.

## Deliverables

- staging deployment;
- production deployment;
- rollback procedure;
- backup/recovery procedure;
- deployment checklist.

## Acceptance

A failed deployment can be rolled back without corrupting canonical data.

---

# PHASE 16 — FINAL POLISH

## Product

Check:
- content hierarchy;
- clarity;
- navigation;
- empty states;
- error states;
- truthful claims;
- mobile UX.

## Learning

Check:
- child comprehension;
- LLE behaviour;
- immediate feedback;
- offline operation;
- progress;
- assessment;
- mastery;
- rewards.

## Brand alignment

Check against the separate Brand Book:
- tone;
- visual story;
- imagery;
- narrative consistency;
- evidence language.

Do not rewrite the Brand Book into the product codebase.

## Engineering

Check:
- dead code;
- duplicated components;
- bundle size;
- accessibility;
- security;
- logs;
- monitoring;
- dependency versions;
- documentation.

## Deliverable

Production-readiness sign-off.

---

# PHASE 17 — POST-LAUNCH OPERATIONS

## Continuous controls

Monitor:
- uptime;
- errors;
- learning module failures;
- sync failures;
- catalogue publication;
- evidence workflow;
- security alerts;
- performance.

## Content governance

Every new module follows:

**AIOS processing → validation → HIL approval → catalogue publication → release**

## Change governance

Every major change gets:
- requirement;
- owner;
- implementation;
- tests;
- HIL/product review where applicable;
- version;
- rollback path.

---

# FINAL BUILD GATES

Before calling the platform production-ready:

### Architecture
- no unresolved critical ADRs;
- clear system ownership;
- no accidental single point of failure.

### Catalogue
- dynamic;
- unlimited in principle;
- HIL-controlled;
- no frontend hard-coded authority.

### Learning
- offline core works;
- progress is reliable;
- mastery is deterministic;
- AI is not progression authority.

### Security
- RLS verified;
- role boundaries verified;
- child data protected;
- secrets protected.

### Evidence
- verification enforced;
- public claims traceable;
- illustrative content distinguished from real evidence.

### Operations
- monitoring;
- backup;
- rollback;
- CI/CD;
- documented runbooks.

### Product
- Brand Book alignment checked;
- public story remains truthful;
- child experience remains focused on understanding.

---

# AI CODING AGENT RULE

At the beginning of every implementation task, the agent must state:

1. which phase is open;
2. which document requirements are being implemented;
3. which existing components/data are being reused;
4. what assumptions are required;
5. whether an HIL/product-owner decision is needed.

If an assumption changes product authority, child safety, data ownership, learning progression, public claims, or catalogue behaviour, **do not guess. Stop and request approval.**



## FINALIZED PHASE-1 TECHNOLOGY + ROLE BASELINE

This stack is the implementation baseline for Antigravity AIOS. It is deliberately modular and cost-reversible.

| Layer / Capability | Finalized technology/resource | Role |
|---|---|---|
| Public website | **Vercel** | Production public website, catalogue presentation and public ecosystem experience |
| Web application | **Vercel** | Authenticated/authorised web app and operational interfaces |
| Canonical application database | **Supabase PostgreSQL** | System of record for application data, permissions, progress and audit data |
| Backend/API/workers | **Railway** | Backend services, workers and scheduled/background processing where genuinely required |
| DNS / edge | **Cloudflare** | DNS and edge services |
| Object/media storage | **Cloudflare R2** | Application-controlled object storage for media/evidence/assets when required; accessed through a storage abstraction |
| Source + working + backup repository | **Personal Google Drive (~5 TB)** | Current learning resources, current assessment resources, source documents, working files, archives and backup copies; NOT the application system of record |
| Workflow orchestration | **Hosted n8n** | Workflow automation/orchestration across content, operations and integrations |
| Agentic memory | **Memo0 AI** | Reusable workflow knowledge, validated patterns, transformation conventions and known failure modes; NOT canonical truth |
| Primary AI/content assistance | **Gemini 2 Pro plan** | Content transformation, reasoning assistance, OCR cleanup, assessment assistance and validation assistance where appropriate |
| OCR/document processing adapter | **Telegram Bot API** | Optional low-cost OCR/document/image processing route; adapter only, not system of record |
| Human-in-the-loop build/operations | **Antigravity AIOS + HIL** | Build orchestration, implementation execution, review gates and controlled operational workflows |
| General AI working resource | **ChatGPT Go** | Product/engineering analysis, documentation, review and assistance |
| Open-source/model cache | **Hugging Face + suitable open-source/created models** | Replaceable processing/model capability; approved assets may be cached in Google Drive |
| Existing learning runtime | **Self-contained HTML/CSS/JS learning modules** | Offline-first child learning runtime independent of cloud services |
| Reserved future AI capacity | **Claude grant** | Future/conditional capacity; Phase-1 architecture must not depend on spending it |

### Stack invariants

1. **Supabase is the canonical application system of record.**
2. **Google Drive is source/working/archive/backup infrastructure, not the live application database.**
3. **Cloudflare R2 is object storage, not the application database.**
4. **Telegram is an adapter/utility, not a child-learning runtime or permanent evidence store.**
5. **Memo0 is agentic memory, not authority.**
6. **AI providers are replaceable processing capabilities, not runtime dependencies for children.**
7. **Existing self-contained learning HTML must continue to work without Vercel, Supabase, Railway, Cloudflare, Telegram, Memo0 or an AI provider.**
8. **No second primary database is introduced merely for convenience.**
9. **Open-source game templates must be licence-compatible and must sit behind an Aasha adapter.**
10. **Every external service must have a documented fallback or migration boundary where practical.**

## FINALIZED ROLE / RESPONSIBILITY MODEL

| Role | Responsibility | Must not do |
|---|---|---|
| **Product Owner / Foundation HIL authority** | Final product decisions, content/assessment approval, safety, privacy, evidence and publication gates | Delegate final authority to AI/memory |
| **Antigravity AIOS** | Execute the approved build plan, coordinate coding tasks, maintain implementation consistency and produce build artifacts | Invent product requirements or silently override frozen decisions |
| **Frontend/App Engineering** | Vercel application, UI, catalogue, dashboards, module delivery integration | Make the website the content authority |
| **Backend/Data Engineering** | Supabase schema/RLS, APIs, progress, assessment events, audit and Railway services | Create unnecessary microservices or a second system of record |
| **Content/Assessment Pipeline** | Source extraction, learning transformation, question generation/normalisation, validation and module assembly | Publish unapproved AI-generated content |
| **Game Template Engineering** | Evaluate, adapt and maintain reusable open-source game templates and Aasha adapters | Build a bespoke game for every chapter |
| **QA/Security/Accessibility** | Automated tests, runtime validation, licence/dependency review, security, accessibility and offline tests | Treat visual attractiveness as acceptance |
| **Workflow/Ops** | n8n workflows, Telegram adapter, Drive/R2 movement, scheduled processing and operational alerts | Put canonical truth into workflow tools |
| **Memo0 / AI utilities** | Retain reusable patterns and assist processing | Approve, publish or redefine canonical requirements |

The roles are organisational/technical boundaries, not necessarily separate people. One person may hold multiple roles during the pilot.
