# App Flow Document — Aasha Website + Web App
## Version 2.1 — Build Specification

**Status:** Phase 1 planning only

## 1. Global flow

**Public visitor**
Home → Understand → Learn/Ecosystem → Evidence → Participate

**Child**
Catalogue → Module → Learn → Explore → Practise → Assess → Mastery → Continue

**Teacher/facilitator**
Login → Cohort → Learners → Learning progress → Needs/support → Activity verification

**Programme staff**
Login → Cohorts → Activities → Evidence → Verification → Impact

**Supporter**
Understand → What is being built → Evidence → Cohort/impact context → Support

## 2. Global shell

Desktop:
- primary navigation;
- page title/context;
- content;
- footer.

Mobile:
- compact header;
- clear menu;
- one primary action;
- accessible controls.

Authenticated app:
- role-aware navigation;
- account/session state;
- breadcrumb/context where useful.

## 3. Home

Order:
1. product proposition;
2. learning entry point;
3. how learning works;
4. journey beyond learning;
5. evidence/impact;
6. participation;
7. footer.

Do not turn the first viewport into a programme catalogue.

## 4. Learning catalogue

### Entry

User selects Learn.

### Catalogue query

Frontend requests published catalogue records.

Filters are generated from available data, not hard-coded lists.

Possible filters:
- class/grade;
- subject;
- curriculum;
- status/edition where appropriate.

### Module card

Display only approved public metadata.

CTA:
- Open;
- Download/offline where supported.

### Module launch

Open independent learning runtime.

If offline:
- already downloaded/opened module continues to work.

If online:
- platform may provide metadata/sync without becoming required for core learning.

## 5. Learning runtime

### Initialisation

1. load module;
2. identify local child profile if applicable;
3. restore progress;
4. render current step.

### Interaction loop

Step → action → immediate feedback → state update → persist locally → next step.

### Assessment

Question → answer → deterministic evaluation → conceptual feedback → event/reward update → next question.

### Completion

Show:
- concepts attempted/mastered;
- progress;
- XP/reward information;
- next learning option.

Do not force a network call before completion.

## 6. Authentication

Authentication is for platform-controlled experiences, not a prerequisite for basic offline learning.

### Staff/teacher/parent

Login → session → role resolution → role-specific dashboard.

### Child

Default learning identity remains device/local-profile based unless a later approved architecture introduces optional linked identity.

## 7. Teacher/facilitator flow

Dashboard:
- assigned cohorts;
- learner progress;
- concepts requiring support;
- recent activity.

Learner detail:
- progress;
- mastery;
- assessment patterns;
- recommended human intervention.

No ranking-based public leaderboard.

## 8. Cohort flow

Create/manage cohort → add authorised participants → connect learning/activity → view milestones → inspect verified evidence → produce aggregate view.

## 9. Eco Seva flow

Activity information → participate → record activity → submit evidence if required → facilitator verification → verified timeline → aggregate impact.

## 10. Jal Seva flow

Learn why → provide/fill water for birds/animals → return/check/refill → record → verify where required → continue.

The UI must use the approved Jal Seva definition and not substitute generic water-saving content.

## 11. Evidence flow

Submit → validation → pending review → verifier decision.

Decision:
- verified;
- rejected;
- needs clarification.

Only appropriate verified evidence can become public.

## 12. Impact flow

Impact dashboard/page:
- select domain;
- see verified aggregate;
- inspect methodology/context;
- follow evidence trail;
- understand limitations.

Never show a metric merely because a database row exists.

## 13. Aasha Economy flow

Eligible activity/learning → earned virtual value → save → choose → redeem/use where enabled.

Every balance-changing operation must originate from a valid ledger event.

## 14. Support flow

Support page → capability/programme explanation → approved contribution mechanism → provider/confirmation → record where integrated.

Do not promise detailed allocation tracking unless the underlying system supports it.

## 15. Content administration flow

Source received → content job → agent processing → automated validation → HIL review → approval → catalogue publication.

Rejected:
→ feedback → revision → re-validation → HIL review.

No direct agent-to-production path.

## 16. Error states

Catalogue unavailable:
show honest service message and preserve cached public metadata where safe.

Learning backend unavailable:
continue offline.

Sync unavailable:
queue locally and retry later.

Evidence upload failed:
retain draft and allow retry.

Unverified evidence:
show “awaiting verification”, never “impact”.

## 17. Accessibility flow

Every route must support:
- keyboard navigation where applicable;
- visible focus;
- semantic headings;
- accessible form errors;
- readable labels;
- reduced motion;
- mobile touch interaction.

## 18. HIL gates

Pause for human approval before:
- learning publication;
- public evidence publication;
- impact claim publication;
- child-media publication;
- major privacy changes;
- economy rule changes.


## 19. Assessment → Game Template Flow

When an assessment task is selected:

```text
Learning concept
   ↓
Canonical assessment task
   ↓
Task validation
   ↓
Pedagogical renderer selection
   ├── Standard assessment renderer
   └── Approved reusable game template
             ↓
       Aasha game adapter
   ↓
Child interaction
   ↓
Canonical answer/result
   ↓
Deterministic assessment evaluation
   ↓
Feedback / misconception guidance
   ↓
Learning event
   ↓
Gamification event
   ↓
Progress update
```

### Important rule

The flow must never imply that every chapter gets a unique game.

A reusable game template can be selected for many chapters. A chapter can also use multiple reusable templates or no game template at all.

### Game failure fallback

If a game template cannot initialise:
- preserve the task;
- fall back to an approved standard renderer where possible;
- do not block the learning journey;
- log the technical failure;
- preserve any valid progress already recorded.



## FINALIZED PHASE-1 TECHNOLOGY + ROLE BASELINE

This stack is the implementation baseline for Antigravity AIOS. It is deliberately modular and cost-reversible.

| Layer / Capability | Finalized technology/resource | Role |
|---|---|---|
| Public website | **Vercel** | Production public website, catalogue presentation and public ecosystem experience |
| Web application | **Vercel** | Authenticated/authorised web app and operational interfaces |
| Canonical application database | **Supabase PostgreSQL** | System of record for application data, permissions, progress and audit data |
| Backend/API/workers | **Railway** | Backend services, workers and scheduled/background processing where genuinely required |
| DNS / edge | **Cloudflare** | DNS and edge services |
| Object/media storage | **Cloudflare R2** | Application-controlled object storage for media/evidence/assets when required; accessed through a storage abstraction |
| Source + working + backup repository | **Personal Google Drive (~5 TB)** | Current learning resources, current assessment resources, source documents, working files, archives and backup copies; NOT the application system of record |
| Workflow orchestration | **Hosted n8n** | Workflow automation/orchestration across content, operations and integrations |
| Agentic memory | **Memo0 AI** | Reusable workflow knowledge, validated patterns, transformation conventions and known failure modes; NOT canonical truth |
| Primary AI/content assistance | **Gemini 2 Pro plan** | Content transformation, reasoning assistance, OCR cleanup, assessment assistance and validation assistance where appropriate |
| OCR/document processing adapter | **Telegram Bot API** | Optional low-cost OCR/document/image processing route; adapter only, not system of record |
| Human-in-the-loop build/operations | **Antigravity AIOS + HIL** | Build orchestration, implementation execution, review gates and controlled operational workflows |
| General AI working resource | **ChatGPT Go** | Product/engineering analysis, documentation, review and assistance |
| Open-source/model cache | **Hugging Face + suitable open-source/created models** | Replaceable processing/model capability; approved assets may be cached in Google Drive |
| Existing learning runtime | **Self-contained HTML/CSS/JS learning modules** | Offline-first child learning runtime independent of cloud services |
| Reserved future AI capacity | **Claude grant** | Future/conditional capacity; Phase-1 architecture must not depend on spending it |

### Stack invariants

1. **Supabase is the canonical application system of record.**
2. **Google Drive is source/working/archive/backup infrastructure, not the live application database.**
3. **Cloudflare R2 is object storage, not the application database.**
4. **Telegram is an adapter/utility, not a child-learning runtime or permanent evidence store.**
5. **Memo0 is agentic memory, not authority.**
6. **AI providers are replaceable processing capabilities, not runtime dependencies for children.**
7. **Existing self-contained learning HTML must continue to work without Vercel, Supabase, Railway, Cloudflare, Telegram, Memo0 or an AI provider.**
8. **No second primary database is introduced merely for convenience.**
9. **Open-source game templates must be licence-compatible and must sit behind an Aasha adapter.**
10. **Every external service must have a documented fallback or migration boundary where practical.**

## FINALIZED ROLE / RESPONSIBILITY MODEL

| Role | Responsibility | Must not do |
|---|---|---|
| **Product Owner / Foundation HIL authority** | Final product decisions, content/assessment approval, safety, privacy, evidence and publication gates | Delegate final authority to AI/memory |
| **Antigravity AIOS** | Execute the approved build plan, coordinate coding tasks, maintain implementation consistency and produce build artifacts | Invent product requirements or silently override frozen decisions |
| **Frontend/App Engineering** | Vercel application, UI, catalogue, dashboards, module delivery integration | Make the website the content authority |
| **Backend/Data Engineering** | Supabase schema/RLS, APIs, progress, assessment events, audit and Railway services | Create unnecessary microservices or a second system of record |
| **Content/Assessment Pipeline** | Source extraction, learning transformation, question generation/normalisation, validation and module assembly | Publish unapproved AI-generated content |
| **Game Template Engineering** | Evaluate, adapt and maintain reusable open-source game templates and Aasha adapters | Build a bespoke game for every chapter |
| **QA/Security/Accessibility** | Automated tests, runtime validation, licence/dependency review, security, accessibility and offline tests | Treat visual attractiveness as acceptance |
| **Workflow/Ops** | n8n workflows, Telegram adapter, Drive/R2 movement, scheduled processing and operational alerts | Put canonical truth into workflow tools |
| **Memo0 / AI utilities** | Retain reusable patterns and assist processing | Approve, publish or redefine canonical requirements |

The roles are organisational/technical boundaries, not necessarily separate people. One person may hold multiple roles during the pilot.
