# Technical Requirements Document — Aasha
## Version 3.1 — Full-Stack Architecture Planning Baseline

**Status:** Phase 1 architecture planning only  
**Implementation:** Not started

## 1. Architecture goal

Build a maintainable full-stack platform around an independently capable offline learning runtime.

The architecture must separate:

1. public website;
2. authenticated web application;
3. learning-module runtime;
4. canonical application data;
5. content/AI pipeline;
6. media/evidence storage;
7. workflow orchestration.

## 2. Proposed stack

| Area | Preferred component | Responsibility |
|---|---|---|
| Public web | Vercel | Public experience and catalogue |
| Web app | Vercel | Authenticated dashboards/workflows |
| Canonical DB | Supabase PostgreSQL | Application system of record |
| Backend/worker | Railway | API/worker processing where needed |
| DNS/edge | Cloudflare | DNS and justified edge services |
| Object/media storage | Cloudflare R2 | Application-controlled media/evidence/assets behind storage abstraction |
| Source/working/archive/backup | Personal Google Drive (~5 TB) | Current learning + assessment resources, source files, archives and backups; not system of record |
| Workflow | hosted n8n | Orchestration |
| Agent memory | Memo0 | Agentic memory, not truth |
| OCR adapter | Telegram Bot API where useful | Optional ingestion route |
| AI | replaceable approved providers/models | Processing assistance |
| Learning runtime | self-contained HTML + vanilla JS | Offline learning |

## 3. Important correction to legacy architecture

The old prototype architecture is not the final web-platform architecture.

Existing chapter HTML remains an independent offline runtime.

The new public website/web app should not be forced into the chapter's vanilla-JS/no-backend architecture.

Conversely, the chapter runtime must not be forced to depend on the web app or cloud services.

## 4. Frontend architecture

### Public website

Use a component-based web application architecture suitable for:
- reusable layouts;
- dynamic catalogue;
- accessibility;
- SEO;
- responsive pages;
- content-driven rendering.

### Authenticated app

Use a maintainable component/state/form architecture.

The implementation technology may be selected during Phase 1, but the agent must record the decision and rationale before scaffolding.

### Learning runtime

Preserve:
- self-contained HTML;
- embedded JS/CSS;
- offline capability;
- local state;
- no mandatory network request;
- small footprint;
- deterministic rendering.

## 5. Backend architecture

Do not create unnecessary microservices.

Use a modular backend boundary:

- authentication/authorisation;
- catalogue/content;
- learning sync;
- progress/assessment;
- cohorts;
- activities;
- evidence;
- impact;
- contributions;
- audit;
- background jobs.

A single backend can initially expose these as modules.

## 6. Canonical data authority

Supabase/PostgreSQL is the application system of record once the platform backend is implemented.

However, **learning content approval authority remains the AIOS + HIL-approved Learning Catalogue workflow**.

The database stores approved catalogue metadata/state; it does not give AI permission to invent or approve content.

## 7. Content publication pipeline

Required conceptual flow:

**Source → extraction/OCR → normalisation → learning transformation → assessment → LLE → assembly → automated validation → HIL review → approved version → catalogue publication → module distribution**

Each stage must be versioned where practical.

## 8. Agent architecture

Specialised agents may include:
- Source/Extraction Agent;
- Curriculum Analysis Agent;
- Learning Design Agent;
- Assessment Agent;
- LLE Agent;
- Assembly Agent;
- QA/Validation Agent.

Each agent needs:
- input contract;
- output contract;
- validation;
- error handling;
- provenance;
- workflow version.

AI must never self-approve or self-publish.

## 9. Reusable Assessment + Game Template Architecture

### 9.1 Generic assessment task

The backend/content model must represent educational tasks independently from their visual renderer.

A task can contain:
- task_id;
- version;
- chapter/module;
- concept;
- source reference;
- task type;
- prompt;
- input schema;
- answer schema;
- validation rule;
- solution steps;
- explanation;
- misconception/correction data;
- difficulty;
- rendering mode;
- optional game_template_id.

`game_template_id` is nullable because a standard renderer may be preferable.

### 9.2 Game template registry

Each reusable game template must record:
- template_id;
- name;
- version;
- source repository;
- source revision/commit;
- licence;
- attribution;
- modification record;
- supported task types;
- adapter version;
- dependency status;
- offline status;
- accessibility status;
- security review status;
- HIL approval status.

### 9.3 Aasha game adapter

```text
Canonical Assessment Task
        ↓
Aasha Game Adapter
        ↓
Reusable Open-Source Game Template
        ↓
Child Interaction
        ↓
Adapter-normalised Result
        ↓
Assessment Evaluator
        ↓
Learning Event
        ↓
Gamification Event
```

The game template is never the canonical source of educational truth.

### 9.4 Reuse rule

**One reusable game shell × many chapter datasets** is preferred over **one bespoke game × one chapter**.

A game may be reused across:
- different chapters;
- different subjects;
- different question families;
- different age/stage presentations,

provided the interaction remains pedagogically appropriate.

### 9.5 Open-source compliance gate

Before production use:
1. identify repository;
2. pin source revision;
3. verify licence;
4. verify redistribution/customisation compatibility;
5. record attribution requirements;
6. audit dependencies;
7. remove/replace uncontrolled external runtime dependencies where permitted;
8. document modifications;
9. pass security/accessibility/offline tests;
10. obtain HIL approval.

### 9.6 Mathematical evaluation

Do not rely on naive string equality for mathematical answers where deterministic equivalence can be evaluated.

Support, as required by a task:
- exact numeric equality;
- tolerance;
- equivalent fractions/decimals;
- unit-aware answers;
- algebraic equivalence where implemented;
- ordered multi-step solutions;
- partial-step feedback.

### 9.7 Runtime independence

The child learning runtime must remain functional if:
- AI is unavailable;
- Memo0 is unavailable;
- Telegram is unavailable;
- n8n is unavailable;
- Google Drive is unavailable;
- Supabase is unavailable for a period;
- Railway is unavailable;
- Cloudflare services are unavailable.

Cloud services may support catalogue delivery/sync, but must not become hidden dependencies of an already-downloaded learning module.

## 10. API principles

If backend APIs are introduced:
- version APIs;
- validate input/output;
- enforce authorisation server-side;
- rate-limit sensitive endpoints;
- use idempotency for sync/job endpoints;
- paginate collections;
- return stable error structures;
- avoid exposing internal IDs unnecessarily.

Suggested namespace:
`/api/v1/...`

## 10. Offline sync

Offline learning is authoritative for the local learning session.

Sync, when enabled, should:
1. queue local events/state;
2. authenticate only where required;
3. upload safely;
4. deduplicate using stable event IDs;
5. resolve conflicts deterministically;
6. never overwrite canonical reward ledger through a blind client balance;
7. allow learning to continue if sync fails.

## 11. Security

Mandatory:
- HTTPS;
- secure secrets;
- server-side authorisation;
- RLS for Supabase data;
- input validation;
- output encoding/sanitisation;
- upload type/size validation;
- audit logging for privileged actions;
- minimal PII;
- no sensitive data in logs;
- secure session handling.

## 12. Child safety

No child-facing:
- open social network;
- chat;
- public profiles;
- uncontrolled external browsing;
- advertisements;
- tracking pixels.

Any future child-data collection requires an explicit privacy/HIL review and appropriate consent/legal basis.

## 13. Performance

Targets to establish during architecture testing:
- fast first render on ordinary Indian mobile networks;
- responsive interaction;
- catalogue pages usable on low-end devices;
- learning module retains offline performance;
- no unnecessary JavaScript shipped to the child learning runtime.

Existing prototype targets such as sub-500 KB chapter files remain engineering goals for chapter assets where feasible, but content quality must not be damaged solely to hit an arbitrary number.

## 14. Reliability

Every external dependency needs:
- timeout;
- retry strategy where safe;
- failure state;
- monitoring;
- fallback.

Core learning cannot depend on:
- AI provider;
- n8n;
- Memo0;
- Telegram;
- Google Drive;
- backend availability.

## 15. Deployment architecture

Preferred baseline:

**Cloudflare DNS → Vercel public/app → Supabase DB/Auth/Storage where appropriate**

**Railway → workers/API processing where required**

Use Cloudflare object storage only where it provides a clear benefit.

Do not introduce a reverse proxy in front of Vercel merely because an older architecture diagram contains one.

## 16. CI/CD

Required pipeline concept:
- lint;
- type/check;
- unit tests;
- integration tests;
- build;
- accessibility checks;
- security checks;
- learning-module validation;
- deployment preview;
- production approval.

## 17. Technical decision records

Before implementation, the project should record:
- frontend framework choice;
- API strategy;
- ORM/query strategy;
- authentication approach;
- storage choice;
- test stack;
- deployment boundaries;
- observability;
- backup/recovery.

The coding agent must not silently choose a major architecture decision.



## FINALIZED PHASE-1 TECHNOLOGY + ROLE BASELINE

This stack is the implementation baseline for Antigravity AIOS. It is deliberately modular and cost-reversible.

| Layer / Capability | Finalized technology/resource | Role |
|---|---|---|
| Public website | **Vercel** | Production public website, catalogue presentation and public ecosystem experience |
| Web application | **Vercel** | Authenticated/authorised web app and operational interfaces |
| Canonical application database | **Supabase PostgreSQL** | System of record for application data, permissions, progress and audit data |
| Backend/API/workers | **Railway** | Backend services, workers and scheduled/background processing where genuinely required |
| DNS / edge | **Cloudflare** | DNS and edge services |
| Object/media storage | **Cloudflare R2** | Application-controlled object storage for media/evidence/assets when required; accessed through a storage abstraction |
| Source + working + backup repository | **Personal Google Drive (~5 TB)** | Current learning resources, current assessment resources, source documents, working files, archives and backup copies; NOT the application system of record |
| Workflow orchestration | **Hosted n8n** | Workflow automation/orchestration across content, operations and integrations |
| Agentic memory | **Memo0 AI** | Reusable workflow knowledge, validated patterns, transformation conventions and known failure modes; NOT canonical truth |
| Primary AI/content assistance | **Gemini 2 Pro plan** | Content transformation, reasoning assistance, OCR cleanup, assessment assistance and validation assistance where appropriate |
| OCR/document processing adapter | **Telegram Bot API** | Optional low-cost OCR/document/image processing route; adapter only, not system of record |
| Human-in-the-loop build/operations | **Antigravity AIOS + HIL** | Build orchestration, implementation execution, review gates and controlled operational workflows |
| General AI working resource | **ChatGPT Go** | Product/engineering analysis, documentation, review and assistance |
| Open-source/model cache | **Hugging Face + suitable open-source/created models** | Replaceable processing/model capability; approved assets may be cached in Google Drive |
| Existing learning runtime | **Self-contained HTML/CSS/JS learning modules** | Offline-first child learning runtime independent of cloud services |
| Reserved future AI capacity | **Claude grant** | Future/conditional capacity; Phase-1 architecture must not depend on spending it |

### Stack invariants

1. **Supabase is the canonical application system of record.**
2. **Google Drive is source/working/archive/backup infrastructure, not the live application database.**
3. **Cloudflare R2 is object storage, not the application database.**
4. **Telegram is an adapter/utility, not a child-learning runtime or permanent evidence store.**
5. **Memo0 is agentic memory, not authority.**
6. **AI providers are replaceable processing capabilities, not runtime dependencies for children.**
7. **Existing self-contained learning HTML must continue to work without Vercel, Supabase, Railway, Cloudflare, Telegram, Memo0 or an AI provider.**
8. **No second primary database is introduced merely for convenience.**
9. **Open-source game templates must be licence-compatible and must sit behind an Aasha adapter.**
10. **Every external service must have a documented fallback or migration boundary where practical.**

## FINALIZED ROLE / RESPONSIBILITY MODEL

| Role | Responsibility | Must not do |
|---|---|---|
| **Product Owner / Foundation HIL authority** | Final product decisions, content/assessment approval, safety, privacy, evidence and publication gates | Delegate final authority to AI/memory |
| **Antigravity AIOS** | Execute the approved build plan, coordinate coding tasks, maintain implementation consistency and produce build artifacts | Invent product requirements or silently override frozen decisions |
| **Frontend/App Engineering** | Vercel application, UI, catalogue, dashboards, module delivery integration | Make the website the content authority |
| **Backend/Data Engineering** | Supabase schema/RLS, APIs, progress, assessment events, audit and Railway services | Create unnecessary microservices or a second system of record |
| **Content/Assessment Pipeline** | Source extraction, learning transformation, question generation/normalisation, validation and module assembly | Publish unapproved AI-generated content |
| **Game Template Engineering** | Evaluate, adapt and maintain reusable open-source game templates and Aasha adapters | Build a bespoke game for every chapter |
| **QA/Security/Accessibility** | Automated tests, runtime validation, licence/dependency review, security, accessibility and offline tests | Treat visual attractiveness as acceptance |
| **Workflow/Ops** | n8n workflows, Telegram adapter, Drive/R2 movement, scheduled processing and operational alerts | Put canonical truth into workflow tools |
| **Memo0 / AI utilities** | Retain reusable patterns and assist processing | Approve, publish or redefine canonical requirements |

The roles are organisational/technical boundaries, not necessarily separate people. One person may hold multiple roles during the pilot.
